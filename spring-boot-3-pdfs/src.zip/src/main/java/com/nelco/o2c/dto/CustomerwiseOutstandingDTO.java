package com.nelco.o2c.dto;

import java.math.BigDecimal;

public class CustomerwiseOutstandingDTO {
private String m_strCustomerCode="";
private String m_strCustomerName="";
private BigDecimal m_strOutstandingAmt;

public String getM_strCustomerCode() {
	return m_strCustomerCode;
}
public void setM_strCustomerCode(String m_strCustomerCode) {
	this.m_strCustomerCode = m_strCustomerCode;
}
public String getM_strCustomerName() {
	return m_strCustomerName;
}
public void setM_strCustomerName(String m_strCustomerName) {
	this.m_strCustomerName = m_strCustomerName;
}
public BigDecimal getM_strOutstandingAmt() {
	return m_strOutstandingAmt;
}
public void setM_strOutstandingAmt(BigDecimal m_strOutstandingAmt) {
	this.m_strOutstandingAmt = m_strOutstandingAmt;
}



}
