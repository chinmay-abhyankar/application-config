/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

/**
 * @author Amol.l
 *
 */
public class OppDetailsDTO  implements Serializable {

	private static final long serialVersionUID = 2L;
	private Integer oppDetailsId;
	private String zohoId;
	private Integer opportunityId;
	private String val;
	private String content;

	
	public OppDetailsDTO(Integer oppDetailsId, String zohoId, Integer opportunityId, String val, String content) {
		super();
		this.oppDetailsId = oppDetailsId;
		this.zohoId = zohoId;
		this.opportunityId = opportunityId;
		this.val = val;
		this.content = content;
	}
	public OppDetailsDTO() {
		// TODO Auto-generated constructor stub
	}
	public Integer getOppDetailsId() {
		return oppDetailsId;
	}
	public void setOppDetailsId(Integer oppDetailsId) {
		this.oppDetailsId = oppDetailsId;
	}
	public String getZohoId() {
		return zohoId;
	}
	public void setZohoId(String zohoId) {
		this.zohoId = zohoId;
	}
	public Integer getOpportunityId() {
		return opportunityId;
	}
	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}
	public String getVal() {
		return val;
	}
	public void setVal(String val) {
		this.val = val;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
}
