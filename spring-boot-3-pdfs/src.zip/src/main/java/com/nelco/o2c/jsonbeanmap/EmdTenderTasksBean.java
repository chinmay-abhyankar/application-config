/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

/**
 * @author Jayashankar.r
 *
 */
public class EmdTenderTasksBean {
	private Integer opportunityId;
	private String zohoID;
	private String potentialName;
	private String businessLine;
	private String potentialOwner;
	private String ceoStatus;
	private Integer emdRequestDetailsId;
	private String requestStatus;
	private Integer tenderFeeRequestDetailsId;
	
	public Integer getTenderFeeRequestDetailsId() {
		return tenderFeeRequestDetailsId;
	}
	public void setTenderFeeRequestDetailsId(Integer tenderFeeRequestDetailsId) {
		this.tenderFeeRequestDetailsId = tenderFeeRequestDetailsId;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public Integer getEmdRequestDetailsId() {
		return emdRequestDetailsId;
	}
	public void setEmdRequestDetailsId(Integer emdRequestDetailsId) {
		this.emdRequestDetailsId = emdRequestDetailsId;
	}
	public Integer getOpportunityId() {
		return opportunityId;
	}
	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}
	public String getZohoID() {
		return zohoID;
	}
	public void setZohoID(String zohoID) {
		this.zohoID = zohoID;
	}
	public String getPotentialName() {
		return potentialName;
	}
	public void setPotentialName(String potentialName) {
		this.potentialName = potentialName;
	}
	public String getBusinessLine() {
		return businessLine;
	}
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}
	public String getPotentialOwner() {
		return potentialOwner;
	}
	public void setPotentialOwner(String potentialOwner) {
		this.potentialOwner = potentialOwner;
	}
	public String getCeoStatus() {
		return ceoStatus;
	}
	public void setCeoStatus(String ceoStatus) {
		this.ceoStatus = ceoStatus;
	}
	
	
}
