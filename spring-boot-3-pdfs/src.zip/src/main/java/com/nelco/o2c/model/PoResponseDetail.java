package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the po_response_details database table.
 * 
 */
@Entity
@Table(name = "po_response_details")
@NamedQuery(name = "PoResponseDetail.findAll", query = "SELECT p FROM PoResponseDetail p")
public class PoResponseDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "po_response_details_id")
	private Integer poResponseDetailsId;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "po_query_details_id")
	private Integer poQueryDetailsId;

	@Column(name = "response_str")
	private String responseStr;

	@Column(name = "user_mst_id")
	private Integer userMstId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_mst_id", referencedColumnName = "user_mst_id", insertable = false, updatable = false)
	private UserMst userMst;

	public UserMst getUserMst() {
		return userMst;
	}

	public void setUserMst(UserMst userMst) {
		this.userMst = userMst;
	}

	public Integer getPoResponseDetailsId() {
		return poResponseDetailsId;
	}

	public void setPoResponseDetailsId(Integer poResponseDetailsId) {
		this.poResponseDetailsId = poResponseDetailsId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getPoQueryDetailsId() {
		return poQueryDetailsId;
	}

	public void setPoQueryDetailsId(Integer poQueryDetailsId) {
		this.poQueryDetailsId = poQueryDetailsId;
	}

	public String getResponseStr() {
		return responseStr;
	}

	public void setResponseStr(String responseStr) {
		this.responseStr = responseStr;
	}

	public Integer getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

}