/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.ChildContractDropDownDTO;
import com.nelco.o2c.dto.ContractDropDownDTO;
import com.nelco.o2c.dto.HubMstDTO;
import com.nelco.o2c.model.ConditionTypeMst;
import com.nelco.o2c.model.ContractDocTypeSapmst;
import com.nelco.o2c.model.DeliveryStatusMst;
import com.nelco.o2c.model.DistChannelMst;
import com.nelco.o2c.model.DivisionMst;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.InstallationTypeMst;
import com.nelco.o2c.model.PayTermsMst;
import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.PodStatusMst;
import com.nelco.o2c.model.PricingGroupMst;
import com.nelco.o2c.model.QuarterMst;
import com.nelco.o2c.model.SalesOfficeMst;
import com.nelco.o2c.model.SalesOrgMst;
import com.nelco.o2c.model.SegmentMst;
import com.nelco.o2c.model.TechnologyMaster;

/**
 * @author Amol.l
 *
 */
@Repository
public class CommonMasterDaoImpl implements CommonMasterDao {

	@PersistenceContext
	private EntityManager em;

	Query query;

	@Override
	public List<ContractDocTypeSapmst> getContractDocTypeList(ContractDropDownDTO contractDropDownDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("ContractDocTypeSapmst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<ContractDocTypeSapmst> contractDocTypeList = (List<ContractDocTypeSapmst>) query.getResultList();
			return contractDocTypeList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<ContractDocTypeSapmst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<DivisionMst> getDivisionList(ContractDropDownDTO contractDropDownDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("DivisionMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<DivisionMst> divisionList = (List<DivisionMst>) query.getResultList();
			return divisionList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<DivisionMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<DistChannelMst> getDistChannelList(ContractDropDownDTO contractDropDownDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("DistChannelMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<DistChannelMst> distChannelList = (List<DistChannelMst>) query.getResultList();
			return distChannelList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<DistChannelMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<SalesOfficeMst> getSalesOfficeList(ContractDropDownDTO contractDropDownDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("SalesOfficeMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<SalesOfficeMst> salesOfficeList = (List<SalesOfficeMst>) query.getResultList();
			return salesOfficeList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<SalesOfficeMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<SalesOrgMst> getSalesOrgList(ContractDropDownDTO contractDropDownDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("SalesOrgMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<SalesOrgMst> salesOrgList = (List<SalesOrgMst>) query.getResultList();
			return salesOrgList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<SalesOrgMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<SegmentMst> getSegmentList(ChildContractDropDownDTO childContractDropDownDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("SegmentMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<SegmentMst> SegmentList = (List<SegmentMst>) query.getResultList();
			return SegmentList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<SegmentMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<QuarterMst> getQuarterList(ChildContractDropDownDTO childContractDropDownDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("QuarterMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<QuarterMst> quarterMstList = (List<QuarterMst>) query.getResultList();
			return quarterMstList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<QuarterMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<DeliveryStatusMst> getDeliveryStatusMstList() {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("DeliveryStatusMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<DeliveryStatusMst> deliveryStatusMstList = (List<DeliveryStatusMst>) query.getResultList();
			return deliveryStatusMstList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<DeliveryStatusMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<PodStatusMst> getPodStatusMstList() {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("PodStatusMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<PodStatusMst> podStatusMstList = (List<PodStatusMst>) query.getResultList();
			return podStatusMstList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<PodStatusMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<HubMst> getHubList(HubMstDTO hubMstDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("HubMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<HubMst> hubMstList = (List<HubMst>) query.getResultList();
			return hubMstList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<HubMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<ConditionTypeMst> getConditionTypeList(ChildContractDropDownDTO childContractDropDownDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("ConditionTypeMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<ConditionTypeMst> conditionTypeList = (List<ConditionTypeMst>) query.getResultList();
			return conditionTypeList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<ConditionTypeMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<PricingGroupMst> getPricingGroupList(ChildContractDropDownDTO childContractDropDownDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("PricingGroupMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<PricingGroupMst> pricingGroupList = (List<PricingGroupMst>) query.getResultList();
			return pricingGroupList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<PricingGroupMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<PayTermsMst> getPayTermsList(ChildContractDropDownDTO childContractDropDownDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("PayTermsMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<PayTermsMst> payTermsList = (List<PayTermsMst>) query.getResultList();
			return payTermsList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<PayTermsMst>();
		} finally {
			em.close();
		}
	}
	
	@Override
	public int getCount(String table, String column, String value) {
		String lQuery = "select count(*) from " + table + " where " + column + "=?1 ";
		query = em.createNativeQuery(lQuery);
		query.setParameter(1, value.trim());
		int num = (int) query.getSingleResult();
		return num;
	}
	
	@Override
	public int getCount(String table, String column1, String value1,String column2, String value2) {
		String lQuery = "select count(*) from " + table + " where " + column1 + "=?1 and " +column2 + " =?2 ";
		query = em.createNativeQuery(lQuery);
		query.setParameter(1, value1.trim());
		query.setParameter(2, value2.trim());
		int num = (int) query.getSingleResult();
		return num;
	}
	
	@Override
	public int getIncMaterialCount(String table, String column1, String value1,String column2, String value2) {
		String lQuery = "select count(*) from " + table + " where " + column1 + "=?1 and " +column2 + " =?2 " +" and item_category = 'TADV' and material_num in ('120100004','120100463') ";
		query = em.createNativeQuery(lQuery);
		query.setParameter(1, value1.trim());
		query.setParameter(2, value2.trim());
		int num = (int) query.getSingleResult();
		return num;
	}
	
	@Override
	public TechnologyMaster getTechnologyByDesc(String value) {
		try {

			query = em.createNamedQuery("TechnologyMaster.findByName");
			query.setParameter(1, value);
			TechnologyMaster technologyMaster = (TechnologyMaster) query.getSingleResult();
			return technologyMaster != null ? technologyMaster : new TechnologyMaster();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new TechnologyMaster();
		} finally {
			em.close();
		}
	}
	
	@Override
	public HubMst getHubByDesc(String hubDesc) {
		try {
			query = em.createNamedQuery("HubMst.hubByDesc");
			query.setParameter(1, hubDesc);
			HubMst hubMst = (HubMst) query.getSingleResult();
			return hubMst != null ? hubMst : new HubMst();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HubMst();
		} finally {
			em.close();
		}
	}
	
	@Override
	public InstallationTypeMst getInstallTypeMstByDesc(String installationTypeVal) {
		try {
			query = em.createNamedQuery("InstallationTypeMst.InstallTypeMstByDesc");
			query.setParameter(1, installationTypeVal);
			InstallationTypeMst installTypeMst = (InstallationTypeMst) query.getSingleResult();
			return installTypeMst != null ? installTypeMst : new InstallationTypeMst();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new InstallationTypeMst();
		} finally {
			em.close();
		}
	}
	
	@Override
	public PlantSapmst getPlantByPlantCode(String plantCode) {
		try {
			query = em.createNamedQuery("PlantSapmst.plantByPlantCode");
			query.setParameter(1, plantCode);
			PlantSapmst plantSapmst = (PlantSapmst) query.getSingleResult();
			return plantSapmst != null ? plantSapmst : new PlantSapmst();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new PlantSapmst();
		} finally {
			em.close();
		}
	}
}
