/**
 * 
 */
package com.nelco.o2c.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nelco.o2c.dto.SparesSoDeliveryDTO;
import com.nelco.o2c.dto.SparesSoDeliveryMasterDTO;
import com.nelco.o2c.dto.SparesSoPodUploadDTO;
import com.nelco.o2c.service.SparesSoDeliveryService;

/**
 * @author Jayshankar.r
 *
 */
@RestController
public class SparesSoDeliveryController {

	@Autowired
	SparesSoDeliveryService sparesSoDeliveryService;
	
	@RequestMapping(value = "/getSparesSoDeliveryList.do",method = RequestMethod.POST)
	public SparesSoDeliveryDTO getSparesSoDeliveryList(@RequestBody SparesSoDeliveryDTO sparesSoDeliveryInputDTO) {
		return sparesSoDeliveryService.getSparesSoDeliveryList(sparesSoDeliveryInputDTO);
	}
	
	@RequestMapping(value = "/getSparesSoDeliveryDropDowns.do",method = RequestMethod.POST)
	public SparesSoDeliveryMasterDTO getSparesSoDeliveryDropDowns() {
		return sparesSoDeliveryService.getSparesSoDeliveryDropDowns();
	}
	
	@RequestMapping(value = "/saveSparesSoDeliveryDetails.do", method = RequestMethod.POST)
	public SparesSoDeliveryDTO saveSparesSoDeliveryDetails(@RequestBody SparesSoDeliveryDTO sparesSoDeliveryInputDTO) {
		return sparesSoDeliveryService.saveSparesSoDeliveryDetails(sparesSoDeliveryInputDTO);
	}
	
	@RequestMapping(value = "/uploadPodSparesSo.do", method = RequestMethod.POST)
	public SparesSoPodUploadDTO uploadPodSparesSo(@RequestBody SparesSoPodUploadDTO sparesSoPodUploadInputDTO) {
		return sparesSoDeliveryService.uploadPodSparesSo(sparesSoPodUploadInputDTO);

	}
	
	@RequestMapping(value = "/getPodUploadListSparesSo.do", method = RequestMethod.POST)
	public SparesSoPodUploadDTO getPodUploadListSparesSo(@RequestBody SparesSoPodUploadDTO sparesSoPodUploadInputDTO) {
		return sparesSoDeliveryService.getPodUploadListSparesSo(sparesSoPodUploadInputDTO);

	}
	
	@RequestMapping(value = "/getSparesSoDeliveryListDownload.do",method = {
			RequestMethod.GET,RequestMethod.POST
	})
	@CrossOrigin
	public void getSparesSoDeliveryUpdate(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestParam("inputJson") String ipJson) throws JsonParseException, JsonMappingException, SQLException, IOException {
		SparesSoDeliveryDTO  sparesSoDeliveryDTO = utility(ipJson);
		sparesSoDeliveryService.spareSoDeliveryUpdate(httpServletRequest,httpServletResponse,sparesSoDeliveryDTO);
	}
	
	public SparesSoDeliveryDTO utility(@RequestParam("inputJson") String ipJson) throws SQLException, JsonParseException, JsonMappingException, IOException {
		
		 ObjectMapper mapper = new ObjectMapper();
		 SparesSoDeliveryDTO sparesSoDeliveryDTO = mapper.readValue(ipJson, SparesSoDeliveryDTO.class);
	     return sparesSoDeliveryDTO;
	}
	
	
}
