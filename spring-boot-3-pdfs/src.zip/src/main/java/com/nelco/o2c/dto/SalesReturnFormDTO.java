package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.nelco.o2c.model.OppUploadDetail;

public class SalesReturnFormDTO {
	
	private List<OppUploadDetail> oppUploadDetails = new ArrayList<OppUploadDetail>();
	private SalesDTO salesDTO = new SalesDTO();
	
	public SalesDTO getSalesDTO() {
		return salesDTO;
	}

	public void setSalesDTO(SalesDTO salesDTO) {
		this.salesDTO = salesDTO;
	}

	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}

	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}

	
	
	
}
