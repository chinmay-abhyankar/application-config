/**
 * 
 */
package com.nelco.o2c.dao;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.BrfDetailsDTO;
import com.nelco.o2c.dto.BrfDetailsListDTO;
import com.nelco.o2c.dto.CustomerMstDTO;
import com.nelco.o2c.model.Brf;
import com.nelco.o2c.model.BrfSoDetails;
import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.model.DrfDemoDate;
import com.nelco.o2c.model.DrfDetails;
import com.nelco.o2c.model.MaterialChildContract;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Amol.l
 *
 */
@Repository
public class DrfBrfDaoImpl implements DrfBrfDao {
	
	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	CustomerMstDao customerMstDao;

	Query query;

	@Override
	public List<BrfDetailsDTO> getDrfBrfListByDate(BrfDetailsListDTO brfDetailsListDTO) {
		// TODO Auto-generated method stub
		try {
			String queryString = "";
			String fromDate = DateUtil.convertDateToSqlDate(brfDetailsListDTO.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(brfDetailsListDTO.getToDate());
//		    queryString = "SELECT c from ChildContract c inner join c.contract con inner join con.proposal p inner join p.serviceOrderMst som left join c.brf b left join b.statusMst sm where som.serviceOrderDetId in (3,4) and c.createdDate between ?1 and ?2 and c.sapContractNum is not null";				
			
			if (brfDetailsListDTO.getRoleCode().equals(Constants.FINANCEROLECODE) || brfDetailsListDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE) || brfDetailsListDTO.getRoleCode().equals(Constants.REGULATORYHEAD)) {
			queryString = "select distinct so.so_number,dd.drf_details_id,dd.demo_start,dd.demo_end,dd.market_segment,so.sold_to_party,so.dist_channel,so.division,so.sales_org,csm.customer_name,dd.created_date,sm.status_name, "
					+ " dd.acc_mgr,um.user_name as acco_mgr_name "
					+ " from drf_details dd "
					+ " inner join so_orders so on dd.drf_details_id = so.drf_details_id and so.cont_sales_doc_type ='ZTNT' "
					+ " inner join customer_sapmst csm on (so.sold_to_party = csm.customer_num and so.dist_channel=csm.dist_channel and so.division=csm.division and so.sales_org=csm.sales_org) "
					+ " inner join (select distinct drf_details_id,status_mst_id from drf_status_tracker where status_mst_id=4) as dst on dst.drf_details_id = dd.drf_details_id "
					+ " inner join user_mst um on dd.acc_mgr = um.user_mst_id "
					+ " inner join status_mst sm on dst.status_mst_id = sm.status_mst_id "
					+ " left join brf b on dd.drf_details_id = b.drf_details_id "
					+ " where dd.created_date between ?1 and ?2 ";
			}
			else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCMGRCODE) || brfDetailsListDTO.getRoleCode().equals(Constants.OPERATIONSHEADCODE) || brfDetailsListDTO.getRoleCode().equals(Constants.NOCENGINEERCODE)) {
			queryString = "select distinct so.so_number,dd.drf_details_id,dd.demo_start,dd.demo_end,dd.market_segment,so.sold_to_party,so.dist_channel,so.division,so.sales_org,csm.customer_name,dd.created_date,sm.status_name, "
					+ " dd.acc_mgr,um.user_name as acco_mgr_name "
					+ " from drf_details dd "
					+ " inner join so_orders so on dd.drf_details_id = so.drf_details_id and so.cont_sales_doc_type ='ZTNT' "
					+ " inner join customer_sapmst csm on (so.sold_to_party = csm.customer_num and so.dist_channel=csm.dist_channel and so.division=csm.division and so.sales_org=csm.sales_org) "
					+ " inner join user_mst um on dd.acc_mgr = um.user_mst_id "
					+ " inner join brf b on dd.drf_details_id = b.drf_details_id "
					+ " inner join status_mst sm on b.status_mst_id = sm.status_mst_id " 
					+ " inner join user_to_hub utb on b.hub_mst_id = utb.hub_mst_id"
					+ " where dd.created_date between ?1 and ?2 ";
			}
			
			if (brfDetailsListDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)) {
				queryString = queryString + " and dd.prg_mgr=?3 ";
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, brfDetailsListDTO.getUserMstId());
			}
			else if (brfDetailsListDTO.getRoleCode().equals(Constants.FINANCEROLECODE)) {
				queryString = queryString + " and b.finance_id=?3  ";
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, brfDetailsListDTO.getUserMstId());

			} 
			else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCENGINEERCODE)) {
				queryString = queryString + " and utb.user_mst_id =?3  ";
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, brfDetailsListDTO.getUserMstId());
			} 
			else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCMGRCODE) || brfDetailsListDTO.getRoleCode().equals(Constants.OPERATIONSHEADCODE)) {
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
			}
			else if (brfDetailsListDTO.getRoleCode().equals(Constants.REGULATORYHEAD)) {
				queryString = queryString + " and b.regulatory_id = ?3  ";
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, brfDetailsListDTO.getUserMstId());
			}

			List<BrfDetailsDTO> brfDetailsDTOList = new ArrayList<BrfDetailsDTO>();
			BrfDetailsDTO brfDetailsDTO = null;
			List<MaterialChildContract> materialChildContractList = null;
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			
			for (Object[] objects : resultList) {
				brfDetailsDTO = new BrfDetailsDTO();
							
				brfDetailsDTO.setSoNumber((String) objects[0]);
				brfDetailsDTO.setDrfDetailsId((Integer) objects[1]);
				brfDetailsDTO.setDemoStart(DateUtil.convertDateTimeToString(objects[2].toString()));
				brfDetailsDTO.setDemoEnd(DateUtil.convertDateTimeToString(objects[3].toString()));
//				brfDetailsDTO.setQuarter((String) objects[3]);
				brfDetailsDTO.setMarketSegment((String) objects[4]);
//				brfDetailsDTO.setAccoMgr((Integer) objects[5]);
//				brfDetailsDTO.setPoNum((String) objects[6]);
				brfDetailsDTO.setSoldToParty((String) objects[5]);
				brfDetailsDTO.setDistChannel((String) objects[6]);
				brfDetailsDTO.setDivision((String) objects[7]);
				brfDetailsDTO.setSalesOrg((String) objects[8]);
				brfDetailsDTO.setCustomerName((String) objects[9]);
//				brfDetailsDTO.setAccoMgrName((String) objects[10]);
				
/*				
				if(objects[0] != null) {
				
					brfDetailsDTO.setNumOfBrf(this.getBrfCountByDrfId((String) objects[0]));
				}
								
				if(objects[0] != null) {
//				materialChildContract = new MaterialChildContract();
//				materialChildContract = this.getMaterialChildContractById((Integer) objects[7]);
//				brfDetailsDTO.setMaterialDesc(materialChildContract.getMaterialDesc());
				materialChildContractList = new ArrayList<MaterialChildContract>() ;
				materialChildContractList = this.materialListByChildContId((Integer) objects[7]);
				brfDetailsDTO.setMaterialChildContractList(materialChildContractList);
				brfDetailsDTO.setOrderQty(this.sumOfOrderQtyByChildContId((Integer) objects[7]));
				}
				
				*/
				
				if (objects[0] != null) {
					brfDetailsDTO.setBrfNumOfSiteCreated(this.getRemainNumSiteBySoNumber((String) objects[0],(Integer) objects[1]));
				}
				
				brfDetailsDTO.setCreatedDate(DateUtil.convertDateTimeToString(objects[10].toString()));	
				brfDetailsDTO.setStatusName((String) objects[11]);
				brfDetailsDTO.setAccoMgr(Integer.parseInt(objects[12].toString()));
				brfDetailsDTO.setAccoMgrName((String) objects[13]);
				brfDetailsDTOList.add(brfDetailsDTO);
			}
			
			return brfDetailsDTOList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<BrfDetailsDTO>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<BrfDetailsDTO> brfListBySONumAndDate(BrfDetailsListDTO brfDetailsListDTO) {	
		// TODO Auto-generated method stub
		try {
			String queryString = "";
			String fromDate = DateUtil.convertDateToSqlDate(brfDetailsListDTO.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(brfDetailsListDTO.getToDate());
//			    queryString = "SELECT c from ChildContract c inner join c.contract con inner join con.proposal p inner join p.serviceOrderMst som left join c.brf b left join b.statusMst sm where som.serviceOrderDetId in (3,4) and c.createdDate between ?1 and ?2 and c.sapContractNum is not null";
				
			queryString = "select distinct so.so_number,dd.drf_details_id,dd.demo_start,dd.demo_end,dd.market_segment,"
					+ " b.brf_id,b.acco_mgr as acco_mgr,b.bandwidth,b.brf_plan,b.bw_allocation,b.created_date,b.existing_site,"
					+ " b.product,b.old_so_num,b.po_num,b.site_name,b.sold_to_party,"
					+ " b.status_mst_id,sm.status_name,sm.status_code,b.technology,b.tent_act_date,b.finance_id,"
					+ " b.noc_mgr_id,b.prog_mgr,b.regulatory_id,b.sales_org,b.dist_channel,b.division,b.finance_remark,b.noc_remark,"
					+ " csm.customer_name,um.user_name as acco_mgr_name,b.pm_remark,b.hub_mst_id,hm.hub_desc "
					+ " from drf_details dd "
					+ " inner join so_orders so on dd.drf_details_id = so.drf_details_id and so.cont_sales_doc_type ='ZTNT' "
					+ " inner join customer_sapmst csm on (so.sold_to_party = csm.customer_num and so.dist_channel=csm.dist_channel and so.division=csm.division and so.sales_org=csm.sales_org) "
					+ " inner join (select distinct drf_details_id,status_mst_id from drf_status_tracker where status_mst_id=4) as dst on dst.drf_details_id = dd.drf_details_id "
					+ " inner join status_mst dsm on dst.status_mst_id = dsm.status_mst_id "
					+ " left join brf b on dd.drf_details_id = b.drf_details_id "
					+ " inner join user_mst um on b.acco_mgr = um.user_mst_id "
					+ " inner join hub_mst hm  on b.hub_mst_id = hm.hub_mst_id ";

			if (brfDetailsListDTO.getRoleCode().equals(Constants.FINANCEROLECODE)
					|| brfDetailsListDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)
					|| brfDetailsListDTO.getRoleCode().equals(Constants.REGULATORYHEAD)) {
				queryString = queryString + " left join status_mst sm on b.status_mst_id = sm.status_mst_id "
						+ " where b.created_date between ?1 and ?2 ";
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCMGRCODE)
					|| brfDetailsListDTO.getRoleCode().equals(Constants.OPERATIONSHEADCODE)
					|| brfDetailsListDTO.getRoleCode().equals(Constants.NOCENGINEERCODE)) {
				queryString = queryString + " inner join status_mst sm on b.status_mst_id = sm.status_mst_id "
						+ " inner join user_to_hub utb on b.hub_mst_id = utb.hub_mst_id "
						+ " where b.created_date between ?1 and ?2 ";
			}

			if (brfDetailsListDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)) {

				if (brfDetailsListDTO.getPendingList().equals(Constants.YESPENDINGLIST)) {
					queryString = queryString + "  and sm.status_code in ('BRFNA','BRFR') and dd.prg_mgr =?3 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getUserMstId());
				} else if (brfDetailsListDTO.getPendingList().equals(Constants.NOPENDINGLIST)) {
					queryString = queryString + "  and b.so_number = ?3 and dd.prg_mgr=?4 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getSoNumber());
					query.setParameter(4, brfDetailsListDTO.getUserMstId());
				}
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.FINANCEROLECODE)) {
				if (brfDetailsListDTO.getPendingList().equals(Constants.YESPENDINGLIST)) {
					queryString = queryString + " and sm.status_code in('BRFSTF') and b.finance_id=?3 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getUserMstId());
				} else if (brfDetailsListDTO.getPendingList().equals(Constants.NOPENDINGLIST)) {
					queryString = queryString
							+ " and sm.status_code in('BRFSTF','BRFSTNOC','BRFA','BRFR') and b.so_number = ?3 and b.finance_id=?4 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getSoNumber());
					query.setParameter(4, brfDetailsListDTO.getUserMstId());
				}
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCENGINEERCODE)) {
				if (brfDetailsListDTO.getPendingList().equals(Constants.YESPENDINGLIST)) {
					queryString = queryString + "  and sm.status_code in ('BRFSTNOC') and utb.user_mst_id=?3 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getUserMstId());
				} else if (brfDetailsListDTO.getPendingList().equals(Constants.NOPENDINGLIST)) {
					queryString = queryString + " and sm.status_code in('BRFSTNOC','BRFA','BRFR') and b.so_number = ?3 and utb.user_mst_id=?4 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getSoNumber());
					query.setParameter(4, brfDetailsListDTO.getUserMstId());
				}
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCMGRCODE)
					|| brfDetailsListDTO.getRoleCode().equals(Constants.OPERATIONSHEADCODE)) {
				if (brfDetailsListDTO.getPendingList().equals(Constants.YESPENDINGLIST)) {
					queryString = queryString + "  and sm.status_code in ('BRFSTNOC') ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
				} else if (brfDetailsListDTO.getPendingList().equals(Constants.NOPENDINGLIST)) {
					queryString = queryString
							+ " and sm.status_code in('BRFSTNOC','BRFA','BRFR') and b.so_number = ?3 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getSoNumber());
				}
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.REGULATORYHEAD)) {
				queryString = queryString + " and b.regulatory_id = ?4 and sm.status_code in('BRFA') ";
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, brfDetailsListDTO.getSoNumber());
				query.setParameter(4, brfDetailsListDTO.getUserMstId());
			}

			List<BrfDetailsDTO> brfDetailsDTOList = new ArrayList<BrfDetailsDTO>();
			BrfDetailsDTO brfDetailsDTO = null;
			List<MaterialChildContract> materialChildContractList = null;
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) query.getResultList();

			for (Object[] objects : resultList) {
				brfDetailsDTO = new BrfDetailsDTO();

				brfDetailsDTO.setSoNumber((String) objects[0]);
				brfDetailsDTO.setDrfDetailsId((Integer) objects[1]);
				brfDetailsDTO.setDemoStart(DateUtil.convertDateTimeToString(objects[2].toString()));
				brfDetailsDTO.setDemoEnd(DateUtil.convertDateTimeToString(objects[3].toString()));
				brfDetailsDTO.setMarketSegment((String) objects[4]);
				brfDetailsDTO.setBrfId((Integer) objects[5]);
				brfDetailsDTO.setAccoMgr((Integer) objects[6]);
				brfDetailsDTO.setBandwidth((String) objects[7]);
				brfDetailsDTO.setBrfPlan((String) objects[8]);
				brfDetailsDTO.setBwAllocation((String) objects[9]);
				if (objects[10] != null) {
					brfDetailsDTO.setCreatedDate(DateUtil.convertDateTimeToString(objects[10].toString()));
				}
				brfDetailsDTO.setExistingSite((String) objects[11]);
				brfDetailsDTO.setProduct((String) objects[12]);
				brfDetailsDTO.setOldSoNum((String) objects[13]);
				brfDetailsDTO.setPoNum((String) objects[14]);
				brfDetailsDTO.setSiteName((String) objects[15]);
				brfDetailsDTO.setSoldToParty((String) objects[16]);
				brfDetailsDTO.setStatusMstId((Integer) objects[17]);
				brfDetailsDTO.setStatusName((String) objects[18]);
				brfDetailsDTO.setStatusCode((String) objects[19]);
				brfDetailsDTO.setTechnology((String) objects[20]);
				if (objects[21] != null) {
					brfDetailsDTO.setTentActDate(DateUtil.convertDateTimeToString(objects[21].toString()));
				}
				brfDetailsDTO.setFinanceId((Integer) objects[22]);
				brfDetailsDTO.setNocMgrId((Integer) objects[23]);
				brfDetailsDTO.setProgMgr((Integer) objects[24]);
				brfDetailsDTO.setRegulatoryId((Integer) objects[25]);
				brfDetailsDTO.setSalesOrg((String) objects[26]);
				brfDetailsDTO.setDistChannel((String) objects[27]);
				brfDetailsDTO.setDivision((String) objects[28]);
				brfDetailsDTO.setFinanceRemark((String) objects[29]);
				brfDetailsDTO.setNocRemark((String) objects[30]);
				brfDetailsDTO.setCustomerName((String) objects[31]);
				brfDetailsDTO.setAccoMgrName((String) objects[32]);
				brfDetailsDTO.setPmRemark((String) objects[33]);
				brfDetailsDTO.setHubMstId((Integer) objects[34]);
				brfDetailsDTO.setHubDesc((String) objects[35]);
				
/*				

				if (objects[2] != null) {
					brfDetailsDTO.setNumOfBrf(this.getBrfCountByContractNum((String) objects[2]));
				}

				if (objects[2] != null) {
//					materialChildContract = new MaterialChildContract();
//					materialChildContract = this.getMaterialChildContractById((Integer) objects[23]);
//					brfDetailsDTO.setMaterialDesc(materialChildContract.getMaterialDesc());
					
					materialChildContractList = new ArrayList<MaterialChildContract>() ;
					materialChildContractList = this.materialListByChildContId((Integer) objects[23]);
					brfDetailsDTO.setMaterialChildContractList(materialChildContractList);
					brfDetailsDTO.setOrderQty(this.sumOfOrderQtyByChildContId((Integer) objects[23]));
				}
				
				*/
				
				if (objects[0] != null) {
					brfDetailsDTO.setBrfNumOfSiteCreated(this.getRemainNumSiteBySoNumber((String) objects[0],(Integer) objects[1]));
				}
				
				
				

//				brfDetailsDTO.setItem((String) objects[36]);
//				brfDetailsDTO.setMaterialNum((String) objects[37]);
//				brfDetailsDTO.setSoOrdersId((Integer)objects[38]);
//				brfDetailsDTO.setCustomerName((String) objects[39]);
				
				/*
				if (objects[35] != null) {
					CustomerSapmst customerSapmst = new CustomerSapmst();
					CustomerMstDTO customerMstDTO = new CustomerMstDTO();
					customerMstDTO.setCustomerSapmstId((Integer) objects[35]);
					customerSapmst = customerMstDao.getCustomerdetailsByCustomerNum(customerMstDTO);
					brfDetailsDTO.setCustomerSapmst(customerSapmst);
				}
				*/

				brfDetailsDTOList.add(brfDetailsDTO);
			}

			return brfDetailsDTOList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<BrfDetailsDTO>();
		} finally {
			em.close();
		}
	}

	@Override
	public Brf drfBrfByBrfId(Integer brfId) {
		try {
			query = em.createNativeQuery(" select b.brf_id,um.user_mst_id as acco_mgr,b.bandwidth,b.brf_plan,b.bw_allocation,b.so_number,b.created_date,"
					+ " b.existing_site,b.product,b.old_so_num,b.po_num,b.site_name,b.sold_to_party,b.status_mst_id,sm.status_name,"
					+ " sm.status_code,b.technology,b.tent_act_date,b.drf_details_id,b.finance_id,b.noc_mgr_id,b.prog_mgr,b.regulatory_id,"
					+ " b.sales_org,b.dist_channel,b.division,b.finance_remark,b.noc_remark,csm.customer_name,"
					+ " bsd.brf_so_details_id,bsd.brf_id as bsd_brf_id,bsd.old_so_num as bsd_old_so_num ,bsd.new_so_num as bsd_new_so_num,"
					+ " bsd.existing_site as bsd_existing_site, bsd.technology as bsd_technology,bsd.brf_plan as bsd_brf_plan,"
					+ " bsd.bandwidth as bsd_bandwidth,bsd.tent_act_date as bsd_tent_act_date,bsd.new_so_act_date as bsd_new_so_act_date,"
					+ " bsd.modified_date as bsd_modified_date,bsd.created_date as bsd_created_date,um.user_name as acco_mgr_name, um2.user_name as progMgrName, "
					+ " b.pm_remark,b.hub_mst_id,hm.hub_desc,ROW_NUMBER() OVER(ORDER BY bsd.brf_so_details_id ASC) AS rowNumber  "
					+ " from brf b "
					+ " inner join status_mst sm on b.status_mst_id = sm.status_mst_id "
					+ " inner join drf_details dd on dd.drf_details_id = b.drf_details_id "
					+ " inner join so_orders so on dd.drf_details_id = so.drf_details_id and so.cont_sales_doc_type ='ZTNT' "
					+ " inner join customer_sapmst csm on (b.sold_to_party = csm.customer_num and b.dist_channel=csm.dist_channel and b.division=csm.division and b.sales_org=csm.sales_org) "
					+ " inner join user_mst um on b.acco_mgr = um.user_mst_id "
					+ " inner join user_mst um2 on um2.user_mst_id = b.prog_mgr "
					+ " inner join hub_mst hm  on b.hub_mst_id = hm.hub_mst_id" 
					+ " left join brf_so_details bsd on b.brf_id=bsd.brf_id "
					+ " where b.brf_id =?1  order by rowNumber asc ");
			query.setParameter(1, brfId);
			query.setMaxResults(50);
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			Brf brf = new Brf();
			List<BrfSoDetails> brfSoDetailsList = new ArrayList<BrfSoDetails>();
			BrfSoDetails brfSoDetails = null;
			int count =1;
			for (Object[] objects : resultList) {
				brfSoDetails = new BrfSoDetails();
				if(count == 1 )
				{
				brf.setBrfId((Integer) objects[0]);
				brf.setAccoMgr((Integer) objects[1]);
				brf.setBandwidth((String) objects[2]);
				brf.setBrfPlan((String) objects[3]);
				brf.setBwAllocation((String) objects[4]);
				brf.setSoNumber((String) objects[5]);
				if(objects[6] != null) {
					brf.setCreatedDate(DateUtil.convertDateTimeToString(objects[6].toString()));
				}
				brf.setExistingSite((String) objects[7]);
				brf.setProduct((String) objects[8]);
				brf.setOldSoNum((String) objects[9]);
				brf.setPoNum((String) objects[10]);
				brf.setSiteName((String) objects[11]);
				brf.setSoldToParty((String) objects[12]);
				brf.setStatusMstId((Integer) objects[13]);
				brf.setStatusName((String) objects[14]);
				brf.setStatusCode((String) objects[15]);
				brf.setTechnology((String) objects[16]);
				if(objects[17] != null) {
					brf.setTentActDate(DateUtil.convertDateTimeToString(objects[17].toString()));
				}
				brf.setDrfDetailsId((Integer) objects[18]);
				brf.setFinanceId((Integer) objects[19]);
				brf.setNocMgrId((Integer) objects[20]);
				brf.setProgMgr((Integer) objects[21]);
				brf.setRegulatoryId((Integer)objects[22]);
				brf.setSalesOrg((String) objects[23]);
				brf.setDistChannel((String) objects[24]);
				brf.setDivision((String) objects[25]);
				brf.setFinanceRemark((String) objects[26]);
				brf.setNocRemark((String) objects[27]);
				brf.setCustomerName((String) objects[28]);
				brf.setAccoMgrName((String) objects[41]);
				brf.setProgMgrName((String) objects[42]);
				brf.setPmRemark((String) objects[43]);
				brf.setHubMstId((Integer)objects[44]);
				brf.setHubDesc((String)objects[45]);
							
				if(objects[5] != null) {
					brf.setBrfNumOfSiteCreated(this.getRemainNumSiteBySoNumber((String) objects[5],(Integer) objects[18]));
					}		
				}
				
				brfSoDetails.setBrfSoDetailsId((Integer) objects[29]);
				brfSoDetails.setBrfId((Integer) objects[30]);
				brfSoDetails.setOldSoNum((String) objects[31]);
				brfSoDetails.setNewSoNum((String) objects[32]);
				brfSoDetails.setExistingSite((String) objects[33]);
				brfSoDetails.setTechnology((String) objects[34]);
				brfSoDetails.setBrfPlan((String) objects[35]);
				brfSoDetails.setBandwidth((String) objects[36]);
				
				if(objects[37] != null) {
				brfSoDetails.setTentActDate(DateUtil.convertDateTimeToString(objects[37].toString()));
				}
				if(objects[38] != null) {				
				brfSoDetails.setNewSoActDate(DateUtil.convertDateTimeToString(objects[38].toString()));
				}
				if(objects[39] != null) {
				brfSoDetails.setModifiedDate(DateUtil.convertDateTimeToString(objects[39].toString()));
				}
				if(objects[40] != null) {
				brfSoDetails.setCreatedDate(DateUtil.convertDateTimeToString(objects[40].toString()));
				}
				brfSoDetails.setRowNumber(((BigInteger) objects[46]).intValue());
				count ++;
				brfSoDetailsList.add(brfSoDetails);
				
				
			}
			if (brf != null) {
				brf.setBrfSoDetailsList(brfSoDetailsList);
				
			} 
			return brf;
	/*		else {
				return new Brf();
			}
*/
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new Brf();
		} finally {
			em.close();
		}
	}
	
	@Override
	public Integer getRemainNumSiteBySoNumber(String soNumber,Integer drfDetailsId) {
		// TODO Auto-generated method stub
		Integer brfNumOfSiteCreated = null;
	
		try {
			query = em.createNativeQuery(" select  sum(cast(site_name as int)) as brfQty from brf where so_number =?1 and drf_details_id =?2 group by so_number  ");
			query.setParameter(1, soNumber);
			query.setParameter(2, drfDetailsId);
			Object resultList = (Object) query.getSingleResult();
			if( resultList!=null) { 
				brfNumOfSiteCreated = (Integer) resultList;
			}
			return brfNumOfSiteCreated;
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		} finally {
			em.close();
		}
	}
	
	@Override
	public void updateDRFDemoDates(DrfDetails drfDetails) {
		query = em.createNativeQuery(" update drf_details set demo_start= ?2,demo_end = ?3 where  drf_details_id= ?1 ");
		query.setParameter(1, drfDetails.getDrfDetailsId());
		query.setParameter(2, drfDetails.getDemoStart());
		query.setParameter(3, drfDetails.getDemoEnd());
		query.executeUpdate();
	}

	@Override
	public DrfDemoDate saveDrfDemoDate(DrfDemoDate drfDemoDate) {
		// TODO Auto-generated method stub
		
		DrfDemoDate drfDemoDateNew = em.merge(drfDemoDate);
		if (drfDemoDate.getDrfDemoDateId() == null) {
			em.refresh(drfDemoDateNew);
		}
		return drfDemoDateNew;
	}

}
