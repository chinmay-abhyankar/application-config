package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the antenna_type_mst database table.
 * 
 */
@Entity
@Table(name="antenna_type_mst")
@NamedQuery(name="AntennaTypeMst.findAll", query="SELECT a FROM AntennaTypeMst a where a.isActive = 'Y' ")
public class AntennaTypeMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="antenna_type_mst_id")
	private Integer antennaTypeMstId;

	@Column(name="antenna_type")
	private String antennaType;

	@Column(name="antenna_type_code")
	private String antennaTypeCode;

	@Column(name="is_active")
	private String isActive;

	public AntennaTypeMst() {
	}

	public Integer getAntennaTypeMstId() {
		return this.antennaTypeMstId;
	}

	public void setAntennaTypeMstId(Integer antennaTypeMstId) {
		this.antennaTypeMstId = antennaTypeMstId;
	}

	public String getAntennaType() {
		return this.antennaType;
	}

	public void setAntennaType(String antennaType) {
		this.antennaType = antennaType;
	}

	public String getAntennaTypeCode() {
		return this.antennaTypeCode;
	}

	public void setAntennaTypeCode(String antennaTypeCode) {
		this.antennaTypeCode = antennaTypeCode;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

}