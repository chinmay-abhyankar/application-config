package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.nelco.o2c.dto.DisconnectionReconnectionDatesToCSVDTO;
import com.nelco.o2c.dto.ReactivationListDTO;
import com.nelco.o2c.dto.ReactivationOnCRDTO;
import com.nelco.o2c.model.ReactivationRequestMst;
import com.nelco.o2c.utility.DateUtil;

@Repository
public class ReactivationOnCRDaoImpl implements ReactivationOnCRDao{
	@PersistenceContext
	private EntityManager em;
	Query query;	
	StoredProcedureQuery spQuery;
	
	@Override
	public List<ReactivationListDTO> getReactivationRequestsList(HttpServletRequest request) {
		spQuery = em.createStoredProcedureQuery("isp_getDisconnectedSitesForReconnectionOnCR")
				.registerStoredProcedureParameter("customer", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("startDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("endDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("userId", String.class, ParameterMode.IN);
		spQuery.setParameter("customer", request.getParameter("customer"))
				.setParameter("startDate", DateUtil.convertDateToSqlDate(request.getParameter("startDate")))
				.setParameter("endDate", DateUtil.convertDateToSqlDate(request.getParameter("endDate")))
				.setParameter("userId", request.getParameter("userId"));
		List<Object[]> requestList=spQuery.getResultList();
		return requestList.stream().map(result -> new ReactivationListDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3])
		         ,String.valueOf(result[4]),String.valueOf(result[5]),String.valueOf(result[6]),String.valueOf(result[7])
		         ,String.valueOf(result[8]),String.valueOf(result[9]),"")
		   ).collect(Collectors.toList());
	}

	@Override
	public ReactivationRequestMst initiateReactivationRequest(ReactivationRequestMst reactivationRequest) {
		query=em.createNamedQuery("ReactivationRequestMst.getRequestId");
		String requestId=String.valueOf(query.getSingleResult());
		reactivationRequest.setRequestId(requestId);
		reactivationRequest.setRequestDate(String.valueOf(DateUtil.getCurrentSqlDate()));
		reactivationRequest.setBusinessheadAppStatus("2");
		reactivationRequest.setRequestStatus("0");
		reactivationRequest.setReactivationType("2");
		reactivationRequest.setReactivationStatus("0");		
		ReactivationRequestMst requestDetails=em.merge(reactivationRequest);
		
		/*spQuery = em.createStoredProcedureQuery("isp_sendReactivationNotificationsForExeccution")
				.registerStoredProcedureParameter("requestId", String.class, ParameterMode.IN);
		spQuery.setParameter("requestId", requestId);
		spQuery.execute();*/
		return requestDetails;
	}

	
	@Override
	public ReactivationRequestMst reactivateSite(ReactivationRequestMst toBeStatuses) {
		query=em.createNamedQuery("ReactivationRequestMst.reactivateSiteOnCR");	
		query.setParameter("requestId", toBeStatuses.getRequestId());
		query.executeUpdate();
		return toBeStatuses;
	}

	@Override
	public List<DisconnectionReconnectionDatesToCSVDTO> getBillingStartDate(String requestId) {
		DisconnectionReconnectionDatesToCSVDTO dto;
		List<DisconnectionReconnectionDatesToCSVDTO> result=new ArrayList<DisconnectionReconnectionDatesToCSVDTO>();
		query = em.createNativeQuery("SELECT DISTINCT dcrm.so_no,convert(VARCHAR,cc.con_end_date,105)"
				+ " FROM reactivation_request_mst rrm"
				+ " LEFT JOIN disconnection_request_on_cr_mst dcrm ON rrm.disconnection_request_id=dcrm.request_id"
				+ " LEFT JOIN so_orders so ON dcrm.so_no=so.so_number"
				+ " LEFT JOIN child_contract cc ON so.contract_num=cc.sap_contract_num"
				+ " WHERE rrm.request_id='"+requestId+"'");
		
		@SuppressWarnings("unchecked")
		List<Object[]> resultList = (List<Object[]>) query.getResultList();
		if( resultList!=null && resultList.size()>0) { 		
		for (Object[] objects : resultList) {
			dto=new DisconnectionReconnectionDatesToCSVDTO();
			dto.setSo_no(String.valueOf(objects[0]));
			dto.setEndDate(String.valueOf(objects[1]));
			result.add(dto);
		}		
	}	
		return result;
}
	
	public int getCount(String table, String column, String value) {
		String lQuery = "select count(*) from " + table + " where " + column + "=?1";
		query = em.createNativeQuery(lQuery);
		query.setParameter(1, value);
		int num = (int) query.getSingleResult();
		return num;
	}
	
	@SuppressWarnings("unchecked")
	public String validateIpforDisconnection(String value) {
		String result ="";
		Object[] obj=null;
		spQuery = em.createStoredProcedureQuery("isp_validateIPForDisconnection")
				.registerStoredProcedureParameter("ip", String.class, ParameterMode.IN);
		spQuery.setParameter("ip",value);
		List<Object[]> soList=spQuery.getResultList();
		for(int i=0;i<soList.size();i++){
		result = String.valueOf(soList.get(i));
		if(result.equals("Y"))
			result="N";
		else if(result.equals("N"))
			result="Y";
			
		}
		
		return result;
	}

	@Override
	public List<ReactivationOnCRDTO> uploadFile(MultipartFile file, String userId, HashMap<String, String> resultMap) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void sendReactivationOnCRIntimation(String commonId) {
		spQuery = em.createStoredProcedureQuery("isp_SendReactivationOnCRNotificationsForExeccution")
				.registerStoredProcedureParameter("commonId", String.class, ParameterMode.IN);
		spQuery.setParameter("commonId", commonId);
		spQuery.execute();
	}

}
