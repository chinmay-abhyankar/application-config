package com.nelco.o2c.dto;

import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.model.FranchiseeMaster;
import com.nelco.o2c.model.SiteSurveyMaster;

public class SiteSurveyEngineerDTO {
	private Integer id;
	private Integer site_survey_id;
	private Integer franchisee_id;
	private String name;
	private String mobile_no;
	private String email_id;
	private String engVisitDate;
	private String engVisitTiming;
	private Integer userMstId;
	
	
	
	
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getEngVisitDate() {
		return engVisitDate;
	}
	public void setEngVisitDate(String engVisitDate) {
		this.engVisitDate = engVisitDate;
	}
	public String getEngVisitTiming() {
		return engVisitTiming;
	}
	public void setEngVisitTiming(String engVisitTiming) {
		this.engVisitTiming = engVisitTiming;
	}
	public Integer getFranchisee_id() {
		return franchisee_id;
	}
	public void setFranchisee_id(Integer franchisee_id) {
		this.franchisee_id = franchisee_id;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getSite_survey_id() {
		return site_survey_id;
	}
	public void setSite_survey_id(Integer site_survey_id) {
		this.site_survey_id = site_survey_id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	
	
	
	
	
}


