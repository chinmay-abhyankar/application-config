/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.StoC;
import com.nelco.o2c.model.StoCsDelivery;

/**
 * @author Jayashankar.r
 *
 */
public class CsStoDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Integer userMstId;
	private String fromDate;
	private String toDate;
	private String roleCode;
	private List<StoC> stoCsList;
	private StoC stoCs;
	private Integer stoCsId;
	private Boolean isSaved = false;
	private List<StoCsDelivery> stoCsDeliveryList;
	private String selectedStatus;
	private String stoCsGenId;
	private String deliveryNum;
	private String plant; 
	
	public String getDeliveryNum() {
		return deliveryNum;
	}
	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}
	public String getStoCsGenId() {
		return stoCsGenId;
	}
	public void setStoCsGenId(String stoCsGenId) {
		this.stoCsGenId = stoCsGenId;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public List<StoC> getStoCsList() {
		return stoCsList;
	}
	public void setStoCsList(List<StoC> stoCsList) {
		this.stoCsList = stoCsList;
	}
	public StoC getStoCs() {
		return stoCs;
	}
	public void setStoCs(StoC stoCs) {
		this.stoCs = stoCs;
	}
	public Integer getStoCsId() {
		return stoCsId;
	}
	public void setStoCsId(Integer stoCsId) {
		this.stoCsId = stoCsId;
	}
	public Boolean getIsSaved() {
		return isSaved;
	}
	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}
	public List<StoCsDelivery> getStoCsDeliveryList() {
		return stoCsDeliveryList;
	}
	public void setStoCsDeliveryList(List<StoCsDelivery> stoCsDeliveryList) {
		this.stoCsDeliveryList = stoCsDeliveryList;
	}
	public String getSelectedStatus() {
		return selectedStatus;
	}
	public void setSelectedStatus(String selectedStatus) {
		this.selectedStatus = selectedStatus;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	
}
