/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.DeliveryStatusMst;
import com.nelco.o2c.model.FileTypeMst;

/**
 * @author Jayshankar.r
 *
 */
public class SparesSoDeliveryMasterDTO  implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private List<DeliveryStatusMst> deliveryStatusList;
	private List<FileTypeMst> fileList;
	public List<DeliveryStatusMst> getDeliveryStatusList() {
		return deliveryStatusList;
	}
	public void setDeliveryStatusList(List<DeliveryStatusMst> deliveryStatusList) {
		this.deliveryStatusList = deliveryStatusList;
	}
	public List<FileTypeMst> getFileList() {
		return fileList;
	}
	public void setFileList(List<FileTypeMst> fileList) {
		this.fileList = fileList;
	}
	
	
}
