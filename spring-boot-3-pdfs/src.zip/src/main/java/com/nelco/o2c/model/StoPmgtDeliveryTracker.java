package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the sto_pmgt_delivery_tracker database table.
 * 
 */
@Entity
@Table(name = "sto_pmgt_delivery_tracker")
@NamedQuery(name = "StoPmgtDeliveryTracker.findAll", query = "SELECT s FROM StoPmgtDeliveryTracker s")
public class StoPmgtDeliveryTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sto_pmgt_delivery_tracker_id")
	private Integer stoPmgtDeliveryTrackerId;

	@Column(name = "delivery_status_mst_id")
	private Integer deliveryStatusMstId;

	@Column(name = "req_by")
	private Integer reqBy;

	@Column(name = "status_req_date")
	private String statusReqDate;

	@Column(name = "sto_pmgt_delivery_id")
	private Integer stoPmgtDeliveryId;

	public StoPmgtDeliveryTracker() {
	}

	public Integer getStoPmgtDeliveryTrackerId() {
		return stoPmgtDeliveryTrackerId;
	}

	public void setStoPmgtDeliveryTrackerId(Integer stoPmgtDeliveryTrackerId) {
		this.stoPmgtDeliveryTrackerId = stoPmgtDeliveryTrackerId;
	}

	public Integer getDeliveryStatusMstId() {
		return deliveryStatusMstId;
	}

	public void setDeliveryStatusMstId(Integer deliveryStatusMstId) {
		this.deliveryStatusMstId = deliveryStatusMstId;
	}

	public Integer getReqBy() {
		return reqBy;
	}

	public void setReqBy(Integer reqBy) {
		this.reqBy = reqBy;
	}

	public String getStatusReqDate() {
		return statusReqDate;
	}

	public void setStatusReqDate(String statusReqDate) {
		this.statusReqDate = statusReqDate;
	}

	public Integer getStoPmgtDeliveryId() {
		return stoPmgtDeliveryId;
	}

	public void setStoPmgtDeliveryId(Integer stoPmgtDeliveryId) {
		this.stoPmgtDeliveryId = stoPmgtDeliveryId;
	}

}