package com.nelco.o2c.dto;

import java.util.HashMap;

public class ResponseDTO {
	private String status = "";
    private String message = "";
    private Integer brfId; 
    private Integer contractId;
    HashMap<String, String> resultMap = new HashMap<String, String>();
    
    public HashMap<String, String> getResultMap() {
		return resultMap;
	}
	public void setResultMap(HashMap<String, String> resultMap) {
		this.resultMap = resultMap;
	}
	public Integer getContractId() {
		return contractId;
	}
	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getBrfId() {
		return brfId;
	}
	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}
    
}
