/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

import com.nelco.o2c.model.UserMst;

/**
 * @author Jayashankar.r
 *
 */
public class LoginDTO implements Serializable {
	
	private static final long serialVersionUID = 13L;
	
	private String loginId;
	private String password;
	private Boolean authFailed = true;
	private UserMst userMst;
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Boolean getAuthFailed() {
		return authFailed;
	}
	public void setAuthFailed(Boolean authFailed) {
		this.authFailed = authFailed;
	}
	public UserMst getUserMst() {
		return userMst;
	}
	public void setUserMst(UserMst userMst) {
		this.userMst = userMst;
	}
	
	
}
