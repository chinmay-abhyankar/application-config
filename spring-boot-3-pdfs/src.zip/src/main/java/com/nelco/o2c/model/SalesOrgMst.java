package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the sales_org_mst database table.
 * 
 */
@Entity
@Table(name="sales_org_mst")
@NamedQuery(name="SalesOrgMst.findAll", query="SELECT s FROM SalesOrgMst s")
public class SalesOrgMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="sales_org_mst_id")
	private Integer salesOrgMstId;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="is_active")
	private String isActive;

	@Column(name="sales_org_code")
	private String salesOrgCode;

	@Column(name="sales_org_desc")
	private String salesOrgDesc;

	private String sequence;

	public SalesOrgMst() {
	}

	public Integer getSalesOrgMstId() {
		return salesOrgMstId;
	}

	public void setSalesOrgMstId(Integer salesOrgMstId) {
		this.salesOrgMstId = salesOrgMstId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getSalesOrgCode() {
		return this.salesOrgCode;
	}

	public void setSalesOrgCode(String salesOrgCode) {
		this.salesOrgCode = salesOrgCode;
	}

	public String getSalesOrgDesc() {
		return this.salesOrgDesc;
	}

	public void setSalesOrgDesc(String salesOrgDesc) {
		this.salesOrgDesc = salesOrgDesc;
	}

	public String getSequence() {
		return this.sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

}