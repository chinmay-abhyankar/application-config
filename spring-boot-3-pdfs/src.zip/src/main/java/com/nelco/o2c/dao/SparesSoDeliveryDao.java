/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.SparesSoDeliveryDTO;
import com.nelco.o2c.dto.SparesSoPodUploadDTO;
import com.nelco.o2c.model.DeliveryStatusMst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.SparesSoDelivery;
import com.nelco.o2c.model.SparesSoDeliveryPodTracker;
import com.nelco.o2c.model.SparesSoDeliveryTracker;

/**
 * @author Jayshankar.r
 *
 */
public interface SparesSoDeliveryDao {

	List<SparesSoDelivery> getSparesSoDeliveryList(SparesSoDeliveryDTO sparesSoDeliveryInputDTO);

	List<DeliveryStatusMst> getDeliveryStatusListNotIndelStatusCode(List<String> delStatusCodeList);

	SparesSoDelivery saveSparesSoDelivery(SparesSoDelivery delivery);

	void savesparesSoDeliveryTracker(SparesSoDeliveryTracker sparesSoDeliveryTracker);

	void saveSparesSoDeliveryPodTracker(SparesSoDeliveryPodTracker sparesSoDeliveryPodTracker);

	String getSparesSoEmailString(SparesSoDelivery sparesSoDelivery);

	List<OppUploadDetail> setOppUploadDetailsBySparesSoDeliveryId(SparesSoPodUploadDTO sparesSoPodUploadInputDTO);

	void updatePodStatusInSparesSoDelivery(Integer uploadedStatusNumber, Integer sparesSoDeliveryId);

}
