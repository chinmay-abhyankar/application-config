/**
 * 
 */
package com.nelco.o2c.dao;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.nelco.o2c.dto.ChildContractDTO;
import com.nelco.o2c.dto.ChildContractListDTO;
import com.nelco.o2c.dto.CommonMailDTO;
import com.nelco.o2c.model.ChildContract;
import com.nelco.o2c.model.MaterialChildContract;
import com.nelco.o2c.model.OppUploadDetail;

/**
 * @author Amol.l
 *
 */

public interface ChildContractDao {
	
	public ChildContract getChildConBychildConId(ChildContractDTO childContractDTO);

	public ChildContract saveChildContract(ChildContract childContract);

	public MaterialChildContract saveMatChildContract(MaterialChildContract matChildContract);

	public List<ChildContract> getChildConByConIdAndDate(ChildContractListDTO childContractListDTO);

	public ChildContractListDTO updateContractRemarkFinance(ChildContractListDTO childContractListDTO);

	public CommonMailDTO getSentMailDet(Integer childContractId);

	public ChildContract getChildConBySapContNum(ChildContractDTO childContractDTO);

	public List<OppUploadDetail> getUploadListByChildContractId(ChildContract childContract);

	public List<ChildContract> uploadFile(MultipartFile file, String userMstId, String contractId) throws Exception;

	public String getAccountManger(String childContractId);
}
