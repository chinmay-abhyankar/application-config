/**
 * 
 */
package com.nelco.o2c.controller;

import java.sql.SQLException;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.nelco.o2c.dto.PmgtStoDTO;
import com.nelco.o2c.dto.PmgtStoDropDownDTO;
import com.nelco.o2c.dto.PmgtStoPodUploadDetailsDTO;
import com.nelco.o2c.dto.SparesSoDTO;
import com.nelco.o2c.service.PmgtStoService;

/**
 * @author Jayashankar.r
 *
 */
@RestController
public class PmgtStoController {

	@Autowired
	PmgtStoService pmgtStoService;

	@RequestMapping(value = "/getPmgtStoList.do", method = RequestMethod.POST)
	public PmgtStoDTO getPmgtStoList(@RequestBody PmgtStoDTO ipPmgtStoDTO) {
		return pmgtStoService.getPmgtStoList(ipPmgtStoDTO);
	}

	@RequestMapping(value = "/getPmgtSto.do", method = RequestMethod.POST)
	public PmgtStoDTO getPmgtSto(@RequestBody PmgtStoDTO ipPmgtStoDTO) {
		return pmgtStoService.getPmgtSto(ipPmgtStoDTO);
	}
	
	@RequestMapping(value = "/getPmgtStoByReqId.do", method = RequestMethod.POST)
	public PmgtStoDTO getPmgtStoByReqId(@RequestBody PmgtStoDTO ipPmgtStoDTO) {
		return pmgtStoService.getPmgtStoByReqId(ipPmgtStoDTO);
	}

	@RequestMapping(value = "/saveSto.do", method = RequestMethod.POST)
	public PmgtStoDTO saveStoPmgt(@RequestBody PmgtStoDTO ipPmgtStoDTO) {
		ipPmgtStoDTO.getStoPmgt().setPlantSapmst(null);
		return pmgtStoService.saveSto(ipPmgtStoDTO);
	}

	@RequestMapping(value = "/submitSto.do", method = RequestMethod.POST)
	public PmgtStoDTO submitStoPmgt(@RequestBody PmgtStoDTO ipPmgtStoDTO) {
		return pmgtStoService.submitSto(ipPmgtStoDTO);
	}

	@RequestMapping(value = "/getPmgtStoDropDowns.do", method = RequestMethod.POST)
	public PmgtStoDropDownDTO getPmgtStoDropDowns(@RequestBody PmgtStoDTO ipPmgtStoDTO) {
		return pmgtStoService.getPmgtStoDropDowns(ipPmgtStoDTO);
	}

	@RequestMapping(value = "/getDeliveryTrackPmgtSto.do", method = RequestMethod.POST)
	public PmgtStoDTO getDeliveryTrackPmgtSto(@RequestBody PmgtStoDTO ipPmgtStoDTO) {
		return pmgtStoService.getDeliveryTrackPmgtSto(ipPmgtStoDTO);
	}
	
	@RequestMapping(value = "/stoPmgtDelBydeliveryNum.do", method = RequestMethod.POST)
	public PmgtStoDTO stoPmgtDelBydeliveryNum(@RequestBody PmgtStoDTO ipPmgtStoDTO) {
		return pmgtStoService.stoPmgtDelBydeliveryNum(ipPmgtStoDTO);
	}
	
	@RequestMapping(value = "/saveDeliverTrackPmgtSto.do", method = RequestMethod.POST)
	public PmgtStoDTO saveDeliverTrackPmgtSto(@RequestBody PmgtStoDTO ipPmgtStoDTO) {
		return pmgtStoService.saveDeliverTrackPmgtSto(ipPmgtStoDTO);
	}

	@RequestMapping(value = "/uploadfilePmgtSto.do", method = RequestMethod.POST)
	public PmgtStoPodUploadDetailsDTO uploadfilePmgtSto(MultipartHttpServletRequest request,
			@RequestParam String fileTypeMstId, @RequestParam String stoPmgtDeliveryId,
			@RequestParam String createdBy) {
		Iterator<String> fileNames = request.getFileNames();
		PmgtStoPodUploadDetailsDTO podUploadDetailsDTO = null;
		if (fileNames.hasNext()) {
			MultipartFile file = request.getFile(fileNames.next());
			podUploadDetailsDTO = pmgtStoService.uploadPodFilePmgtSto(file, fileTypeMstId, stoPmgtDeliveryId,
					createdBy);
		}

		return podUploadDetailsDTO;

	}

	@RequestMapping(value = "/getUpPodFileDetPmgtSto.do", method = RequestMethod.POST)
	public PmgtStoPodUploadDetailsDTO getUpPodFileDetPmgtSto(
			@RequestBody PmgtStoPodUploadDetailsDTO podUploadDetailsDTO) {

		podUploadDetailsDTO = pmgtStoService.getUpPodFileDetPmgtSto(podUploadDetailsDTO.getStoPmgtDeliveryId());

		return podUploadDetailsDTO;

	}
	
	@RequestMapping(value = "/updateSparesSO.do", method = RequestMethod.POST)
	public SparesSoDTO updateSparesSO(@RequestBody SparesSoDTO ipsparesSoDTO) {
		return pmgtStoService.updateSparesSO(ipsparesSoDTO);
	}
	
	@RequestMapping(value = "/getReceivingPlantList.do", method = RequestMethod.POST)
	public PmgtStoDropDownDTO getReceivingPlantList(@RequestBody PmgtStoDTO ipPmgtStoDTO) {
		return pmgtStoService.getReceivingPlantList(ipPmgtStoDTO);
	}
	
	@RequestMapping(value = "/getStorageListByReceivingPlant.do", method = RequestMethod.POST)
	public PmgtStoDropDownDTO getStorageListByReceivingPlant(@RequestBody PmgtStoDTO ipPmgtStoDTO) {
		return pmgtStoService.getStorageListByReceivingPlant(ipPmgtStoDTO);
	}
	
	
	@RequestMapping(value = "/downloadPmgtStoDelId.do", method = {RequestMethod.POST,RequestMethod.GET})
	@CrossOrigin
	public void getSTOCsDeliveryById(HttpServletRequest request, HttpServletResponse response,@RequestParam String pmgtDeliveryNum) {
		try {
			pmgtStoService.downloadPmgtStoByDelId(request, response, pmgtDeliveryNum);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		}
}
