/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

import com.nelco.o2c.model.PmgtStoPodUploadDetail;

/**
 * @author Jayashankar.r
 *
 */
public class PmgtStoPodUploadDetailsDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer stoPmgtDeliveryId;
	private PmgtStoPodUploadDetail pmgtStoPodUploadDetail;

	public Integer getStoPmgtDeliveryId() {
		return stoPmgtDeliveryId;
	}

	public void setStoPmgtDeliveryId(Integer stoPmgtDeliveryId) {
		this.stoPmgtDeliveryId = stoPmgtDeliveryId;
	}

	public PmgtStoPodUploadDetail getPmgtStoPodUploadDetail() {
		return pmgtStoPodUploadDetail;
	}

	public void setPmgtStoPodUploadDetail(PmgtStoPodUploadDetail pmgtStoPodUploadDetail) {
		this.pmgtStoPodUploadDetail = pmgtStoPodUploadDetail;
	}

}
