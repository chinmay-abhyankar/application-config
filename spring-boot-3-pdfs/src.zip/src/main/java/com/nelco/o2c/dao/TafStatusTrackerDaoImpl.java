package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.TafStatusTrackerDTO;
@Repository
public class TafStatusTrackerDaoImpl implements TafStatusTrackerDao {
	@PersistenceContext
	private EntityManager em;
	
	StoredProcedureQuery query;
	
	@Override
	public List<TafStatusTrackerDTO> getTafStatusTracker(String commonDTO) {
		try {
			query = em.createStoredProcedureQuery("isp_getBidManagerComments")
					.registerStoredProcedureParameter("tafId", String.class, ParameterMode.IN);
			query.setParameter("tafId",commonDTO);
			query.execute();
	
			List<TafStatusTrackerDTO> taflist =  new ArrayList<TafStatusTrackerDTO>();
			List<Object[]> result = (List<Object[]>) query.getResultList();
			for (Object[] objects : result) {
				TafStatusTrackerDTO tafStatusTrackerDTO = new TafStatusTrackerDTO();
				tafStatusTrackerDTO.setTafId((Integer)objects[0]);
				tafStatusTrackerDTO.setBidManagerComments((String)objects[1]!=null?(String)objects[1]:"");
				tafStatusTrackerDTO.setIsRejected((String)objects[2]!=null?(String)objects[2]:"NA");
				tafStatusTrackerDTO.setStatusCode((String)objects[3]);
				tafStatusTrackerDTO.setStatusName((String)objects[4]);
				
				taflist.add(tafStatusTrackerDTO);
			}
			
			return taflist!=null?taflist:new ArrayList<TafStatusTrackerDTO>();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			em.close();
		}
	}

}
