package com.nelco.o2c.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;


/**
 * The persistent class for the franchise_inv_req database table.
 * 
 */
@Entity
@Table(name="franchise_inv_req")
@NamedQueries({
	@NamedQuery(name = "FranchiseInvReq.getCurrentDayCountStoCs",query = "select (count(f)+1) from FranchiseInvReq f where f.createdDate between ?1 and ?2"),
	@NamedQuery(name="FranchiseInvReq.findAll", query="SELECT f FROM FranchiseInvReq f"),
	@NamedQuery(name = "FranchiseInvReq.getPaymentRequestListByRoleandUserId",query = "SELECT f.franchiseInvReqId,"
			+ " f.createdDate,f.modifiedDate,f.statusCode,f.uniqId,f.createdBy,"
			+ " sm.statusMstId,sm.statusCode,sm.statusName,f.rejRemarks,f.csId,f.hoCsId,f.csHead,sum(ssc.totalCost)"
			+ " FROM FranchiseInvReq f "
			+ " inner join f.franchiseInvReqUserMapList umap "
			+ " inner join f.statusMst sm "
			+"  inner join f.siteSurveyCost ssc"
			+ " where umap.userMstId = :userMstId and umap.roleMstId = :roleMstId and f.statusCode=:statusCode and f.createdDate between :fromDate and :toDate group by "
			+ "f.franchiseInvReqId,f.createdDate,f.modifiedDate,f.statusCode,f.uniqId,f.createdBy,sm.statusMstId,sm.statusCode,sm.statusName,f.rejRemarks,f.csId,f.hoCsId,f.csHead")
})
public class FranchiseInvReq implements Serializable {


	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="franchise_inv_req_id")
	private Integer franchiseInvReqId;

	@Column(name="created_date",updatable=false)
	private String createdDate;

	@Column(name="modified_date")
	private String modifiedDate;

	@Column(name="status_code")
	private String statusCode;

	@Column(name="uniq_id")
	private String uniqId;
	
	@Column(name = "created_by")
	private Integer createdBy;
	
	
	@Transient
	private BigDecimal totalCost; 
	

	@ManyToOne(fetch = FetchType.LAZY,cascade={CascadeType.REFRESH})
	@JoinColumn(name = "status_code", referencedColumnName = "status_code", insertable = false, updatable = false)
	private StatusMst statusMst;
	
	@OneToMany(fetch = FetchType.LAZY,cascade={CascadeType.REFRESH})
	@JoinColumn(name = "franchise_inv_req_id", referencedColumnName = "franchise_inv_req_id", insertable = false, updatable = false)
	private List<FranchiseInvReqUserMap> franchiseInvReqUserMapList;
	
	@OneToMany(targetEntity=SiteSurveyCost.class,fetch = FetchType.LAZY,cascade= {CascadeType.REFRESH})
	@JoinColumn(name="franchise_inv_req_id",referencedColumnName="franchise_inv_req_id",insertable = false, updatable = false)
	private List<SiteSurveyCost> siteSurveyCost;
	

	public List<SiteSurveyCost> getSiteSurveyCost() {
		return siteSurveyCost;
	}

	public BigDecimal getTotalCost() {
		return totalCost;
	}
	
	public void setTotalCost(BigDecimal totalCost) {
		this.totalCost = totalCost;
	}
	public void setSiteSurveyCost(List<SiteSurveyCost> siteSurveyCost) {
		this.siteSurveyCost = siteSurveyCost;
	}

	@Column(name = "rej_remarks")
	private String rejRemarks;
	
	@Column(name = "cs_id")
	private Integer csId;
	
	@Column(name = "ho_cs_id")
	private Integer hoCsId;
	
	@Column(name = "cs_head")
	private Integer csHead;
	
	
	
	public Integer getCsId() {
		return csId;
	}

	public void setCsId(Integer csId) {
		this.csId = csId;
	}

	public Integer getHoCsId() {
		return hoCsId;
	}

	public void setHoCsId(Integer hoCsId) {
		this.hoCsId = hoCsId;
	}

	public Integer getCsHead() {
		return csHead;
	}

	public void setCsHead(Integer csHead) {
		this.csHead = csHead;
	}

	public String getRejRemarks() {
		return rejRemarks;
	}

	public void setRejRemarks(String rejRemarks) {
		this.rejRemarks = rejRemarks;
	}

	public List<FranchiseInvReqUserMap> getFranchiseInvReqUserMapList() {
		return franchiseInvReqUserMapList;
	}

	public void setFranchiseInvReqUserMapList(List<FranchiseInvReqUserMap> franchiseInvReqUserMapList) {
		this.franchiseInvReqUserMapList = franchiseInvReqUserMapList;
	}

	public StatusMst getStatusMst() {
		return statusMst;
	}

	public void setStatusMst(StatusMst statusMst) {
		this.statusMst = statusMst;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public FranchiseInvReq() {
	}

	public Integer getFranchiseInvReqId() {
		return franchiseInvReqId;
	}

	public void setFranchiseInvReqId(Integer franchiseInvReqId) {
		this.franchiseInvReqId = franchiseInvReqId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getUniqId() {
		return uniqId;
	}

	public void setUniqId(String uniqId) {
		this.uniqId = uniqId;
	}



}