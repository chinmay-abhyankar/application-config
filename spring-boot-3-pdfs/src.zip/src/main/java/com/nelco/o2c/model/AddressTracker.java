/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author Amol.l
 *
 */
@Entity
@Table(name = "address_tracker")
@NamedQueries({ @NamedQuery(name = "AddressTracker.findAll", query = "SELECT at FROM AddressTracker at ") })
public class AddressTracker implements Serializable {
	private static final long serialVersionUID = 80L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "address_tracker_id")
	private Integer addressTrackerId;

	@Column(name = "contact_person")
	private String contactPerson;

	@Column(name = "delivery_id")
	private Integer deliveryId;

	@Column(name = "contact_pers_mob")
	private String contactPersMob;

	@Column(name = "contact_pers_address")
	private String contactPersAddress;

	@Column(name = "req_by")
	private String reqBy;
	
	@Column(name = "created_date")
	private String createdDate;

	public AddressTracker() {
		// TODO Auto-generated constructor stub
	}

	public Integer getAddressTrackerId() {
		return addressTrackerId;
	}

	public void setAddressTrackerId(Integer addressTrackerId) {
		this.addressTrackerId = addressTrackerId;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getContactPersMob() {
		return contactPersMob;
	}

	public void setContactPersMob(String contactPersMob) {
		this.contactPersMob = contactPersMob;
	}

	public String getContactPersAddress() {
		return contactPersAddress;
	}

	public void setContactPersAddress(String contactPersAddress) {
		this.contactPersAddress = contactPersAddress;
	}

	public Integer getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(Integer deliveryId) {
		this.deliveryId = deliveryId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getReqBy() {
		return reqBy;
	}

	public void setReqBy(String reqBy) {
		this.reqBy = reqBy;
	}
	
}
