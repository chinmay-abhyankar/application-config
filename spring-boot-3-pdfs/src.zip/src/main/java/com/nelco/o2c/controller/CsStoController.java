/**
 * 
 */
package com.nelco.o2c.controller;

import java.sql.SQLException;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.nelco.o2c.dto.CsStoDTO;
import com.nelco.o2c.dto.CsStoPodUploadDetailsDTO;
import com.nelco.o2c.dto.PmgtStoDropDownDTO;
import com.nelco.o2c.service.CsStoService;

/**
 * @author Jayashankar.r
 *
 */
@RestController
public class CsStoController {

	@Autowired
	CsStoService csStoService;
	
	@RequestMapping(value = "/getCsStoList.do", method = RequestMethod.POST)
	public CsStoDTO getCsStoList(@RequestBody CsStoDTO ipCsStoDTO) {
		return csStoService.getCsStoList(ipCsStoDTO);
	}

	@RequestMapping(value = "/getCsSto.do", method = RequestMethod.POST)
	public CsStoDTO getCsSto(@RequestBody CsStoDTO ipCsStoDTO) {
		return csStoService.getCsSto(ipCsStoDTO);
	}
	
	@RequestMapping(value = "/getCsStoByReqId.do", method = RequestMethod.POST)
	public CsStoDTO getCsStoByReqId(@RequestBody CsStoDTO ipCsStoDTO) {
		return csStoService.getCsStoByReqId(ipCsStoDTO);
	}

	@RequestMapping(value = "/saveCsSto.do", method = RequestMethod.POST)
	public CsStoDTO saveSto(@RequestBody CsStoDTO ipCsStoDTO) {
		ipCsStoDTO.getStoCs().setPlantSapmst(null);
		return csStoService.saveCsSto(ipCsStoDTO);
	}

	@RequestMapping(value = "/submitCsSto.do", method = RequestMethod.POST)
	public CsStoDTO submitSto(@RequestBody CsStoDTO ipCsStoDTO) {
		return csStoService.submitCsSto(ipCsStoDTO);
	}

	@RequestMapping(value = "/getCsStoDropDowns.do", method = RequestMethod.POST)
	public PmgtStoDropDownDTO getCsStoDropDowns(@RequestBody CsStoDTO ipCsStoDTO) {
		return csStoService.getCsStoDropDowns(ipCsStoDTO);
	}

	@RequestMapping(value = "/getDeliveryTrackCsSto.do", method = RequestMethod.POST)
	public CsStoDTO getDeliveryTrackCsSto(@RequestBody CsStoDTO ipCsStoDTO) {
		return csStoService.getDeliveryTrackCsSto(ipCsStoDTO);
	}
	
	@RequestMapping(value = "/stoCsDelBydeliveryNum.do", method = RequestMethod.POST)
	public CsStoDTO stoCsDelBydeliveryNum(@RequestBody CsStoDTO ipCsStoDTO) {
		return csStoService.stoCsDelBydeliveryNum(ipCsStoDTO);
	}

	@RequestMapping(value = "/saveDeliverTrackCsSto.do", method = RequestMethod.POST)
	public CsStoDTO saveDeliverTrackCsSto(@RequestBody CsStoDTO ipCsStoDTO) {
		return csStoService.saveDeliverTrackCsSto(ipCsStoDTO);
	}

	@RequestMapping(value = "/uploadfileCsSto.do", method = RequestMethod.POST)
	public CsStoPodUploadDetailsDTO uploadfileCsSto(MultipartHttpServletRequest request,
			@RequestParam String fileTypeMstId, @RequestParam String stoCsDeliveryId,
			@RequestParam String createdBy) {
		Iterator<String> fileNames = request.getFileNames();
		CsStoPodUploadDetailsDTO podUploadDetailsDTO = null;
		if (fileNames.hasNext()) {
			MultipartFile file = request.getFile(fileNames.next());
			podUploadDetailsDTO = csStoService.uploadfileCsSto(file, fileTypeMstId, stoCsDeliveryId,
					createdBy);
		}

		return podUploadDetailsDTO;

	}

	@RequestMapping(value = "/getUpPodFileDetCsSto.do", method = RequestMethod.POST)
	public CsStoPodUploadDetailsDTO getUpPodFileDetCsSto(
			@RequestBody CsStoPodUploadDetailsDTO podUploadDetailsDTO) {

		podUploadDetailsDTO = csStoService.getUpPodFileDetCsSto(podUploadDetailsDTO.getStoCsDeliveryId());

		return podUploadDetailsDTO;

	}
	
	@RequestMapping(value = "/downloadCsStoDelId.do", method = {RequestMethod.POST,RequestMethod.GET})
	@CrossOrigin
	public void getSTOCsDeliveryById(HttpServletRequest request, HttpServletResponse response,@RequestParam String stoCsDeliveryId) {
		try {
			csStoService.downloadCsStoDelById(request,response,stoCsDeliveryId);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		}
	
}
