/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.PreBidTaskResponse;

/**
 * @author Amol.l
 *
 */
public class PreBidTaskResponseDTO implements Serializable {
	private static final long serialVersionUID = 24L;
	
	private Integer opportunityId;
	private Integer userMstId;
	private String opportunityName;
	private List<PreBidTaskResponse> preBidTaskResponseList = new ArrayList<PreBidTaskResponse>();
		
	public String getOpportunityName() {
		return opportunityName;
	}
	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}
	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public List<PreBidTaskResponse> getPreBidTaskResponseList() {
		return preBidTaskResponseList;
	}
	public void setPreBidTaskResponseList(List<PreBidTaskResponse> preBidTaskResponseList) {
		this.preBidTaskResponseList = preBidTaskResponseList;
	}
	

}
