package com.nelco.o2c.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Immutable
@Table(name="customer_sapmst_billing")
public class CustomerMstBilling {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id",updatable=false,nullable=false)
	private Integer id;
	
	@Column(name="customer_num")
	private String customerNum;
	
	@Column(name="customer_name")
	private String customerName;
	
	@Column(name="city_name")
	private String cityName;
	
	@Column(name="region_code")
	private String regionCode;

	public CustomerMstBilling() {}
	
	
	
	
	public CustomerMstBilling(String customerNum, String customerName, String cityName, String regionCode) {
		this.customerNum = customerNum;
		this.customerName = customerName;
		this.cityName = cityName;
		this.regionCode = regionCode;
	}




	public Integer getId() {
		return id;
	}

	public void setCountryMstId(Integer id) {
		this.id = id;
	}

	public String getCustomerNum() {
		return customerNum;
	}

	public void setCustomerNum(String customerNum) {
		this.customerNum = customerNum;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	
}
