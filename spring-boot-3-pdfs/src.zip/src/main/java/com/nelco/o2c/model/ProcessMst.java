package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the process_mst database table.
 * 
 */
@Entity
@Table(name="process_mst")
@NamedQueries({
@NamedQuery(name="ProcessMst.findAll", query="SELECT p FROM ProcessMst p")/*,@NamedQuery(name="ProcessMst.getFileProcessUploadDetails", query="SELECT pm FROM ProcessMst pm inner join pm.fileProcValMst")*/})
public class ProcessMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="process_mst_id")
	private Integer processMstId;

	@Column(name="process_code")
	private String processCode;

	@Column(name="process_name")
	private String processName;
	
//	@ManyToOne(fetch=FetchType.LAZY)
//	@JoinColumn(name="process_mst_id",referencedColumnName="process_mst_id", insertable = false, updatable = false)
//	private FileProcValMst fileProcValMst;

	public Integer getProcessMstId() {
		return processMstId;
	}

	public void setProcessMstId(Integer processMstId) {
		this.processMstId = processMstId;
	}

	public String getProcessCode() {
		return processCode;
	}

	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

/*	public FileProcValMst getFileProcValMst() {
		return fileProcValMst;
	}

	public void setFileProcValMst(FileProcValMst fileProcValMst) {
		this.fileProcValMst = fileProcValMst;
	}

	@Override
	public String toString() {
		return "ProcessMst [processMstId=" + processMstId + ", processCode=" + processCode + ", processName="
				+ processName + ", fileProcValMst=" + fileProcValMst + "]";
	}
	
	*/

}