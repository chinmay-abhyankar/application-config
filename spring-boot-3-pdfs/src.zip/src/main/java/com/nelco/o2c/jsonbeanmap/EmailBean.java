/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

/**
 * @author Jayashankar.r
 *
 */
public class EmailBean {

	private String toMail;
	private String emailBody;
	private String subject;
	private String copyRecepients;
	private String fileAttachments;

	public String getToMail() {
		return toMail;
	}

	public void setToMail(String toMail) {
		this.toMail = toMail;
	}

	public String getEmailBody() {
		return emailBody;
	}

	public void setEmailBody(String emailBody) {
		this.emailBody = emailBody;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getCopyRecepients() {
		return copyRecepients;
	}

	public void setCopyRecepients(String copyRecepients) {
		this.copyRecepients = copyRecepients;
	}

	public String getFileAttachments() {
		return fileAttachments;
	}

	public void setFileAttachments(String fileAttachments) {
		this.fileAttachments = fileAttachments;
	}

}
