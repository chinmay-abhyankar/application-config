/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

/**
 * @author Jayashankar.r
 *
 */
public class TafApprovalBean {
	private Integer tafId;
	private String tafStatusCode;
	
	public Integer getTafId() {
		return tafId;
	}
	public void setTafId(Integer tafId) {
		this.tafId = tafId;
	}
	public String getTafStatusCode() {
		return tafStatusCode;
	}
	public void setTafStatusCode(String tafStatusCode) {
		this.tafStatusCode = tafStatusCode;
	}
	
	
}
