package com.nelco.o2c.dto;

public class InvoiceSubmissionDTO {
	private String customerNo="";
	private String customerName="";
	private String invoiceNo="";
	private String invoiceDate="";
	private String submissionDate="";
	private String outstandingAmt="";
	private String submissionDueDate="";
	private String invoiceType="";
	private String billingDate="";
	private String soNo="";
	private String checkStatus="";
	private String cancellationStatus="";
	private String cancellationStatusCode="";
	private String requestId="";
	private String submissionStatus="";
	private String companyCode="";
	private int rowNumber=0;
	
	public InvoiceSubmissionDTO(String customerNo,String customerName
			,String invoiceNo,String invoiceDate,String submissionDate,String outstandingAmt,String submissionDueDate,String invoiceType,String billingDate,String soNo,String checkStatus,String cancellationStatus,String cancellationStatusCode,String requestId,String submissionStatus,String companyCode,int rowNumber){
		this.customerNo=customerNo;
		this.customerName=customerName;
		this.invoiceNo=invoiceNo;
		this.invoiceDate=invoiceDate;
		this.submissionDate=submissionDate;
		this.outstandingAmt=outstandingAmt;
		this.submissionDueDate=submissionDueDate;
		this.invoiceType=invoiceType;
		this.billingDate=billingDate;
		this.soNo=soNo;
		this.checkStatus=checkStatus;
		this.cancellationStatus=cancellationStatus;
		this.cancellationStatusCode=cancellationStatusCode;
		this.requestId=requestId;
		this.submissionStatus=submissionStatus;
		this.companyCode=companyCode;
		this.rowNumber=rowNumber;
	}
	
	public int getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}

	public String getSubmissionStatus() {
		return submissionStatus;
	}

	public void setSubmissionStatus(String submissionStatus) {
		this.submissionStatus = submissionStatus;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getCancellationStatus() {
		return cancellationStatus;
	}

	public void setCancellationStatus(String cancellationStatus) {
		this.cancellationStatus = cancellationStatus;
	}

	public String getCancellationStatusCode() {
		return cancellationStatusCode;
	}

	public void setCancellationStatusCode(String cancellationStatusCode) {
		this.cancellationStatusCode = cancellationStatusCode;
	}

	public String getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}

	public String getBillingDate() {
		return billingDate;
	}

	public void setBillingDate(String billingDate) {
		this.billingDate = billingDate;
	}

	public String getSoNo() {
		return soNo;
	}

	public void setSoNo(String soNo) {
		this.soNo = soNo;
	}

	public String getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getSubmissionDate() {
		return submissionDate;
	}
	public void setSubmissionDate(String submissionDate) {
		this.submissionDate = submissionDate;
	}
	public String getOutstandingAmt() {
		return outstandingAmt;
	}
	public void setOutstandingAmt(String outstandingAmt) {
		this.outstandingAmt = outstandingAmt;
	}
	public String getSubmissionDueDate() {
		return submissionDueDate;
	}
	public void setSubmissionDueDate(String submissionDueDate) {
		this.submissionDueDate = submissionDueDate;
	}
	public String getInvoiceType() {
		return invoiceType;
	}
	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}
	
}
