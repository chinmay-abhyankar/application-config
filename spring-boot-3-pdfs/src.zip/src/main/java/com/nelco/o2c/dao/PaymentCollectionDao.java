package com.nelco.o2c.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.nelco.o2c.dto.PaymentCollectionBreakupDTO;
import com.nelco.o2c.dto.PaymentCollectionDTO;
import com.nelco.o2c.model.PaymentCollectionCustomerwise;
import com.nelco.o2c.model.PaymentCollectionInvoicewise;


public interface PaymentCollectionDao {

	List<PaymentCollectionDTO> getInvoiceListForSubmission(HttpServletRequest request);

	List<PaymentCollectionBreakupDTO> getPaymentCollectionBreakupList(HttpServletRequest request);

	PaymentCollectionCustomerwise submitPaymentDetails(PaymentCollectionCustomerwise requestDetails);

	PaymentCollectionInvoicewise submitInvoicewisePaymentBreakup(PaymentCollectionInvoicewise breakupDetails);

}
