/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.DrfInfoDTO;
import com.nelco.o2c.dto.FileUploadDTO;
import com.nelco.o2c.dto.PotentialInfoDTO;
import com.nelco.o2c.model.DrfDetails;
import com.nelco.o2c.model.DrfStatusTracker;
import com.nelco.o2c.model.DrfUploadDetail;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.Opportunity;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Amol.l
 *
 */
@Repository
public class PotentialInfoDaoImpl implements PotentialInfoDao {

	@PersistenceContext
	EntityManager em;

	Query query;

	@Override
	public List<OppDetails> amPotentialInfo(PotentialInfoDTO potentialInfoDTO) {
		// TODO Auto-generated method stub

		try {
			query = em.createNamedQuery("OppDetails.amPotentialInfo");
			query.setParameter(1, potentialInfoDTO.getSmOwnerId());
			query.setParameter(2, potentialInfoDTO.getFromDate());
			query.setParameter(3, potentialInfoDTO.getToDate()+" 23:59:59");
			@SuppressWarnings("unchecked")
			List<OppDetails> opportunityDetObj = (List<OppDetails>) query.getResultList();
			// potentialInfoDTO.setOpportunityList(opportunityObj);
//			return opportunityObj != null && opportunityObj.size() > 0 ? opportunityObj.get(0) : null;
			return opportunityDetObj;
//			return potentialInfoListDTO.setPotentialInfoDTOList(potentialInfoDTOList);;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<OppDetails>();
		} finally {
			em.close();
		}

	}

	@Override
	public Opportunity getOpportunityByZohoId(String zohoId) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("Opportunity.getOpportunityByzohoId");
			query.setParameter(1, zohoId);
			Opportunity opportunity = (Opportunity) query.getSingleResult();
			return opportunity;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new Opportunity();
		} finally {
			em.close();
		}

	}
	
	@Override
	public Opportunity getOpportunityByOpId(String opportunityId) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("Opportunity.getOpportunityByOpId");
			query.setParameter(1, opportunityId);
			Opportunity opportunity = (Opportunity) query.getSingleResult();
			return opportunity;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new Opportunity();
		} finally {
			em.close();
		}

	}
	

	@Override
	public List<DrfDetails> amDrfInfoByOppId(DrfInfoDTO drfInfoDTO) {
		// TODO Auto-generated method stub
		try {
			// query = em.createNamedQuery("DrfDetails.accountManagerDrfInfo");
			String queryString = "select dd from DrfDetails dd inner join dd.opportunity where dd.opportunityId =?1 ";

			if (drfInfoDTO.getRoleCode().equalsIgnoreCase(Constants.ACCOUNTMANAGERCODE)) {
				queryString = queryString + " and dd.accMgr=?2";
				query = em.createQuery(queryString);
				query.setParameter(1, drfInfoDTO.getOpportunityId());
				query.setParameter(2, drfInfoDTO.getUserMstId());
			} else if (drfInfoDTO.getRoleCode().equalsIgnoreCase(Constants.PRESALESMGRCODE)) {
				queryString = queryString + " and dd.preSalesResName=?2";
				query = em.createQuery(queryString);
				query.setParameter(1, drfInfoDTO.getOpportunityId());
				query.setParameter(2, drfInfoDTO.getUserMstId());
			} else if (drfInfoDTO.getRoleCode().equalsIgnoreCase(Constants.PRESALESHEADCODE)) {
				queryString = queryString + " and dd.preSalesHead=?2";
				query = em.createQuery(queryString);
				query.setParameter(1, drfInfoDTO.getOpportunityId());
				query.setParameter(2, drfInfoDTO.getUserMstId());
			} else if (drfInfoDTO.getRoleCode().equalsIgnoreCase(Constants.OPERATIONSHEADCODE)) {
				queryString = queryString + " and dd.opHead=?2";
				query = em.createQuery(queryString);
				query.setParameter(1, drfInfoDTO.getOpportunityId());
				query.setParameter(2, drfInfoDTO.getUserMstId());
			} else if (drfInfoDTO.getRoleCode().equalsIgnoreCase(Constants.PMGTHEADCODE)) {
				queryString = queryString + " and dd.pmgtHead=?2";
				query = em.createQuery(queryString);
				query.setParameter(1, drfInfoDTO.getOpportunityId());
				query.setParameter(2, drfInfoDTO.getUserMstId());
			} else {
				query = em.createQuery(queryString);
				query.setParameter(1, drfInfoDTO.getOpportunityId());
			}

//			if(drfInfoDTO.getRoleCode().equalsIgnoreCase(Constants.SALESCOORDCODE)) {
//				queryString = queryString+" preSalesResName=?2";
//			}

			@SuppressWarnings("unchecked")
			List<DrfDetails> drfDetails = (List<DrfDetails>) query.getResultList();
			return drfDetails;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<DrfDetails>();
		} finally {
			em.close();
		}
	}
	
//	DrfDetails.drfInfoforHeadlogins

	@Override
	public DrfDetails saveDrfDetails(DrfDetails drfDetails) {
		// TODO Auto-generated method stub
		return em.merge(drfDetails);
	}

	@Override
	public DrfStatusTracker saveDrfStatusTracker(DrfStatusTracker drfStatusTracker) {
		// TODO Auto-generated method stub
		return em.merge(drfStatusTracker);
	}

	@Override
	public DrfDetails getDrfDetailsByDrfId(Integer drfDetailsId) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("DrfDetails.getDrfInfoByDrfId");
			query.setParameter(1, drfDetailsId);
			DrfDetails drfDetails = (DrfDetails) query.getSingleResult();
			List<DrfStatusTracker> drfStatusTrackerList = drfDetails.getDrfStatusTrackerList()!=null?drfDetails.getDrfStatusTrackerList():new ArrayList<DrfStatusTracker>();
			
			int statusTrackerSize = drfStatusTrackerList.size();
			if(statusTrackerSize>0) {
				List<DrfStatusTracker> drfStatusTrackerListNew = new ArrayList<DrfStatusTracker>();
				drfStatusTrackerListNew.add(drfStatusTrackerList.get(statusTrackerSize-1));
				drfDetails.setDrfStatusTrackerList(drfStatusTrackerListNew);
			}
			
			return drfDetails;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new DrfDetails();
		} finally {
			em.close();
		}

	}

	@Override
	public DrfStatusTracker getDrfStatusTrackerDetailsByDrfId(Integer drfDetailsId,Integer statusTrackerId) {
		// TODO Auto-generated method stub

		try {

			DrfStatusTracker drfStatusTracker = null;
			if(statusTrackerId!=null) {
				drfStatusTracker = em.find(DrfStatusTracker.class, statusTrackerId);
			} else {
				query = em.createNamedQuery("DrfStatusTracker.getDrfStatusTrackerDetailsByDrfId");
				query.setParameter(1, drfDetailsId);
				drfStatusTracker = (DrfStatusTracker) query.setMaxResults(1).getResultList().get(0);
			}
			return drfStatusTracker;
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new DrfStatusTracker();
		} finally {
			em.close();
		}
	}

	@Override
	public List<FileTypeMst> getFileProcessUploadDetails(FileUploadDTO fileUploadDTO) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("FileProcValMst.getFileProcessUploadDetailsForDRF");
			@SuppressWarnings("unchecked")
			List<FileTypeMst> fileTypeMstList = (List<FileTypeMst>) query.getResultList();
			return fileTypeMstList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<FileTypeMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public DrfUploadDetail saveDrfUploadDetails(DrfUploadDetail drfUploadDetail) {
		// TODO Auto-generated method stub
		return em.merge(drfUploadDetail);
	}

	@Override
	public DrfUploadDetail getDrfUploadDetailsBydrfUpDetailsId(Integer drfUpDetailsId) {
		try {

			query = em.createNamedQuery("DrfUploadDetail.getDrfUploadDetailsBydrfUpDetailsId");
			query.setParameter(1, drfUpDetailsId);
			DrfUploadDetail drfUploadDetail = (DrfUploadDetail) query.getSingleResult();
			return drfUploadDetail;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new DrfUploadDetail();
		} finally {
			em.close();
		}
	}

	@Override
	public List<DrfDetails> drfInfoforHeadlogins(Integer opportunityId) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		try {
			if(opportunityId!=null) {
				query = em.createNamedQuery("DrfDetails.drfInfoforHeadlogins");
				query.setParameter(1, opportunityId);
			} else {
				query = em.createNamedQuery("DrfDetails.drfInfoforHeadloginsWithoutOppId");
			}
			
			@SuppressWarnings("unchecked")
			List<DrfDetails> drfDetails = (List<DrfDetails>) query.getResultList();
			return drfDetails;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<DrfDetails>();
		} finally {
			em.close();
		}
	
	}

	@Override
	public void saveUploadUploadDetails(List<DrfUploadDetail> drfUploadDetailList) {
		// TODO Auto-generated method stub
		for (DrfUploadDetail drfUploadDetail : drfUploadDetailList) {
			drfUploadDetail.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
			em.merge(drfUploadDetail);
		}
	}
	
	

}
