/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.Contract;

/**
 * @author Amol.l
 *
 */
public class ContractDTO implements Serializable {
	
	private static final long serialVersionUID = 27L;
	private Integer contractId;
	private String proposalId;
	private Contract contract = new Contract();
	private String isSave;
	private List<Contract> masterContracts = new ArrayList<Contract>();
	public Integer getContractId() {
		return contractId;
	}
	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public Contract getContract() {
		return contract;
	}
	public void setContract(Contract contract) {
		this.contract = contract;
	}
	public String getIsSave() {
		return isSave;
	}
	public void setIsSave(String isSave) {
		this.isSave = isSave;
	}
	public List<Contract> getMasterContracts() {
		return masterContracts;
	}
	public void setMasterContracts(List<Contract> masterContracts) {
		this.masterContracts = masterContracts;
	};
		
		
}
