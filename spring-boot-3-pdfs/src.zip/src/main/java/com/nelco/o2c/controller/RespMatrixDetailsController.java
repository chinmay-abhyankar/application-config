/**
 * 
 */
package com.nelco.o2c.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.EmailDocDTO;
import com.nelco.o2c.dto.OppUploadDetailDTO;
import com.nelco.o2c.dto.PotentialInfoListDTO;
import com.nelco.o2c.dto.PreSalesRespMatrixDTO;
import com.nelco.o2c.dto.RespMatrixDetailsDTO;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.service.RespMatrixDetailsService;

/**
 * @author Amol.l
 *
 */
@RestController
public class RespMatrixDetailsController {

	@Autowired
	RespMatrixDetailsService respMatrixDetailsService;

	@RequestMapping(value = "/getRespMatrix.do", method = RequestMethod.POST)
	public PotentialInfoListDTO getRespMatrix(@RequestBody CommonDTO commonDTO) {
		return respMatrixDetailsService.getRespMatrix(commonDTO);
	}

	@RequestMapping(value = "/getRespMatrixDetByUserMstIdAndOpId.do", method = RequestMethod.POST)
	public RespMatrixDetailsDTO getRespMatrixDetByUserMstIdAndOpId(
			@RequestBody RespMatrixDetailsDTO respMatrixDetailsDTO) {
//		System.out.println(request.getRequestURL().toString().replace(request.getRequestURI(), "").concat(request.getContextPath()).concat("/"));
		return respMatrixDetailsService.getRespMatrixDetByUserMstIdAndOpId(respMatrixDetailsDTO);
	}

	@RequestMapping(value = "/saveRespMatrixDetails.do", method = RequestMethod.POST)
	public RespMatrixDetailsDTO saveRespMatrixDetails(@RequestBody RespMatrixDetailsDTO respMatrixDetailsDTO,
			HttpServletRequest request) {
		respMatrixDetailsService.saveRespMatrixDetails(respMatrixDetailsDTO, request);

		return respMatrixDetailsService.getRespMatrixDetByUserMstIdAndOpId(respMatrixDetailsDTO);

	}

	@RequestMapping(value = "/checkRiskDocuments.do", method = RequestMethod.POST)
	public OppUploadDetailDTO checkRiskDocuments(@RequestBody OppUploadDetail oppUploadDetail) {

		return respMatrixDetailsService.checkRiskDocuments(oppUploadDetail);

	}

	@RequestMapping(value = "/sendUploadDoc.do", method = RequestMethod.POST)
	public EmailDocDTO sendUploadDoc(@RequestBody EmailDocDTO emailDocDTO, HttpServletRequest request) {

		return respMatrixDetailsService.sendUploadDoc(emailDocDTO, request);

	}

	@RequestMapping(value = "/PSMgrBidTasks.do", method = RequestMethod.POST)
	public PotentialInfoListDTO PSMgrBidTasks(@RequestBody CommonDTO commonDTO) {
		return respMatrixDetailsService.PSMgrBidTasks(commonDTO);
	}

	@RequestMapping(value = "/getPSMRespMatrixByUserMstIdAndOpId.do", method = RequestMethod.POST)
	public PreSalesRespMatrixDTO getPSMRespMatrixByUserMstIdAndOpId(
			@RequestBody PreSalesRespMatrixDTO preSalesRespMatrixDTO) {
//		System.out.println(request.getRequestURL().toString().replace(request.getRequestURI(), "").concat(request.getContextPath()).concat("/"));
		return respMatrixDetailsService.getPSMRespMatrixByUserMstIdAndOpId(preSalesRespMatrixDTO);
	}

	@RequestMapping(value = "/savePSMRespMatrixDetails.do", method = RequestMethod.POST)
	public PreSalesRespMatrixDTO savePSMRespMatrixDetails(@RequestBody PreSalesRespMatrixDTO preSalesRespMatrixDTO,
			HttpServletRequest request) {
		respMatrixDetailsService.savePSMRespMatrixDetails(preSalesRespMatrixDTO, request);

		return respMatrixDetailsService.getPSMRespMatrixByUserMstIdAndOpId(preSalesRespMatrixDTO);

	}

}