package com.nelco.o2c.dto;

public class ReactivationOnCRDTO {

}
