/**
 * 
 */
package com.nelco.o2c.dao;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nelco.o2c.jsonbeanmap.EmailBean;
import com.nelco.o2c.model.ChildContract;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class CallSpDaoImpl implements CallSpDao {

	@PersistenceContext
	private EntityManager em;

	StoredProcedureQuery query;

	@Transactional
	@Override
	public void sendEmail(EmailBean emailBean) {
		try {
			// TODO Auto-generated method stub
			query = em.createStoredProcedureQuery("sp_send_mail")
					.registerStoredProcedureParameter("tomail", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("emailbody", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("subject", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("copy_recipents", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("file_attachments", String.class, ParameterMode.IN);
			query.setParameter("tomail", emailBean.getToMail()).setParameter("emailbody", emailBean.getEmailBody())
					.setParameter("subject", emailBean.getSubject())
					.setParameter("copy_recipents", emailBean.getCopyRecepients())
					.setParameter("file_attachments", emailBean.getFileAttachments());
			query.execute();
			System.out.println("Call procedure Email");
			//System.out.println("Output Parameter -----" + query.getSingleResult().toString());
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public void callContractGenSp() {
		try {
			// TODO Auto-generated method stub
			query = em.createStoredProcedureQuery("sp_generate_contract_csv");
			query.execute();
			System.out.println("Called Contract generation procedure");
			//System.out.println("Output Parameter -----" + query.getSingleResult().toString());
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public void callContGenProcBychildConId(ChildContract childContract) {
		try {
			// TODO Auto-generated method stub
			query = em.createStoredProcedureQuery("isp_gen_cont_csv_by_child_con_id")
					.registerStoredProcedureParameter("childContractId", Integer.class, ParameterMode.IN);
			query.setParameter("childContractId", childContract.getChildContractId());
			query.execute();
			System.out.println("Called Contract generation procedure By Child contract ID");
			//System.out.println("Output Parameter -----" + query.getSingleResult().toString());
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public void callIspEmailToFinanceFirBillCreation(Integer firId, String firUniqId) {
		// TODO Auto-generated method stub
		try {
			query = em.createStoredProcedureQuery("isp_email_to_finance_fir_bill_creation")
					.registerStoredProcedureParameter("firId", Integer.class, ParameterMode.IN)
					.registerStoredProcedureParameter("firUniqId", String.class, ParameterMode.IN);
			query.setParameter("firId", firId);
			query.setParameter("firUniqId", firUniqId);
			query.execute();
			System.out.println("Called callIspEmailToFinanceFirBillCreation successfully");
		} finally {
			em.close();
		}
	}

}
