package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;

/**
 * The persistent class for the sto_pmgt database table.
 * 
 */
@Entity
@Table(name = "sto_pmgt")
@NamedQueries({ @NamedQuery(name = "StoPmgt.findAll", query = "SELECT s FROM StoPmgt s"),
		@NamedQuery(name = "StoPmgt.getStoPmgtListPm", query = "SELECT s FROM StoPmgt s where s.createdDate between ?1 and ?2 and s.reqById=?3 "),
		@NamedQuery(name = "StoPmgt.getStoPmgtListStores", query = "SELECT s FROM StoPmgt s where s.createdDate between ?1 and ?2 and s.storeUserId=?3 and s.stoPmSubmit = 'Y'"),
		@NamedQuery(name = "StoPmgt.getStoPmgtListPmgtCoord", query = "SELECT s FROM StoPmgt s where s.createdDate between ?1 and ?2 and s.pmgtCoordId=?3 "),
		@NamedQuery(name = "StoPmgt.findByCreatedDate", query = "SELECT s FROM StoPmgt s where s.createdDate between ?1 and ?2 "),
		@NamedQuery(name = "StoPmgt.updatePmSubmit", query = " update StoPmgt s set s.stoReqTime=?1, s.stoPmSubmit = 'Y', s.statusMstId=?2 where s.stoPmgtId=?3 "),
		@NamedQuery(name = "StoPmgt.updateStoresSubmit", query = " update StoPmgt s set s.storesUpdateTime=?1, s.stoStoresSubmit = 'Y', s.statusMstId=?2 where s.stoPmgtId=?3 "),
		@NamedQuery(name = "StoPmgt.getCurrentDayMaxCount", query = " select (count(s)+1) from StoPmgt s where s.createdDate between ?1 and ?2 "),
		@NamedQuery(name = "StoPmgt.getPmgtStoByReqId", query = " SELECT s FROM StoPmgt s where s.stoPmgtGenId = ?1 ")})
public class StoPmgt implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sto_pmgt_id")
	private Integer stoPmgtId;

	@Column(name = "pmgt_coord_id")
	private Integer pmgtCoordId;

	@Column(name = "req_by_id")
	private Integer reqById;

	@Column(name = "sto_pmgt_gen_id")
	private String stoPmgtGenId;

	@Column(name = "sto_req_time")
	private String stoReqTime;

	@Column(name = "store_user_id")
	private Integer storeUserId;

	@Column(name = "stores_update_time")
	private String storesUpdateTime;

	@Column(name = "supply_plant_id")
	private Integer supplyPlantId;

	@Column(name = "sto_pm_submit")
	private String stoPmSubmit = "N";

	@Column(name = "stoStoresSubmit")
	private String stoStoresSubmit = "N";

	@Column(name = "created_date", updatable = false)
	private String createdDate;

	@Column(name = "finance_id")
	private Integer financeId;

	@Column(name = "status_mst_id")
	private Integer statusMstId;
	
	@Column(name = "pr_no")
	private String prNo;
	
	@Column(name = "po_num")
	private String poNum;

	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "sto_pmgt_id", referencedColumnName = "sto_pmgt_id", insertable = false, updatable = false)
	private List<StoPmgtMaterial> stoPmgtMaterialList = new ArrayList<StoPmgtMaterial>();

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "status_mst_id", referencedColumnName = "status_mst_id", insertable = false, updatable = false)
	private StatusMst statusMst;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "supply_plant_id", referencedColumnName = "plant_sapmst_id", insertable = false, updatable = false)
	private PlantSapmst plantSapmst;
	
	public String getPrNo() {
		return prNo;
	}

	public void setPrNo(String prNo) {
		this.prNo = prNo;
	}

	public PlantSapmst getPlantSapmst() {
		return plantSapmst;
	}

	public void setPlantSapmst(PlantSapmst plantSapmst) {
		this.plantSapmst = plantSapmst;
	}

	public StatusMst getStatusMst() {
		return statusMst;
	}

	public void setStatusMst(StatusMst statusMst) {
		this.statusMst = statusMst;
	}

	public Integer getStatusMstId() {
		return statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}

	public List<StoPmgtMaterial> getStoPmgtMaterialList() {
		return stoPmgtMaterialList;
	}

	public void setStoPmgtMaterialList(List<StoPmgtMaterial> stoPmgtMaterialList) {
		this.stoPmgtMaterialList = stoPmgtMaterialList;
	}

	public Integer getFinanceId() {
		return financeId;
	}

	public void setFinanceId(Integer financeId) {
		this.financeId = financeId;
	}

	public String getCreatedDate() {
		return DateUtil.convertDateTimeToString(this.createdDate);
		// return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getStoPmgtId() {
		return stoPmgtId;
	}

	public void setStoPmgtId(Integer stoPmgtId) {
		this.stoPmgtId = stoPmgtId;
	}

	public Integer getPmgtCoordId() {
		return pmgtCoordId;
	}

	public void setPmgtCoordId(Integer pmgtCoordId) {
		this.pmgtCoordId = pmgtCoordId;
	}

	public Integer getReqById() {
		return reqById;
	}

	public void setReqById(Integer reqById) {
		this.reqById = reqById;
	}

	public String getStoPmgtGenId() {
		return stoPmgtGenId;
	}

	public void setStoPmgtGenId(String stoPmgtGenId) {
		this.stoPmgtGenId = stoPmgtGenId;
	}

	public String getStoReqTime() {
		return stoReqTime;
	}

	public void setStoReqTime(String stoReqTime) {
		this.stoReqTime = stoReqTime;
	}

	public Integer getStoreUserId() {
		return storeUserId;
	}

	public void setStoreUserId(Integer storeUserId) {
		this.storeUserId = storeUserId;
	}

	public String getStoresUpdateTime() {
		return storesUpdateTime;
	}

	public void setStoresUpdateTime(String storesUpdateTime) {
		this.storesUpdateTime = storesUpdateTime;
	}

	public Integer getSupplyPlantId() {
		return supplyPlantId;
	}

	public void setSupplyPlantId(Integer supplyPlantId) {
		this.supplyPlantId = supplyPlantId;
	}

	public String getStoPmSubmit() {
		return stoPmSubmit;
	}

	public void setStoPmSubmit(String stoPmSubmit) {
		this.stoPmSubmit = stoPmSubmit;
	}

	public String getStoStoresSubmit() {
		return stoStoresSubmit;
	}

	public void setStoStoresSubmit(String stoStoresSubmit) {
		this.stoStoresSubmit = stoStoresSubmit;
	}

	public String getPoNum() {
		return poNum;
	}

	public void setPoNum(String poNum) {
		this.poNum = poNum;
	}
	
}