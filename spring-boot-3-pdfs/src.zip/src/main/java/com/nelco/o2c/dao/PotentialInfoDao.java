/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.DrfInfoDTO;
import com.nelco.o2c.dto.FileUploadDTO;
import com.nelco.o2c.dto.PotentialInfoDTO;
import com.nelco.o2c.model.DrfDetails;
import com.nelco.o2c.model.DrfStatusTracker;
import com.nelco.o2c.model.DrfUploadDetail;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.Opportunity;

/**
 * @author Amol.l
 *
 */
public interface PotentialInfoDao {

	public List<OppDetails> amPotentialInfo(PotentialInfoDTO potentialInfoDTO);

	public Opportunity getOpportunityByZohoId(String zohoId);

	public List<DrfDetails> amDrfInfoByOppId(DrfInfoDTO drfInfoDTO);
	
	public  List<DrfDetails> drfInfoforHeadlogins(Integer opportunityId);

	public DrfDetails saveDrfDetails(DrfDetails drfDetails);

	public DrfStatusTracker saveDrfStatusTracker(DrfStatusTracker drfStatusTracker);

	public DrfDetails getDrfDetailsByDrfId(Integer drfDetailsId);
	
	public DrfStatusTracker getDrfStatusTrackerDetailsByDrfId(Integer drfDetailsId,Integer statusTrackerId);
	
	public List<FileTypeMst> getFileProcessUploadDetails(FileUploadDTO fileUploadDTO);
	
	public DrfUploadDetail saveDrfUploadDetails(DrfUploadDetail drfUploadDetail);
	
	public DrfUploadDetail getDrfUploadDetailsBydrfUpDetailsId(Integer drfUpDetailsId);

	public Opportunity getOpportunityByOpId(String opportunityId);

	public void saveUploadUploadDetails(List<DrfUploadDetail> drfUploadDetailList);
	
}
