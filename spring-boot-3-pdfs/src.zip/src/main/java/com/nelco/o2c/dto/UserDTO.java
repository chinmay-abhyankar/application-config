package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.UserRegionMaster;
import com.nelco.o2c.model.UserToFranchisee;

/**
 * @author Chinmay A
 *
 */

public class UserDTO implements Serializable {

	private static final long serialVersionUID = 34L;

	private Integer userMstId;
	private String userName;
	private String email;
	private Integer deptMstId;
	private String deptCode;
	private String deptName;
	private String subDeptMstId;
	private String subDeptCode;
	private String subDeptName;
	private Integer roleMstId;
	private String roleCode;
	private String roleDesc;
	private String stateMstId;
	private String stateName;
	private String stateCode;
	private Integer zoneMstId;
	private String zoneMstCode;
	private String zoneDesc;
	private String isHeadFlag;
	private String loginId;
	private String password;
	private String smOwnerId;
	private String orgCode;
	private String createdDate;
	private String updatedDate;
	private Character isActive;
	
	private Integer hubMstId;
	private String hubCode;
	private Integer franchiseMstId;

	
	public Integer getHubMstId() {
		return hubMstId;
	}
	public void setHubMstId(Integer hubMstId) {
		this.hubMstId = hubMstId;
	}
	public String getHubCode() {
		return hubCode;
	}
	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}
	
	public String getStateMstId() {
		return stateMstId;
	}
	public void setStateMstId(String stateMstId) {
		this.stateMstId = stateMstId;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getSubDeptName() {
		return subDeptName;
	}
	public void setSubDeptName(String subDeptName) {
		this.subDeptName = subDeptName;
	}
	public String getRoleDesc() {
		return roleDesc;
	}
	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}
	public String getZoneDesc() {
		return zoneDesc;
	}
	public void setZoneDesc(String zoneDesc) {
		this.zoneDesc = zoneDesc;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getDeptMstId() {
		return deptMstId;
	}
	public void setDeptMstId(Integer deptMstId) {
		this.deptMstId = deptMstId;
	}
	public String getSubDeptMstId() {
		return subDeptMstId;
	}
	public void setSubDeptMstId(String subDeptMstId) {
		this.subDeptMstId = subDeptMstId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public Integer getZoneMstId() {
		return zoneMstId;
	}
	public void setZoneMstId(Integer zoneMstId) {
		this.zoneMstId = zoneMstId;
	}
	public String getIsHeadFlag() {
		return isHeadFlag;
	}
	public void setIsHeadFlag(String isHeadFlag) {
		this.isHeadFlag = isHeadFlag;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSmOwnerId() {
		return smOwnerId;
	}
	public void setSmOwnerId(String smOwnerId) {
		this.smOwnerId = smOwnerId;
	}
	public String getOrgCode() {
		return orgCode;
	}
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getRoleMstId() {
		return roleMstId;
	}
	public void setRoleMstId(Integer roleMstId) {
		this.roleMstId = roleMstId;
	}

	public Character getIsActive() {
		return isActive;
	}
	public void setIsActive(Character isActive) {
		this.isActive = isActive;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	public String getSubDeptCode() {
		return subDeptCode;
	}
	public void setSubDeptCode(String subDeptCode) {
		this.subDeptCode = subDeptCode;
	}
	public String getZoneMstCode() {
		return zoneMstCode;
	}
	public void setZoneMstCode(String zoneMstCode) {
		this.zoneMstCode = zoneMstCode;
	}
	public Integer getFranchiseMstId() {
		return franchiseMstId;
	}
	public void setFranchiseMstId(Integer franchiseMstId) {
		this.franchiseMstId = franchiseMstId;
	}
	
}
