/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.model.DrfQueryUserMap;
import com.nelco.o2c.model.Query;
import com.nelco.o2c.model.Response;

/**
 * @author Jayashankar.r
 *
 */
public interface QueryDao {
	
	public List<Query> getQueryDetails(CommonDTO commonDTO);
	
	public com.nelco.o2c.model.Query getQueryDetailsByQuertId(Integer queryId);

	public com.nelco.o2c.model.Query postQuery(Query query);

	public void postResponse(Response response);

	public void updateInsertDrfQueryUserMap(DrfQueryUserMap drfQueryUserMap);
}
