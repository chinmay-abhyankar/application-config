/**
 * 
 */
package com.nelco.o2c.controller;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.URLConnection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aspose.cells.PdfCompliance;
import com.aspose.cells.PdfSaveOptions;
import com.aspose.cells.Workbook;

import com.aspose.email.MailMessage;
import com.aspose.email.SaveOptions;
import com.aspose.words.Document;
import com.aspose.words.LoadFormat;
import com.aspose.words.LoadOptions;
import com.aspose.words.SaveFormat;
import com.nelco.o2c.utility.MyFileNotFoundException;


/**
 * @author Chinmay A
 *
 */
@RestController
public class FileDownloadController implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Autowired
	private Environment env;
	
	//"xlsx", "xls", "pdf", "jpg", "jpeg", "png", "doc", "docx", "msg","txt","jfif","zip"
	@RequestMapping(value="/viewResource.do", method = {RequestMethod.GET,RequestMethod.POST})
	public void viewResource(HttpServletRequest httpServletRequest,HttpServletResponse response,
			@RequestParam("fileName") String fileName) {
		try {
			File file = new File(env.getProperty("finaluploadfolder") + fileName);
			if (file.exists()) {	
				String ext = FilenameUtils.getExtension(fileName);
				String filePath =  env.getProperty("finaluploadfolder") +File.separator + fileName;
				String fileNameWithOutExt = FilenameUtils.removeExtension(fileName);
				String convertedFilePath = env.getProperty("finaluploadfolder") + File.separator+fileNameWithOutExt+".pdf";
				
				switch(ext) {
				case "xlsx":{
					
					Workbook workbook = new Workbook(filePath);

					PdfSaveOptions saveOptions = new PdfSaveOptions();
					//Set the compliance type
					saveOptions.setCompliance(PdfCompliance.PDF_A_1_B); 
					saveOptions.setAllColumnsInOnePagePerSheet(true);
					//Save the document in PDF format
					workbook.save(convertedFilePath,saveOptions);
					display(convertedFilePath,response);
					break;
					}
				case "xls":{
					Workbook workbook = new Workbook(filePath);

					PdfSaveOptions saveOptions = new PdfSaveOptions();
					saveOptions.setCompliance(PdfCompliance.PDF_A_1_B); 
					saveOptions.setAllColumnsInOnePagePerSheet(true);
					
					workbook.save(convertedFilePath,saveOptions);
					display(convertedFilePath,response);
					break;
				}
				case "doc":{
					Document doc = new Document(filePath);
					doc.save(convertedFilePath, com.aspose.words.SaveFormat.PDF);
					display(convertedFilePath,response);
					break;
				}
				case "docx":{
					Document doc = new Document(filePath);
					doc.save(convertedFilePath, com.aspose.words.SaveFormat.PDF);
					display(convertedFilePath,response);
					break;
				}
				case "msg":{
					FileInputStream fstream=new FileInputStream(filePath);
				       MailMessage eml = MailMessage.load(fstream);
				       ByteArrayOutputStream emlStream = new ByteArrayOutputStream();
				       eml.save(emlStream, SaveOptions.getDefaultMhtml());
				 
				       //Load the stream in Word document
				       LoadOptions lo = new LoadOptions();
				       lo.setLoadFormat(LoadFormat.MHTML);
				       Document doc = new Document(new ByteArrayInputStream(emlStream.toByteArray()), lo);
				       doc.save(convertedFilePath, SaveFormat.PDF);
				   		display(convertedFilePath,response);
				   		break;
				}
				default:{
					//"pdf", "jpg", "jpeg", "png","jfif"	
					fileName = filePath;
					display(fileName,response);	
				}
				}
			}
			else {
				throw new MyFileNotFoundException("Requested File Not Found!!!");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void display(String convertedFile,HttpServletResponse response) {
		try {
			File file = new File(convertedFile); 
			String mimeType = URLConnection.guessContentTypeFromName(file.getName());
			if (mimeType == null) {
				
				mimeType = "application/octet-stream";
			}
			response.setContentType(mimeType);
			response.setHeader("Content-Disposition", String.format("inline; filename=\"" + file.getName() + "\""));
			response.setContentLength((int) file.length());
			InputStream inputStream = new BufferedInputStream(new FileInputStream(file));
			FileCopyUtils.copy(inputStream, response.getOutputStream());

		}catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				response.getOutputStream().close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}



