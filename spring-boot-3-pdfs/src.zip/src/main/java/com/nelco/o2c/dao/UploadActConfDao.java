/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.HsoUploadDTO;
import com.nelco.o2c.model.HsoDetail;
import com.nelco.o2c.model.HsoTransactionDetail;

/**
 * @author Jayshankar.r
 *
 */
public interface UploadActConfDao {

	HsoUploadDTO updateHsoTransactionDetails(List<HsoTransactionDetail> transactionDetailsList,List<HsoDetail> hsoDetails);

}
