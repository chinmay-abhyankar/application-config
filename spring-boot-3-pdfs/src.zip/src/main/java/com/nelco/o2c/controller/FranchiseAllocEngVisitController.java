package com.nelco.o2c.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.FrachiseeEngVisitDetailsDTO;
import com.nelco.o2c.dto.VisitCommonDTO;
import com.nelco.o2c.model.FaEngVisitDetail;
import com.nelco.o2c.service.FranchiseeAllocEngVisitService;

@RestController
public class FranchiseAllocEngVisitController {
	@Autowired
	FranchiseeAllocEngVisitService franchiseeAllocEngVisitService;
		
	@RequestMapping(value = "/saveFranchiseAllocVisitDetails.do", method = RequestMethod.POST)
	public FaEngVisitDetail saveVisitDetails(@RequestBody FrachiseeEngVisitDetailsDTO visitCommonDTOInput) {
		return franchiseeAllocEngVisitService.saveFranchiseAllocVisitDetails(visitCommonDTOInput);
	}
	
	@RequestMapping(value = "/submitFranchiseAllocVisitDetails.do", method = RequestMethod.POST)
	public FaEngVisitDetail submitFranchiseAllocVisitDetails(@RequestBody FrachiseeEngVisitDetailsDTO dtoObject) {
		return franchiseeAllocEngVisitService.submitFranchiseAllocVisitDetails(dtoObject);
	}

	@RequestMapping(value = "/getEngineerVisitByFranchiseeAllocId.do", method = RequestMethod.GET)
	public List<FaEngVisitDetail> getEngineerVisitByFranchiseeAllocId(HttpServletRequest request) {
		return franchiseeAllocEngVisitService.getEngineerVisitByFranchiseeAllocId(request);
	}
	
	@RequestMapping(value = "/getFranchiseeAllocVisitById.do", method = RequestMethod.GET)
	public FaEngVisitDetail getFranchiseeAllocEngineerById(HttpServletRequest request) {
		return franchiseeAllocEngVisitService.getFranchiseeAllocEngineerById(request);
	}
}
