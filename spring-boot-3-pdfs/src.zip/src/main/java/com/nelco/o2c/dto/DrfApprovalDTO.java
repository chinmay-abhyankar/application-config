/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

/**
 * @author Jayashankar.r
 *
 */
public class DrfApprovalDTO implements Serializable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<DrfInfoDTO> apprViewList;
	private List<Integer> drfId;

	public List<Integer> getDrfId() {
		return drfId;
	}

	public void setDrfId(List<Integer> drfId) {
		this.drfId = drfId;
	}

	public List<DrfInfoDTO> getApprViewList() {
		return apprViewList;
	}

	public void setApprViewList(List<DrfInfoDTO> apprViewList) {
		this.apprViewList = apprViewList;
	}
	
	
}
