package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.model.StateMst;
import com.nelco.o2c.model.StatusMst;

public interface SiteSurveyReportDao {
	public List<StatusMst> searchStatusByCode(List<String> statusList);
	
	public List<String> searchAllCustomers();
	
	public List<String> searchAllFranchise();

	public List<StateMst> getAllStates();
	
}
