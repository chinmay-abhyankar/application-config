package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the pricing_group_mst database table.
 * 
 */
@Entity
@Table(name="pricing_group_mst")
@NamedQuery(name="PricingGroupMst.findAll", query="SELECT p FROM PricingGroupMst p where p.isActive = 'Y'")
public class PricingGroupMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pricing_group_mst_id")
	private Integer pricingGroupMstId;

	@Column(name="is_active")
	private String isActive;

	@Column(name="pricing_group_code")
	private String pricingGroupCode;

	@Column(name="pricing_group_val")
	private String pricingGroupVal;

	public PricingGroupMst() {
	}

	public Integer getPricingGroupMstId() {
		return this.pricingGroupMstId;
	}

	public void setPricingGroupMstId(Integer pricingGroupMstId) {
		this.pricingGroupMstId = pricingGroupMstId;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getPricingGroupCode() {
		return this.pricingGroupCode;
	}

	public void setPricingGroupCode(String pricingGroupCode) {
		this.pricingGroupCode = pricingGroupCode;
	}

	public String getPricingGroupVal() {
		return this.pricingGroupVal;
	}

	public void setPricingGroupVal(String pricingGroupVal) {
		this.pricingGroupVal = pricingGroupVal;
	}

}