package com.nelco.o2c.dto;

public class PaymentCollectionDTO {
private String customerNo="";
private String customerName="";
private String paymentNo="";
private String collectedAmt="";
private String paymentDate="";
private String userId="";

public PaymentCollectionDTO(String customerNo,String customerName,String paymentNo,String collectedAmt,String paymentDate,String userId){
	this.customerNo=customerNo;
	this.customerName=customerName;
	this.paymentNo=paymentNo;
	this.collectedAmt=collectedAmt;
	this.paymentDate=paymentDate;
	this.userId=userId;
}

public String getCustomerNo() {
	return customerNo;
}
public void setCustomerNo(String customerNo) {
	this.customerNo = customerNo;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getPaymentNo() {
	return paymentNo;
}
public void setPaymentNo(String paymentNo) {
	this.paymentNo = paymentNo;
}
public String getCollectedAmt() {
	return collectedAmt;
}
public void setCollectedAmt(String collectedAmt) {
	this.collectedAmt = collectedAmt;
}
public String getPaymentDate() {
	return paymentDate;
}
public void setPaymentDate(String paymentDate) {
	this.paymentDate = paymentDate;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}

}
