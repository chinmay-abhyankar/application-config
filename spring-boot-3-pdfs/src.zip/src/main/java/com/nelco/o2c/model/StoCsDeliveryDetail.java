package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the sto_cs_delivery_details database table.
 * 
 */
@Entity
@Table(name="sto_cs_delivery_details")
@NamedQuery(name="StoCsDeliveryDetail.findAll", query="SELECT s FROM StoCsDeliveryDetail s")
public class StoCsDeliveryDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="sto_cs_delivery_details_id")
	private Integer stoCsDeliveryDetailsId;

	@Column(name="material_desc")
	private String materialDesc;

	@Column(name="material_num")
	private String materialNum;

	private String quantity;

	@Column(name="rec_plant_code")
	private String recPlantCode;

	@Column(name="rec_plant_name")
	private String recPlantName;

	@Column(name="sto_cs_delivery_id")
	private Integer stoCsDeliveryId;

	@Column(name="sto_cs_gen_id")
	private String stoCsGenId;

	public StoCsDeliveryDetail() {
	}

	public Integer getStoCsDeliveryDetailsId() {
		return stoCsDeliveryDetailsId;
	}

	public void setStoCsDeliveryDetailsId(Integer stoCsDeliveryDetailsId) {
		this.stoCsDeliveryDetailsId = stoCsDeliveryDetailsId;
	}

	public String getMaterialDesc() {
		return materialDesc;
	}

	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}

	public String getMaterialNum() {
		return materialNum;
	}

	public void setMaterialNum(String materialNum) {
		this.materialNum = materialNum;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getRecPlantCode() {
		return recPlantCode;
	}

	public void setRecPlantCode(String recPlantCode) {
		this.recPlantCode = recPlantCode;
	}

	public String getRecPlantName() {
		return recPlantName;
	}

	public void setRecPlantName(String recPlantName) {
		this.recPlantName = recPlantName;
	}

	public Integer getStoCsDeliveryId() {
		return stoCsDeliveryId;
	}

	public void setStoCsDeliveryId(Integer stoCsDeliveryId) {
		this.stoCsDeliveryId = stoCsDeliveryId;
	}

	public String getStoCsGenId() {
		return stoCsGenId;
	}

	public void setStoCsGenId(String stoCsGenId) {
		this.stoCsGenId = stoCsGenId;
	}

	

}