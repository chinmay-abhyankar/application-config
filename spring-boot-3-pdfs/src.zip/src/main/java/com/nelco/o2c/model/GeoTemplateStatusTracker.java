package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;


/**
 * The persistent class for the geo_template_status_tracker database table.
 * 
 */
@Entity
@Table(name="geo_template_status_tracker")
@NamedQuery(name="GeoTemplateStatusTracker.findAll", query="SELECT g FROM GeoTemplateStatusTracker g")
public class GeoTemplateStatusTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="geo_template_status_tracker_id")
	private Integer geoTemplateStatusTrackerId;

	@Column(name="appr_flg")
	private String apprFlg;

	@Column(name="appr_reason")
	private String apprReason;

	@Column(name="geo_template_id")
	private Integer geoTemplateId;

	@Column(name="req_by")
	private Integer reqBy;

	@Column(name="status_mst_id")
	private Integer statusMstId;

	@Column(name="status_req_date")
	private String statusReqDate;

	public GeoTemplateStatusTracker() {
	}

	public Integer getGeoTemplateStatusTrackerId() {
		return geoTemplateStatusTrackerId;
	}

	public void setGeoTemplateStatusTrackerId(Integer geoTemplateStatusTrackerId) {
		this.geoTemplateStatusTrackerId = geoTemplateStatusTrackerId;
	}

	public String getApprFlg() {
		return apprFlg;
	}

	public void setApprFlg(String apprFlg) {
		this.apprFlg = apprFlg;
	}

	public String getApprReason() {
		return apprReason;
	}

	public void setApprReason(String apprReason) {
		this.apprReason = apprReason;
	}

	public Integer getGeoTemplateId() {
		return geoTemplateId;
	}

	public void setGeoTemplateId(Integer geoTemplateId) {
		this.geoTemplateId = geoTemplateId;
	}

	public Integer getReqBy() {
		return reqBy;
	}

	public void setReqBy(Integer reqBy) {
		this.reqBy = reqBy;
	}

	public Integer getStatusMstId() {
		return statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}

	public String getStatusReqDate() {
//		return statusReqDate;
		return DateUtil.convertDateTimeToString(this.statusReqDate);
	}

	public void setStatusReqDate(String statusReqDate) {
		this.statusReqDate = statusReqDate;
	}

	


}