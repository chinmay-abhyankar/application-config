/**
 * 
 */
package com.nelco.o2c.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.nelco.o2c.dto.BrfDTO;
import com.nelco.o2c.dto.BrfDetailsDTO;
import com.nelco.o2c.dto.BrfDetailsListDTO;
import com.nelco.o2c.dto.BrfStatusTrackerDTO;
import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.OldSoDTO;
import com.nelco.o2c.dto.OppUploadDetailDTO;
import com.nelco.o2c.dto.ResponseDTO;
import com.nelco.o2c.model.Brf;
import com.nelco.o2c.model.BrfSoDetails;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.service.BrfService;

/**
 * @author Amol.l
 *
 */

@RestController
public class BrfController {

	@Autowired
	BrfService brfService;

	@RequestMapping(value = "/getBrfListByDate.do", method = RequestMethod.POST)
	public BrfDetailsListDTO getBrfListByDate(@RequestBody BrfDetailsListDTO brfDetailsListDTO) {
		BrfDetailsListDTO brfDetailsListDTONew = new BrfDetailsListDTO();
		List<BrfDetailsDTO> brfDetailsDTOList = new ArrayList<BrfDetailsDTO>();
		brfDetailsDTOList = brfService.getBrfListByDate(brfDetailsListDTO);
		brfDetailsListDTONew.setToDate(brfDetailsListDTO.getToDate());
		brfDetailsListDTONew.setFromDate(brfDetailsListDTO.getFromDate());
		brfDetailsListDTONew.setBrfDetailsDTOList(brfDetailsDTOList);
		brfDetailsListDTONew.setContractId(brfDetailsListDTO.getContractId());
		return brfDetailsListDTONew;
	}
	
	@RequestMapping(value = "/brfListByContNumAndDate.do", method = RequestMethod.POST)
	public BrfDetailsListDTO getBrfListByContNumAndDate(@RequestBody BrfDetailsListDTO brfDetailsListDTO) {
		BrfDetailsListDTO brfDetailsListDTONew = new BrfDetailsListDTO();
		List<BrfDetailsDTO> brfDetailsDTOList = new ArrayList<BrfDetailsDTO>();
		brfDetailsDTOList = brfService.getBrfListByContNumAndDate(brfDetailsListDTO);
		brfDetailsListDTONew.setToDate(brfDetailsListDTO.getToDate());
		brfDetailsListDTONew.setFromDate(brfDetailsListDTO.getFromDate());
		brfDetailsListDTONew.setBrfDetailsDTOList(brfDetailsDTOList);
		brfDetailsListDTONew.setContractId(brfDetailsListDTO.getContractId());
		return brfDetailsListDTONew;
	}
	
	@RequestMapping(value = "/brfListToFillGeoTemplate.do", method = RequestMethod.POST)
	public BrfDetailsListDTO brfListToFillGeoTemplate(@RequestBody BrfDetailsListDTO brfDetailsListDTO) {
		BrfDetailsListDTO brfDetailsListDTONew = new BrfDetailsListDTO();
		List<BrfDetailsDTO> brfDetailsDTOList = new ArrayList<BrfDetailsDTO>();
		brfDetailsDTOList = brfService.brfListToFillGeoTemplate(brfDetailsListDTO);
		brfDetailsListDTONew.setToDate(brfDetailsListDTO.getToDate());
		brfDetailsListDTONew.setFromDate(brfDetailsListDTO.getFromDate());
		brfDetailsListDTONew.setBrfDetailsDTOList(brfDetailsDTOList);
		brfDetailsListDTONew.setContractId(brfDetailsListDTO.getContractId());
		return brfDetailsListDTONew;
	}

	@RequestMapping(value = "/getBrfByBrfId.do", method = RequestMethod.POST)
	public BrfDTO getBrfByBrfId(@RequestBody BrfDTO brfDTO) {
		BrfDTO brfDTONew = new BrfDTO();
		Brf brf = new Brf();
		brf = brfService.getBrfByBrfId(brfDTO.getBrfId());
		brfDTONew.setBrfId(brfDTO.getBrfId());
		brfDTONew.setBrf(brf);
		brfDTONew.setOppUploadDetails(brfService.getUploadDetailsByBrfId(brfDTO.getBrfId()));
		return brfDTONew;
	}

	@RequestMapping(value = "/saveBrf.do", method = RequestMethod.POST)
	public BrfDTO saveBrf(@RequestBody BrfDTO brfDTO) {
		BrfDTO brfDTONew = new BrfDTO();
		Brf brf = new Brf();
		brf = brfService.saveBrf(brfDTO);
		brfDTONew.setBrf(brf);
		brfDTONew.setIsSaved(true);
		return brfDTONew;
	}

	@RequestMapping(value = "/brfApprRej.do", method = RequestMethod.POST)
	public BrfStatusTrackerDTO brfApprRej(@RequestBody CommonDTO commonDTO) {

		return brfService.brfApprRej(commonDTO);
	}

	@RequestMapping(value = "/getApprRejBrfDetails.do", method = RequestMethod.POST)
	public BrfStatusTrackerDTO getApprRejBrfDetails(@RequestBody CommonDTO commonDTO) {
		return brfService.getApprRejBrfDetails(commonDTO);
	}
	
	@RequestMapping(value = "/closedToOldSo.do", method = RequestMethod.POST)
	public List<OldSoDTO> closedToOldSo(@RequestBody CommonDTO commonDTO) {
		return brfService.closedToOldSo(commonDTO);
	}
	
	@RequestMapping(value = "/getBrfFileList.do", method = RequestMethod.POST)
	public BrfDTO getBrfFileList(@RequestBody BrfDTO brfDTO) {
		BrfDTO brfDTONew = new BrfDTO();
		List<FileTypeMst> fileList = brfService.getBrfFileList(brfDTO);
		brfDTONew.setBrfFileList(fileList);
		return brfDTONew;
	}
	
	@RequestMapping(value = "/getBrfStatusTrack.do", method = RequestMethod.POST)
	public BrfDTO getBrfStatusTrack(@RequestBody BrfDTO brfDTO) {
		return brfService.getBrfStatusTrack(brfDTO);
	}

	//This is for uploading of site survey request from PMGT login
	@RequestMapping(value = "/uploadBrfSoDetails.do", method = RequestMethod.POST)
	public ResponseDTO uploadBrfSoDetails(MultipartHttpServletRequest request,@RequestParam String userMstId,@RequestParam String brfId) throws Exception {
		ResponseDTO responseDTO=new ResponseDTO();		
		MultipartFile file = request.getFile("brfSoFile");
		if(brfService.validateFile(file, userMstId,responseDTO)){
			brfService.uploadFile(file, userMstId, brfId);
			responseDTO.setStatus("Success");
		}else{
			return responseDTO;
		}
		responseDTO.setBrfId(Integer.parseInt(userMstId));
		return responseDTO;
		
	}
	
	@RequestMapping(value = "/softDeleteByOpUpDetId.do", method = RequestMethod.POST)
	public OppUploadDetailDTO softDeleteByOpUpDetId(@RequestBody OppUploadDetailDTO oppUploadDetailDTO) {
		OppUploadDetailDTO oppUploadDetailDTONew = new OppUploadDetailDTO();
		OppUploadDetail oppUploadDetail = new OppUploadDetail();
		
		if(oppUploadDetailDTO.getOppUploadDetail().getOppUploadDetailsId() != null)
		{
		brfService.softDeleteByOpUpDetId(oppUploadDetailDTO.getOppUploadDetail().getOppUploadDetailsId());
		}
		
		if(oppUploadDetailDTO.getOppUploadDetail().getBrfId() != null) {
		oppUploadDetail.setBrfId(oppUploadDetailDTO.getOppUploadDetail().getBrfId());
		}
		
		if(oppUploadDetailDTO.getOppUploadDetail().getOpportunityId() != null) {
			oppUploadDetail.setOpportunityId(oppUploadDetailDTO.getOppUploadDetail().getOpportunityId());
		}
		
		if(oppUploadDetailDTO.getOppUploadDetail().getProposalId() != null) {
			oppUploadDetail.setProposalId(oppUploadDetailDTO.getOppUploadDetail().getProposalId());
		}

		if(oppUploadDetailDTO.getOppUploadDetail().getRespMatrixDetailsId() != null ) {
			oppUploadDetail.setRespMatrixDetailsId(oppUploadDetailDTO.getOppUploadDetail().getRespMatrixDetailsId());
		}
		
		if(oppUploadDetailDTO.getOppUploadDetail().getSiteSurveyCostId() != null ) {
			oppUploadDetail.setSiteSurveyCostId(oppUploadDetailDTO.getOppUploadDetail().getSiteSurveyCostId());
		}
		
		if(oppUploadDetailDTO.getOppUploadDetail().getSsEngVisitDetailsId() != null) {
			oppUploadDetail.setSsEngVisitDetailsId(oppUploadDetailDTO.getOppUploadDetail().getSsEngVisitDetailsId());
		}
		

		
		oppUploadDetailDTONew.setOppUploadDetail(oppUploadDetail);
		return oppUploadDetailDTONew;
	}
	
	@RequestMapping(value = "/brfSoDetListByBrfId.do", method = RequestMethod.POST)
	public BrfDTO brfSoDetListByBrfId(@RequestBody BrfDTO brfDTO) {
		BrfDTO brfDTONew = new BrfDTO();
		List<BrfSoDetails> brfSoDetailsList = new ArrayList<BrfSoDetails>();
		brfSoDetailsList = brfService.brfSoDetListByBrfId(brfDTO);
		brfDTONew.setBrfId(brfDTO.getBrfId());
		brfDTONew.setBrfSoDetailsList(brfSoDetailsList);
		return brfDTONew;
	}
}
