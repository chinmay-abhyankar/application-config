package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.ReportContractDTO;
import com.nelco.o2c.dto.UserDTO;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.ReportMst;
import com.nelco.o2c.model.StatusMst;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.model.UserToReport;

@Repository
public class UserToReportDaoImpl implements UserToReportDao {

	@PersistenceContext
	EntityManager em;

	@Autowired
	ReportMstDao reportsMstDao;

	@Autowired
	PmgtStoDao pmgtStoDao;

	@Override
	public List<ReportMst> getAsssignedReportsName(int userId) {

		ReportMst resultList = null;
		List<ReportMst> reportMstList = new ArrayList<>();
		Query theQuery = em.createQuery("from UserToReport where userMstId=:userId");
		theQuery.setParameter("userId", String.valueOf(userId));

		List<UserToReport> userToReport = theQuery.getResultList();

		if (userToReport != null && userToReport.size() > 0) {
			for (UserToReport user : userToReport) {
				Integer intObj = Integer.parseInt(user.getReportId());
				resultList = reportsMstDao.findById(intObj.intValue());
				reportMstList.add(resultList);
				reportMstList.sort((ReportMst u1, ReportMst u2) -> u1.getReportName().compareTo(u2.getReportName()));
			}
		}
		// find reports name by id findById from reportsDAo
		return reportMstList;
	}

	@Override
	public List<StatusMst> searchStatusByCode(List<String> statusList) {
		List<StatusMst> statusMstList = null;
		try {
			Query query = em.createNamedQuery("StatusMst.findByCode");
			query.setParameter("statusCodeList", statusList);
			statusMstList = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return statusMstList;
	}

	@Override
	public List<HubMst> allActiveHubs() {
		try {
			List<HubMst> hubMstList = new ArrayList<HubMst>();
			Query query = em.createNamedQuery("HubMst.allActiveHubs");
			query.setParameter(1, "Y");
			@SuppressWarnings("unchecked")
			List<HubMst> result = query.getResultList();
			for (HubMst hmst : result) {
				HubMst hubMst = new HubMst();
				hubMst.setHubMstId(hmst.getHubMstId());
				hubMst.setHubCode(hmst.getHubCode());
				hubMst.setHubDesc(hmst.getHubDesc());
				hubMst.setIsActive(hmst.getIsActive());

				hubMstList.add(hubMst);
			}

			return hubMstList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<HubMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<UserDTO> getALlProgramMangers() {
		List<UserMst> results = pmgtStoDao.getUserByRoleCodeList(null, Arrays.asList("PM"));
		List<UserDTO> userList = new ArrayList<UserDTO>();

		results.forEach(user -> {
			UserDTO userDTO = new UserDTO();
			userDTO.setUserMstId(user.getUserMstId());
			userDTO.setUserName(user.getUserName());
			userDTO.setLoginId(user.getLoginId());
			userDTO.setRoleCode(user.getRoleMst().getRoleCd());

			userList.add(userDTO);
			userList.sort((UserDTO u1, UserDTO u2) -> u1.getUserName().compareTo(u2.getUserName()));
		});

		return userList;
	}

	@Override
	public List<ReportContractDTO> searchSapContractNum(String sapContractNumber) {
		Query theQuery = em.createQuery(
				"select c.childContractId,c.sapContractNum from ChildContract c where sapContractNum like :sapContractNumber");
		try {
			theQuery.setParameter("sapContractNumber", "%" + String.valueOf(sapContractNumber) + "%");
			theQuery.setMaxResults(20);
			theQuery.setHint("org.hibernate.cacheable", Boolean.TRUE);

			@SuppressWarnings("unchecked")
			List<Object[]> resultSet = (List<Object[]>) theQuery.getResultList();

			List<ReportContractDTO> sapContractNumbers = new ArrayList<ReportContractDTO>();

			resultSet.forEach(action -> {
				ReportContractDTO childContract = new ReportContractDTO();
				childContract.setChildContractId(String.valueOf(action[0]));
				childContract.setSapContractNumber(action[1] != null ? (String) action[1] : "");
				sapContractNumbers.add(childContract);
			});

			return sapContractNumbers != null ? sapContractNumbers : new ArrayList<ReportContractDTO>();
		} finally {
			em.close();
		}

	}

}
