package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the spares_so_user_map database table.
 * 
 */
@Entity
@Table(name="spares_so_user_map")
@NamedQueries({
	@NamedQuery(name="SparesSoUserMap.findAll", query="SELECT s FROM SparesSoUserMap s"),
	@NamedQuery(name="SparesSoUserMap.countUserSparesSo", query = "select count(s) FROM SparesSoUserMap s where s.sparesSoId = :sparesSoId and s.userMstId = :userMstId ")
})
public class SparesSoUserMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="spares_so_user_map_id")
	private Integer sparesSoUserMapId;

	@Column(name="spares_so_id")
	private Integer sparesSoId;

	@Column(name="user_mst_id")
	private Integer userMstId;

	public SparesSoUserMap() {
	}

	public Integer getSparesSoUserMapId() {
		return this.sparesSoUserMapId;
	}

	public void setSparesSoUserMapId(Integer sparesSoUserMapId) {
		this.sparesSoUserMapId = sparesSoUserMapId;
	}

	public Integer getSparesSoId() {
		return this.sparesSoId;
	}

	public void setSparesSoId(Integer sparesSoId) {
		this.sparesSoId = sparesSoId;
	}

	public Integer getUserMstId() {
		return this.userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

}