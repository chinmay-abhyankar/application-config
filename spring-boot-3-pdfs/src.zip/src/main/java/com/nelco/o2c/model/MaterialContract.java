package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the material_contract database table.
 * 
 */
@Entity
@Table(name = "material_contract")
@NamedQueries({
		@NamedQuery(name = "MaterialContract.searchContractMaterial", query = " SELECT new MaterialContract(matc.contractId,"
				+ " matc.materialNo, sum(matc.orderQty), matc.materialSapmst)   FROM MaterialContract matc "
				+ " inner join matc.materialSapmst mm " + " where (mm.materialNo like :materialNumParam or mm.materialDesc like :materialDescParam) "
				+ " and matc.contractId=:contractIdParam " + " group by matc.contractId,matc.materialNo "),
		@NamedQuery(name = "MaterialContract.findAll", query = "SELECT m FROM MaterialContract m") })
@NamedNativeQuery(name = "MaterialContract.searchValidContractMaterial", query = "select "
		+ " a.acid,a.amatnum,a.asum-COALESCE (b.bsum,b.bsum,0), "
		+ " 1 as matpk ,matsap.material_num ,matsap.material_desc, "//matsap.material_sapmst_id
		+ " matsap.material_type ,matsap.material_group ,matsap.base_unit ,matsap.division ,"
		+ " '' as plantt ,matsap.sales_org ,matsap.dist_channel ,matsap.sales_unit ,"//matsap.plant
		+ " matsap.item_category ,matsap.delivery_plant ,matsap.acc_assign_group ,"
		+ " matsap.control_group  as cr_date,a.rate as final_rate,a.aitem_no as final_item_no,  "
		+ " a.apricgrp,a.act "
		+ " from "//,convert(varchar, matsap.created_date, 105)
		+ " (select matc.pricing_group_code as apricgrp,matc.condition_type_code as act,matc.item_no as aitem_no,matc.contract_id as acid,matc.material_no as amatnum,matc.sales_org,sum(matc.order_qty) as asum,matc.rate,matc.dist_channel "//matc.plant,
		+ " from material_contract matc inner join contract c on matc.contract_id = c.contract_id "
		+ " where matc.contract_id = :contractIdParam group by matc.material_no,matc.item_no,matc.contract_id,matc.sales_org,matc.rate,matc.condition_type_code,matc.pricing_group_code,matc.dist_channel) as a "//matc.plant,
		+ " left join (select '' as bpricgrp,'' as bct,'' as bitem_no,cc.contract_id as bccid, mcc.material_no as bmatnum, mcc.sales_org,sum(mcc.order_qty) as bsum,'' as rate,mcc.dist_channel "//mcc.plant,
		+ " from child_contract cc inner join material_child_contract mcc "
		+ " on cc.child_contract_id = mcc.child_contract_id where cc.contract_id = :contractIdParam "
		+ " group by mcc.material_no,cc.contract_id, mcc.sales_org,mcc.dist_channel) as b on (a.amatnum = b.bmatnum and a.sales_org = b.sales_org ) "//,mcc.plant//and a.plant = b.plant  //29-08-2019   mcc.condition_type_code,mcc.pricing_group_code,mcc.item_no   ( after b block and a.aitem_no = b.bitem_no)
		+ " inner join (select distinct material_num,material_desc,material_type,material_group,base_unit,division,sales_org,dist_channel,sales_unit,'' as item_category,'' as delivery_plant,'' as acc_assign_group,'' as control_group from material_sapmst) matsap on (a.amatnum = matsap.material_num and a.sales_org = matsap.sales_org and a.dist_channel = matsap.dist_channel) "//and a.plant = matsap.plant
		+ " where matsap.material_num like :materialNumParam or matsap.material_desc like :materialDescParam order by final_item_no asc")
public class MaterialContract implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "material_contract_id")
	private Integer materialContractId;

	@Column(name = "contract_id")
	private Integer contractId;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "material_desc")
	private String materialDesc;

	@Column(name = "material_no")
	private String materialNo;

	@Column(name = "order_qty")
	private Integer orderQty;

	private String plant;

	private String rate;

	@Column(name = "sales_unit")
	private String salesUnit;

	@Column(name = "item_no")
	private String itemNum;

	private String value;
	
	@Column(name = "sales_org")
	private String salesOrg;
	
	@Column(name = "pricing_group_code")
	private String pricingGroupCode;
	
	@Column(name = "condition_type_code")
	private String conditionTypeCode;
	
	@Column(name = "dist_channel")
	private String distChannel;
	
	

	public String getDistChannel() {
		return distChannel;
	}

	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}

	public String getPricingGroupCode() {
		return pricingGroupCode;
	}

	public void setPricingGroupCode(String pricingGroupCode) {
		this.pricingGroupCode = pricingGroupCode;
	}

	public String getConditionTypeCode() {
		return conditionTypeCode;
	}

	public void setConditionTypeCode(String conditionTypeCode) {
		this.conditionTypeCode = conditionTypeCode;
	}

	public MaterialContract() {
	}

	public MaterialContract(Integer contractId, String materialNo, Long orderQty, MaterialSapmst materialSapmst) {
		super();

		this.contractId = contractId;
		this.materialNo = materialNo;
		this.orderQty = orderQty.intValue();
		this.materialSapmst = materialSapmst;
	}
	
	public MaterialContract(Integer contractId, String materialNoTrans, Long orderQty, 
			Integer materialSapmstId, String accAssignGroup, String baseUnit, String controlGroup,
			String createdDate, String deliveryPlant, String distChannel, String division, String itemCategory,
			String materialDesc, String materialGroup, String materialNo, String materialType, String plant,
			String salesOrg, String salesUnit) {
		super();
		this.contractId = contractId;
		this.materialNo = materialNoTrans;
		this.orderQty = orderQty.intValue();
		MaterialSapmst materialSapmst = new MaterialSapmst();
		materialSapmst.setMaterialSapmstId(materialSapmstId);
		materialSapmst.setAccAssignGroup(accAssignGroup);
		materialSapmst.setBaseUnit(baseUnit);
		materialSapmst.setControlGroup(controlGroup);
		materialSapmst.setCreatedDate(createdDate);
		materialSapmst.setDeliveryPlant(deliveryPlant);
		materialSapmst.setDistChannel(distChannel);
		materialSapmst.setDivision(division);
		materialSapmst.setItemCategory(itemCategory);
		materialSapmst.setMaterialDesc(materialDesc);
		materialSapmst.setMaterialGroup(materialGroup);
		materialSapmst.setMaterialNo(materialNo);
		materialSapmst.setMaterialType(materialType);
		materialSapmst.setPlant(plant);
		materialSapmst.setSalesOrg(salesOrg);
		materialSapmst.setSalesUnit(salesUnit);
		this.materialSapmst = materialSapmst;
	}
	

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({@JoinColumn(name = "material_no", referencedColumnName = "material_num", insertable = false, updatable = false),
		@JoinColumn(name = "plant", referencedColumnName = "plant", insertable = false, updatable = false),
		@JoinColumn(name = "sales_org", referencedColumnName = "sales_org", insertable = false, updatable = false),
		@JoinColumn(name = "dist_channel", referencedColumnName = "dist_channel", insertable = false, updatable = false)})
	private MaterialSapmst materialSapmst;
	
	@Transient
	private String separator = " - ";

	public String getSalesOrg() {
		return salesOrg;
	}

	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

	public String getSeparator() {
		return separator;
	}

	public void setSeparator(String separator) {
		this.separator = separator;
	}

	public MaterialSapmst getMaterialSapmst() {
		return materialSapmst;
	}

	public void setMaterialSapmst(MaterialSapmst materialSapmst) {
		this.materialSapmst = materialSapmst;
	}

	public String getItemNum() {
		return itemNum;
	}

	public void setItemNum(String itemNum) {
		this.itemNum = itemNum;
	}

	public Integer getMaterialContractId() {
		return materialContractId;
	}

	public void setMaterialContractId(Integer materialContractId) {
		this.materialContractId = materialContractId;
	}

	public Integer getContractId() {
		return contractId;
	}

	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getMaterialDesc() {
		return this.materialDesc;
	}

	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}

	public String getMaterialNo() {
		return this.materialNo;
	}

	public void setMaterialNo(String materialNo) {
		this.materialNo = materialNo;
	}

	public Integer getOrderQty() {
		return this.orderQty;
	}

	public void setOrderQty(Integer orderQty) {
		this.orderQty = orderQty;
	}

	public String getPlant() {
		return this.plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getRate() {
		return this.rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getSalesUnit() {
		return this.salesUnit;
	}

	public void setSalesUnit(String salesUnit) {
		this.salesUnit = salesUnit;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}