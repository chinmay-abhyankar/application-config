package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the file_proc_val_mst database table.
 * 
 */
@Entity
@Table(name = "file_proc_val_mst")
@NamedQueries({
@NamedQuery(name = "FileProcValMst.findAll", query = "SELECT f FROM FileProcValMst f"),
@NamedQuery(name="FileProcValMst.getFileProcessUploadDetails", query="SELECT ftm FROM FileProcValMst fpvm inner join fpvm.fileTypeMst ftm "),
@NamedQuery(name="FileProcValMst.getFileProcessUploadDetailsForDRF", query="SELECT ftm FROM FileProcValMst fpvm inner join fpvm.fileTypeMst ftm where fpvm.processMstId in (2) "),
@NamedQuery(name="FileProcValMst.getFileTypesByProcess", query="SELECT ftm FROM FileProcValMst fpvm inner join fpvm.fileTypeMst ftm where fpvm.processMstId in (3) "),
		@NamedQuery(name="FileProcValMst.getFileTypesByTenderProcess", query="SELECT ftm FROM FileProcValMst fpvm inner join fpvm.fileTypeMst ftm where fpvm.processMstId =?1 ")})
public class FileProcValMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "file_val_mst_id")
	private Integer fileValMstId;

	@Column(name = "file_type_mst_id")
	private Integer fileTypeMstId;

	@Column(name = "process_mst_id")
	private Integer processMstId;
	
	@Column(name = "is_mandatory")
	private String isMandatory = "Y";
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="file_type_mst_id",referencedColumnName="file_type_mst_id", insertable = false, updatable = false)
	private FileTypeMst fileTypeMst;

	public String getIsMandatory() {
		return isMandatory;
	}

	public void setIsMandatory(String isMandatory) {
		this.isMandatory = isMandatory;
	}

	public Integer getFileValMstId() {
		return fileValMstId;
	}

	public void setFileValMstId(Integer fileValMstId) {
		this.fileValMstId = fileValMstId;
	}

	public Integer getFileTypeMstId() {
		return fileTypeMstId;
	}

	public void setFileTypeMstId(Integer fileTypeMstId) {
		this.fileTypeMstId = fileTypeMstId;
	}

	public Integer getProcessMstId() {
		return processMstId;
	}

	public void setProcessMstId(Integer processMstId) {
		this.processMstId = processMstId;
	}

	
	public FileTypeMst getFileTypeMst() {
		return fileTypeMst;
	}

	public void setFileTypeMst(FileTypeMst fileTypeMst) {
		this.fileTypeMst = fileTypeMst;
	}

	@Override
	public String toString() {
		return "FileProcValMst [fileValMstId=" + fileValMstId + ", fileTypeMstId=" + fileTypeMstId + ", processMstId="
				+ processMstId + ", fileTypeMst=" + fileTypeMst + "]";
	}
	

}