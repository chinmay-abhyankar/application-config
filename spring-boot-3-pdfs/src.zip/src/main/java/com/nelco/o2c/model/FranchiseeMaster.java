package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
@Entity
@Table(name="franchise_mst")
@NamedQuery(name="FranchiseeMaster.findAll", query="SELECT h FROM FranchiseeMaster h ")
public class FranchiseeMaster implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="franchise_mst_id")
	private Integer franchise_mst_id;

	@Column(name="franchise_name")
	private String franchise_name;
	
	@Column(name="region")
	private String region;
	
	@Column(name="office_city")
	private String office_city;
	
	@Column(name="owner_name")
	private String owner_name;
	
	@Column(name="owner_no")
	private String owner_no;
	
	@Column(name="address")
	private String address;
	
	@Column(name="email")
	private String email;
	
	@Column(name = "vendor_code")
	private String vendorCode;
	
	

	public String getVendorCode() {
		return vendorCode;
	}

	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}

	public Integer getFranchise_mst_id() {
		return franchise_mst_id;
	}

	public void setFranchise_mst_id(Integer franchise_mst_id) {
		this.franchise_mst_id = franchise_mst_id;
	}

	public String getFranchise_name() {
		return franchise_name;
	}

	public void setFranchise_name(String franchise_name) {
		this.franchise_name = franchise_name;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getOffice_city() {
		return office_city;
	}

	public void setOffice_city(String office_city) {
		this.office_city = office_city;
	}

	public String getOwner_name() {
		return owner_name;
	}

	public void setOwner_name(String owner_name) {
		this.owner_name = owner_name;
	}

	public String getOwner_no() {
		return owner_no;
	}

	public void setOwner_no(String owner_no) {
		this.owner_no = owner_no;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
