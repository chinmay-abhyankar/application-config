package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the hso_details database table.
 * 
 */
@Entity
@Table(name="hso_details")
@NamedQueries({
	@NamedQuery(name="HsoDetail.findAll", query="SELECT h FROM HsoDetail h"),
	@NamedQuery(name="HsoDetail.findBySoNumber", query="SELECT h FROM HsoDetail h where h.soNumber = :soNumber and h.wccStatus = 'WCC_Approved' "),
	@NamedQuery(name = "HsoDetail.searchIp", query = " SELECT h FROM HsoDetail h where h.status='Approved' and h.ip like ?1 "),
	@NamedQuery(name="HsoDetail.updateHsoDetails", query="update HsoDetail h set h.iflCableLength = :iflCableLength "
			+ " where h.hsoDetailsId = :hsoDetailsId ")
})
public class HsoDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "hso_details_id")
	private Integer hsoDetailsId;

	private String amsl;

	@Column(name="antenna_make")
	private String antennaMake;

	@Column(name="antenna_size")
	private String antennaSize;

	@Column(name="buc_serial")
	private String bucSerial;

	@Column(name="buc_watage")
	private String bucWatage;

	@Column(name="bw_po_contact")
	private String bwPoContact;

	@Column(name="bw_satelite")
	private String bwSatelite;

	@Column(name="cndb_hub")
	private String cndbHub;

	@Column(name="create_date")
	private String createDate;

	@Column(name="create_time")
	private String createTime;

	private String crosspole;

	@Column(name="customer_name")
	private String customerName;

	@Column(name="details_date")
	private String detailsDate;

	@Column(name="ebdb_hub")
	private String ebdbHub;

	@Column(name="fe_name")
	private String feName;

	@Column(name="hso_number")
	private String hsoNumber;

	@Column(name="ht_antenna_level")
	private String htAntennaLevel;

	@Column(name="ht_antenna_mask")
	private String htAntennaMask;

	@Column(name="ht_building")
	private String htBuilding;

	@Column(name="hub_mst_id")
	private Integer hubMstId;

	@Column(name="hub_name")
	private String hubName;

	private String id;

	@Column(name="idu_serial")
	private String iduSerial;

	@Column(name="ifl_cable_length")
	private String iflCableLength;

	@Column(name="installation_type")
	private String installationType;

	private String ip;

	@Column(name="ladder_length")
	private String ladderLength;

	@Column(name="lan_ip")
	private String lanIp;

	@Column(name="lan_sub_mask")
	private String lanSubMask;

	private String latitude;

	@Column(name="lnbc_serial")
	private String lnbcSerial;

	private String location;

	private String longitude;

	@Column(name="monkey_cage")
	private String monkeyCage;

	private String msp;

	@Column(name="new_postal_address")
	private String newPostalAddress;

	private String pincode;

	@Column(name="postal_address")
	private String postalAddress;

	@Column(name="rac_code")
	private String racCode;

	private String region;

	private String remark;

	private String sacfa;

	@Column(name="so_number")
	private String soNumber;

	private String state;

	private String status;

	private String technology;

	@Column(name="trn_out_power")
	private String trnOutPower;

	@Column(name="tx_capability")
	private String txCapability;

	private String ups;

	@Column(name="verified_by")
	private String verifiedBy;

	@Column(name="verified_date")
	private String verifiedDate;

	@Column(name="verified_time")
	private String verifiedTime;

	@Column(name="vsat_sub_mask")
	private String vsatSubMask;

	@Column(name="wcc_code")
	private String wccCode;

	@Column(name="wcc_create_date")
	private String wccCreateDate;

	@Column(name="wcc_remark")
	private String wccRemark;

	@Column(name="wcc_status")
	private String wccStatus;

	@Column(name="wcc_update_time")
	private String wccUpdateTime;

	@Column(name="wcc_verified_date")
	private String wccVerifiedDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "hub_mst_id", referencedColumnName = "hub_mst_id", insertable = false, updatable = false)
	private HubMst hubMst;
	
	public Integer getHsoDetailsId() {
		return hsoDetailsId;
	}

	public void setHsoDetailsId(Integer hsoDetailsId) {
		this.hsoDetailsId = hsoDetailsId;
	}

	public HsoDetail() {
	}

	public String getAmsl() {
		return amsl;
	}

	public void setAmsl(String amsl) {
		this.amsl = amsl;
	}

	public String getAntennaMake() {
		return antennaMake;
	}

	public void setAntennaMake(String antennaMake) {
		this.antennaMake = antennaMake;
	}

	public String getAntennaSize() {
		return antennaSize;
	}

	public void setAntennaSize(String antennaSize) {
		this.antennaSize = antennaSize;
	}

	public String getBucSerial() {
		return bucSerial;
	}

	public void setBucSerial(String bucSerial) {
		this.bucSerial = bucSerial;
	}

	public String getBucWatage() {
		return bucWatage;
	}

	public void setBucWatage(String bucWatage) {
		this.bucWatage = bucWatage;
	}

	public String getBwPoContact() {
		return bwPoContact;
	}

	public void setBwPoContact(String bwPoContact) {
		this.bwPoContact = bwPoContact;
	}

	public String getBwSatelite() {
		return bwSatelite;
	}

	public void setBwSatelite(String bwSatelite) {
		this.bwSatelite = bwSatelite;
	}

	public String getCndbHub() {
		return cndbHub;
	}

	public void setCndbHub(String cndbHub) {
		this.cndbHub = cndbHub;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getCrosspole() {
		return crosspole;
	}

	public void setCrosspole(String crosspole) {
		this.crosspole = crosspole;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getDetailsDate() {
		return detailsDate;
	}

	public void setDetailsDate(String detailsDate) {
		this.detailsDate = detailsDate;
	}

	public String getEbdbHub() {
		return ebdbHub;
	}

	public void setEbdbHub(String ebdbHub) {
		this.ebdbHub = ebdbHub;
	}

	public String getFeName() {
		return feName;
	}

	public void setFeName(String feName) {
		this.feName = feName;
	}

	public String getHsoNumber() {
		return hsoNumber;
	}

	public void setHsoNumber(String hsoNumber) {
		this.hsoNumber = hsoNumber;
	}

	public String getHtAntennaLevel() {
		return htAntennaLevel;
	}

	public void setHtAntennaLevel(String htAntennaLevel) {
		this.htAntennaLevel = htAntennaLevel;
	}

	public String getHtAntennaMask() {
		return htAntennaMask;
	}

	public void setHtAntennaMask(String htAntennaMask) {
		this.htAntennaMask = htAntennaMask;
	}

	public String getHtBuilding() {
		return htBuilding;
	}

	public void setHtBuilding(String htBuilding) {
		this.htBuilding = htBuilding;
	}

	public Integer getHubMstId() {
		return hubMstId;
	}

	public void setHubMstId(Integer hubMstId) {
		this.hubMstId = hubMstId;
	}

	public String getHubName() {
		return hubName;
	}

	public void setHubName(String hubName) {
		this.hubName = hubName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIduSerial() {
		return iduSerial;
	}

	public void setIduSerial(String iduSerial) {
		this.iduSerial = iduSerial;
	}

	public String getIflCableLength() {
		return iflCableLength;
	}

	public void setIflCableLength(String iflCableLength) {
		this.iflCableLength = iflCableLength;
	}

	public String getInstallationType() {
		return installationType;
	}

	public void setInstallationType(String installationType) {
		this.installationType = installationType;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getLadderLength() {
		return ladderLength;
	}

	public void setLadderLength(String ladderLength) {
		this.ladderLength = ladderLength;
	}

	public String getLanIp() {
		return lanIp;
	}

	public void setLanIp(String lanIp) {
		this.lanIp = lanIp;
	}

	public String getLanSubMask() {
		return lanSubMask;
	}

	public void setLanSubMask(String lanSubMask) {
		this.lanSubMask = lanSubMask;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLnbcSerial() {
		return lnbcSerial;
	}

	public void setLnbcSerial(String lnbcSerial) {
		this.lnbcSerial = lnbcSerial;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getMonkeyCage() {
		return monkeyCage;
	}

	public void setMonkeyCage(String monkeyCage) {
		this.monkeyCage = monkeyCage;
	}

	public String getMsp() {
		return msp;
	}

	public void setMsp(String msp) {
		this.msp = msp;
	}

	public String getNewPostalAddress() {
		return newPostalAddress;
	}

	public void setNewPostalAddress(String newPostalAddress) {
		this.newPostalAddress = newPostalAddress;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getPostalAddress() {
		return postalAddress;
	}

	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}

	public String getRacCode() {
		return racCode;
	}

	public void setRacCode(String racCode) {
		this.racCode = racCode;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getSacfa() {
		return sacfa;
	}

	public void setSacfa(String sacfa) {
		this.sacfa = sacfa;
	}

	public String getSoNumber() {
		return soNumber;
	}

	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getTrnOutPower() {
		return trnOutPower;
	}

	public void setTrnOutPower(String trnOutPower) {
		this.trnOutPower = trnOutPower;
	}

	public String getTxCapability() {
		return txCapability;
	}

	public void setTxCapability(String txCapability) {
		this.txCapability = txCapability;
	}

	public String getUps() {
		return ups;
	}

	public void setUps(String ups) {
		this.ups = ups;
	}

	public String getVerifiedBy() {
		return verifiedBy;
	}

	public void setVerifiedBy(String verifiedBy) {
		this.verifiedBy = verifiedBy;
	}

	public String getVerifiedDate() {
		return verifiedDate;
	}

	public void setVerifiedDate(String verifiedDate) {
		this.verifiedDate = verifiedDate;
	}

	public String getVerifiedTime() {
		return verifiedTime;
	}

	public void setVerifiedTime(String verifiedTime) {
		this.verifiedTime = verifiedTime;
	}

	public String getVsatSubMask() {
		return vsatSubMask;
	}

	public void setVsatSubMask(String vsatSubMask) {
		this.vsatSubMask = vsatSubMask;
	}

	public String getWccCode() {
		return wccCode;
	}

	public void setWccCode(String wccCode) {
		this.wccCode = wccCode;
	}

	public String getWccCreateDate() {
		return wccCreateDate;
	}

	public void setWccCreateDate(String wccCreateDate) {
		this.wccCreateDate = wccCreateDate;
	}

	public String getWccRemark() {
		return wccRemark;
	}

	public void setWccRemark(String wccRemark) {
		this.wccRemark = wccRemark;
	}

	public String getWccStatus() {
		return wccStatus;
	}

	public void setWccStatus(String wccStatus) {
		this.wccStatus = wccStatus;
	}

	public String getWccUpdateTime() {
		return wccUpdateTime;
	}

	public void setWccUpdateTime(String wccUpdateTime) {
		this.wccUpdateTime = wccUpdateTime;
	}

	public String getWccVerifiedDate() {
		return wccVerifiedDate;
	}

	public void setWccVerifiedDate(String wccVerifiedDate) {
		this.wccVerifiedDate = wccVerifiedDate;
	}

	public HubMst getHubMst() {
		return hubMst;
	}

	public void setHubMst(HubMst hubMst) {
		this.hubMst = hubMst;
	}

	

}