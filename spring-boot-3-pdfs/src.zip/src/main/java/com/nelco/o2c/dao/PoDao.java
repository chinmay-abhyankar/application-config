/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.PoDTO;
import com.nelco.o2c.dto.PoPendingDTO;
import com.nelco.o2c.dto.PoQueryResponseDTO;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.OrderTypeMst;
import com.nelco.o2c.model.PoApprovalDetail;
import com.nelco.o2c.model.PoQueryDetail;
import com.nelco.o2c.model.PoResponseDetail;
import com.nelco.o2c.model.PoStatusTracker;
import com.nelco.o2c.model.ProductTypeMst;
import com.nelco.o2c.model.Proposal;
import com.nelco.o2c.model.ServiceOrderMst;
import com.nelco.o2c.model.StatusMst;
import com.nelco.o2c.model.UserMst;

/**
 * @author Jayashankar.r
 *
 */
public interface PoDao {

	public List<OppDetails> getPoDetails(PoDTO poInputDTO);

	public StatusMst getPoStatus(Integer proposalId);

	public Proposal getPo(PoDTO poInputDTO);

	public List<ServiceOrderMst> getserviceOrderList();

	public List<ProductTypeMst> getproductTypeList();

	public List<OppUploadDetail> getOppUploadDetails(PoDTO poInputDTO);

	public Proposal savePo(Proposal proposal);
	
	public List<UserMst> getUserListByJobCodeAndOrg(String roleCd,String orgCode);

	public void savePoStatusTracker(PoStatusTracker poStatusTracker);

	public PoApprovalDetail saveApproverDetails(PoApprovalDetail poApprDetails);

	public PoApprovalDetail getApprovalDetByPropIdAndUserId(PoDTO poInputDTO);

	public boolean checkIfAllApproved(PoDTO poInputDTO);

	public List<PoQueryDetail> getPoQueryDetails(PoQueryResponseDTO poQueryResponseDTO);
	
	public PoQueryDetail getPoQueryDetailsById(Integer id);

	public PoQueryDetail postPoQuery(PoQueryDetail query);

	public PoResponseDetail postPoResponse(PoResponseDetail response);

	public List<UserMst> getPmList(Integer roleId);

	public List<HubMst> getHubList();

	public void updateAccMgrPoRemarks(PoDTO poDTO);
	
	public UserMst getUserDetailEmailById(Integer id);
	
	public UserMst getUserDetailEmailBySmOwnerId(String smowner);

	public List<PoApprovalDetail> getPoApprovalData(PoDTO inputPoDTO);

	public List<OrderTypeMst> getOrderTypeList();

	void updateApproverFlag(Proposal submittedProposal);
	
	public List<Proposal> getProposalByOppId(int oppid,PoDTO poInputDTO);
	
	public String getReciveingPlantEmail(String plantSapMstId);
	
	public String getBusineesLine(Integer oppurtunityId);

	public boolean checkProposalId(Integer proposalId);

	public boolean checkProposalIdAndUserMstId(Integer proposalId, Integer userMstId);

	public PoApprovalDetail getPoApprovalDetailByProposalIdAndUserId(Integer proposalId, Integer userMstId);

	public boolean checkValidUuidKeyByPropIdAndUserId(String uuidKey, Integer proposalId, Integer userMstId);

	public List<PoPendingDTO> getPendingPoApprovals(PoDTO inputPoDTO);
}
