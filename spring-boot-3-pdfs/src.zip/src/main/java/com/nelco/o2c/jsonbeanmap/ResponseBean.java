/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Jayashankar.r
 *
 */
public class ResponseBean {

	@JsonProperty("nodata")
	private CodeMsgBean nodata;

	@JsonProperty("uri")
	private String uri;
	
	@JsonProperty("result")
	private ResultBean result;

	public CodeMsgBean getNodata() {
		return nodata;
	}

	public void setNodata(CodeMsgBean nodata) {
		this.nodata = nodata;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public ResultBean getResult() {
		return result;
	}

	public void setResult(ResultBean result) {
		this.result = result;
	}

	
}
