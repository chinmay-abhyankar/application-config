package com.nelco.o2c.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.model.ReportMst;

@Repository
public class ReportMstDaoImpl implements ReportMstDao {

	@PersistenceContext
	private EntityManager em;
	
	
	@Autowired
	public ReportMstDaoImpl(EntityManager entityManager) {
		em = entityManager;
	}


	@Override
	public List<ReportMst> getAllReportNames() {
		Query query = em.createQuery("from ReportMst",ReportMst.class);
		
		List<ReportMst> reportMst = query.getResultList();
		
		return reportMst;
	}


	@Override
	public ReportMst findById(int theId) {
		ReportMst reportMst = em.find(ReportMst.class,theId);
		return reportMst;
	}


	

}
