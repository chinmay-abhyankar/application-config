package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.PaymentCollectionCustomerwise;
import com.nelco.o2c.model.PaymentCollectionInvoicewise;



public class PaymentCollectionFormDTO {
	List<PaymentCollectionDTO> customerwisePaymentList=new ArrayList<PaymentCollectionDTO>();
	List<PaymentCollectionBreakupDTO> invoicewiseCollectionBreakupList=new ArrayList<PaymentCollectionBreakupDTO>();
	List<PaymentCollectionCustomerwise> requestDetails=new ArrayList<PaymentCollectionCustomerwise>();
	List<PaymentCollectionInvoicewise> breakupDetails=new ArrayList<PaymentCollectionInvoicewise>();
	
	
	public List<PaymentCollectionInvoicewise> getBreakupDetails() {
		return breakupDetails;
	}

	public void setBreakupDetails(List<PaymentCollectionInvoicewise> breakupDetails) {
		this.breakupDetails = breakupDetails;
	}

	public List<PaymentCollectionCustomerwise> getRequestDetails() {
		return requestDetails;
	}

	public void setRequestDetails(List<PaymentCollectionCustomerwise> requestDetails) {
		this.requestDetails = requestDetails;
	}

	public List<PaymentCollectionBreakupDTO> getInvoicewiseCollectionBreakupList() {
		return invoicewiseCollectionBreakupList;
	}

	public void setInvoicewiseCollectionBreakupList(List<PaymentCollectionBreakupDTO> invoicewiseCollectionBreakupList) {
		this.invoicewiseCollectionBreakupList = invoicewiseCollectionBreakupList;
	}

	public List<PaymentCollectionDTO> getCustomerwisePaymentList() {
		return customerwisePaymentList;
	}

	public void setCustomerwisePaymentList(List<PaymentCollectionDTO> customerwisePaymentList) {
		this.customerwisePaymentList = customerwisePaymentList;
	}
	
}
