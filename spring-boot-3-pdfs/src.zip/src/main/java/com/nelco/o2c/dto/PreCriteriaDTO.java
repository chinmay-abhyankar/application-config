/**
 * 
 */
package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nelco.o2c.model.PreCriteria;

/**
 * @author Jayashankar.r
 *
 */
@Component
public class PreCriteriaDTO {
	private List<PreCriteria> preCriterias= new ArrayList<PreCriteria>();
	private Integer oppId;
	
	public Integer getOppId() {
		return oppId;
	}

	public void setOppId(Integer oppId) {
		this.oppId = oppId;
	}

	public List<PreCriteria> getPreCriterias() {
		return preCriterias;
	}

	public void setPreCriterias(List<PreCriteria> preCriterias) {
		this.preCriterias = preCriterias;
	}
	
	
}
