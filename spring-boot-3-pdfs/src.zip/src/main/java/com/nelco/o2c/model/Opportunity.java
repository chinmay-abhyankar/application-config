/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 * @author Jayashankar.r
 *
 */
@Entity
@Table(name="opportunity")
@NamedQueries({
		@NamedQuery(name = "Opportunity.getOpportunityByzohoId", query ="select op from Opportunity op where op.zohoId=?1"),
		@NamedQuery(name = "Opportunity.getOpportunityByOpId", query ="select op from Opportunity op where op.opportunityId=?1"),
		@NamedQuery(name = "Opportunity.getSmownerByOppId", query ="select op.opportunityId,op.smownerId from Opportunity op where op.opportunityId=?1")})
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "opportunityId")
public class Opportunity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 10L;
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="opportunity_id")
	private Integer opportunityId;
	
	@Column(name="zoho_id",length=50)
	private String zohoId;
	
	@Column(name="created_date")
	private Date createdDate;
	
	@Column(name="created_by",length=20)
	private String createdBy;
	
	@Column(name="zoho_created_time")
	private String zohoCreatedTime;
	
	@Column(name="zoho_modified_time")
	private String zohoModifiedTime;
	
	@Column(name="smowner_id")
	private String smownerId;
	
	@Column(name = "current_status")
	private String currentStatus;
	
	@OneToMany(fetch=FetchType.LAZY, mappedBy="opportunity")
	@JsonManagedReference
/*	@JoinColumn(name="opportunity_id",referencedColumnName="opportunity_id", insertable = false, updatable = false)*/
	private List<DrfDetails> drfDetails;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="opportunity_id",referencedColumnName="opportunity_id", insertable = false, updatable = false)
	private Taf taf;
	
	@OneToMany(fetch=FetchType.EAGER)
	@JoinColumn(name="opportunity_id",referencedColumnName="opportunity_id", insertable = false, updatable = false)
	private List<Proposal> proposal;
	
	

	public List<Proposal> getProposal() {
		return proposal;
	}

	public void setProposal(List<Proposal> proposal) {
		this.proposal = proposal;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public String getSmownerId() {
		return smownerId;
	}

	public void setSmownerId(String smownerId) {
		this.smownerId = smownerId;
	}

	public String getZohoCreatedTime() {
		return zohoCreatedTime;
	}

	public void setZohoCreatedTime(String zohoCreatedTime) {
		this.zohoCreatedTime = zohoCreatedTime;
	}

	public String getZohoModifiedTime() {
		return zohoModifiedTime;
	}

	public void setZohoModifiedTime(String zohoModifiedTime) {
		this.zohoModifiedTime = zohoModifiedTime;
	}

	public Taf getTaf() {
		return taf;
	}

	public void setTaf(Taf taf) {
		this.taf = taf;
	}

	public List<DrfDetails> getDrfDetails() {
		return drfDetails;
	}

	public void setDrfDetails(List<DrfDetails> drfDetails) {
		this.drfDetails = drfDetails;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getZohoId() {
		return zohoId;
	}

	public void setZohoId(String zohoId) {
		this.zohoId = zohoId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public String toString() {
		return "Opportunity [opportunityId=" + opportunityId + ", zohoId=" + zohoId + ", createdDate=" + createdDate
				+ ", createdBy=" + createdBy + "]";
	}

}
