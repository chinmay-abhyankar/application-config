package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.SalesReturnMst;

public class SalesReturnSaveDTO {
	private List<OppUploadDetail> oppUploadDetails = new ArrayList<OppUploadDetail>();
	private SalesReturnMst salesReturnMst=new SalesReturnMst();
	
	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}
	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}
	public SalesReturnMst getSalesReturnMst() {
		return salesReturnMst;
	}
	public void setSalesReturnMst(SalesReturnMst salesReturnMst) {
		this.salesReturnMst = salesReturnMst;
	}
	
	
}
