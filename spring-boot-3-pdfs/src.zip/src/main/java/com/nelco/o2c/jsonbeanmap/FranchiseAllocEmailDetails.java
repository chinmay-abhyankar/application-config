/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

/**
 * @author Jayshankar.r
 *
 */
public class FranchiseAllocEmailDetails {

	private String soldToParty;
	private String customerName;
	private String shipToParty;
	private String shtpAddress;
	private String soNumber;
	private String deliverNumber;
	private String additionalAddress;
	private String installationType;
	private String vsatId;
	private String vsatIp;
	private String contactPersonNumber;
	private String siteContactPerson;
	private String additionalRemarks;
	private String technology;
	private String hubDesc;
	private String subCustomer;
	
	
	
	
	
	
	public String getSubCustomer() {
		return subCustomer;
	}
	public void setSubCustomer(String subCustomer) {
		this.subCustomer = subCustomer;
	}
	public String getVsatId() {
		return vsatId;
	}
	public void setVsatId(String vsatId) {
		this.vsatId = vsatId;
	}
	public String getVsatIp() {
		return vsatIp;
	}
	public void setVsatIp(String vsatIp) {
		this.vsatIp = vsatIp;
	}
	public String getContactPersonNumber() {
		return contactPersonNumber;
	}
	public void setContactPersonNumber(String contactPersonNumber) {
		this.contactPersonNumber = contactPersonNumber;
	}
	public String getSiteContactPerson() {
		return siteContactPerson;
	}
	public void setSiteContactPerson(String siteContactPerson) {
		this.siteContactPerson = siteContactPerson;
	}
	public String getAdditionalRemarks() {
		return additionalRemarks;
	}
	public void setAdditionalRemarks(String additionalRemarks) {
		this.additionalRemarks = additionalRemarks;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getHubDesc() {
		return hubDesc;
	}
	public void setHubDesc(String hubDesc) {
		this.hubDesc = hubDesc;
	}
	public String getSoldToParty() {
		return soldToParty;
	}
	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getShipToParty() {
		return shipToParty;
	}
	public void setShipToParty(String shipToParty) {
		this.shipToParty = shipToParty;
	}
	public String getShtpAddress() {
		return shtpAddress;
	}
	public void setShtpAddress(String shtpAddress) {
		this.shtpAddress = shtpAddress;
	}
	public String getSoNumber() {
		return soNumber;
	}
	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}
	public String getDeliverNumber() {
		return deliverNumber;
	}
	public void setDeliverNumber(String deliverNumber) {
		this.deliverNumber = deliverNumber;
	}
	public String getAdditionalAddress() {
		return additionalAddress;
	}
	public void setAdditionalAddress(String additionalAddress) {
		this.additionalAddress = additionalAddress;
	}
	public String getInstallationType() {
		return installationType;
	}
	public void setInstallationType(String installationType) {
		this.installationType = installationType;
	}
	
	
	
}
