package com.nelco.o2c.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.servlet.http.HttpServletRequest;

import org.hibernate.query.criteria.internal.CriteriaUpdateImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.CustomerInfoDTO;
import com.nelco.o2c.dto.DisconnectionDTO;
import com.nelco.o2c.dto.DisconnectionFormDTO;
import com.nelco.o2c.dto.DisconnectionOnCRDTO;
import com.nelco.o2c.dto.DisconnectionReconnectionDatesToCSVDTO;
import com.nelco.o2c.dto.DisconnectionRequestDetailsDTO;
import com.nelco.o2c.dto.DisconnectionRequestTrackerDTO;
import com.nelco.o2c.dto.InvoiceInfoDTO;
import com.nelco.o2c.dto.OppUploadDetailDTO;
import com.nelco.o2c.dto.OutstandingInvoicesDTO;
import com.nelco.o2c.dto.ReminderDetailsDTO;
import com.nelco.o2c.dto.SiteInfoDTO;
import com.nelco.o2c.model.AntennaSizeMaster;
import com.nelco.o2c.model.CustomerAgeingDetails;
import com.nelco.o2c.model.DisconnectionActionsTracker;
import com.nelco.o2c.model.DisconnectionAlltypesMst;
import com.nelco.o2c.model.DisconnectionNoticeRequestMst;
import com.nelco.o2c.model.DisconnectionRequestAction;
import com.nelco.o2c.model.DisconnectionRequestMst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.utility.DateUtil;

@Repository
public class DisconnectionDaoImpl implements DisconnectionDao{
	@PersistenceContext
	private EntityManager em;

	Query query;
	
	@Autowired
	private Environment env;

	StoredProcedureQuery spQuery;
	
	@Override
	public List<CustomerAgeingDetails> getCustomerwiseOutstanding(DisconnectionDTO disconnectionDTO) {
		query=em.createNamedQuery("CustomerAgeingDetails.getCustomerwiseOutstanding");
		@SuppressWarnings("unchecked")
		List<CustomerAgeingDetails> customerwiseOutstanding=(List<CustomerAgeingDetails>) query.getResultList();
		return customerwiseOutstanding;
	}

	@Override
	public List<CustomerAgeingDetails> getOutstandingforCustomer(HttpServletRequest request) {
		query=em.createNamedQuery("CustomerAgeingDetails.getOutstandingforCustomer");		
		query.setParameter("customerParam", request.getParameter("customer"));
		query.setParameter("startDateParam", DateUtil.convertDateToSqlDate(request.getParameter("start_date")));
		query.setParameter("endDateParam", DateUtil.convertDateToSqlDate(request.getParameter("end_date")));
		List<CustomerAgeingDetails> invoiceList=(List<CustomerAgeingDetails>) query.getResultList();
		return invoiceList;
	}
    //Call stored procedure
	@Override
	public List<OutstandingInvoicesDTO> getOutstandingInvoicesList(HttpServletRequest request) {
		
		spQuery = em.createStoredProcedureQuery("isp_getOutstandingInvoicesList")
				.registerStoredProcedureParameter("customer", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("startDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("endDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("userId", String.class, ParameterMode.IN);
		spQuery.setParameter("customer", request.getParameter("customer"))
				.setParameter("startDate", DateUtil.convertDateToSqlDate(request.getParameter("startdate")))
				.setParameter("endDate", DateUtil.convertDateToSqlDate(request.getParameter("enddate")))
				.setParameter("userId", request.getParameter("userId"));
		List<Object[]> invoiceList=spQuery.getResultList();
		return invoiceList.stream().map(result -> new OutstandingInvoicesDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3]),(BigDecimal) result[4],String.valueOf(result[5]),String.valueOf(result[6]),String.valueOf(result[7]),String.valueOf(result[8])
		         ,String.valueOf(result[9]),String.valueOf(result[10]),String.valueOf(result[11]),String.valueOf(result[12]),String.valueOf(result[13]),String.valueOf(result[14]),String.valueOf(result[15]),String.valueOf(result[16]),String.valueOf(result[17]),String.valueOf(result[18]),String.valueOf(result[19])
		   )).collect(Collectors.toList());
	}

	@Override
	public DisconnectionFormDTO getDisconnectionMasters(DisconnectionFormDTO disconnectionFormDTO) {
		List<DisconnectionAlltypesMst> masters=null;
		query = em.createNamedQuery("DisconnectionAlltypesMst.findDisconnectionStatus");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		masters=query.getResultList();
		disconnectionFormDTO.setDisconnectionStatus(masters != null ? masters : new ArrayList<DisconnectionAlltypesMst>());
		
		query = em.createNamedQuery("DisconnectionAlltypesMst.findDisconnectionActions");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		masters=query.getResultList();
		disconnectionFormDTO.setDisconnectionActions(masters != null ? masters : new ArrayList<DisconnectionAlltypesMst>());
		
		query = em.createNamedQuery("DisconnectionAlltypesMst.findDisconnectionSeverity");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		masters=query.getResultList();
		disconnectionFormDTO.setDisconnectionSeverities(masters != null ? masters : new ArrayList<DisconnectionAlltypesMst>());
		
		return disconnectionFormDTO;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Map<String, Object>> getReminderIdFromInvoiceNo(String invoiceNo) {
		query=em.createNamedQuery("DisconnectionRequestAction.getLatestRequestIdFromInvoiceNo");
		query.setParameter("invoiceNo", invoiceNo);			
		List lst=query.getResultList();
		Object[] obj=(Object[])lst.get(0);
		HashMap map=new HashMap<>();
		map.put("requestId", obj[0]);
		map.put("userId", obj[1]);
		List<Map<String, Object>> result=new ArrayList<Map<String, Object>>();
		result.add(map);
		return result;
	}

	@Override
	public DisconnectionRequestAction saveReminders(DisconnectionRequestAction disconnectionRequestAction) {
		String uploadURL="";
		query=em.createNamedQuery("DisconnectionRequestAction.updatePrevReminderStatus");		
		query.setParameter("requestStatus", "3");
		query.setParameter("invoiceNo", disconnectionRequestAction.getInvoiceNo());
		query.executeUpdate();
		query=em.createNamedQuery("DisconnectionRequestAction.getReminderId");
		query.setParameter("actionType", disconnectionRequestAction.getActionType());
		String reminderId=String.valueOf(query.getSingleResult());
		disconnectionRequestAction.setRequestId(reminderId);
		
		query=em.createNamedQuery("DisconnectionRequestAction.getReminnderCount");
		query.setParameter("invoiceNo", disconnectionRequestAction.getInvoiceNo());
		query.setParameter("actionType", disconnectionRequestAction.getActionType());
		System.out.println(disconnectionRequestAction.getInvoiceNo());
		String count=String.valueOf(query.getSingleResult());
		int requestCount=Integer.parseInt(String.valueOf(count));
		
		disconnectionRequestAction.setRequestId(reminderId);
		disconnectionRequestAction.setRequestType("non payment");
		disconnectionRequestAction.setRequestCount(requestCount);
		disconnectionRequestAction.setActionDate(DateUtil.convertDateToSqlDate(disconnectionRequestAction.getActionDate()));		
					
		DisconnectionRequestAction savedReminder=em.merge(disconnectionRequestAction);
		
		OppUploadDetail oppUploadDetail = disconnectionRequestAction.getOppUploadDetails();
		if(oppUploadDetail!=null){
		oppUploadDetail.setReminderId(savedReminder.getRequestId());
		oppUploadDetail.setCreatedBy(savedReminder.getUserid());
		oppUploadDetail.setFileTypeMstId(42);
		String currTime2 = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
		oppUploadDetail.setUploadTime(currTime2);
		oppUploadDetail.setCreatedDate(new Date());
		oppUploadDetail.setUploadTime(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		uploadURL=oppUploadDetail.getUploadUrl();
		oppUploadDetail.setUploadUrl(env.getProperty("finaluploadfolder") + oppUploadDetail.getUpFileName());
		oppUploadDetail.setIsDelete("N");
		oppUploadDetail=em.merge(oppUploadDetail);
		oppUploadDetail.setUploadUrl(uploadURL);
		}
		
		updateDisconnectionActionTracker(disconnectionRequestAction.getInvoiceNo(), savedReminder.getRequestId(), savedReminder.getUserid(), "Updated Reminder Details", "", "");
		
		return savedReminder;
	}

	

	@Override
	public DisconnectionRequestAction updateReminderStatus(DisconnectionRequestAction toBeUpdatedReminders) {
		String requestId="";
		List<Map<String, Object>> lst = getReminderIdFromInvoiceNo(toBeUpdatedReminders.getInvoiceNo());
		for (Map<String, Object> result : lst) {
			requestId = String.valueOf(result.get("requestId"));
		}
		query=em.createNamedQuery("DisconnectionRequestAction.updateReminderStatus");		
		query.setParameter("requestStatus", toBeUpdatedReminders.getRequestStatus());
		query.setParameter("requestId", requestId);
		query.executeUpdate();
		
		updateDisconnectionActionTracker(toBeUpdatedReminders.getInvoiceNo(), requestId, toBeUpdatedReminders.getUserid(), "Updated Reminder Status", "", "");
		
		return toBeUpdatedReminders;
	}

	@Override
	public DisconnectionNoticeRequestMst initiateDisconnectionNotice(DisconnectionNoticeRequestMst disconnectionNotice) {
		query=em.createNamedQuery("DisconnectionNoticeRequestMst.getRequestId");
		String requestId=String.valueOf(query.getSingleResult());
		disconnectionNotice.setRequestId(requestId);
		disconnectionNotice.setRequestDate(String.valueOf(DateUtil.getCurrentSqlDate()));
		disconnectionNotice.setSalesheadAppStatus("0");
		disconnectionNotice.setFinanceheadAppStatus("0");
		disconnectionNotice.setDisconnectionnoticeStatus("0");
		
		DisconnectionNoticeRequestMst requestDetails=em.merge(disconnectionNotice);
		
		spQuery = em.createStoredProcedureQuery("isp_SendDisconnectionNotificationsToApprovers")
				.registerStoredProcedureParameter("requestId", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("requestType", String.class, ParameterMode.IN);
		spQuery.setParameter("requestId", requestId)
				.setParameter("requestType", "notice");
		spQuery.execute();
		
		updateDisconnectionActionTracker(disconnectionNotice.getInvoiceNo(), requestId, disconnectionNotice.getUserId(), "Initiated Disconnection Notice Request", "", "");		
		
		return requestDetails;
	}

	

	@SuppressWarnings("unchecked")
	@Override
	public CustomerInfoDTO getCustomerInfoFromInvoiceNo(String invoiceNo) {
		Object[] obj;
		spQuery = em.createStoredProcedureQuery("isp_getCustomerInfoFromInvoiceNo")
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN);
		spQuery.setParameter("invoiceNo", invoiceNo);
		List<Object[]> invoiceList=spQuery.getResultList();
		CustomerInfoDTO dto=new CustomerInfoDTO();
		for(int i=0;i<invoiceList.size();i++){
			obj=invoiceList.get(0);
			dto.setCustomerNo(String.valueOf(obj[0]));
			dto.setCustomerName(String.valueOf(obj[1]));
			dto.setCustomerCity(String.valueOf(obj[2]));
			dto.setCustomerRegion(String.valueOf(obj[3]));
			dto.setCustomerCountry(String.valueOf(obj[4]));
			dto.setCustomerSalesOrg(String.valueOf(obj[5]));
		}
		/*return invoiceList.stream().map(result -> new CustomerInfoDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3]),String.valueOf(result[4]),String.valueOf(result[5])
		   )).collect(Collectors.toList()).get(0);*/
		
		return dto;
	}

	@SuppressWarnings("unchecked")
	@Override
	public InvoiceInfoDTO getInvoiceInfoFromInvoiceNo(String invoiceNo) {
		Object[] obj;
		spQuery = em.createStoredProcedureQuery("isp_getInvoiceDetailsFromInvoiceNo")
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN);
		spQuery.setParameter("invoiceNo", invoiceNo);
		List<Object[]> invoiceList=spQuery.getResultList();
		InvoiceInfoDTO dto=new InvoiceInfoDTO();
		for(int i=0;i<invoiceList.size();i++){
			obj=invoiceList.get(0);
			dto.setInvoiceNo(String.valueOf(obj[0]));
			dto.setInvoiceDate(String.valueOf(obj[1]));
			dto.setInvoiceSubmissionDate(String.valueOf(obj[2]));
			dto.setSoNo(String.valueOf(obj[3]));
			dto.setPaymentDueDate(String.valueOf(obj[4]));
			dto.setOutstandingAmt(String.valueOf(obj[5]));
		}
		/*return invoiceList.stream().map(result -> new InvoiceInfoDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3]),String.valueOf(result[4]),String.valueOf(result[5])
		   )).collect(Collectors.toList()).get(0);*/
		return dto;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ReminderDetailsDTO> getReminderDetailsFromInvoiceNo(String invoiceNo) {
		Object[] obj;
		spQuery = em.createStoredProcedureQuery("isp_getDisconnectionActionDetailsFromInvoiceNo")
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN);
		spQuery.setParameter("invoiceNo", invoiceNo);
		List<Object[]> invoiceList=spQuery.getResultList();
		ReminderDetailsDTO dto=new ReminderDetailsDTO();
		List<ReminderDetailsDTO> lst=new ArrayList<ReminderDetailsDTO>();
		for(int i=0;i<invoiceList.size();i++){
			obj=invoiceList.get(i);
			dto=new ReminderDetailsDTO();
			dto.setReminderNo(String.valueOf(obj[0]));
			dto.setReminderDate(String.valueOf(obj[1]));
			dto.setReminderStatus(String.valueOf(obj[2]));
			dto.setUserId(String.valueOf(obj[3]));
			dto.setActionType(String.valueOf(obj[4]));
			dto.setUploadedDocuments(setUploadedDocuments(String.valueOf(obj[5])));
			lst.add(dto);
		}
		/*return invoiceList.stream().map(result -> new ReminderDetailsDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3])
		   )).collect(Collectors.toList());*/
		return lst;
	}

	private List<OppUploadDetailDTO> setUploadedDocuments(String requestId) {
		List<OppUploadDetailDTO> docList=new ArrayList<OppUploadDetailDTO>();
		Object[] obj;
		query=em.createNamedQuery("OppUploadDetail.getUploadListForRemindersAndNotice");
		query.setParameter("reminderId", requestId);			
		List lst=query.getResultList();
		for(int i=0;i<lst.size();i++){
			obj=(Object[])lst.get(i);
			OppUploadDetailDTO dto=new OppUploadDetailDTO();
			dto.setOppUploadDetailsId(String.valueOf(obj[0]));
			dto.setFileName(String.valueOf(obj[1]));
			dto.setUploadUrl(String.valueOf(obj[2]));
			docList.add(dto);
		}
		return docList;
	}

	@Override
	public DisconnectionNoticeRequestMst updateNoticeRequestStatus(DisconnectionNoticeRequestMst toBeStatuses) {

		if(toBeStatuses.getUserRole().equals("23"))
		query=em.createNamedQuery("DisconnectionNoticeRequestMst.updateSalesHeadAppStatus");
		else if(toBeStatuses.getUserRole().equals("41"))
		query=em.createNamedQuery("DisconnectionNoticeRequestMst.updateFinanceHeadAppStatus");
		query.setParameter("requestStatus", toBeStatuses.getRequestStatus());
		query.setParameter("requestId", toBeStatuses.getRequestId());
		query.executeUpdate();
		
		
		
		spQuery = em.createStoredProcedureQuery("isp_SendDisconnectionNotificationsForExeccution")
				.registerStoredProcedureParameter("requestId", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("requestType", String.class, ParameterMode.IN);
		spQuery.setParameter("requestId", toBeStatuses.getRequestId())
				.setParameter("requestType", "notice");
		spQuery.execute();
		String action="";
		if(toBeStatuses.getRequestStatus().equals("2"))
			action="Approved Disconnection Notice Request";
		if(toBeStatuses.getRequestStatus().equals("3"))
			action="Rejected Disconnection Notice Request";
		updateDisconnectionActionTracker(toBeStatuses.getInvoiceNo(), toBeStatuses.getRequestId(), toBeStatuses.getUserId(), action, toBeStatuses.getAppRemark(), "");
		
		
		
		return toBeStatuses;
	}
	
	

	private List<Map<String, Object>> getDisconnectionNoticeIdFromInvoiceNo(String invoiceNo) {
		query=em.createNamedQuery("DisconnectionRequestAction.getLatestRequestIdFromInvoiceNo");
		query.setParameter("invoiceNo", invoiceNo);			
		List lst=query.getResultList();
		Object[] obj=(Object[])lst.get(0);
		HashMap map=new HashMap<>();
		map.put("requestId", obj[0]);
		map.put("userId", obj[1]);
		List<Map<String, Object>> result=new ArrayList<Map<String, Object>>();
		result.add(map);
		return result;
	}

	@Override
	public DisconnectionRequestDetailsDTO getDisconnectionRequestDetails(String invoiceNo) {
		Object[] obj;
		spQuery = em.createStoredProcedureQuery("isp_getRequestDetailsFromInvoiceNo")
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN);
		spQuery.setParameter("invoiceNo", invoiceNo);
		List<Object[]> invoiceList=spQuery.getResultList();
		DisconnectionRequestDetailsDTO dto=new DisconnectionRequestDetailsDTO();
		for(int i=0;i<invoiceList.size();i++){
			obj=invoiceList.get(0);
			dto.setRequestId(String.valueOf(obj[0]));
			dto.setRequestDate(String.valueOf(obj[1]));
			dto.setRequester(String.valueOf(obj[2]));
			dto.setSalesHeadAppStatus(String.valueOf(obj[3]));
			dto.setFinanceHeadAppStatus(String.valueOf(obj[4]));
			dto.setBusinessHeadAppStatus(String.valueOf(obj[5]));
			dto.setMdAPPStatus(String.valueOf(obj[6]));
			dto.setRequestType(String.valueOf(obj[7]));
			dto.setRequestTypeCode(String.valueOf(obj[8]));
			dto.setDisconnectionDate(String.valueOf(obj[9]));
			dto.setDisconnectionStatus(String.valueOf(obj[10]));
		}
		return dto;
	}

	@Override
	public DisconnectionRequestMst updateDisconnectionRequestStatus(DisconnectionRequestMst toBeStatuses) {
		if(toBeStatuses.getUserRole().equals("1"))
			query=em.createNamedQuery("DisconnectionRequestMst.updateBusinessHeadAppStatus");
			else if(toBeStatuses.getUserRole().equals("42"))
			query=em.createNamedQuery("DisconnectionRequestMst.updateMDAppStatus");
			query.setParameter("requestStatus", toBeStatuses.getRequestStatus());
			query.setParameter("requestId", toBeStatuses.getRequestId());
			query.executeUpdate();
			
			query=em.createNamedQuery("DisconnectionRequestMst.updateDisconnectionRequestStatus");
			query.setParameter("requestStatus", toBeStatuses.getRequestStatus());
			query.setParameter("requestId", toBeStatuses.getRequestId());
			query.executeUpdate();
			
			String action="";
			if(toBeStatuses.getRequestStatus().equals("2"))
				action="Approved Disconnection Notice Request";
			if(toBeStatuses.getRequestStatus().equals("3"))
				action="Rejected Disconnection Notice Request";
			
			spQuery = em.createStoredProcedureQuery("isp_getInvoiceNoFromDisconnectionRequestId")
					.registerStoredProcedureParameter("requestId", String.class, ParameterMode.IN);
			spQuery.setParameter("requestId", toBeStatuses.getRequestId());
			String invioceNo=String.valueOf(spQuery.getSingleResult());
			updateDisconnectionActionTracker(invioceNo, toBeStatuses.getRequestId(), toBeStatuses.getUserId(), action, toBeStatuses.getAppRemark(), "");
			return toBeStatuses;
	}

	@Override
	public DisconnectionRequestMst disconnectSite(DisconnectionRequestMst toBeStatuses) {
		
			query=em.createNamedQuery("DisconnectionRequestMst.updateDisconnectionStatus");
			query.setParameter("requestStatus", toBeStatuses.getRequestStatus());
			query.setParameter("requestId", toBeStatuses.getRequestId());
			query.executeUpdate();
			
			spQuery = em.createStoredProcedureQuery("isp_getInvoiceNoFromDisconnectionRequestId")
					.registerStoredProcedureParameter("requestId", String.class, ParameterMode.IN);
			spQuery.setParameter("requestId", toBeStatuses.getRequestId());
			String invioceNo=String.valueOf(spQuery.getSingleResult());
			updateDisconnectionActionTracker(invioceNo, toBeStatuses.getRequestId(), toBeStatuses.getUserId(), "Discoonected Site", toBeStatuses.getAppRemark(), "");
			return toBeStatuses;
	}

	@Override
	public List<DisconnectionReconnectionDatesToCSVDTO> getBillingEndDate(String requestId) {
		DisconnectionReconnectionDatesToCSVDTO dto;
		List<DisconnectionReconnectionDatesToCSVDTO> result=new ArrayList<DisconnectionReconnectionDatesToCSVDTO>();
		query = em.createNativeQuery("SELECT car.so_no,CONVERT(VARCHAR,drm.disconnection_date,105)as enddate"
				+ " FROM disconnection_request_mst drm"
				+ " INNER JOIN disconnection_notice_request_mst dnrm on drm.notice_id=dnrm.request_id"
				+ " INNER JOIN customer_ageing_report car on dnrm.invoice_no=car.invoice_no"
				+ " WHERE drm.request_id='"+requestId+"'");
		
		@SuppressWarnings("unchecked")
		List<Object[]> resultList = (List<Object[]>) query.getResultList();
		if( resultList!=null && resultList.size()>0) { 		
		for (Object[] objects : resultList) {
			dto=new DisconnectionReconnectionDatesToCSVDTO();
			dto.setSo_no(String.valueOf(objects[0]));
			dto.setEndDate(String.valueOf(objects[1]));
			result.add(dto);
		}		
	}	
		return result;
}

	@Override
	public List<DisconnectionOnCRDTO> getDisconnectionForNonPaymentReport(HttpServletRequest request) {
		spQuery = em.createStoredProcedureQuery("isp_getDisconnectionForNonPaymentReport")
				.registerStoredProcedureParameter("customer", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("disconnectionStartDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("disconnectionEndDate", String.class, ParameterMode.IN);
		spQuery.setParameter("customer", request.getParameter("customer"))
				.setParameter("disconnectionStartDate", DateUtil.convertDateToSqlDate(request.getParameter("startDate")))
				.setParameter("disconnectionEndDate", DateUtil.convertDateToSqlDate(request.getParameter("EndDate")));
		List<Object[]> soList=spQuery.getResultList();
		return soList.stream().map(result -> new DisconnectionOnCRDTO(
		          String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2])
		         ,String.valueOf(result[3]),String.valueOf(result[4]),String.valueOf(result[5])
		         ,String.valueOf(result[6]),String.valueOf(result[7]),String.valueOf(result[8]),String.valueOf(result[9])
		         ,String.valueOf(result[10]),String.valueOf(result[11]),String.valueOf(result[12]),String.valueOf(result[13])
		         ,String.valueOf(result[14]),String.valueOf(result[15]),String.valueOf(result[16]),String.valueOf(result[17])
		         ,String.valueOf(result[18]),String.valueOf(result[19]),String.valueOf(result[20])
				 )).collect(Collectors.toList());
	}
	
	private void updateDisconnectionActionTracker(String identifierField,String requestId,String userId,String action,String remark,String attchmentId){
		DisconnectionActionsTracker disconnectionActionsTracker=new DisconnectionActionsTracker();
		disconnectionActionsTracker.setIdentifierField(identifierField);
		disconnectionActionsTracker.setRequestid(requestId);
		disconnectionActionsTracker.setUserid(userId);
		disconnectionActionsTracker.setAction(action);
		disconnectionActionsTracker.setRemark(remark);
		disconnectionActionsTracker.setAttachmentId(attchmentId);
		em.merge(disconnectionActionsTracker);
	}

	@Override
	public List<DisconnectionRequestTrackerDTO> getDisconnectionRequestTracker(String invoiceNo) {
		Object[] obj;
		spQuery = em.createStoredProcedureQuery("isp_getDisconnectionTrackerFromInvoiceNo")
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN);
		spQuery.setParameter("invoiceNo", invoiceNo);
		List<Object[]> invoiceList=spQuery.getResultList();
		DisconnectionRequestTrackerDTO dto=new DisconnectionRequestTrackerDTO();
		List<DisconnectionRequestTrackerDTO> lst=new ArrayList<DisconnectionRequestTrackerDTO>();
		for(int i=0;i<invoiceList.size();i++){
			obj=invoiceList.get(i);
			dto=new DisconnectionRequestTrackerDTO();
			dto.setUser(String.valueOf(obj[0]));
			dto.setRequestId(String.valueOf(obj[1]));
			dto.setAction(String.valueOf(obj[2]));
			dto.setActionDate(String.valueOf(obj[3]));
			dto.setRemark(String.valueOf(obj[4]));
			lst.add(dto);
		}
		/*return invoiceList.stream().map(result -> new ReminderDetailsDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3])
		   )).collect(Collectors.toList());*/
		return lst;
	}

	@Override
	public SiteInfoDTO getSiteDetailsFromInvoiceNo(String invoiceNo) {
		Object[] obj;
		spQuery = em.createStoredProcedureQuery("isp_getSiteDetailsFromInvoiceNo")
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN);
		spQuery.setParameter("invoiceNo", invoiceNo);
		List<Object[]> siteDetails=spQuery.getResultList();
		SiteInfoDTO dto=new SiteInfoDTO();
		for(int i=0;i<siteDetails.size();i++){
			obj=siteDetails.get(0);
			dto.setSoNo(String.valueOf(obj[0]));
			dto.setVsatIP(String.valueOf(obj[1]));
			dto.setVsatID(String.valueOf(obj[2]));
			dto.setHub(String.valueOf(obj[3]));
			dto.setTechnology(String.valueOf(obj[4]));
			dto.setCircuit_id(String.valueOf(obj[5]));
		}
		/*return invoiceList.stream().map(result -> new InvoiceInfoDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3]),String.valueOf(result[4]),String.valueOf(result[5])
		   )).collect(Collectors.toList()).get(0);*/
		return dto;
	}

	@Override
	public void sendDisconnectionNotifications(String requestId) {
		// TODO Auto-generated method stub
		
	}


	
}
