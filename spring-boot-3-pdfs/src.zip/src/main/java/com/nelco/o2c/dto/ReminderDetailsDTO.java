package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nelco.o2c.model.OppUploadDetail;

@Component
public class ReminderDetailsDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7210094885563651204L;
	private String reminderNo="";
	private String reminderDate="";
	private String reminderStatus="";
	private String userId="";
	private String actionType="";
	private List<OppUploadDetailDTO> uploadedDocuments=new ArrayList<OppUploadDetailDTO>();
	
//	public ReminderDetailsDTO(String reminderNo,String reminderDate,String reminderStatus,String userId){
//		this.reminderNo=reminderNo;
//		this.reminderDate=reminderDate;
//		this.reminderStatus=reminderStatus;
//		this.userId=userId;
//	}
	
	public String getReminderNo() {
		return reminderNo;
	}
	public List<OppUploadDetailDTO> getUploadedDocuments() {
		return uploadedDocuments;
	}
	public void setUploadedDocuments(List<OppUploadDetailDTO> uploadedDocuments) {
		this.uploadedDocuments = uploadedDocuments;
	}
	public void setReminderNo(String reminderNo) {
		this.reminderNo = reminderNo;
	}
	public String getReminderDate() {
		return reminderDate;
	}
	public void setReminderDate(String reminderDate) {
		this.reminderDate = reminderDate;
	}
	public String getReminderStatus() {
		return reminderStatus;
	}
	public void setReminderStatus(String reminderStatus) {
		this.reminderStatus = reminderStatus;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getActionType() {
		return actionType;
	}
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	
	
}
