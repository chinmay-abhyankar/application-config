/**
 * 
 */
package com.nelco.o2c.dto;

import java.util.List;

import com.nelco.o2c.model.DeptMst;
import com.nelco.o2c.model.FranchiseeMaster;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.RoleMst;
import com.nelco.o2c.model.StateMst;
import com.nelco.o2c.model.SubDeptMst;
import com.nelco.o2c.model.ZoneMst;

/**
 * @author Chinmay A
 *
 */
public class UserManagementDTO {
	
	List<DeptMst> deptMstList;
	List<SubDeptMst> subDeptMstList;
	List<RoleMst> roleMstList;
	List<ZoneMst> zoneMstList;
	List<StateMst> stateMstList;  
	List<HubMst> hubMstList;
	List<FranchiseeMaster> franchiseeList;
	public List<DeptMst> getDeptMstList() {
		return deptMstList;
	}
	public void setDeptMstList(List<DeptMst> deptMstList) {
		this.deptMstList = deptMstList;
	}
	public List<SubDeptMst> getSubDeptMstList() {
		return subDeptMstList;
	}
	public void setSubDeptMstList(List<SubDeptMst> subDeptMstList) {
		this.subDeptMstList = subDeptMstList;
	}
	public List<RoleMst> getRoleMstList() {
		return roleMstList;
	}
	public void setRoleMstList(List<RoleMst> roleMstList) {
		this.roleMstList = roleMstList;
	}
	public List<ZoneMst> getZoneMstList() {
		return zoneMstList;
	}
	public void setZoneMstList(List<ZoneMst> zoneMstList) {
		this.zoneMstList = zoneMstList;
	}
	public List<StateMst> getStateMstList() {
		return stateMstList;
	}
	public void setStateMstList(List<StateMst> stateMstList) {
		this.stateMstList = stateMstList;
	}
	public List<HubMst> getHubMstList() {
		return hubMstList;
	}
	public void setHubMstList(List<HubMst> hubMstList) {
		this.hubMstList = hubMstList;
	}
	public List<FranchiseeMaster> getFranchiseeList() {
		return franchiseeList;
	}
	public void setFranchiseeList(List<FranchiseeMaster> franchiseeList) {
		this.franchiseeList = franchiseeList;
	}
	
	
}
