package com.nelco.o2c.dto;

public class SiteInfoDTO {
	private String soNo="";
	private String vsatIP="";
	private String vsatID="";
	private String hub="";
	private String technology="";
	private String circuit_id="";
	public String getSoNo() {
		return soNo;
	}
	public void setSoNo(String soNo) {
		this.soNo = soNo;
	}
	public String getVsatIP() {
		return vsatIP;
	}
	public void setVsatIP(String vsatIP) {
		this.vsatIP = vsatIP;
	}
	public String getVsatID() {
		return vsatID;
	}
	public void setVsatID(String vsatID) {
		this.vsatID = vsatID;
	}
	public String getHub() {
		return hub;
	}
	public void setHub(String hub) {
		this.hub = hub;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getCircuit_id() {
		return circuit_id;
	}
	public void setCircuit_id(String circuit_id) {
		this.circuit_id = circuit_id;
	}
	
	
}
