/**
 * 
 */
package com.nelco.o2c.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.ClauseContractListDTO;
import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.DeptListDTO;
import com.nelco.o2c.dto.DrfApprovalDTO;
import com.nelco.o2c.dto.DrfInfoDTO;
import com.nelco.o2c.dto.MaterialDTO;
import com.nelco.o2c.dto.PlantSapmstDTO;
import com.nelco.o2c.dto.PotentialInfoListDTO;
import com.nelco.o2c.dto.UserRoleListDTO;
import com.nelco.o2c.dto.UsersDeptwiseDTO;
import com.nelco.o2c.model.ClauseContractMst;
import com.nelco.o2c.model.DeptMst;
import com.nelco.o2c.model.DrfTypeMst;
import com.nelco.o2c.model.DrfTypeMstDTO;
import com.nelco.o2c.model.MaterialSapmst;
import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.service.CommonPotentialsService;

/**
 * @author Jayashankar.r
 *
 */
@RestController
public class CommonPotentialsController {
	
	@Autowired
	CommonPotentialsService commonPotentialsService;

	@RequestMapping(value = "/getPotentialInfo.do", method = RequestMethod.POST)
	public PotentialInfoListDTO getPotentialInfo(@RequestBody CommonDTO commonDTO) {
		return commonPotentialsService.getPotentialInfo(commonDTO);
	}
	
	@RequestMapping(value = "/getUserDetailsById.do", method = RequestMethod.POST)
	public UserMst getUserDetailsById(@RequestBody UserMst userMst) {
		return commonPotentialsService.getUserDetailsById(userMst.getUserMstId());
	}
	
	@RequestMapping(value = "/getUserDetByLoginId.do", method = RequestMethod.POST)
	public UserMst getUserDetByLoginId(@RequestBody UserMst userMst) {
		return commonPotentialsService.getUserDetByLoginId(userMst.getLoginId());
	}
	
	@RequestMapping(value = "/uniqueMaterial.do", method = RequestMethod.POST)
	public MaterialSapmst uniqueMaterial(@RequestBody MaterialDTO materialDTO) {
		return commonPotentialsService.uniqueMaterial(materialDTO);
	}
	
	@RequestMapping(value = "/getUserListByJobCode.do", method = RequestMethod.POST)
	public UserRoleListDTO getUserListByJobCode(@RequestBody UserRoleListDTO userRoleListDTO) {
		
		return commonPotentialsService.getUserListByJobCode(userRoleListDTO);
	}
	
	@RequestMapping(value = "/getAllDeptList.do", method = RequestMethod.POST)
	public DeptListDTO getAllDeptList(@RequestBody DeptMst deptMst) {
		return commonPotentialsService.getAllDeptList(deptMst);
	}
	
	@RequestMapping(value = "/getUserListDeptwise.do", method = RequestMethod.POST)
	public UsersDeptwiseDTO getUserListDeptwise(@RequestBody DeptMst deptMst) {
		
		return commonPotentialsService.getUserListDeptwise(deptMst);
	}
	
	@RequestMapping(value = "/getAllDrfTypeList.do", method = RequestMethod.POST)
	public DrfTypeMstDTO getAllDrfTypeList(@RequestBody DrfTypeMst drfTypeMst) {
		return commonPotentialsService.getAllDrfTypeList(drfTypeMst);
	}
	
	@RequestMapping(value = "/getNocMgrAndFinanceUsers.do", method = RequestMethod.POST)
	public UserRoleListDTO getNocMgrAndFinanceUsers(@RequestBody UserRoleListDTO userRoleListDTO) {
		
		return commonPotentialsService.getNocMgrAndFinanceUsers(userRoleListDTO);
	}
	
	@RequestMapping(value = "/getPmFinanceAmUsers.do", method = RequestMethod.POST)
	public UserRoleListDTO getPmFinanceAmUsers(@RequestBody UserRoleListDTO userRoleListDTO) {
		
		return commonPotentialsService.getPmFinanceAmUsers(userRoleListDTO);
	}
	
	@RequestMapping(value="/getDrfApprovalInfo.do",method = RequestMethod.POST)
	public DrfApprovalDTO getDrfApprovalInfo(@RequestBody DrfInfoDTO drfInfoDTO) {
		
		return commonPotentialsService.getDrfApprovalInfo(drfInfoDTO);
	}
	
		
	@RequestMapping(value="/allClauseContList.do",method = RequestMethod.POST)
	public ClauseContractListDTO allClauseContList(ClauseContractMst clauseContractMst) {
		 
//		ClauseContractListDTO clauseContractListDTO = new ClauseContractListDTO();
		return commonPotentialsService.allClauseContList(clauseContractMst);
//		return clauseContractListDTO;
	}
	
	@RequestMapping(value="/allPlantList.do",method = RequestMethod.POST)
	public PlantSapmstDTO allPlantList(PlantSapmstDTO plantSapmstDTO) {
		PlantSapmstDTO plantSapmstDTONew = new PlantSapmstDTO();
		List<PlantSapmst> plantList = new ArrayList<PlantSapmst>();
	
		plantList = commonPotentialsService.allPlantList(plantSapmstDTO);
		
		PlantSapmst plantSapmst = new PlantSapmst();
		plantSapmst.setPlantCode("ALL");
		plantSapmst.setPlantName("All");
		plantList.add(plantSapmst);
		
		plantSapmstDTONew.setPlantList(plantList);
		return plantSapmstDTONew;
	}
	
}
