/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.FranchiseInvReq;
import com.nelco.o2c.model.IncInvoice;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.StatusMst;

/**
 * @author Jayshankar.r
 *
 */
public class PaymentRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<OppUploadDetail> oppUploadDetails;
	private Integer csId;
	private Integer userMstId;
	private Integer hoCsId;
	private Integer csHead;
	private Integer roleMstId;
	private List<Integer> siteSurveyCostIds;
	private UserEmailDetailsBean cseUser;
	private List<FranchiseInvReq> payReqList;
	private UserEmailDetailsBean hoCsUser;
	private UserEmailDetailsBean csHeadUser;
	private List<UserEmailDetailsBean> cseUsers;
	private List<UserEmailDetailsBean> hoCsUsers;
	private List<UserEmailDetailsBean> csHeadUsers;
	private String statusCode;
	private List<StatusMst> statusList;
	private Integer franchiseInvReqId;
	private String roleCode;
	private String apprRejFlag;
	private String rejRemarks;
	private String fromDate;
	private String toDate;
	private List<FileTypeMst> fileList;
	private List<IncInvoice> incInvoiceList;
	
	
	
	
	
	public List<IncInvoice> getIncInvoiceList() {
		return incInvoiceList;
	}
	public void setIncInvoiceList(List<IncInvoice> incInvoiceList) {
		this.incInvoiceList = incInvoiceList;
	}
	public List<FileTypeMst> getFileList() {
		return fileList;
	}
	public void setFileList(List<FileTypeMst> fileList) {
		this.fileList = fileList;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getRejRemarks() {
		return rejRemarks;
	}
	public void setRejRemarks(String rejRemarks) {
		this.rejRemarks = rejRemarks;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getApprRejFlag() {
		return apprRejFlag;
	}
	public void setApprRejFlag(String apprRejFlag) {
		this.apprRejFlag = apprRejFlag;
	}
	public Integer getFranchiseInvReqId() {
		return franchiseInvReqId;
	}
	public void setFranchiseInvReqId(Integer franchiseInvReqId) {
		this.franchiseInvReqId = franchiseInvReqId;
	}
	public List<StatusMst> getStatusList() {
		return statusList;
	}
	public void setStatusList(List<StatusMst> statusList) {
		this.statusList = statusList;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public UserEmailDetailsBean getHoCsUser() {
		return hoCsUser;
	}
	public void setHoCsUser(UserEmailDetailsBean hoCsUser) {
		this.hoCsUser = hoCsUser;
	}
	public UserEmailDetailsBean getCsHeadUser() {
		return csHeadUser;
	}
	public void setCsHeadUser(UserEmailDetailsBean csHeadUser) {
		this.csHeadUser = csHeadUser;
	}
	public List<UserEmailDetailsBean> getCseUsers() {
		return cseUsers;
	}
	public void setCseUsers(List<UserEmailDetailsBean> cseUsers) {
		this.cseUsers = cseUsers;
	}
	public List<UserEmailDetailsBean> getHoCsUsers() {
		return hoCsUsers;
	}
	public void setHoCsUsers(List<UserEmailDetailsBean> hoCsUsers) {
		this.hoCsUsers = hoCsUsers;
	}
	public List<UserEmailDetailsBean> getCsHeadUsers() {
		return csHeadUsers;
	}
	public void setCsHeadUsers(List<UserEmailDetailsBean> csHeadUsers) {
		this.csHeadUsers = csHeadUsers;
	}
	public List<FranchiseInvReq> getPayReqList() {
		return payReqList;
	}
	public void setPayReqList(List<FranchiseInvReq> payReqList) {
		this.payReqList = payReqList;
	}
	public UserEmailDetailsBean getCseUser() {
		return cseUser;
	}
	public void setCseUser(UserEmailDetailsBean cseUser) {
		this.cseUser = cseUser;
	}
	public List<Integer> getSiteSurveyCostIds() {
		return siteSurveyCostIds;
	}
	public void setSiteSurveyCostIds(List<Integer> siteSurveyCostIds) {
		this.siteSurveyCostIds = siteSurveyCostIds;
	}
	public Integer getRoleMstId() {
		return roleMstId;
	}
	public void setRoleMstId(Integer roleMstId) {
		this.roleMstId = roleMstId;
	}
	public Integer getCsId() {
		return csId;
	}
	public void setCsId(Integer csId) {
		this.csId = csId;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public Integer getHoCsId() {
		return hoCsId;
	}
	public void setHoCsId(Integer hoCsId) {
		this.hoCsId = hoCsId;
	}
	public Integer getCsHead() {
		return csHead;
	}
	public void setCsHead(Integer csHead) {
		this.csHead = csHead;
	}
	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}
	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}
	
	
	

}
