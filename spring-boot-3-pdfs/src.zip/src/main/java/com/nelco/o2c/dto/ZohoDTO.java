/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Amol.l
 *
 */
public class ZohoDTO  implements Serializable {

	private static final long serialVersionUID = 106L;

	@JsonProperty("access_token")
	private String accessToken;
	
	@JsonProperty("api_domain")
	private String apiDomain;
	
	@JsonProperty("token_type")
	private String tokenType;
	
	@JsonProperty("expires_in")
	private String expiresIn;
	
	private String lastModifiedTime;
	
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public String getApiDomain() {
		return apiDomain;
	}
	public void setApiDomain(String apiDomain) {
		this.apiDomain = apiDomain;
	}
	public String getTokenType() {
		return tokenType;
	}
	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}
	public String getExpiresIn() {
		return expiresIn;
	}
	public void setExpiresIn(String expiresIn) {
		this.expiresIn = expiresIn;
	}
	public String getLastModifiedTime() {
		return lastModifiedTime;
	}
	public void setLastModifiedTime(String lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}

}
