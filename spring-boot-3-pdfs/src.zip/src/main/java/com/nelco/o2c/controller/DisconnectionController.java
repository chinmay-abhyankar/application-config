package com.nelco.o2c.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.DisconnectionDTO;
import com.nelco.o2c.dto.DisconnectionFormDTO;
import com.nelco.o2c.dto.PoDTO;
import com.nelco.o2c.service.DisconnectionService;

@RestController
public class DisconnectionController {
@Autowired
DisconnectionService disconnectionService;

@RequestMapping(value = "/getCustomerwiseOutstanding.do", method = RequestMethod.POST)
public DisconnectionDTO getCustomerwiseOutstanding(@RequestBody DisconnectionDTO disconnectionDTO) {
	return disconnectionService.getCustomerwiseOutstanding(disconnectionDTO);
}

@RequestMapping(value = "/getOutstandingforCustomer.do", method = RequestMethod.GET)
public DisconnectionDTO getOutstandingforCustomer(@RequestBody DisconnectionDTO disconnectionDTO, HttpServletRequest request) {
	return disconnectionService.getOutstandingforCustomer(disconnectionDTO,request);
}

@RequestMapping(value = "/getOutstandingInvoicesList.do", method = RequestMethod.GET)
public DisconnectionDTO getOutstandingInvoicesList(DisconnectionDTO disconnectionDTO, HttpServletRequest request) {
	return disconnectionService.getOutstandingInvoicesList(disconnectionDTO, request);
}

@RequestMapping(value = "/getDisconnectionMasters.do", method = RequestMethod.GET)
public DisconnectionFormDTO getDisconnectionMasters(DisconnectionFormDTO disconnectionFormDTO) {
	return disconnectionService.getDisconnectionMasters(disconnectionFormDTO);
}

@RequestMapping(value = "/updateReminderStatus.do", method = RequestMethod.POST)
public DisconnectionFormDTO updateReminderStatus(@RequestBody DisconnectionFormDTO disconnectionFormDTO, HttpServletRequest request) {
	return disconnectionService.updateReminderStatus(disconnectionFormDTO,request);
}

@RequestMapping(value = "/saveReminderDetails.do", method = RequestMethod.POST)
public DisconnectionFormDTO saveReminderDetails(@RequestBody DisconnectionFormDTO disconnectionFormDTO, HttpServletRequest request) {
	return disconnectionService.saveReminderDetails(disconnectionFormDTO,request);
}

@RequestMapping(value = "/initiateDisconnectionNotice.do", method = RequestMethod.POST)
public DisconnectionFormDTO initiateDisconnectionNotice(@RequestBody DisconnectionFormDTO disconnectionFormDTO, HttpServletRequest request) {
	return disconnectionService.initiateDisconnectionNotice(disconnectionFormDTO,request);
}

@RequestMapping(value = "/disconnectionNoticeRequestDetails.do", method = RequestMethod.GET)
public DisconnectionFormDTO getDisconnectionNoticeRequestDetails(DisconnectionFormDTO disconnectionFormDTO, HttpServletRequest request) {
	return disconnectionService.getDisconnectionNoticeRequestDetails(disconnectionFormDTO,request);
}

@RequestMapping(value = "/appRejDisconnectionNoticeRequest.do", method = RequestMethod.POST)
public DisconnectionFormDTO appRejDisconnectionNoticeRequest(@RequestBody DisconnectionFormDTO disconnectionFormDTO, HttpServletRequest request) {
	return disconnectionService.appRejDisconnectionNoticeRequest(disconnectionFormDTO,request);
}

@RequestMapping(value = "/appRejDisconnectionRequest.do", method = RequestMethod.POST)
public DisconnectionFormDTO appRejDisconnectionRequest(@RequestBody DisconnectionFormDTO disconnectionFormDTO, HttpServletRequest request) {
	return disconnectionService.appRejDisconnectionRequest(disconnectionFormDTO,request);
}

@RequestMapping(value = "/updateDisconnectionRequestStatus.do", method = RequestMethod.POST)
public DisconnectionFormDTO updateDisconnectionRequestStatus(@RequestBody DisconnectionFormDTO disconnectionFormDTO, HttpServletRequest request) {
	return disconnectionService.updateDisconnectionRequestStatus(disconnectionFormDTO,request);
}

@RequestMapping(value = "/getDisconnectionForNonPaymentReport.do", method = RequestMethod.GET)
public DisconnectionDTO getDisconnectionForNonPaymentReport(DisconnectionDTO disconnectionDTO, HttpServletRequest request) {
	return disconnectionService.getDisconnectionForNonPaymentReport(disconnectionDTO, request);
}
}
