package com.nelco.o2c.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.nelco.o2c.dto.SiteSurveyDTO;
import com.nelco.o2c.dto.SiteSurveyEngineerDTO;
import com.nelco.o2c.dto.SiteSurveyFormDTO;
import com.nelco.o2c.dto.SiteSurveyListDTO;
import com.nelco.o2c.dto.UpdateFranchiseDTO;
import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.model.FranchiseeMaster;
import com.nelco.o2c.model.SiteSurveyEngineerMst;
import com.nelco.o2c.model.SiteSurveyMaster;

public interface SiteSurveyDao {
	public SiteSurveyFormDTO getSiteSurveyFormMasters(SiteSurveyFormDTO SiteSurveyFormDTO);
	
	public List<CustomerSapmst> getListCustomerAutoComplete(HttpServletRequest request);	
	
	public SiteSurveyMaster saveSiteSurveyDTO(SiteSurveyDTO siteSurveyDTO);
	
	public SiteSurveyMaster submitSiteSurveyDTO(SiteSurveyDTO siteSurveyDTO);
	
	public Integer getCurrentDayCountSiteSurveyMaster();
	
	public List<FranchiseeMaster> getFranchiseeList();
	
	public List<SiteSurveyListDTO> getSiteSurveyListCS(HttpServletRequest request);
	
	public List<SiteSurveyListDTO> getSitSurveyListByUser(HttpServletRequest request);	
	
	public SiteSurveyMaster updateFranchisee(UpdateFranchiseDTO input);
	
	public SiteSurveyMaster getSiteSurveyById(HttpServletRequest request);
	
	public List<SiteSurveyListDTO>  getSitSurveyListForFranchisee(HttpServletRequest request);
	
	public SiteSurveyEngineerMst saveSiteSurveyEngineer(SiteSurveyEngineerDTO siteSurveyEngineerDTO);
	
	public SiteSurveyEngineerMst getEngineerById(HttpServletRequest request);
	
	public void uploadFile(MultipartFile file,String userId) throws Exception;
	
	public int getCount(String table,String column,String value);
	
	public List<SiteSurveyEngineerMst> getEngineerListBySiteIdFrachiseeId(HttpServletRequest request);
	
	public void updateTracker(Integer site_survey_id,Integer status,Integer user_id) throws Exception;

	public SiteSurveyMaster getSiteSurveyByUniqId(SiteSurveyDTO siteSurveyDTO);
	
}
