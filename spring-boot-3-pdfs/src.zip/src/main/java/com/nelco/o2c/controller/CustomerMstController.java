/**
 * 
 */
package com.nelco.o2c.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.CustomerMstDTO;
import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.service.CustomerMstService;

/**
 * @author Amol.l
 *
 */
@RestController
public class CustomerMstController {
	
	@Autowired
	CustomerMstService customerMstService;

	@RequestMapping(value = "/getCustomerdetailsByCustomerNum.do", method = RequestMethod.POST)
	public CustomerMstDTO getCustomerdetailsByCustomerNum(@RequestBody CustomerMstDTO customerMstDTO) {
		CustomerMstDTO customerMstDTONew = new CustomerMstDTO();
		CustomerSapmst customerSapmst = new CustomerSapmst();
		customerSapmst = customerMstService.getCustomerdetailsByCustomerNum(customerMstDTO);
		customerMstDTONew.setCustomerSapmst(customerSapmst);
		customerMstDTONew.setCustomerNum(customerMstDTO.getCustomerNum());
		return customerMstDTONew;
	}
}
