package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the query database table.
 * 
 */
@Entity
@Table(name = "query")
@NamedQueries({ @NamedQuery(name = "Queries.findAllQueries", query = "SELECT q FROM Query q"),
		@NamedQuery(name = "Queries.findByDrfId", query = "SELECT q FROM Query q inner join q.drfQueryUserMapSet dqum where q.drfDetailsId = ?1 and dqum.queryUserId = ?2"),
		@NamedQuery(name = "Queries.getByQueryId", query = "SELECT q FROM Query q where q.queryId = ?1")})
public class Query implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "query_id")
	private Integer queryId;

	@Column(name = "created_date",insertable = false)
	private String createdDate;

	@Column(name = "drf_details_id")
	private Integer drfDetailsId;

	@Column(name = "query")
	private String query;

	@Column(name = "user_mst_id")
	private Integer userMstId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_mst_id", referencedColumnName = "user_mst_id", insertable = false, updatable = false)
	private UserMst userMst;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "query_id", referencedColumnName = "query_id", insertable = false, updatable = false)
	private List<Response> responses;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "query_id", referencedColumnName = "query_id", insertable = false, updatable = false)
	private Set<DrfQueryUserMap> drfQueryUserMapSet;
	
	

	public Set<DrfQueryUserMap> getDrfQueryUserMapSet() {
		return drfQueryUserMapSet;
	}

	public void setDrfQueryUserMapSet(Set<DrfQueryUserMap> drfQueryUserMapSet) {
		this.drfQueryUserMapSet = drfQueryUserMapSet;
	}

	public UserMst getUserMst() {
		return userMst;
	}

	public void setUserMst(UserMst userMst) {
		this.userMst = userMst;
	}

	public List<Response> getResponses() {
		return responses;
	}

	public void setResponses(List<Response> responses) {
		this.responses = responses;
	}

	public Integer getQueryId() {
		return queryId;
	}

	public void setQueryId(Integer queryId) {
		this.queryId = queryId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}

	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public Integer getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

}