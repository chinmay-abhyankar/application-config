package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;


/**
 * The persistent class for the fa_eng_visit_details database table.
 * 
 */
@Entity
@Table(name="fa_eng_visit_details")
@NamedQueries({
	@NamedQuery(name="FaEngVisitDetail.findAll", query="SELECT f FROM FaEngVisitDetail f")	
	,@NamedQuery(name="FaEngVisitDetail.findByFranchiseeAllocId", query="SELECT f FROM FaEngVisitDetail f"
			+ " where f.franchiseeAllocId=?1")	
	,@NamedQuery(name="FaEngVisitDetail.findById", query="SELECT f FROM FaEngVisitDetail f"
			+ " where f.id=?1")	
	,@NamedQuery(name = "FaEngVisitDetail.updateSubmitFlag", query = "update FaEngVisitDetail"
			+ " s set s.isSubmit = 'Y' where s.id=?1")
})
public class FaEngVisitDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;

	@Column(name="abort_reason")
	private String abortReason;

	@Column(name="actual_person_contact")
	private String actualPersonContact;

	@Column(name="actual_person_name")
	private String actualPersonName;

	@Column(name="additional_remarks")
	private String additionalRemarks;
	
	@Column(name="remarks")
	private String remarks;

	@Column(name="antenna_size_id")
	private Integer antennaSizeId;

	@Column(name="building_height")
	private String buildingHeight;

	@Column(name="cable_len")
	private String cableLen;

	private String contact;

	@Column(name="created_date")
	private String createdDate;

	@Column(name="cust_address")
	private String custAddress;

	@Column(name="customer_name")
	private String customerName;

	@Column(name="engineer_id")
	private Integer engineerId;

	@Column(name="franchisee_alloc_id")
	private Integer franchiseeAllocId;

	@Column(name="hub_details")
	private Integer hubDetails;

	@Column(name="idu_room_ready")
	private String iduRoomReady;

	@Column(name="is_submit")
	private String isSubmit;

	@Column(name="km_appl_mst_id")
	private Integer kmApplMstId;

	@Column(name="ladder_height")
	private String ladderHeight;

	@Column(name="ladder_req")
	private String ladderReq;

	@Column(name="monkey_protection_req")
	private String monkeyProtectionReq;

	@Column(name="non_feasible_option_mst_id")
	private Integer nonFeasibleOptionMstId;

	@Column(name="platform_req")
	private String platformReq;
	
	
	
	@Column(name="technology")
	private Integer technology;
	
	@Column(name="ups_avail")
	private String upsAvail;
	
	@Column(name="visit")
	private String visit;
	
	@Column(name = "material_avail")
	private String materialAvail = "N";

	@Column(name="work_completion_status_mst_id")
	private Integer workCompletionStatusMstId;

	@Column(name="work_completion_status_update_time")
	private String workCompletionStatusUpdateTime;
	
	@Column(name="visit_date")
	private String visitDate;
	
	@Column(name="visit_time")
	private String visitTime;
	
	@Column(name="antenna_type_mst_id")
	private Integer antennaTypeMstId;
	
	@Column(name="site_clear_for_wm_now")
	private String siteClearForWmNow;	
	
	@Column(name="mast_height")
	private String mastHeight;
	
	@Column(name="antenna_location_mst_id")
	private Integer antennaLocationMstId;
	
	@Column(name="earthing")
	private String earthing;
	
	@Column(name="lan_cable")
	private String lanCable;
	
	@Column(name="noc_from_building")
	private String nocFromBuilding;
	
	@Column(name="earthing_wire")
	private String earthingWire;
	
	@Column(name="power_socket_avail")
	private String powerSocketAvail;
	
	@Column(name="monkey_menace")
	private String monkeyMenace;
	
	@Column(name = "tso_number")
	private String tsoNumber;
	
	@Column(name = "tso_approved_date",updatable = false)
	private String tsoApprovedDate;
	
	@Column(name = "installation_status_mst_id")
	private Integer installationStatusMstId;
	
	@Column(name = "inc_attribution_mst_id")
	private Integer incAttributionMstId;
	
	@Column(name="activity_type")
	private Integer activityType;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "franchisee_alloc_id", referencedColumnName = "id", insertable = false, updatable = false)
	private FranchiseeAllocationMst franchiseeAllocationMst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "engineer_id", referencedColumnName = "id", insertable = false, updatable = false)
	private FranchiseeAllocEngMst franchiseeAllocEngMst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "work_completion_status_mst_id", referencedColumnName = "work_completion_status_mst_id", insertable = false, updatable = false)
	private WorkCompletionStatusMst workCompletionStatusMst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "installation_status_mst_id", referencedColumnName = "installation_status_mst_id", insertable = false, updatable = false)
	private InstallationStatusMst installationStatusMst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "inc_attribution_mst_id", referencedColumnName = "inc_attribution_mst_id", insertable = false, updatable = false)
	private IncAttributionMst incAttributionMst;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "fa_eng_visit_details_id", referencedColumnName = "id", insertable = false, updatable = false)
	private List<OppUploadDetail> oppUploadDetails = new ArrayList<OppUploadDetail>();


	public Integer getActivityType() {
		return activityType;
	}

	public void setActivityType(Integer activityType) {
		this.activityType = activityType;
	}

	public IncAttributionMst getIncAttributionMst() {
		return incAttributionMst;
	}

	public void setIncAttributionMst(IncAttributionMst incAttributionMst) {
		this.incAttributionMst = incAttributionMst;
	}

	public Integer getIncAttributionMstId() {
		return incAttributionMstId;
	}

	public void setIncAttributionMstId(Integer incAttributionMstId) {
		this.incAttributionMstId = incAttributionMstId;
	}

	public InstallationStatusMst getInstallationStatusMst() {
		return installationStatusMst;
	}

	public void setInstallationStatusMst(InstallationStatusMst installationStatusMst) {
		this.installationStatusMst = installationStatusMst;
	}

	public Integer getInstallationStatusMstId() {
		return installationStatusMstId;
	}

	public void setInstallationStatusMstId(Integer installationStatusMstId) {
		this.installationStatusMstId = installationStatusMstId;
	}

	public String getTsoApprovedDate() {
		//return tsoApprovedDate;
		return DateUtil.convertDateTimeToString(this.tsoApprovedDate);
	}

	public void setTsoApprovedDate(String tsoApprovedDate) {
		this.tsoApprovedDate = tsoApprovedDate;
	}

	public String getTsoNumber() {
		return tsoNumber;
	}

	public void setTsoNumber(String tsoNumber) {
		this.tsoNumber = tsoNumber;
	}

	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}

	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}

	public String getVisitDate() {
		return visitDate;
	}



	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}



	public String getVisitTime() {
		return visitTime;
	}



	public void setVisitTime(String visitTime) {
		this.visitTime = visitTime;
	}



	public Integer getAntennaTypeMstId() {
		return antennaTypeMstId;
	}



	public void setAntennaTypeMstId(Integer antennaTypeMstId) {
		this.antennaTypeMstId = antennaTypeMstId;
	}



	public String getSiteClearForWmNow() {
		return siteClearForWmNow;
	}



	public void setSiteClearForWmNow(String siteClearForWmNow) {
		this.siteClearForWmNow = siteClearForWmNow;
	}



	public String getMastHeight() {
		return mastHeight;
	}



	public void setMastHeight(String mastHeight) {
		this.mastHeight = mastHeight;
	}



	public Integer getAntennaLocationMstId() {
		return antennaLocationMstId;
	}



	public void setAntennaLocationMstId(Integer antennaLocationMstId) {
		this.antennaLocationMstId = antennaLocationMstId;
	}



	public String getEarthing() {
		return earthing;
	}



	public void setEarthing(String earthing) {
		this.earthing = earthing;
	}



	public String getLanCable() {
		return lanCable;
	}



	public void setLanCable(String lanCable) {
		this.lanCable = lanCable;
	}



	public String getNocFromBuilding() {
		return nocFromBuilding;
	}



	public void setNocFromBuilding(String nocFromBuilding) {
		this.nocFromBuilding = nocFromBuilding;
	}



	public String getEarthingWire() {
		return earthingWire;
	}



	public void setEarthingWire(String earthingWire) {
		this.earthingWire = earthingWire;
	}



	public String getPowerSocketAvail() {
		return powerSocketAvail;
	}



	public void setPowerSocketAvail(String powerSocketAvail) {
		this.powerSocketAvail = powerSocketAvail;
	}



	public String getMonkeyMenace() {
		return monkeyMenace;
	}



	public void setMonkeyMenace(String monkeyMenace) {
		this.monkeyMenace = monkeyMenace;
	}



	public String getRemarks() {
		return remarks;
	}



	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}



	public FranchiseeAllocEngMst getFranchiseeAllocEngMst() {
		return franchiseeAllocEngMst;
	}



	public void setFranchiseeAllocEngMst(FranchiseeAllocEngMst franchiseeAllocEngMst) {
		this.franchiseeAllocEngMst = franchiseeAllocEngMst;
	}



	public FranchiseeAllocationMst getFranchiseeAllocationMst() {
		return franchiseeAllocationMst;
	}



	public void setFranchiseeAllocationMst(FranchiseeAllocationMst franchiseeAllocationMst) {
		this.franchiseeAllocationMst = franchiseeAllocationMst;
	}



	public WorkCompletionStatusMst getWorkCompletionStatusMst() {
		return workCompletionStatusMst;
	}



	public void setWorkCompletionStatusMst(WorkCompletionStatusMst workCompletionStatusMst) {
		this.workCompletionStatusMst = workCompletionStatusMst;
	}



	public FaEngVisitDetail() {
	}

	

	public String getAbortReason() {
		return this.abortReason;
	}

	public void setAbortReason(String abortReason) {
		this.abortReason = abortReason;
	}

	public String getActualPersonContact() {
		return this.actualPersonContact;
	}

	public void setActualPersonContact(String actualPersonContact) {
		this.actualPersonContact = actualPersonContact;
	}

	public String getActualPersonName() {
		return this.actualPersonName;
	}

	public void setActualPersonName(String actualPersonName) {
		this.actualPersonName = actualPersonName;
	}

	public String getAdditionalRemarks() {
		return this.additionalRemarks;
	}

	public void setAdditionalRemarks(String additionalRemarks) {
		this.additionalRemarks = additionalRemarks;
	}

	public Integer getAntennaSizeId() {
		return this.antennaSizeId;
	}

	public void setAntennaSizeId(Integer antennaSizeId) {
		this.antennaSizeId = antennaSizeId;
	}

	public String getBuildingHeight() {
		return this.buildingHeight;
	}

	public void setBuildingHeight(String buildingHeight) {
		this.buildingHeight = buildingHeight;
	}

	public String getCableLen() {
		return this.cableLen;
	}

	public void setCableLen(String cableLen) {
		this.cableLen = cableLen;
	}

	public String getContact() {
		return this.contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCustAddress() {
		return this.custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	public String getCustomerName() {
		return this.customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	

	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public Integer getEngineerId() {
		return engineerId;
	}



	public void setEngineerId(Integer engineerId) {
		this.engineerId = engineerId;
	}



	public Integer getFranchiseeAllocId() {
		return this.franchiseeAllocId;
	}

	public void setFranchiseeAllocId(Integer franchiseeAllocId) {
		this.franchiseeAllocId = franchiseeAllocId;
	}

	public Integer getHubDetails() {
		return this.hubDetails;
	}

	public void setHubDetails(Integer hubDetails) {
		this.hubDetails = hubDetails;
	}

	public String getIduRoomReady() {
		return this.iduRoomReady;
	}

	public void setIduRoomReady(String iduRoomReady) {
		this.iduRoomReady = iduRoomReady;
	}

	public String getIsSubmit() {
		return this.isSubmit;
	}

	public void setIsSubmit(String isSubmit) {
		this.isSubmit = isSubmit;
	}

	public Integer getKmApplMstId() {
		return this.kmApplMstId;
	}

	public void setKmApplMstId(Integer kmApplMstId) {
		this.kmApplMstId = kmApplMstId;
	}

	public String getLadderHeight() {
		return this.ladderHeight;
	}

	public void setLadderHeight(String ladderHeight) {
		this.ladderHeight = ladderHeight;
	}

	public String getLadderReq() {
		return this.ladderReq;
	}

	public void setLadderReq(String ladderReq) {
		this.ladderReq = ladderReq;
	}

	public String getMonkeyProtectionReq() {
		return this.monkeyProtectionReq;
	}

	public void setMonkeyProtectionReq(String monkeyProtectionReq) {
		this.monkeyProtectionReq = monkeyProtectionReq;
	}

	public Integer getNonFeasibleOptionMstId() {
		return this.nonFeasibleOptionMstId;
	}

	public void setNonFeasibleOptionMstId(Integer nonFeasibleOptionMstId) {
		this.nonFeasibleOptionMstId = nonFeasibleOptionMstId;
	}

	public String getPlatformReq() {
		return this.platformReq;
	}

	public void setPlatformReq(String platformReq) {
		this.platformReq = platformReq;
	}

	

	public Integer getTechnology() {
		return this.technology;
	}

	public void setTechnology(Integer technology) {
		this.technology = technology;
	}
	

	public String getUpsAvail() {
		return this.upsAvail;
	}

	public void setUpsAvail(String upsAvail) {
		this.upsAvail = upsAvail;
	}

	public String getVisit() {
		return this.visit;
	}

	public void setVisit(String visit) {
		this.visit = visit;
	}

	
	public String getMaterialAvail() {
		return materialAvail;
	}

	public void setMaterialAvail(String materialAvail) {
		this.materialAvail = materialAvail;
	}

	public Integer getWorkCompletionStatusMstId() {
		return this.workCompletionStatusMstId;
	}

	public void setWorkCompletionStatusMstId(Integer workCompletionStatusMstId) {
		this.workCompletionStatusMstId = workCompletionStatusMstId;
	}

	public String getWorkCompletionStatusUpdateTime() {
		return this.workCompletionStatusUpdateTime;
	}

	public void setWorkCompletionStatusUpdateTime(String workCompletionStatusUpdateTime) {
		this.workCompletionStatusUpdateTime = workCompletionStatusUpdateTime;
	}

}