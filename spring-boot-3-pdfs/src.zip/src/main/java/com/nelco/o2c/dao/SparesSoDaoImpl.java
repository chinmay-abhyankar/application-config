/**
 * 
 */
package com.nelco.o2c.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.nelco.o2c.dto.ConstantProperties;
import com.nelco.o2c.dto.FranchiseeDTO;
import com.nelco.o2c.dto.MaterialDTO;
import com.nelco.o2c.dto.SiteSurveyDTO;
import com.nelco.o2c.dto.SparesDTO;
import com.nelco.o2c.model.ChildContract;
import com.nelco.o2c.model.Contract;
import com.nelco.o2c.model.Delivery;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.FranchiseeAllocationMst;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.InstallationTypeMst;
import com.nelco.o2c.model.MaterialChildContract;
import com.nelco.o2c.model.MaterialContract;
import com.nelco.o2c.model.MaterialSapmst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.SiteSurveyMaster;
import com.nelco.o2c.model.SparesSo;
import com.nelco.o2c.model.SparesSoDetail;
import com.nelco.o2c.model.SparesSoUserMap;
import com.nelco.o2c.model.TechnologyMaster;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.service.CommonMasterService;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Jayshankar.r
 *
 */
@Repository
public class SparesSoDaoImpl implements SparesSoDao {
	
	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	CommonMasterService commonMasterService;
	
	@Autowired
	ConstantProperties prop;
	
	@Autowired
	AutoPopulateDao autoPopulateDao;
	
	Query query;

	@SuppressWarnings("unchecked")
	@Override
	public List<SparesSo> getSparesSoList(SparesDTO sparesInputDTO) {
		// TODO Auto-generated method stub
		String fromDate = DateUtil.convertDateToSqlDate(sparesInputDTO.getFromDate());
		String toDate = DateUtil.convertDateToSqlDate(sparesInputDTO.getToDate()) + Constants.MAXDAYTIME;
		try {
			
			//query = em.createNamedQuery("SparesSo.findByCreatedId");
			query = em.createQuery("SELECT  distinct s FROM SparesSo s inner join fetch s.sparesSoUserMapList userList left join fetch s.sparesSoDetailsList sl left join fetch s.sparesSoDelPgiSet ssdp  where userList.userMstId = :userMstId and s.createdDate between :fromDate and :toDate order by s.sparesSoId desc ");
			query.setParameter("userMstId", sparesInputDTO.getUserMstId());
			query.setParameter("fromDate", fromDate);
			query.setParameter("toDate", toDate);
			List<SparesSo> result = (List<SparesSo>) query.getResultList();
			return result;
		} finally {
			// TODO: handle finally clause
			em.close();
			fromDate = null;
			toDate = null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public SparesSo getSparesSoById(Integer sparesSoId) {
		try {
			// TODO Auto-generated method stub
			if (sparesSoId != null) {
				query = em.createNamedQuery("SparesSo.findById");
				query.setParameter("sparesSoId", sparesSoId);

				List<SparesSo> result = (List<SparesSo>) query.getResultList();

				return result != null && result.size() > 0 ? result.get(0) : new SparesSo();
			} else
				return new SparesSo();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppUploadDetail> getOppUploadBySparesSoId(Integer sparesSoId) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("OppUploadDetail.getOppUploadBySparesSoId");
			query.setParameter("sparesSoId", sparesSoId);
			List<OppUploadDetail> resultList = (List<OppUploadDetail>) query.getResultList();
			return resultList;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public SparesSo saveSparesSo(SparesSo sparesSo) {
		// TODO Auto-generated method stub
		String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
		try {
			String uniqId = "";
			if (sparesSo.getSparesSoId() == null) {
				synchronized (this) {
					Integer maxProposalNumber = getCurrentDayCountSparesSo();
					uniqId = "SPARES_" + (DateUtil.getCurrentISTDateAsString(DateUtil.SIMPLE_DATE_FORMAT)
							.replace("-", "_").concat("_").concat(maxProposalNumber.toString()));
				}
				sparesSo.setUniqId(uniqId);
				
			}
			
			sparesSo.setCreatedDate(currTime);
			sparesSo.setModifiedDate(currTime);
			return em.merge(sparesSo);
		} finally {
			// TODO: handle finally clause
			em.close();
			currTime = null;
		}
	}

	public Integer getCurrentDayCountSparesSo() {
		try {
			String currentDate = DateUtil.getCurrentISTDateOnlyAsString(DateUtil.DATE_ONLY_FORMAT_MSSQL);
			query = em.createNamedQuery("SparesSo.getCurrentDayMaxCount");
			query.setParameter(1, currentDate);
			query.setParameter(2, currentDate + " 23:59:59.999");
			Long maxNumber = (Long) query.getSingleResult();
			return maxNumber.intValue();
		} finally {
			em.close();
		}
	}
	
	@Override
	public SparesSoDetail saveSparesSoDetail(SparesSoDetail sparesSoDetail) {
		// TODO Auto-generated method stub
		String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
		
		try {
			sparesSoDetail.setDelFlg("N");
			sparesSoDetail.setCreatedDate(currTime);
			sparesSoDetail.setModifiedDate(currTime);
			return em.merge(sparesSoDetail);
		} finally {
			// TODO: handle finally clause
			em.close();
			currTime = null;
		}
	}

	@Override
	public SparesSoUserMap saveSparesSoUserMap(SparesSoUserMap sparesSoUserMap) {
		try {
			// TODO Auto-generated method stub
			return em.merge(sparesSoUserMap);
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public boolean checkAlreadyUserEnteredSparesSoMap(Integer sparesSoId, Integer userMstId) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("SparesSoUserMap.countUserSparesSo");
		query.setParameter("sparesSoId", sparesSoId);
		query.setParameter("userMstId", userMstId);
		
		Long maxNumber = (Long) query.getSingleResult();
		return maxNumber.intValue()>0?true:false;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FileTypeMst> getFileListByCode(List<String> fileIdList) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("FileTypeMst.getFileListByCode");
		query.setParameter("fileCodeList", fileIdList);
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		List<FileTypeMst> resultList = (List<FileTypeMst>) query.getResultList();
		return resultList;
	}

	@Override
	public void deleteSparesSoMaterialById(Integer sparesSoDetailsId) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("SparesSoDetail.updateDelFlag");
			query.setParameter("sparesSoDetailsId", sparesSoDetailsId);
			query.executeUpdate();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PlantSapmst> getPlantList() {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("PlantSapmst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<PlantSapmst> resultList = (List<PlantSapmst>) query.getResultList();
			return resultList;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public SparesSo getSparesSoByIncidentId(String incidentId) {
		try {
			// TODO Auto-generated method stub
			
			if(!(String.valueOf(incidentId).trim().equals("") || String.valueOf(incidentId).equals("null"))){
				query = em.createNamedQuery("SparesSo.sparesSoByIncidentId");
				query.setParameter("incidentId", incidentId.trim());

				List<SparesSo> result = (List<SparesSo>) query.getResultList();

				return result != null && result.size() > 0 ? result.get(0) : new SparesSo();
			} else
				return new SparesSo();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Transactional(rollbackFor = Exception.class)
	@Override
	public List<SparesSo> uploadSparesSoReq(MultipartFile file, String userMstId, String roleCode) throws Exception {
		HSSFWorkbook workbook = new HSSFWorkbook(file.getInputStream());
		HSSFRow row = null;
		int i = 1;
		Integer j = null;
		BigDecimal materialNo = null;
		List<SparesSo> sparesSoList = new ArrayList<SparesSo>();
		SparesSo sparesSo = null;
		SparesSo sparesSoNew = null;
		MaterialDTO materialDTO = null;
		SparesSoDetail sparesSoDetail = null;
		PlantSapmst plantSapmst = null;
		SparesSoUserMap sparesSoUserMap = null;
		HSSFSheet worksheet = workbook.getSheetAt(0);
		while (i <= worksheet.getLastRowNum()) {
			row = worksheet.getRow(i++);
			if (!(String.valueOf(row.getCell(0)).trim().equals("")
					|| String.valueOf(row.getCell(0)).trim().equals("null"))) {

				if (j == null || j != (int) Math.round(Double.parseDouble(String.valueOf(row.getCell(0)).trim()))) {
					sparesSo = new SparesSo();
					sparesSoNew = new SparesSo();
					if (!(String.valueOf(row.getCell(4)).trim().equals("")
							|| String.valueOf(row.getCell(4)).trim().equals("null"))) {
						Double soldToParty = Double.parseDouble(String.valueOf(row.getCell(4)).trim());
						sparesSo.setSoldToParty(String.valueOf((long) Math.round(soldToParty)));
					}
					try {
						Double shipToParty = Double.parseDouble(String.valueOf(row.getCell(5)).trim());
						sparesSo.setShipToPartyId(String.valueOf((long) Math.round(shipToParty)));
					} catch (NumberFormatException e) {
						sparesSo.setShipToPartyId(String.valueOf(row.getCell(5)).trim());
					}

					sparesSo.setShipToParty(String.valueOf(row.getCell(6)).trim());
					sparesSo.setShtpAddress(String.valueOf(row.getCell(7)).trim());

					plantSapmst = commonMasterService.getPlantByPlantCode(String.valueOf(row.getCell(8)).trim());
					sparesSo.setPlantSapmstId(plantSapmst.getPlantSapmstId());
					try {
						Double poNumber = Double.parseDouble(String.valueOf(row.getCell(9)).trim());
						sparesSo.setPoNumber(String.valueOf((long) Math.round(poNumber)));
					} catch (NumberFormatException e) {
						sparesSo.setPoNumber(String.valueOf(String.valueOf(row.getCell(9)).trim()));
					}
					sparesSo.setSpecialInstructions(String.valueOf(row.getCell(10)).trim());
					sparesSo.setCreatedById(Integer.parseInt(userMstId));
					if (roleCode.equalsIgnoreCase(Constants.SUPPEXECROLECODE)) {
						sparesSo.setIncidentId(String.valueOf(row.getCell(11)).trim());
						
				/*		if (commonMasterService.getCount("spares_so", "incident_id",
								String.valueOf(row.getCell(11)).trim()) <= 0) {
							sparesSo.setIncidentId(String.valueOf(row.getCell(11)).trim());
						} else {
							throw new Exception("Error of Line No : " + i + " . Duplicate Incident Id : "
									+ String.valueOf(row.getCell(11)).trim());
						}*/
						
					} else {
						sparesSo.setIncidentId(null);
					}
					sparesSo.setIsSubmit("N");
					sparesSo.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
					sparesSo.setModifiedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
					String uniqId = "";
					synchronized (this) {
						Integer maxProposalNumber = getCurrentDayCountSparesSo();
						uniqId = "SPARES_" + (DateUtil.getCurrentISTDateAsString(DateUtil.SIMPLE_DATE_FORMAT)
								.replace("-", "_").concat("_").concat(maxProposalNumber.toString()));
					}
					sparesSo.setUniqId(uniqId);
					if(roleCode.equalsIgnoreCase(Constants.SUPPEXECROLECODE)) {
					sparesSo.setSparesSoType(prop.getCsSpareSoType());
					}
					if(roleCode.equalsIgnoreCase(Constants.PROGRAMMGRCODE)){
						sparesSo.setSparesSoType(prop.getPmgtSpareSoType());
					}
					
					sparesSoNew = em.merge(sparesSo);
					if (sparesSo.getSparesSoId() == null) {
						em.refresh(sparesSoNew);
					}
					sparesSoList.add(sparesSoNew);
					j = (int) Math.round(Double.parseDouble(String.valueOf(row.getCell(0)).trim()));
					
					// code for entering data in user mapping table of spares so begins
					sparesSoUserMap = new SparesSoUserMap();
					sparesSoUserMap.setSparesSoId(sparesSoNew.getSparesSoId());
					sparesSoUserMap.setUserMstId(Integer.parseInt(userMstId));
					SparesSoUserMap savedSparesSoUserMap = this.saveSparesSoUserMap(sparesSoUserMap);
				}
				sparesSoDetail = new SparesSoDetail();
				sparesSoDetail.setSparesSoId(sparesSoNew.getSparesSoId());
				Double itemNum = Double.parseDouble(String.valueOf(row.getCell(1)).trim());
				sparesSoDetail.setItemNo(String.valueOf((int) Math.round(itemNum)));
				try {
					materialNo = new BigDecimal(String.valueOf(row.getCell(2)).trim());
					sparesSoDetail.setMaterialCode(materialNo.toPlainString());
				} catch (NumberFormatException e) {
					sparesSoDetail.setMaterialCode(String.valueOf(row.getCell(2)).trim());
				}
				List<MaterialSapmst> materialList = autoPopulateDao
						.searchMaterialSparesSo(String.valueOf(row.getCell(2)).trim());
				if (materialList != null && materialList.size() > 0) {
					sparesSoDetail.setMaterialDesc(materialList.get(0).getMaterialDesc());
				}
				Double orderQty = Double.parseDouble(String.valueOf(row.getCell(3)).trim());
				sparesSoDetail.setQuantity(new Integer((int) orderQty.intValue()).toString());

				this.saveSparesSoDetail(sparesSoDetail);
			}
		}
		return sparesSoList;

	}

}
