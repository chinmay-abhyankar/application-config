/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Jayashankar.r
 *
 */
@Entity
@Table(name = "role_mst")
public class RoleMst implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "role_mst_id")
	private Integer roleMstId;

	@Column(name = "role_cd", length = 10)
	private String roleCd;

	@Column(name = "role_desc", length = 50)
	private String roleDesc;

	public Integer getRoleMstId() {
		return roleMstId;
	}

	public void setRoleMstId(Integer roleMstId) {
		this.roleMstId = roleMstId;
	}

	public String getRoleCd() {
		return roleCd;
	}

	public void setRoleCd(String roleCd) {
		this.roleCd = roleCd;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

}
