package com.nelco.o2c.model;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.*;

import com.nelco.o2c.utility.DateUtil;


/**
 * The persistent class for the brf_so_details database table.
 * 
 */
@Entity
@Table(name="brf_so_details")
@NamedQuery(name="BrfSoDetails.findAll", query="SELECT b FROM BrfSoDetails b")
public class BrfSoDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="brf_so_details_id")
	private Integer brfSoDetailsId;

	private String bandwidth;

	@Column(name="brf_id")
	private Integer brfId;

	@Column(name="brf_plan")
	private String brfPlan;

	@Column(name="created_date")
	private String createdDate;

	@Column(name="existing_site")
	private String existingSite;

	private String item;

	@Column(name="material_num")
	private String materialNum;

	@Column(name="modified_date")
	private String modifiedDate;

	@Column(name="new_so_act_date")
	private String newSoActDate;

	@Column(name="new_so_num")
	private String newSoNum;

	@Column(name="old_so_num")
	private String oldSoNum;

	@Column(name="so_orders_id")
	private Integer soOrdersId;

	private String technology;

	@Column(name="tent_act_date")
	private String tentActDate;
	
	@Transient
	private Integer rowNumber;

	public BrfSoDetails() {
	}

	public Integer getBrfSoDetailsId() {
		return brfSoDetailsId;
	}

	public void setBrfSoDetailsId(Integer brfSoDetailsId) {
		this.brfSoDetailsId = brfSoDetailsId;
	}

	public String getBandwidth() {
		return bandwidth;
	}

	public void setBandwidth(String bandwidth) {
		this.bandwidth = bandwidth;
	}

	public Integer getBrfId() {
		return brfId;
	}

	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}

	public String getBrfPlan() {
		return brfPlan;
	}

	public void setBrfPlan(String brfPlan) {
		this.brfPlan = brfPlan;
	}

	public String getCreatedDate() {
		
		return DateUtil.convertDateTimeToString(this.createdDate);
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getExistingSite() {
		return existingSite;
	}

	public void setExistingSite(String existingSite) {
		this.existingSite = existingSite;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getMaterialNum() {
		return materialNum;
	}

	public void setMaterialNum(String materialNum) {
		this.materialNum = materialNum;
	}

	public String getModifiedDate() {
		return DateUtil.convertDateTimeToString(this.modifiedDate);
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getNewSoActDate() {
		return DateUtil.convertDateTimeToString(this.newSoActDate);
	}

	public void setNewSoActDate(String newSoActDate) {
		this.newSoActDate = newSoActDate;
	}

	public String getNewSoNum() {
		return newSoNum;
	}

	public void setNewSoNum(String newSoNum) {
		this.newSoNum = newSoNum;
	}

	public String getOldSoNum() {
		return oldSoNum;
	}

	public void setOldSoNum(String oldSoNum) {
		this.oldSoNum = oldSoNum;
	}

	public Integer getSoOrdersId() {
		return soOrdersId;
	}

	public void setSoOrdersId(Integer soOrdersId) {
		this.soOrdersId = soOrdersId;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getTentActDate() {
		return DateUtil.convertDateTimeToString(this.tentActDate);
	}

	public void setTentActDate(String tentActDate) {
		this.tentActDate = tentActDate;
	}

	public Integer getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(Integer rowNumber) {
		this.rowNumber = rowNumber;
	}


}