package com.nelco.o2c.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.model.StateMst;

@Repository
public interface StateMstDao extends JpaRepository<StateMst, Integer> {

}
