package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.FrachiseeEngVisitDetailsDTO;
import com.nelco.o2c.jsonbeanmap.EmailBean;
import com.nelco.o2c.jsonbeanmap.FranchiseAllocEmailDetails;
import com.nelco.o2c.model.FaEngVisitDetail;
import com.nelco.o2c.model.FranchiseeAllocationMst;
import com.nelco.o2c.model.HsoDetail;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.utility.DateUtil;

@Repository
public class FranchiseeAllocVisitDaoImpl implements FranchiseeAllocVisitDao {
	@PersistenceContext
	EntityManager em;

	Query query;

	@Autowired
	HttpSession session;

	@Autowired
	CallSpDao callSpDao;

	@Autowired
	private Environment env;

	@Override
	public FaEngVisitDetail saveFranchiseAllocVisitDetails(FrachiseeEngVisitDetailsDTO frachiseeEngVisitDetailsDTO) {
		FaEngVisitDetail faEngVisitDetailMst = new FaEngVisitDetail();
		faEngVisitDetailMst.setId(frachiseeEngVisitDetailsDTO.getId());
		faEngVisitDetailMst.setAbortReason(frachiseeEngVisitDetailsDTO.getAbortReason());
		faEngVisitDetailMst.setActualPersonContact(frachiseeEngVisitDetailsDTO.getActualPersonContact());
		faEngVisitDetailMst.setActualPersonName(frachiseeEngVisitDetailsDTO.getActualPersonName());
		faEngVisitDetailMst.setAdditionalRemarks(frachiseeEngVisitDetailsDTO.getAdditionalRemarks());
		faEngVisitDetailMst.setAntennaSizeId(frachiseeEngVisitDetailsDTO.getAntennaSizeId());
		faEngVisitDetailMst.setBuildingHeight(frachiseeEngVisitDetailsDTO.getBuildingHeight());
		faEngVisitDetailMst.setCableLen(frachiseeEngVisitDetailsDTO.getCableLen());
		faEngVisitDetailMst.setContact(frachiseeEngVisitDetailsDTO.getContact());
		System.out.println(frachiseeEngVisitDetailsDTO.getVisitDate());
		faEngVisitDetailMst.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		faEngVisitDetailMst.setCustAddress(frachiseeEngVisitDetailsDTO.getCustAddress());
		faEngVisitDetailMst.setCustomerName(frachiseeEngVisitDetailsDTO.getCustomerName());
		faEngVisitDetailMst.setEngineerId(frachiseeEngVisitDetailsDTO.getEngineerId());
		faEngVisitDetailMst.setFranchiseeAllocId(frachiseeEngVisitDetailsDTO.getFranchiseeAllocId());
		faEngVisitDetailMst.setHubDetails(frachiseeEngVisitDetailsDTO.getHubDetails());
		faEngVisitDetailMst.setKmApplMstId(frachiseeEngVisitDetailsDTO.getKmApplMstId());
		faEngVisitDetailMst.setLadderHeight(frachiseeEngVisitDetailsDTO.getLadderHeight());
		faEngVisitDetailMst.setLadderReq(frachiseeEngVisitDetailsDTO.getLadderReq());
		faEngVisitDetailMst.setMonkeyProtectionReq(frachiseeEngVisitDetailsDTO.getMonkeyProtectionReq());
		faEngVisitDetailMst.setNonFeasibleOptionMstId(frachiseeEngVisitDetailsDTO.getNonFeasibleOptionId());
		faEngVisitDetailMst.setPlatformReq(frachiseeEngVisitDetailsDTO.getPlatformReq());
		faEngVisitDetailMst.setTechnology(frachiseeEngVisitDetailsDTO.getTechnology());
		faEngVisitDetailMst.setUpsAvail(frachiseeEngVisitDetailsDTO.getUpsAvail());
		faEngVisitDetailMst.setIsSubmit(frachiseeEngVisitDetailsDTO.getIsSubmit());
		faEngVisitDetailMst.setWorkCompletionStatusMstId(frachiseeEngVisitDetailsDTO.getWorkCompletionStatusId());
		faEngVisitDetailMst
				.setWorkCompletionStatusUpdateTime(frachiseeEngVisitDetailsDTO.getWorkCompletionStatusUpdateTime());
		faEngVisitDetailMst.setIduRoomReady(frachiseeEngVisitDetailsDTO.getIduRoomReady());
		faEngVisitDetailMst.setRemarks(frachiseeEngVisitDetailsDTO.getRemarks());
		faEngVisitDetailMst.setVisit(frachiseeEngVisitDetailsDTO.getVisit());
		if(faEngVisitDetailMst.getVisitDate()!=null){
			faEngVisitDetailMst.setVisitDate(DateUtil.convertDateToSqlDate(frachiseeEngVisitDetailsDTO.getVisitDate()) + " 23:59:59.999");
		}		
		faEngVisitDetailMst.setVisitTime(frachiseeEngVisitDetailsDTO.getVisitTime());
		faEngVisitDetailMst.setAntennaTypeMstId(frachiseeEngVisitDetailsDTO.getAntennaTypeMstId());
		faEngVisitDetailMst.setSiteClearForWmNow(frachiseeEngVisitDetailsDTO.getSiteClearForWmNow());
		faEngVisitDetailMst.setMastHeight(frachiseeEngVisitDetailsDTO.getMastHeight());
		faEngVisitDetailMst.setAntennaLocationMstId(frachiseeEngVisitDetailsDTO.getAntennaLocationMstId());
		faEngVisitDetailMst.setEarthing(frachiseeEngVisitDetailsDTO.getEarthing());
		faEngVisitDetailMst.setLanCable(frachiseeEngVisitDetailsDTO.getLanCable());
		faEngVisitDetailMst.setNocFromBuilding(frachiseeEngVisitDetailsDTO.getNocFromBuilding());
		faEngVisitDetailMst.setEarthingWire(frachiseeEngVisitDetailsDTO.getEarthingWire());
		faEngVisitDetailMst.setPowerSocketAvail(frachiseeEngVisitDetailsDTO.getPowerSocketAvail());
		faEngVisitDetailMst.setMonkeyMenace(frachiseeEngVisitDetailsDTO.getMonkeyMenace());
		faEngVisitDetailMst.setTsoNumber(frachiseeEngVisitDetailsDTO.getTsoNumber());
		faEngVisitDetailMst.setTsoApprovedDate(DateUtil.convertDateToSqlDate(frachiseeEngVisitDetailsDTO.getTsoApprovedDate()));
		faEngVisitDetailMst.setInstallationStatusMstId(frachiseeEngVisitDetailsDTO.getInstallationStatusMstId());
		faEngVisitDetailMst.setIncAttributionMstId(frachiseeEngVisitDetailsDTO.getIncAttributionMstId());
		faEngVisitDetailMst.setActivityType(frachiseeEngVisitDetailsDTO.getActivityType());
		return em.merge(faEngVisitDetailMst);
	}

	@Override
	public List<FaEngVisitDetail> getEngineerVisitByFranchiseeAllocId(HttpServletRequest request) {
		try {
			query = em.createNamedQuery("FaEngVisitDetail.findByFranchiseeAllocId");
			query.setParameter(1, Integer.parseInt(request.getParameter("franchisee_alloc_id")));
			List<FaEngVisitDetail> faEngVisitDetail = query.getResultList();
			return faEngVisitDetail != null ? faEngVisitDetail : new ArrayList<FaEngVisitDetail>();
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public FaEngVisitDetail getFranchiseeAllocEngineerById(HttpServletRequest request) {
		try {
			
			String visitIdStr = request.getParameter("id");
			List<FaEngVisitDetail> resultList = null;
			if(visitIdStr!=null && !visitIdStr.equalsIgnoreCase("null")) {
				query = em.createNamedQuery("FaEngVisitDetail.findById");
				query.setParameter(1, Integer.parseInt(visitIdStr));
				
				resultList = (List<FaEngVisitDetail>) query.getResultList();
			}
			
			
			FaEngVisitDetail faEngVisitDetail = null;
			
			if(resultList!=null && resultList.size()>0) {
				faEngVisitDetail = resultList.get(0);
				
			} else {
				
				faEngVisitDetail = new FaEngVisitDetail();
				
				Integer franchiseeAllocationMstId = Integer.valueOf(request.getParameter("franchiseeAllocationMstId"));
				
				query = em.createNamedQuery("FranchiseeAllocationMst.findById");
				query.setParameter(1, franchiseeAllocationMstId);
				
				List<FranchiseeAllocationMst> faList = (List<FranchiseeAllocationMst>) query.getResultList();
				
				FranchiseeAllocationMst franchiseeAllocationMst =  (faList!=null && faList.size()>0) ?  faList.get(0):null;
				
				String soNumber = (faList!=null && faList.size()>0) ? ((String) faList.get(0).getSoNumber()):null;
				
				if(soNumber!=null) {
					query = em.createNamedQuery("HsoDetail.findBySoNumber");
					query.setParameter("soNumber", soNumber);
					
					List<HsoDetail> hsoDetailList = (List<HsoDetail>) query.getResultList();
					
					//if hso detail present for the so number
					if(hsoDetailList!=null && hsoDetailList.size()>0) {
						HsoDetail hsoDetail = hsoDetailList.get(0);
						
						//setting the data in visit details page
						faEngVisitDetail.setHubDetails(hsoDetail.getHubMstId());
						
						//antenna size
						query = em.createNativeQuery("select id from antenna_size_mst where REPLACE( RTRIM(LTRIM(value)),'M','') =  RTRIM(LTRIM('"+hsoDetail.getAntennaSize()+"'))");
						List<Object> antennaSizeIds = (List<Object>) query.getResultList();
						faEngVisitDetail.setAntennaSizeId(antennaSizeIds!=null && antennaSizeIds.size()>0? (Integer)antennaSizeIds.get(0):null);
						
						//mismatch in technology
						
						//setting cable length
						faEngVisitDetail.setCableLen(hsoDetail.getIflCableLength());
						faEngVisitDetail.setLanCable(hsoDetail.getIflCableLength());
						
						//setting building height
						faEngVisitDetail.setBuildingHeight(hsoDetail.getHtBuilding());
						
						//setting monkey cage
						faEngVisitDetail.setMonkeyProtectionReq(hsoDetail.getMonkeyCage()!=null && hsoDetail.getMonkeyCage().equalsIgnoreCase("Yes")?"Y":"N");
						faEngVisitDetail.setMonkeyMenace(hsoDetail.getMonkeyCage()!=null && hsoDetail.getMonkeyCage().equalsIgnoreCase("Yes")?"Y":"N");
						
						//setting ladder info
						faEngVisitDetail.setLadderReq(hsoDetail.getLadderLength()!=null?"Y":"N");
						faEngVisitDetail.setLadderHeight(hsoDetail.getLadderLength());
						
						//setting ups avail
						faEngVisitDetail.setUpsAvail(hsoDetail.getUps()!=null && hsoDetail.getMonkeyCage().equalsIgnoreCase("Yes")?"Y":"N");
						
						faEngVisitDetail.setFranchiseeAllocId(franchiseeAllocationMst.getId());
						
						
						faEngVisitDetail.setTechnology(franchiseeAllocationMst.getTechnologyMstId());
						
						
						faEngVisitDetail.setTsoNumber(hsoDetail.getHsoNumber());
						
						faEngVisitDetail.setTsoApprovedDate(hsoDetail.getVerifiedDate());
						
					} 				
					
				}
			}
			
			return faEngVisitDetail;
			
		} catch(Exception e) {
			return new FaEngVisitDetail();
		} 
		finally {
			em.close();
		}
	}

	@Override
	public FaEngVisitDetail submitFranchiseAllocVisitDetails(FrachiseeEngVisitDetailsDTO dtoObject) {
		try {
 			query = em.createNamedQuery("FaEngVisitDetail.updateSubmitFlag");	
			System.out.println("Id"+dtoObject.getId());
			System.out.println("F Id"+dtoObject.getFranchiseeAllocId());
			System.out.println("Status"+dtoObject.getWorkCompletionStatusId());
			query.setParameter(1, dtoObject.getId());
			query.executeUpdate();
			if (dtoObject.getWorkCompletionStatusId().equals(2)) {
				query = em.createNamedQuery("FranchiseeAllocationMst.updateEngineerAllocatedStatus");
				query.setParameter(1, 38);
				query.setParameter(2, dtoObject.getFranchiseeAllocId());
				query.executeUpdate();
				
				query = em.createNamedQuery("FranchiseeAllocationMst.findById");
				query.setParameter(1, dtoObject.getFranchiseeAllocId());
				FranchiseeAllocationMst franchiseeAllocationMst = (FranchiseeAllocationMst) query.getSingleResult();
				
				// email sending for franchise allocation begins
				query = em.createNativeQuery("select ur.user_id,u.user_name, "
						+ " u.user_email,fzm.franchise_zone_email "
						+ " from franchisee_allocation_mst f  "
						+ " inner join so_orders so "
						+ " on (f.so_number = so.so_number and f.item = so.item) "
						+ " inner join customer_sapmst cs "
						+ " on (so.ship_to_party = cs.customer_num and so.dist_channel = cs.dist_channel "
						+ " and so.division = cs.division and so.sales_org = cs.sales_org) "
						+ " inner join state_mst sm "
						+ " on cs.region_code = sm.state_code "
						+ " inner join user_to_region_mst ur "
						+ " on sm.state_mst_id = ur.region_code "
						+ " inner join cs_user_franchise_zone_mapping_mst cufzm "
						+ " on ur.user_id = cufzm.user_mst_id "
						+ " inner join user_mst u "
						+ " on ur.user_id = u.user_mst_id "
						+ " inner join franchise_zone_mst fzm "
						+ " on cufzm.franchise_zone_mst_id = fzm.franchise_zone_mst_id "
						+ " inner join role_mst r "
						+ " on r.role_mst_id = u.role_mst_id "
						+ " left outer join delivery d "
						+ " on f.delivery_id = d.delivery_id "
						+ " where r.role_cd in ('SUPEXE') and f.id = "+franchiseeAllocationMst.getId());
				List<Object[]> result = (List<Object[]>) query.getResultList();
				String csUserName = null;
				String csEmail = null;
				Integer userId = null;
				String zoneEmail = null;
				for (Object[] objects : result) {
					userId = (Integer)objects[0];
					csUserName = (String)objects[1];
					csEmail = (csEmail==null?"":csEmail+";")+(String)objects[2];
					zoneEmail = (String)objects[3];
				}
				
				Integer requestUserId = franchiseeAllocationMst.getUser_id();
				query = em.createNamedQuery("UserMst.getUserEmailById");
				query.setParameter(1, requestUserId);
				List<UserMst> userList = (List<UserMst>) query.getResultList();
				
				List<OppUploadDetail> upDetails = dtoObject.getOppUploadDetails();
				
				StringBuilder attachmentListString = null;
				if(upDetails.size()>0) {
					attachmentListString = new StringBuilder();
					attachmentListString.append(upDetails .stream() .map(upDetailObj -> String.valueOf(upDetailObj.getUploadUrl())) .collect(Collectors.joining(";")));
				}
				
				//query to get franchise allocation details begins
				query = em.createNativeQuery(" select so.sold_to_party,stp.customer_name,so.ship_to_party,"
						+ " COALESCE(shtp.street1,'')+' '+COALESCE(shtp.street2,'') +' '+COALESCE(shtp.street3,'')+' '+COALESCE(shtp.street4,'') +' '+COALESCE(shtp.street5,'')+' '+COALESCE(shtp.city_name,'') +'-'+COALESCE(shtp.pin,'')+' '+COALESCE(sm.state_val,'')+','+COALESCE(cm.country_val,'') as shtp_address, "
						+ " fam.so_number,d.delivery_num,fam.installation_address,itm.installation_type_val,"
						+ " fam.vsat_id,fam.vsat_ip,fam.contact_person_number,fam.site_contact_person,"
						+ " fam.additional_remarks,tm.value,hm.hub_desc,fam.sub_customer "
						+ " from franchisee_allocation_mst fam inner join installation_type_mst itm on fam.installation_type_mst_id = itm.installation_type_mst_id inner join so_orders so on fam.so_number = so.so_number and fam.item = so.item inner join customer_sapmst shtp on so.ship_to_party = shtp.customer_num and so.dist_channel = shtp.dist_channel and so.division = shtp.division and so.sales_org = shtp.sales_org inner join customer_sapmst stp on so.sold_to_party = stp.customer_num and so.dist_channel = stp.dist_channel and so.division = stp.division and so.sales_org = stp.sales_org inner join country_mst cm on shtp.country_code = cm.country_code inner join state_mst sm on shtp.region_code = sm.state_code left outer join delivery d on fam.delivery_id = d.delivery_id left outer join hub_mst hm on fam.hub_mst_id = hm.hub_mst_id left outer join technology_mst tm on fam.technology_mst_id = tm.id " + 
						" where fam.id = :famId ");
				query.setParameter("famId", franchiseeAllocationMst.getId());
				List<Object[]> soDetailsResult = (List<Object[]>) query.getResultList();
				FranchiseAllocEmailDetails emailDetails = new FranchiseAllocEmailDetails();
				for (Object[] objects : soDetailsResult) {
					emailDetails.setSoldToParty(objects[0]!=null?(String)objects[0]:"");
					emailDetails.setCustomerName(objects[1]!=null?(String)objects[1]:"");
					emailDetails.setShipToParty(objects[2]!=null?(String)objects[2]:"");
					emailDetails.setShtpAddress(objects[3]!=null?(String)objects[3]:"");
					emailDetails.setSoNumber(objects[4]!=null?(String)objects[4]:"");
					emailDetails.setDeliverNumber(objects[5]!=null?(String)objects[5]:"");
					emailDetails.setAdditionalAddress(objects[6]!=null?(String)objects[6]:"");
					emailDetails.setInstallationType(objects[7]!=null?(String)objects[7]:"");
					emailDetails.setVsatId(objects[8]!=null?(String)objects[8]:"");
					emailDetails.setVsatIp(objects[9]!=null?(String)objects[9]:"");
					emailDetails.setContactPersonNumber(objects[10]!=null?(String)objects[10]:"");
					emailDetails.setSiteContactPerson(objects[11]!=null?(String)objects[11]:"");
					emailDetails.setAdditionalRemarks(objects[12]!=null?(String)objects[12]:"");
					emailDetails.setTechnology(objects[13]!=null?(String)objects[13]:"");
					emailDetails.setHubDesc(objects[14]!=null?(String)objects[14]:"");
					emailDetails.setSubCustomer(objects[15]!=null?(String)objects[15]:"");
				}
				//query to get franchise allocation details ends
						
				
				if(userId!=null) {
					EmailBean emailBean = new EmailBean();
					emailBean.setToMail((csEmail!=null?csEmail+";":"")+(zoneEmail!=null?zoneEmail:""));
					if(attachmentListString!=null) {
						emailBean.setFileAttachments(attachmentListString.toString());
					}
					if(userList!=null && userList.size()>0) {
						emailBean.setCopyRecepients(userList.get(0).getUserEmail());
					}
					emailBean.setSubject("I&C Request Completed : " + franchiseeAllocationMst.getUniqId());
					emailBean.setEmailBody("Dear User,"
							+ "<br>I&C Request has been completed with id : " + franchiseeAllocationMst.getUniqId() + "."
									+ "<br>So Number : " + emailDetails.getSoNumber()
									+ "<br>Customer Name : " + emailDetails.getCustomerName()
									+ "<br>Sub Customer Name : " + emailDetails.getSubCustomer()
									+ "<br>So Number : " + emailDetails.getSoNumber()
									+ "<br>Ship To Party Address : " + emailDetails.getShtpAddress()
									+ "<br>Additional Address : " + emailDetails.getAdditionalAddress()
									+ "<br>Installation Type : " + emailDetails.getInstallationType()
									+ "<br>VSAT ID : " + emailDetails.getVsatId()
									+ "<br>IP : " + emailDetails.getVsatIp()
									+ "<br>Contact Person : " + emailDetails.getSiteContactPerson()
									+ "<br>Contact Person Number : " + emailDetails.getContactPersonNumber()
									+ "<br>Hub : " + emailDetails.getHubDesc()
									+ "<br>Additional Remarks : " + emailDetails.getAdditionalRemarks()
									+ "<br>Technology : " + emailDetails.getTechnology()
							+ "<br>Please login to know more." + "<br> Click here to login :  <a href="
							+ env.getProperty("emaillink") + ">O2C portal link</a>  " + "<br><br>Sincerely");
					callSpDao.sendEmail(emailBean);
				}
				
				// email sending for franchise allocation ends
				
			}			
			query = em.createNamedQuery("FaEngVisitDetail.findById");
			query.setParameter(1, dtoObject.getId());
			FaEngVisitDetail faEngVisitDetail = (FaEngVisitDetail) query.getSingleResult();
			
			
			
			return faEngVisitDetail != null ? faEngVisitDetail : new FaEngVisitDetail();
		} finally {
			// em.close();
		}
	}

	@Override
	public FranchiseeAllocationMst getFranchiseAllocationMstById(Integer franchiseAllocId) {
		// TODO Auto-generated method stub
		try {
			return em.find(FranchiseeAllocationMst.class, franchiseAllocId);
		} catch(Exception e) {
			return null;
		} finally {
			em.close();
		}
		
	}

	@Override
	public void sendEmailOnCompletion(FranchiseeAllocationMst franchiseeAllocationMst,FaEngVisitDetail faEngVisitDetail) {
		// TODO Auto-generated method stub
		
		query = em.createQuery("select op from OppUploadDetail op where op.faEngVisitDetailsId = :faEngVisitDetailsId");
		query.setParameter("faEngVisitDetailsId", faEngVisitDetail.getId());
		List<OppUploadDetail> upDetails = (List<OppUploadDetail>) query.getResultList();
		String attachmentListString = null;
		if(upDetails!=null && upDetails.size()>0)
		attachmentListString = upDetails .stream() .map(upDetailObj -> String.valueOf(upDetailObj.getUploadUrl())) .collect(Collectors.joining(";"));
		
		
		query = em.createNativeQuery("select ur.user_id,u.user_name, "
				+ " u.user_email,fzm.franchise_zone_email "
				+ " from franchisee_allocation_mst f inner join delivery d "
				+ " on f.delivery_id = d.delivery_id "
				+ " inner join so_orders so "
				+ " on (d.so_number = so.so_number and d.wbs_element = so.wbs_element) "
				+ " inner join customer_sapmst cs "
				+ " on (so.ship_to_party = cs.customer_num and so.dist_channel = cs.dist_channel "
				+ " and so.division = cs.division and so.sales_org = cs.sales_org) "
				+ " inner join state_mst sm "
				+ " on cs.region_code = sm.state_code "
				+ " inner join user_to_region_mst ur "
				+ " on sm.state_mst_id = ur.region_code "
				+ " inner join cs_user_franchise_zone_mapping_mst cufzm "
				+ " on ur.user_id = cufzm.user_mst_id "
				+ " inner join user_mst u "
				+ " on ur.user_id = u.user_mst_id "
				+ " inner join franchise_zone_mst fzm "
				+ " on cufzm.franchise_zone_mst_id = fzm.franchise_zone_mst_id "
				+ " where f.id = "+franchiseeAllocationMst.getId());
		List<Object[]> result = (List<Object[]>) query.getResultList();
		String csUserName = null;
		String csEmail = null;
		Integer userId = null;
		String zoneEmail = null;
		for (Object[] objects : result) {
			userId = (Integer)objects[0];
			csUserName = (String)objects[1];
			csEmail = (String)objects[2];
			zoneEmail = (String)objects[3];
		}
		
		query = em.createNativeQuery("select u.user_mst_id,u.user_name,u.user_email from user_to_franchisee_mst uf inner join user_mst u on uf.user_mst_id = u.user_mst_id where uf.franchisee_id="+franchiseeAllocationMst.getFranchisee_id());
		List<Object[]> results = (List<Object[]>) query.getResultList();
		String frUserName = null;
		String frEmail = null;
		Integer fruserId = null;
		for (Object[] objects : results) {
			fruserId = (Integer)objects[0];
			frUserName = (String)objects[1];
			frEmail = (String)objects[2];
			
		}
		
		Integer requestUserId = franchiseeAllocationMst.getUser_id();
		query = em.createNamedQuery("UserMst.getUserEmailById");
		query.setParameter(1, requestUserId);
		List<UserMst> userList = (List<UserMst>) query.getResultList();
		
		//query to get franchise allocation details begins
		query = em.createNativeQuery(" select so.sold_to_party,stp.customer_name,so.ship_to_party,"
				+ " COALESCE(shtp.street1,'')+' '+COALESCE(shtp.street2,'') +' '+COALESCE(shtp.street3,'')+' '+COALESCE(shtp.street4,'') +' '+COALESCE(shtp.street5,'')+' '+COALESCE(shtp.city_name,'') +'-'+COALESCE(shtp.pin,'')+' '+COALESCE(sm.state_val,'')+','+COALESCE(cm.country_val,'') as shtp_address, "
				+ " fam.so_number,d.delivery_num,fam.installation_address,itm.installation_type_val,"
				+ " fam.vsat_id,fam.vsat_ip,fam.contact_person_number,fam.site_contact_person,"
				+ " fam.additional_remarks,tm.value,hm.hub_desc "
				+ " from franchisee_allocation_mst fam inner join installation_type_mst itm on fam.installation_type_mst_id = itm.installation_type_mst_id inner join so_orders so on fam.so_number = so.so_number and fam.item = so.item inner join customer_sapmst shtp on so.ship_to_party = shtp.customer_num and so.dist_channel = shtp.dist_channel and so.division = shtp.division and so.sales_org = shtp.sales_org inner join customer_sapmst stp on so.sold_to_party = stp.customer_num and so.dist_channel = stp.dist_channel and so.division = stp.division and so.sales_org = stp.sales_org inner join country_mst cm on shtp.country_code = cm.country_code inner join state_mst sm on shtp.region_code = sm.state_code left outer join delivery d on fam.delivery_id = d.delivery_id left outer join hub_mst hm on fam.hub_mst_id = hm.hub_mst_id left outer join technology_mst tm on fam.technology_mst_id = tm.id " + 
				" where fam.id = :famId ");
				query.setParameter("famId", franchiseeAllocationMst.getId());
				List<Object[]> soDetailsResult = (List<Object[]>) query.getResultList();
				FranchiseAllocEmailDetails emailDetails = new FranchiseAllocEmailDetails();
				for (Object[] objects : soDetailsResult) {
					emailDetails.setSoldToParty(objects[0]!=null?(String)objects[0]:"");
					emailDetails.setCustomerName(objects[1]!=null?(String)objects[1]:"");
					emailDetails.setShipToParty(objects[2]!=null?(String)objects[2]:"");
					emailDetails.setShtpAddress(objects[3]!=null?(String)objects[3]:"");
					emailDetails.setSoNumber(objects[4]!=null?(String)objects[4]:"");
					emailDetails.setDeliverNumber(objects[5]!=null?(String)objects[5]:"");
					emailDetails.setAdditionalAddress(objects[6]!=null?(String)objects[6]:"");
					emailDetails.setInstallationType(objects[7]!=null?(String)objects[7]:"");
					emailDetails.setVsatId(objects[8]!=null?(String)objects[8]:"");
					emailDetails.setVsatIp(objects[9]!=null?(String)objects[9]:"");
					emailDetails.setContactPersonNumber(objects[10]!=null?(String)objects[10]:"");
					emailDetails.setSiteContactPerson(objects[11]!=null?(String)objects[11]:"");
					emailDetails.setAdditionalRemarks(objects[12]!=null?(String)objects[12]:"");
					emailDetails.setTechnology(objects[13]!=null?(String)objects[13]:"");
					emailDetails.setHubDesc(objects[14]!=null?(String)objects[14]:"");
				}
				//query to get franchise allocation details ends
		
		
		if(userId!=null) {
			EmailBean emailBean = new EmailBean();
			emailBean.setToMail(frEmail);
			if(attachmentListString!=null)
				emailBean.setFileAttachments(attachmentListString);
			
			if(userList!=null && userList.size()>0) {
				emailBean.setCopyRecepients(userList.get(0).getUserEmail()+";"+(csEmail!=null?csEmail+";":"")+(zoneEmail!=null?zoneEmail:""));
			}
			emailBean.setSubject("I&C Request Completed : " + franchiseeAllocationMst.getUniqId());
			emailBean.setEmailBody("Dear User,"
					+ "<br>I&C Request has been Completed with id : " + franchiseeAllocationMst.getUniqId() + "."
							+ "<br>So Number : " + emailDetails.getSoNumber()
							+ "<br>Customer Name : " + emailDetails.getCustomerName()
							+ "<br>Ship To Party Address : " + emailDetails.getShtpAddress()
							+ "<br>Additional Address : " + emailDetails.getAdditionalAddress()
							+ "<br>Installation Type : " + emailDetails.getInstallationType()
							+ "<br>VSAT ID : " + emailDetails.getVsatId()
							+ "<br>IP : " + emailDetails.getVsatIp()
							+ "<br>Contact Person : " + emailDetails.getSiteContactPerson()
							+ "<br>Contact Person Number : " + emailDetails.getContactPersonNumber()
							+ "<br>Hub : " + emailDetails.getHubDesc()
							+ "<br>Additional Remarks : " + emailDetails.getAdditionalRemarks()
							+ "<br>Technology : " + emailDetails.getTechnology()
					+ "<br>Please login to know more." + "<br> Click here to login :  <a href="
					+ env.getProperty("emaillink") + ">O2C portal link</a>  " + "<br><br>Sincerely");
			callSpDao.sendEmail(emailBean);
		}
		
		// email sending for franchise allocation ends
	}

}
