package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.DisconnectionRequestOnCrMst;
import com.nelco.o2c.model.TemplateDownloadRequest;

public class DisconnectionOnCRFormDTO {
	List<DisconnectionOnCRDTO> soList=new ArrayList<DisconnectionOnCRDTO>();
	List<TemplateDownloadRequest> requestList=new ArrayList<TemplateDownloadRequest>();
	List<DisconnectionRequestOnCrMst> requestActionList=new ArrayList<DisconnectionRequestOnCrMst>();
	private String uniqueId="";
	String userId="";

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public List<DisconnectionRequestOnCrMst> getRequestActionList() {
		return requestActionList;
	}

	public void setRequestActionList(List<DisconnectionRequestOnCrMst> requestActionList) {
		this.requestActionList = requestActionList;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<TemplateDownloadRequest> getRequestList() {
		return requestList;
	}

	public void setRequestList(List<TemplateDownloadRequest> requestList) {
		this.requestList = requestList;
	}

	public List<DisconnectionOnCRDTO> getSoList() {
		return soList;
	}

	public void setSoList(List<DisconnectionOnCRDTO> soList) {
		this.soList = soList;
	}

	
}
