/**
 * 
 */
package com.nelco.o2c.aop;

/**
 * @author Jayashankar.r
 *
 */
/*@Aspect
@Component*/
public class Aop {/*
	@Autowired
	private HttpSession session;

	@Around("execution(* com.nelco.o2c.controller.*.*(..))")
	public Object validateSession(ProceedingJoinPoint joinPoint)
			throws Throwable {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder
				.getRequestAttributes()).getRequest();
		HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder
				.getRequestAttributes()).getResponse();
		LoginDTO workArea = (LoginDTO) session
				.getAttribute("workArea");
		//PrintWriter writer = response.getWriter();
		org.aspectj.lang.Signature signature = joinPoint.getSignature();
		// Class returnType = ((MethodSignature) signature).getReturnType();
		if (!request.getRequestURI().contains("login")
				
				&& !request.getRequestURI().endsWith("o2c_UAT/")
				&&!request.getRequestURI().contains("authenticateUser")) {
			if (workArea == null || workArea.getUserMst()==null) {
				System.out.println("Invalid Session");
				JSONObject obj = new JSONObject();
			    obj.put("status", "exception_expired");
			    
			    obj.put("display_text", "There was a error in executing the action!");
			    response.setHeader("Content-Disposition", "application/json");
			    response.setHeader("Content-Disposition", "application/json;charset=UTF-8");
			    
			    response.getOutputStream().println(obj.toString());
			    
				//return "redirect:login.do";
			    return null;
			} else if (workArea.getUserMst().getLoginId().equals("")) {
				System.out.println("Invalid Session");
				JSONObject obj = new JSONObject();
			    obj.put("status", "exception_expired");			    
			    obj.put("display_text", "There was a error in executing the action!");
			    response.setHeader("Content-Disposition", "application/json");
			    response.setHeader("Content-Disposition", "application/json;charset=UTF-8");
			    
			    //writer.write(obj.toString());
			    response.getOutputStream().println(obj.toString());
			    //writer.close();
				//return "redirect:login.do";
			    return null;
			} else {				
				return joinPoint.proceed();
			}
		} else {
			
			return joinPoint.proceed();
		}

	}
*/}
