package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;

/**
 * The persistent class for the sto_cs database table.
 * 
 */
@Entity
@Table(name = "sto_cs")
@NamedQueries({ @NamedQuery(name = "StoC.findAll", query = "SELECT s FROM StoC s"),
		@NamedQuery(name = "StoC.getStoCSListSupexe", query = "SELECT s FROM StoC s where s.createdDate between ?1 and ?2 and s.reqById=?3 "),
		@NamedQuery(name = "StoC.getStoCsListTrc", query = "SELECT s FROM StoC s where s.createdDate between ?1 and ?2 and s.trcUserId=?3"),
		@NamedQuery(name = "StoC.getStoCsListCsCoord", query = "SELECT s FROM StoC s where s.createdDate between ?1 and ?2 and s.csCoordId=?3 "),
		@NamedQuery(name = "StoC.findByCreatedDate", query = "SELECT s FROM StoC s where s.createdDate between ?1 and ?2 "),
		@NamedQuery(name = "StoC.updateCsSubmit", query = " update StoC s set s.statusMstId=?1 where s.stoCsId=?2 "),
		@NamedQuery(name = "StoC.updateTrcSubmit", query = " update StoC s set s.statusMstId=?1 where s.stoCsId=?2 "),
		@NamedQuery(name = "StoC.getCurrentDayCountStoCs", query = " select (count(s)+1) from StoC s where s.createdDate between ?1 and ?2 "),
		@NamedQuery(name = "StoC.getCsStoByReqId", query = " SELECT s FROM StoC s where s.stoCsGenId = ?1 ")})
public class StoC implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sto_cs_id")
	private Integer stoCsId;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "cs_coord_id")
	private Integer csCoordId;

	@Column(name = "finance_id")
	private Integer financeId;

	@Column(name = "req_by_id")
	private Integer reqById;

	@Column(name = "status_mst_id")
	private Integer statusMstId;

	@Column(name = "sto_cs_gen_id")
	private String stoCsGenId;

	@Column(name = "supply_plant_id")
	private Integer supplyPlantId;

	@Column(name = "trc_user_id")
	private Integer trcUserId;

	@Column(name = "store_user_id")
	private Integer storeUserId;
	
	@Column(name = "pr_no")
	private String prNo;
	
	@Column(name = "po_num")
	private String poNum;

	public StoC() {
	}

	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "sto_cs_id", referencedColumnName = "sto_cs_id", insertable = false, updatable = false)
	private List<StoCsMaterial> stoCsMaterialList = new ArrayList<StoCsMaterial>();

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "status_mst_id", referencedColumnName = "status_mst_id", insertable = false, updatable = false)
	private StatusMst statusMst;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "supply_plant_id", referencedColumnName = "plant_sapmst_id", insertable = false, updatable = false)
	private PlantSapmst plantSapmst;

	public String getPrNo() {
		return prNo;
	}

	public void setPrNo(String prNo) {
		this.prNo = prNo;
	}

	public Integer getStoreUserId() {
		return storeUserId;
	}

	public void setStoreUserId(Integer storeUserId) {
		this.storeUserId = storeUserId;
	}

	public List<StoCsMaterial> getStoCsMaterialList() {
		return stoCsMaterialList;
	}

	public void setStoCsMaterialList(List<StoCsMaterial> stoCsMaterialList) {
		this.stoCsMaterialList = stoCsMaterialList;
	}

	public StatusMst getStatusMst() {
		return statusMst;
	}

	public void setStatusMst(StatusMst statusMst) {
		this.statusMst = statusMst;
	}

	public PlantSapmst getPlantSapmst() {
		return plantSapmst;
	}

	public void setPlantSapmst(PlantSapmst plantSapmst) {
		this.plantSapmst = plantSapmst;
	}

	public Integer getStoCsId() {
		return stoCsId;
	}

	public void setStoCsId(Integer stoCsId) {
		this.stoCsId = stoCsId;
	}

	public String getCreatedDate() {
		return DateUtil.convertDateTimeToString(this.createdDate);
		//return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getCsCoordId() {
		return csCoordId;
	}

	public void setCsCoordId(Integer csCoordId) {
		this.csCoordId = csCoordId;
	}

	public Integer getFinanceId() {
		return financeId;
	}

	public void setFinanceId(Integer financeId) {
		this.financeId = financeId;
	}

	public Integer getReqById() {
		return reqById;
	}

	public void setReqById(Integer reqById) {
		this.reqById = reqById;
	}

	public Integer getStatusMstId() {
		return statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}

	public String getStoCsGenId() {
		return stoCsGenId;
	}

	public void setStoCsGenId(String stoCsGenId) {
		this.stoCsGenId = stoCsGenId;
	}

	public Integer getSupplyPlantId() {
		return supplyPlantId;
	}

	public void setSupplyPlantId(Integer supplyPlantId) {
		this.supplyPlantId = supplyPlantId;
	}

	public Integer getTrcUserId() {
		return trcUserId;
	}

	public void setTrcUserId(Integer trcUserId) {
		this.trcUserId = trcUserId;
	}

	public String getPoNum() {
		return poNum;
	}

	public void setPoNum(String poNum) {
		this.poNum = poNum;
	}
	
}