/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

/**
 * @author Amol.l
 *
 */
public class EmailDocDTO implements Serializable {

	private static final long serialVersionUID = 53L;

	private Integer userMstId;
	private Integer respPerId;
	private String fileUrl;
	private String comments;
	private String topicsDel;
	private String successFlag;
	private String opportunityName;
	private Integer opportunityId;
	private Integer respMatrixDetailsId;
	private Integer preSalesRespMatrixId;
	private String roleCode;
	private String respPersonLoginId;
	private String tenderNo;
	
	public String getTenderNo() {
		return tenderNo;
	}

	public void setTenderNo(String tenderNo) {
		this.tenderNo = tenderNo;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getRespPersonLoginId() {
		return respPersonLoginId;
	}

	public void setRespPersonLoginId(String respPersonLoginId) {
		this.respPersonLoginId = respPersonLoginId;
	}

	public Integer getPreSalesRespMatrixId() {
		return preSalesRespMatrixId;
	}

	public void setPreSalesRespMatrixId(Integer preSalesRespMatrixId) {
		this.preSalesRespMatrixId = preSalesRespMatrixId;
	}

	public Integer getRespMatrixDetailsId() {
		return respMatrixDetailsId;
	}

	public void setRespMatrixDetailsId(Integer respMatrixDetailsId) {
		this.respMatrixDetailsId = respMatrixDetailsId;
	}

	public Integer getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public Integer getRespPerId() {
		return respPerId;
	}

	public void setRespPerId(Integer respPerId) {
		this.respPerId = respPerId;
	}

	public String getFileUrl() {
		return fileUrl;
	}

	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getTopicsDel() {
		return topicsDel;
	}

	public void setTopicsDel(String topicsDel) {
		this.topicsDel = topicsDel;
	}

	public String getSuccessFlag() {
		return successFlag;
	}

	public void setSuccessFlag(String successFlag) {
		this.successFlag = successFlag;
	}

}
