package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.utility.DateUtil;

/**
 * The persistent class for the soorder_sapmst database table.
 * 
 */
@Entity
@Table(name = "so_orders")

@NamedQueries({ @NamedQuery(name = "SoOrders.findAll", query = "SELECT so FROM SoOrders so"),
		@NamedQuery(name = "SoOrders.getSoDetailsBySoNumber", query = "SELECT so from SoOrders so where so.soNumber =?1 "),
		@NamedQuery(name = "SoOrders.getSOListByContractNum", query = " SELECT distinct new SoOrders(so.contSalesDocType, so.contractNum, so.creationDate, so.distChannel, "
				+ " so.division, so.salesOffice, so.salesOrg, so.soNumber, so.soldToParty,so.isSparesEmailSent) from SoOrders so where so.contractNum =?1 "),
		@NamedQuery(name = "SoOrders.getSOListWithoutContractNum", query = " SELECT distinct new SoOrders(so.contSalesDocType, so.contractNum, so.creationDate, so.distChannel, "
				+ " so.division, so.salesOffice, so.salesOrg, so.soNumber, so.soldToParty,so.isSparesEmailSent) from SoOrders so "),
		@NamedQuery(name = "SoOrders.searchSObySoNumber", query = "SELECT so from SoOrders so where so.salesOrg= 'TNET' and so.soNumber  like ?1 "),
		@NamedQuery(name = "SoOrders.updateSparesSo", query = "update SoOrders so "
				+ " set so.sparesSoNumber=?1, so.comments=?2,so.isSparesEmailSent='Y' " + " where so.soNumber=?3 "),
		@NamedQuery(name = "SoOrders.getSOListBySparesSoUniqId", query = "select distinct new SoOrders(so.contSalesDocType, so.contractNum, so.creationDate, so.distChannel, "
				+ " so.division, so.salesOffice, so.salesOrg, so.soNumber, so.soldToParty, so.isSparesEmailSent ) "
				+ " from SoOrders so "
				+ " inner join so.sparesSoDelPgi ss where ss.sparesReqId = ?1 "),
		@NamedQuery(name = "SoOrders.getSOListByRelocationSoUniqId", query = "select distinct new SoOrders(so.contSalesDocType, so.contractNum, so.creationDate, so.distChannel, "
				+ " so.division, so.salesOffice, so.salesOrg, so.soNumber, so.soldToParty, so.isSparesEmailSent) "
				+ " from SoOrders so "
				+ " where so.relocSoReqId = ?1 "),
		@NamedQuery(name = "SoOrders.searchSObySoNumberForRelocation", query = "select distinct new SoOrders(so.shipToParty,so.soNumber) "
				+ " from SoOrders so "
				+ " where so.soNumber like ?1 "),
		@NamedQuery(name = "SoOrders.getSOListByDemoSoUniqId", query = "select distinct new SoOrders(so.contSalesDocType, so.contractNum, so.creationDate, so.distChannel, "
				+ " so.division, so.salesOffice, so.salesOrg, so.soNumber, so.soldToParty, so.isSparesEmailSent) "
				+ " from SoOrders so "
				+ " where so.drfDetailsId = ?1 ")})
public class SoOrders implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "so_orders_id")
	private Integer soOrdersId;

	@Column(name = "cont_sales_doc_type")
	private String contSalesDocType;

	@Column(name = "contract_num")
	private String contractNum;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "creation_date")
	private String creationDate;

	@Column(name = "dist_channel")
	private String distChannel;

	private String division;

	@Column(name = "material_num")
	private String materialNum;

	@Column(name = "order_quantity")
	private String orderQuantity;

	@Column(name = "plant")
	private String plant;

	@Column(name = "reason_for_rej")
	private String reasonForRej;

	@Column(name = "sales_office")
	private String salesOffice;

	@Column(name = "sales_org")
	private String salesOrg;

	@Column(name = "sales_unit")
	private String salesUnit;

	@Column(name = "service_order_num")
	private String serviceOrderNum;

	@Column(name = "ship_to_party")
	private String shipToParty;

	@Column(name = "so_number")
	private String soNumber;

	@Column(name = "sold_to_party")
	private String soldToParty;

	@Column(name = "modified_date")
	private String modifiedDate;

	@Column(name = "is_spares_email_sent")
	private String isSparesEmailSent;

	@Column(name = "spares_so_number")
	private String sparesSoNumber;

	@Column(name = "comments")
	private String comments;

	@Column(name = "wbs_element")
	private String wbsElement;

	@Column(name = "item")
	private String item;

	@Transient
	private String separator="-";

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "material_num", referencedColumnName = "material_num", insertable = false, updatable = false),
			@JoinColumn(name = "plant", referencedColumnName = "plant", insertable = false, updatable = false),
			@JoinColumn(name = "sales_org", referencedColumnName = "sales_org", insertable = false, updatable = false),
			@JoinColumn(name = "dist_channel", referencedColumnName = "dist_channel", insertable = false, updatable = false)})
	private MaterialSapmst materialSapmst;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "ship_to_party", referencedColumnName = "customer_num", insertable = false, updatable = false),
			@JoinColumn(name = "dist_channel", referencedColumnName = "dist_channel", insertable = false, updatable = false),
			@JoinColumn(name = "division", referencedColumnName = "division", insertable = false, updatable = false),
			@JoinColumn(name = "sales_org", referencedColumnName = "sales_org", insertable = false, updatable = false) })
	private CustomerSapmst customerSapmst;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "item", referencedColumnName = "so_item", insertable = false, updatable = false),
			@JoinColumn(name = "so_number", referencedColumnName = "so_number", insertable = false, updatable = false) })
	private SparesSoDelPgi sparesSoDelPgi;
	
	@Column(name = "reloc_so_req_id")
	private String relocSoReqId;
	
	@Column(name = "item_category")
	private String itemCategory;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "plant", referencedColumnName = "plant_code", insertable = false, updatable = false)})
	private  PlantSapmst plantMst;
	
	@Column(name = "drf_details_id")
	private Integer drfDetailsId;
	

	

	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}


	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}


	public PlantSapmst getPlantMst() {
		return plantMst;
	}


	public void setPlantMst(PlantSapmst plantMst) {
		this.plantMst = plantMst;
	}


	public SoOrders(String shipToParty, String soNumber) {
		super();
		this.shipToParty = shipToParty;
		this.soNumber = soNumber;
	}


	public String getItemCategory() {
		return itemCategory;
	}


	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}


	public SoOrders() {
	}
	

	public String getRelocSoReqId() {
		return relocSoReqId;
	}





	public void setRelocSoReqId(String relocSoReqId) {
		this.relocSoReqId = relocSoReqId;
	}





	public SparesSoDelPgi getSparesSoDelPgi() {
		return sparesSoDelPgi;
	}



	public void setSparesSoDelPgi(SparesSoDelPgi sparesSoDelPgi) {
		this.sparesSoDelPgi = sparesSoDelPgi;
	}



	public SoOrders(String contSalesDocType, String contractNum, String creationDate, String distChannel,
			String division, String salesOffice, String salesOrg, String soNumber, String soldToParty,String isSparesEmailSent) {
		super();
		this.contSalesDocType = contSalesDocType;
		this.contractNum = contractNum;
		this.creationDate = creationDate;
		this.distChannel = distChannel;
		this.division = division;
		this.salesOffice = salesOffice;
		this.salesOrg = salesOrg;
		this.soNumber = soNumber;
		this.soldToParty = soldToParty;
		this.isSparesEmailSent = isSparesEmailSent;
	}

	public String getWbsElement() {
		return wbsElement;
	}

	public void setWbsElement(String wbsElement) {
		this.wbsElement = wbsElement;
	}

	public CustomerSapmst getCustomerSapmst() {
		return customerSapmst;
	}

	public void setCustomerSapmst(CustomerSapmst customerSapmst) {
		this.customerSapmst = customerSapmst;
	}

	public String getIsSparesEmailSent() {
		return isSparesEmailSent;
	}

	public void setIsSparesEmailSent(String isSparesEmailSent) {
		this.isSparesEmailSent = isSparesEmailSent;
	}

	public String getSparesSoNumber() {
		return sparesSoNumber;
	}

	public void setSparesSoNumber(String sparesSoNumber) {
		this.sparesSoNumber = sparesSoNumber;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getSoOrdersId() {
		return soOrdersId;
	}

	public void setSoOrdersId(Integer soOrdersId) {
		this.soOrdersId = soOrdersId;
	}

	public String getContSalesDocType() {
		return this.contSalesDocType;
	}

	public void setContSalesDocType(String contSalesDocType) {
		this.contSalesDocType = contSalesDocType;
	}

	public String getContractNum() {
		return this.contractNum;
	}

	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}

	public String getCreatedDate() {
//		return createdDate;
		return DateUtil.convertDateTimeToString(createdDate);
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreationDate() {
//		return creationDate;
		return DateUtil.convertDateTimeToString(this.creationDate);
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getDistChannel() {
		return this.distChannel;
	}

	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}

	public String getDivision() {
		return this.division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getMaterialNum() {
		return materialNum;
	}

	public void setMaterialNum(String materialNum) {
		this.materialNum = materialNum;
	}

	public String getOrderQuantity() {
		return this.orderQuantity;
	}

	public void setOrderQuantity(String orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public String getPlant() {
		return this.plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getReasonForRej() {
		return this.reasonForRej;
	}

	public void setReasonForRej(String reasonForRej) {
		this.reasonForRej = reasonForRej;
	}

	public String getSalesOffice() {
		return this.salesOffice;
	}

	public void setSalesOffice(String salesOffice) {
		this.salesOffice = salesOffice;
	}

	public String getSalesOrg() {
		return this.salesOrg;
	}

	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

	public String getSalesUnit() {
		return this.salesUnit;
	}

	public void setSalesUnit(String salesUnit) {
		this.salesUnit = salesUnit;
	}

	public String getServiceOrderNum() {
		return this.serviceOrderNum;
	}

	public void setServiceOrderNum(String serviceOrderNum) {
		this.serviceOrderNum = serviceOrderNum;
	}

	public String getShipToParty() {
		return this.shipToParty;
	}

	public void setShipToParty(String shipToParty) {
		this.shipToParty = shipToParty;
	}

	public String getSoNumber() {
		return this.soNumber;
	}

	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}

	public String getSoldToParty() {
		return this.soldToParty;
	}

	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}

	public MaterialSapmst getMaterialSapmst() {
		return materialSapmst;
	}

	public void setMaterialSapmst(MaterialSapmst materialSapmst) {
		this.materialSapmst = materialSapmst;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getSeparator() {
		return separator;
	}

	public void setSeparator(String separator) {
		this.separator = separator;
	}
	

}