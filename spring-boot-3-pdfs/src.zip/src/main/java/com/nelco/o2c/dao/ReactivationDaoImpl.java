package com.nelco.o2c.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.DisconnectionReconnectionDatesToCSVDTO;
import com.nelco.o2c.dto.DisconnectionRequestDetailsDTO;
import com.nelco.o2c.dto.OutstandingInvoicesDTO;
import com.nelco.o2c.dto.ReactivationListDTO;
import com.nelco.o2c.dto.ReqctivationRequestDetailsDTO;
import com.nelco.o2c.model.DisconnectionNoticeRequestMst;
import com.nelco.o2c.model.ReactivationRequestMst;
import com.nelco.o2c.utility.DateUtil;

@Repository
public class ReactivationDaoImpl implements ReactivationDao {
	@PersistenceContext
	private EntityManager em;

	Query query;
	
	StoredProcedureQuery spQuery;
	@Override
	public List<ReactivationListDTO> getReactivationRequestsList(HttpServletRequest request) {
		spQuery = em.createStoredProcedureQuery("isp_getDisconnectedSitesForReconnection")
				.registerStoredProcedureParameter("customer", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("startDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("endDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("userId", String.class, ParameterMode.IN);
		spQuery.setParameter("customer", request.getParameter("customer"))
				.setParameter("startDate", DateUtil.convertDateToSqlDate(request.getParameter("startDate")))
				.setParameter("endDate", DateUtil.convertDateToSqlDate(request.getParameter("endDate")))
				.setParameter("userId", request.getParameter("userId"));
		List<Object[]> requestList=spQuery.getResultList();
		return requestList.stream().map(result -> new ReactivationListDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3])
		         ,String.valueOf(result[4]),String.valueOf(result[5]),String.valueOf(result[6]),String.valueOf(result[7])
		         ,String.valueOf(result[8]),String.valueOf(result[9]))
		   ).collect(Collectors.toList());
	}
	@Override
	public ReactivationRequestMst appRejReactivationRequest(ReactivationRequestMst toBeStatuses) {
		query=em.createNamedQuery("ReactivationRequestMst.updateBusineddHeadAppStatus");	
		query.setParameter("requestStatus", toBeStatuses.getRequestStatus());
		query.setParameter("requestId", toBeStatuses.getRequestId());
		query.executeUpdate();
		return toBeStatuses;
	}
	@Override
	public ReactivationRequestMst initiateDisconnectionNotice(ReactivationRequestMst reactivationRequest) {
		query=em.createNamedQuery("ReactivationRequestMst.getRequestId");
		String requestId=String.valueOf(query.getSingleResult());
		reactivationRequest.setRequestId(requestId);
		reactivationRequest.setRequestDate(String.valueOf(DateUtil.getCurrentSqlDate()));
		reactivationRequest.setBusinessheadAppStatus("0");
		reactivationRequest.setRequestStatus("0");
		reactivationRequest.setReactivationStatus("0");
		reactivationRequest.setReactivationType("1");		
		ReactivationRequestMst requestDetails=em.merge(reactivationRequest);
		return requestDetails;
	}
	@Override
	public ReactivationRequestMst reactivateSite(ReactivationRequestMst toBeStatuses) {
		query=em.createNamedQuery("ReactivationRequestMst.reactivateSite");	
		query.setParameter("requestId", toBeStatuses.getRequestId());
		query.executeUpdate();
		return toBeStatuses;
	}
	@Override
	public String getInvoiceNoFromRequestId(String requestId) {
		query=em.createNamedQuery("ReactivationRequestMst.getInvoiceNoFromRequestId");
		query.setParameter("requestId", requestId);
		String invoiceNo=String.valueOf(query.getSingleResult());
		return invoiceNo;
	}
	@Override
	public ReqctivationRequestDetailsDTO getReconnectionRequestDetails(String requestId) {
		Object[] obj;
		spQuery = em.createStoredProcedureQuery("isp_getReaconnectionRequestDetails")
				.registerStoredProcedureParameter("requestId", String.class, ParameterMode.IN);
		spQuery.setParameter("requestId", requestId);
		List<Object[]> invoiceList=spQuery.getResultList();
		ReqctivationRequestDetailsDTO dto=new ReqctivationRequestDetailsDTO();
		for(int i=0;i<invoiceList.size();i++){
			obj=invoiceList.get(0);
			dto.setDisconnectionDate(String.valueOf(obj[0]));
			dto.setRequestDate(String.valueOf(obj[1]));
			dto.setRequestId(String.valueOf(obj[2]));
			dto.setUserId(String.valueOf(obj[3]));
			dto.setBusinessHeadAppStatus(String.valueOf(obj[4]));
			dto.setBusinessHeadAppStatusCode(String.valueOf(obj[5]));
			dto.setReactivationStatus(String.valueOf(obj[6]));
			dto.setReactivationStatusCode(String.valueOf(obj[7]));
		}
		return dto;
	}
	@Override
	public List<DisconnectionReconnectionDatesToCSVDTO> getBillingStartDate(String requestId) {
		DisconnectionReconnectionDatesToCSVDTO dto;
		List<DisconnectionReconnectionDatesToCSVDTO> result=new ArrayList<DisconnectionReconnectionDatesToCSVDTO>();
		query = em.createNativeQuery("SELECT car.so_no,CONVERT(VARCHAR,drm.disconnection_date,105)as enddate"
				+ " FROM disconnection_request_mst drm"
				+ " INNER JOIN disconnection_notice_request_mst dnrm on drm.notice_id=dnrm.request_id"
				+ " INNER JOIN customer_ageing_report car on dnrm.invoice_no=car.invoice_no"
				+ " WHERE drm.request_id='"+requestId+"'");
		
		@SuppressWarnings("unchecked")
		List<Object[]> resultList = (List<Object[]>) query.getResultList();
		if( resultList!=null && resultList.size()>0) { 		
		for (Object[] objects : resultList) {
			dto=new DisconnectionReconnectionDatesToCSVDTO();
			dto.setSo_no(String.valueOf(objects[0]));
			dto.setEndDate(String.valueOf(objects[1]));
			result.add(dto);
		}		
	}	
		return result;
}
	
	

}
