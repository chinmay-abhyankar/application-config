/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.SparesSo;
import com.nelco.o2c.model.StateMst;

/**
 * @author Jayshankar.r
 *
 */
public class SparesDTO implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	private Integer userMstId;
	private String roleCode;
	private SparesSo sparesSo;
	private List<SparesSo> sparesSoList;
	private List<OppUploadDetail> oppUploadDetails = new ArrayList<OppUploadDetail>();
	private String fromDate;
	private String toDate;
	private Integer sparesSoId;
	private List<FileTypeMst> fileList;
	private Boolean isSaved = false;
	private Integer sparesSoDetailsId;
	private List<PlantSapmst> plantList;
	private Boolean checkIncidentId = false;
	private String incidentId;
	private String isDuplInciId = "No";
	private List<StateMst> stateMstList;
	
	
	public List<PlantSapmst> getPlantList() {
		return plantList;
	}
	public void setPlantList(List<PlantSapmst> plantList) {
		this.plantList = plantList;
	}
	public Integer getSparesSoDetailsId() {
		return sparesSoDetailsId;
	}
	public void setSparesSoDetailsId(Integer sparesSoDetailsId) {
		this.sparesSoDetailsId = sparesSoDetailsId;
	}
	public Boolean getIsSaved() {
		return isSaved;
	}
	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}
	public List<FileTypeMst> getFileList() {
		return fileList;
	}
	public void setFileList(List<FileTypeMst> fileList) {
		this.fileList = fileList;
	}
	public Integer getSparesSoId() {
		return sparesSoId;
	}
	public void setSparesSoId(Integer sparesSoId) {
		this.sparesSoId = sparesSoId;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}
	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public SparesSo getSparesSo() {
		return sparesSo;
	}
	public void setSparesSo(SparesSo sparesSo) {
		this.sparesSo = sparesSo;
	}
	public List<SparesSo> getSparesSoList() {
		return sparesSoList;
	}
	public void setSparesSoList(List<SparesSo> sparesSoList) {
		this.sparesSoList = sparesSoList;
	}
	public Boolean getCheckIncidentId() {
		return checkIncidentId;
	}
	public void setCheckIncidentId(Boolean checkIncidentId) {
		this.checkIncidentId = checkIncidentId;
	}
	public String getIncidentId() {
		return incidentId;
	}
	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}
	public String getIsDuplInciId() {
		return isDuplInciId;
	}
	public void setIsDuplInciId(String isDuplInciId) {
		this.isDuplInciId = isDuplInciId;
	}
	public List<StateMst> getStateMstList() {
		return stateMstList;
	}
	public void setStateMstList(List<StateMst> stateMstList) {
		this.stateMstList = stateMstList;
	}
	
}
