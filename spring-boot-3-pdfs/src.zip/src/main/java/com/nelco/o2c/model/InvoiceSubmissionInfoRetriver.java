package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the invoice_submission_info_retriver database table.
 * 
 */
@Entity
@Table(name="invoice_submission_info_retriver")
@NamedQuery(name="InvoiceSubmissionInfoRetriver.findAll", query="SELECT i.customerNo,i.customerName"
		+ ",i.invoiceNo,i.invoiceDate,i.invoiceSubmissionDate,i.outstandingAmt,i.submissionDueDate"
		+ ",i.invoiceType,i.billingDate,i.soNo,i.checkStatus,i.cancellationStatus,i.cancellationStatusCode"
		+ ",i.requestId,i.submissionStatus,i.companyCode,i.rowNumber"
		+ " FROM InvoiceSubmissionInfoRetriver i WHERE i.userId=:userId")
public class InvoiceSubmissionInfoRetriver implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private int typeid;

	@Column(name="billing_date", length=50)
	private String billingDate;

	@Column(name="cancellation_status", length=50)
	private String cancellationStatus;

	@Column(name="cancellation_status_code", length=50)
	private String cancellationStatusCode;

	@Column(name="check_status", length=50)
	private String checkStatus;

	@Column(name="company_code", length=50)
	private String companyCode;

	@Column(name="customer_name", length=200)
	private String customerName;

	@Column(name="customer_no", length=50)
	private String customerNo;

	@Column(name="invoice_date", length=50)
	private String invoiceDate;

	@Column(name="invoice_no", length=50)
	private String invoiceNo;

	@Column(name="invoice_submission_date", length=50)
	private String invoiceSubmissionDate;

	@Column(name="invoice_type", length=50)
	private String invoiceType;

	@Column(name="outstanding_amt", precision=18, scale=2)
	private BigDecimal outstandingAmt;

	@Column(name="request_id", length=50)
	private String requestId;

	@Column(name="row_number")
	private int rowNumber;

	@Column(name="so_no", length=50)
	private String soNo;

	@Column(name="submission_due_date", length=50)
	private String submissionDueDate;

	@Column(name="submission_status", length=50)
	private String submissionStatus;

	@Column(name="unique_id", length=50)
	private String uniqueId;

	@Column(name="user_id", length=20)
	private String userId;

	public InvoiceSubmissionInfoRetriver() {
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getBillingDate() {
		return this.billingDate;
	}

	public void setBillingDate(String billingDate) {
		this.billingDate = billingDate;
	}

	public String getCancellationStatus() {
		return this.cancellationStatus;
	}

	public void setCancellationStatus(String cancellationStatus) {
		this.cancellationStatus = cancellationStatus;
	}

	public String getCancellationStatusCode() {
		return this.cancellationStatusCode;
	}

	public void setCancellationStatusCode(String cancellationStatusCode) {
		this.cancellationStatusCode = cancellationStatusCode;
	}

	public String getCheckStatus() {
		return this.checkStatus;
	}

	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCustomerName() {
		return this.customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerNo() {
		return this.customerNo;
	}

	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}

	public String getInvoiceDate() {
		return this.invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceNo() {
		return this.invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getInvoiceSubmissionDate() {
		return this.invoiceSubmissionDate;
	}

	public void setInvoiceSubmissionDate(String invoiceSubmissionDate) {
		this.invoiceSubmissionDate = invoiceSubmissionDate;
	}

	public String getInvoiceType() {
		return this.invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public BigDecimal getOutstandingAmt() {
		return this.outstandingAmt;
	}

	public void setOutstandingAmt(BigDecimal outstandingAmt) {
		this.outstandingAmt = outstandingAmt;
	}

	public String getRequestId() {
		return this.requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public int getRowNumber() {
		return this.rowNumber;
	}

	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}

	public String getSoNo() {
		return this.soNo;
	}

	public void setSoNo(String soNo) {
		this.soNo = soNo;
	}

	public String getSubmissionDueDate() {
		return this.submissionDueDate;
	}

	public void setSubmissionDueDate(String submissionDueDate) {
		this.submissionDueDate = submissionDueDate;
	}

	public String getSubmissionStatus() {
		return this.submissionStatus;
	}

	public void setSubmissionStatus(String submissionStatus) {
		this.submissionStatus = submissionStatus;
	}

	public String getUniqueId() {
		return this.uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}