package com.nelco.o2c.dto;

import java.util.List;

import com.nelco.o2c.model.ActivityTypeMst;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.InstallationTypeMst;
import com.nelco.o2c.model.TechnologyMaster;

public class FranchiseeAllocFormDTO {
	private List<ActivityTypeMst> lstActivityTypeMst;
	private List<InstallationTypeMst> installationTypeList;
	
	private List<TechnologyMaster> techList;
	private List<HubMst> hubList;
	
	
	
	

	public List<TechnologyMaster> getTechList() {
		return techList;
	}

	public void setTechList(List<TechnologyMaster> techList) {
		this.techList = techList;
	}

	public List<HubMst> getHubList() {
		return hubList;
	}

	public void setHubList(List<HubMst> hubList) {
		this.hubList = hubList;
	}

	public List<InstallationTypeMst> getInstallationTypeList() {
		return installationTypeList;
	}

	public void setInstallationTypeList(List<InstallationTypeMst> installationTypeList) {
		this.installationTypeList = installationTypeList;
	}

	public List<ActivityTypeMst> getLstActivityTypeMst() {
		return lstActivityTypeMst;
	}

	public void setLstActivityTypeMst(List<ActivityTypeMst> lstActivityTypeMst) {
		this.lstActivityTypeMst = lstActivityTypeMst;
	}

}
