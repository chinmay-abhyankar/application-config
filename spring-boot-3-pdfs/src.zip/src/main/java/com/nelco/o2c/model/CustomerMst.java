package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the customer_mst database table.
 * 
 */
@Entity
@Table(name = "customer_mst")
@NamedQueries({ @NamedQuery(name = "CustomerMst.findAll", query = "SELECT c FROM CustomerMst c"),
		@NamedQuery(name = "CustomerMst.searchCustomer", query = "SELECT c FROM CustomerMst c where c.customerName like ?1 or c.customerNum like ?2 ") })

public class CustomerMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "customer_mst_id")
	private Integer customerMstId;

	@Column(name = "customer_name")
	private String customerName;

	@Column(name = "customer_num")
	private String customerNum;

	@Column(name = "pin")
	private String pin;

	@Column(name = "street1")
	private String street1;

	@Column(name = "street2")
	private String street2;

	@Column(name = "street3")
	private String street3;

	@Column(name = "street4")
	private String street4;

	@Column(name = "street5")
	private String street5;

	@Column(name = "state_mst_id")
	private Integer stateMstId;

	@Column(name = "city_name")
	private String cityName;

	public Integer getCustomerMstId() {
		return customerMstId;
	}

	public void setCustomerMstId(Integer customerMstId) {
		this.customerMstId = customerMstId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerNum() {
		return customerNum;
	}

	public void setCustomerNum(String customerNum) {
		this.customerNum = customerNum;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getStreet1() {
		return street1;
	}

	public void setStreet1(String street1) {
		this.street1 = street1;
	}

	public String getStreet2() {
		return street2;
	}

	public void setStreet2(String street2) {
		this.street2 = street2;
	}

	public String getStreet3() {
		return street3;
	}

	public void setStreet3(String street3) {
		this.street3 = street3;
	}

	public String getStreet4() {
		return street4;
	}

	public void setStreet4(String street4) {
		this.street4 = street4;
	}

	public String getStreet5() {
		return street5;
	}

	public void setStreet5(String street5) {
		this.street5 = street5;
	}

	public Integer getStateMstId() {
		return stateMstId;
	}

	public void setStateMstId(Integer stateMstId) {
		this.stateMstId = stateMstId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	

}