package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the franchise_to_state database table.
 * 
 */
@Entity
@Table(name="franchise_to_state")
@NamedQuery(name="FranchiseToState.findAll", query="SELECT f FROM FranchiseToState f")
public class FranchiseToState implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="franchise_to_state_id")
	private Integer franchiseToStateId;

	@Column(name="franchise_mst_id")
	private Integer franchiseMstId;

	@Column(name="state_mst_id")
	private Integer stateMstId;

	public FranchiseToState() {
	}

	public Integer getFranchiseToStateId() {
		return franchiseToStateId;
	}

	public void setFranchiseToStateId(Integer franchiseToStateId) {
		this.franchiseToStateId = franchiseToStateId;
	}

	public Integer getFranchiseMstId() {
		return franchiseMstId;
	}

	public void setFranchiseMstId(Integer franchiseMstId) {
		this.franchiseMstId = franchiseMstId;
	}

	public Integer getStateMstId() {
		return stateMstId;
	}

	public void setStateMstId(Integer stateMstId) {
		this.stateMstId = stateMstId;
	}

	

}