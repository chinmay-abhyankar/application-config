package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.dto.UserDTO;


/**
 * The persistent class for the pre_bid_resp_matrix database table.
 * 
 */
@Entity
@Table(name="pre_bid_resp_matrix")
@NamedQueries({
@NamedQuery(name="PreBidRespMatrix.findAll", query="SELECT p FROM PreBidRespMatrix p "),
@NamedQuery(name="PreBidRespMatrix.getByPreBidRespMatrixId", query="SELECT pbm FROM PreBidRespMatrix pbm where pbm.preBidRespMatrixId =?1 "),
@NamedQuery(name="PreBidRespMatrix.getPreBidRespMatrixByUserMstIdAndOpId", query="SELECT pbm FROM PreBidRespMatrix pbm where pbm.createdBy =?1 and pbm.opportunityId=?2 "),
@NamedQuery(name="PreBidRespMatrix.findByOppId", query="SELECT pbm from PreBidRespMatrix pbm where pbm.respPerId=?1 "),
@NamedQuery(name="PreBidRespMatrix.getPreBidResponsesByRespPerIdAndOpId", query="SELECT pbm FROM PreBidRespMatrix pbm left join pbm.preBidTaskResponse pbr where pbm.respPerId =?1 and pbm.opportunityId=?2 "),
@NamedQuery(name="PreBidRespMatrix.getFinalPBResponseByUserMstIdAndOpId", query="SELECT pbm FROM PreBidRespMatrix pbm left join pbm.preBidTaskResponse pbr where pbm.createdBy =?1 and pbm.opportunityId=?2 ")
})

public class PreBidRespMatrix implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pre_bid_resp_matrix_id")
	private Integer preBidRespMatrixId;

	@Column(name="clause_ref")
	private String clauseRef;

	@Column(name="created_by")
	private Integer createdBy;

	@Column(name="created_date")
	private String createdDate;

	@Column(name="dept_mst_id")
	private Integer deptMstId;

	@Column(name="opportunity_id")
	private Integer opportunityId;

	@Column(name="page_no")
	private String pageNo;

	@Column(name="resp_per_id")
	private Integer respPerId;
	
	@Transient
	private DeptMst deptMst;
	
	@Transient
	private UserDTO respPerson;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "pre_bid_resp_matrix_id", referencedColumnName = "pre_bid_resp_matrix_id", insertable = false, updatable = false)
    private PreBidTaskResponse preBidTaskResponse;
	
	public Integer getPreBidRespMatrixId() {
		return preBidRespMatrixId;
	}

	public void setPreBidRespMatrixId(Integer preBidRespMatrixId) {
		this.preBidRespMatrixId = preBidRespMatrixId;
	}

	public String getClauseRef() {
		return clauseRef;
	}

	public void setClauseRef(String clauseRef) {
		this.clauseRef = clauseRef;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getDeptMstId() {
		return deptMstId;
	}

	public void setDeptMstId(Integer deptMstId) {
		this.deptMstId = deptMstId;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getPageNo() {
		return pageNo;
	}

	public void setPageNo(String pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getRespPerId() {
		return respPerId;
	}

	public void setRespPerId(Integer respPerId) {
		this.respPerId = respPerId;
	}
	
	public DeptMst getDeptMst() {
		return deptMst;
	}
	
	public void setDeptMst(DeptMst deptMst) {
		this.deptMst = deptMst;
	}

	public UserDTO getRespPerson() {
		return respPerson;
	}

	public void setRespPerson(UserDTO respPerson) {
		this.respPerson = respPerson;
	}

	public PreBidTaskResponse getPreBidTaskResponse() {
		return preBidTaskResponse;
	}

	public void setPreBidTaskResponse(PreBidTaskResponse preBidTaskResponse) {
		this.preBidTaskResponse = preBidTaskResponse;
	}
	

}