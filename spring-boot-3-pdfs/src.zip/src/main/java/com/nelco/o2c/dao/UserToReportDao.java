package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.ReportContractDTO;
import com.nelco.o2c.dto.UserDTO;
import com.nelco.o2c.model.ChildContract;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.ReportMst;
import com.nelco.o2c.model.StatusMst;

public interface UserToReportDao {
		public List<ReportMst> getAsssignedReportsName(int userId);
		
		public List<StatusMst> searchStatusByCode(List<String> statusList);
		
		public List<HubMst> allActiveHubs();
		
		public List<UserDTO> getALlProgramMangers();
		
		public List<ReportContractDTO> searchSapContractNum(String sapContractNumber);
		
}
