package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.model.StateMst;
import com.nelco.o2c.model.StatusMst;

@Repository
public class SiteSurveyReportDaoImpl implements SiteSurveyReportDao {
	@PersistenceContext
	EntityManager em;

	@Autowired
	private UserToReportDao userToReportDao;

	Query query;

	@Override
	public List<StatusMst> searchStatusByCode(List<String> statusList) {
		// SSSTCS SSSTFR
		List<StatusMst> smlist = userToReportDao.searchStatusByCode(statusList);
		smlist.get(1).setStatusName("CS Allocated");
		smlist.get(2).setStatusName("Franchise Allocated");
		return smlist;
	}

	@Override
	public List<String> searchAllCustomers() {
		List<String> custList = new ArrayList<String>();
		try {
			query = em.createNativeQuery(
					"select distinct customer_name from site_survey_mst where customer_name is not null and customer_name<>''");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);

			custList = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return custList != null ? custList : new ArrayList<String>();
	}

	@Override
	public List<String> searchAllFranchise() {
		List<String> fraList = new ArrayList<String>();
		try {
			query = em.createNativeQuery("select distinct franchise_name from franchise_mst order by franchise_name");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);

			fraList = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return fraList != null ? fraList : new ArrayList<String>();
	}

	@Override
	public List<StateMst> getAllStates() {
		List<StateMst> stateList = new ArrayList<StateMst>();
		try {
			//StateMst.findAll
			query = em.createNativeQuery("select * from state_mst");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			for (Object[] objects : resultList) {
				StateMst stateMst = new StateMst();
				stateMst.setStateMstId((Integer) objects[0]);
				stateMst.setStateCode((String) objects[1]);
				stateMst.setStateVal((String) objects[2]);
				stateMst.setCountryCode((String) objects[3]);

				stateList.add(stateMst);
			}
			
			return stateList;
		}catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

}
