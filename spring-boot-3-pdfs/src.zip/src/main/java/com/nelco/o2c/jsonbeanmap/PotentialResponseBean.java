/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Amol.l
 *
 */
public class PotentialResponseBean  {
	@JsonProperty("data")
	private List<PotentialDataBean> dataList = new ArrayList<PotentialDataBean>();
	
	@JsonProperty("info")
	private PotentialInfoBean info;

	public List<PotentialDataBean> getDataList() {
		return dataList;
	}

	public void setDataList(List<PotentialDataBean> dataList) {
		this.dataList = dataList;
	}

	public PotentialInfoBean getInfo() {
		return info;
	}

	public void setInfo(PotentialInfoBean info) {
		this.info = info;
	}
	
}
