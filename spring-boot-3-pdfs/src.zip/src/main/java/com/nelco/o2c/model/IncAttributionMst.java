package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the inc_attribution_mst database table.
 * 
 */
@Entity
@Table(name="inc_attribution_mst")
@NamedQuery(name="IncAttributionMst.findAll", query="SELECT i FROM IncAttributionMst i where i.isActive = 'Y' ")
public class IncAttributionMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="inc_attribution_mst_id")
	private Integer incAttributionMstId;

	@Column(name="inc_attribution_code")
	private String incAttributionCode;

	@Column(name="inc_attribution_val")
	private String incAttributionVal;

	@Column(name="is_active")
	private String isActive;

	public IncAttributionMst() {
	}

	public Integer getIncAttributionMstId() {
		return incAttributionMstId;
	}

	public void setIncAttributionMstId(Integer incAttributionMstId) {
		this.incAttributionMstId = incAttributionMstId;
	}

	public String getIncAttributionCode() {
		return incAttributionCode;
	}

	public void setIncAttributionCode(String incAttributionCode) {
		this.incAttributionCode = incAttributionCode;
	}

	public String getIncAttributionVal() {
		return incAttributionVal;
	}

	public void setIncAttributionVal(String incAttributionVal) {
		this.incAttributionVal = incAttributionVal;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	

}