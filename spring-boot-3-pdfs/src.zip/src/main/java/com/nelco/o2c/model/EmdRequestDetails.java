/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;

/**
 * @author Jayashankar.r
 *
 */
@Entity
@Table(name = "emd_request_details")
@NamedQueries({@NamedQuery(name = "EmdRequestDetails.findAll", query = "SELECT e FROM EmdRequestDetails e"),
	@NamedQuery(name = "EmdRequestDetails.findByOppId", query = "SELECT e FROM EmdRequestDetails e where e.opportunityId = ?1"),
	@NamedQuery(name = "EmdRequestDetails.findByRequestTo", query = "SELECT e FROM EmdRequestDetails e where e.requestTo = ?1 and e.requestStatus='P' ")})
public class EmdRequestDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "emd_request_details_id")
	private Integer emdRequestDetailsId;

	@Column(name = "opportunity_id")
	private Integer opportunityId;

	@Column(name = "tender_type_mst_id")
	private Integer tenderTypeMstId;

	@Column(name = "request_status")
	private String requestStatus;

	@Column(name = "request_by")
	private Integer requestBy;

	@Column(name = "request_to")
	private Integer requestTo;

	@Column(name = "request_date")
	private String requestDate;

	@Column(name = "completion_date")
	private String completionDate;
	
	@Column(name = "rejection_date")
	private String rejectionDate;
	
	@Column(name = "reject_reason")
	private String rejectReason;
	
	@Column(name = "comments")
	private String comments;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "tender_type_mst_id", referencedColumnName = "tender_type_mst_id", insertable = false, updatable = false)
	private TenderTypeMst tenderTypeMst;
	
	@Transient
	private UserEmailDetailsBean financeUser;
	
	public String getRejectionDate() {
		return rejectionDate;
	}

	public void setRejectionDate(String rejectionDate) {
		this.rejectionDate = rejectionDate;
	}

	public String getRejectReason() {
		return rejectReason;
	}

	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}

	public UserEmailDetailsBean getFinanceUser() {
		return financeUser;
	}

	public void setFinanceUser(UserEmailDetailsBean financeUser) {
		this.financeUser = financeUser;
	}

	public TenderTypeMst getTenderTypeMst() {
		return tenderTypeMst;
	}

	public void setTenderTypeMst(TenderTypeMst tenderTypeMst) {
		this.tenderTypeMst = tenderTypeMst;
	}

	public Integer getEmdRequestDetailsId() {
		return emdRequestDetailsId;
	}

	public void setEmdRequestDetailsId(Integer emdRequestDetailsId) {
		this.emdRequestDetailsId = emdRequestDetailsId;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public Integer getTenderTypeMstId() {
		return tenderTypeMstId;
	}

	public void setTenderTypeMstId(Integer tenderTypeMstId) {
		this.tenderTypeMstId = tenderTypeMstId;
	}

	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	public Integer getRequestBy() {
		return requestBy;
	}

	public void setRequestBy(Integer requestBy) {
		this.requestBy = requestBy;
	}

	public Integer getRequestTo() {
		return requestTo;
	}

	public void setRequestTo(Integer requestTo) {
		this.requestTo = requestTo;
	}

	public String getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getCompletionDate() {
		return completionDate;
	}

	public void setCompletionDate(String completionDate) {
		this.completionDate = completionDate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

}
