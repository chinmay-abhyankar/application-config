package com.nelco.o2c.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.nelco.o2c.dto.CustomerDocumentMappingFormDTO;
import com.nelco.o2c.dto.CustomerDocumentMappingListDTO;
import com.nelco.o2c.model.CustomerMandatoryDocMapping;

public interface CustomerDocumentMappingDao {

	List<CustomerDocumentMappingListDTO> getCustomerDocumentMappingList(HttpServletRequest request);

	CustomerMandatoryDocMapping addDocumentsForCustomer(CustomerMandatoryDocMapping tobeSavedRequest);

	void removeDocumentsForCustomer(CustomerMandatoryDocMapping tobeSavedRequest);

	CustomerDocumentMappingFormDTO getDisconnectionMasters(
			CustomerDocumentMappingFormDTO customerDocumentMappingFormDTO);

}
