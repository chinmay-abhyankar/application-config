/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

import com.nelco.o2c.model.BrfApproverDetail;

/**
 * @author Amol.l
 *
 */
public class BrfApproverDetailDTO  implements Serializable {

	private static final long serialVersionUID = 75L;
	
	private BrfApproverDetail brfApproverDetail = new BrfApproverDetail();

	public BrfApproverDetail getBrfApproverDetail() {
		return brfApproverDetail;
	}

	public void setBrfApproverDetail(BrfApproverDetail brfApproverDetail) {
		this.brfApproverDetail = brfApproverDetail;
	}

}
