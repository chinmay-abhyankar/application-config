package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the pgi_sapmst database table.
 * 
 */
@Entity
@Table(name="pgi_sapmst")
@NamedQuery(name="PgiSapmst.findAll", query="SELECT p FROM PgiSapmst p")
public class PgiSapmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pgi_id")
	private int pgiId;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="delivery_num")
	private String deliveryNum;

	@Column(name="pgi_num")
	private String pgiNum;

	public PgiSapmst() {
	}

	public int getPgiId() {
		return this.pgiId;
	}

	public void setPgiId(int pgiId) {
		this.pgiId = pgiId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDeliveryNum() {
		return this.deliveryNum;
	}

	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}

	public String getPgiNum() {
		return this.pgiNum;
	}

	public void setPgiNum(String pgiNum) {
		this.pgiNum = pgiNum;
	}

}