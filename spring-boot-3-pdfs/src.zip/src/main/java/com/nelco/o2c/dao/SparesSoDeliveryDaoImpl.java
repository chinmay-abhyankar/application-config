/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.ConstantProperties;
import com.nelco.o2c.dto.SparesSoDeliveryDTO;
import com.nelco.o2c.dto.SparesSoPodUploadDTO;
import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.DeliveryStatusMst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.SparesSoDelivery;
import com.nelco.o2c.model.SparesSoDeliveryPodTracker;
import com.nelco.o2c.model.SparesSoDeliveryTracker;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Jayshankar.r
 *
 */
@Repository
public class SparesSoDeliveryDaoImpl implements SparesSoDeliveryDao {
	
	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	private CallSpDao callSpDao;
	
	@Autowired
	ConstantProperties prop;
	
	Query query;

	@SuppressWarnings("unchecked")
	@Override
	public List<SparesSoDelivery> getSparesSoDeliveryList(SparesSoDeliveryDTO sparesSoDeliveryInputDTO) {
		// TODO Auto-generated method stub
		String fromDate = DateUtil.convertDateToSqlDate(sparesSoDeliveryInputDTO.getFromDate()) + Constants.MINDAYTIME;
		String toDate = DateUtil.convertDateToSqlDate(sparesSoDeliveryInputDTO.getToDate()) + Constants.MAXDAYTIME;
		
		try {
			if (sparesSoDeliveryInputDTO.getIsNext().equals(prop.getyFlag())) {
				query = em.createNamedQuery("SparesSoDelivery.findByDeliveryCreationDateGreaterThan");
			} else {
				query = em.createNamedQuery("SparesSoDelivery.findByDeliveryCreationDateLessThan");
			}
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			query.setParameter("fromDate", fromDate);
			query.setParameter("toDate", toDate);
			query.setParameter("sparesSoDeliveryId", sparesSoDeliveryInputDTO.getSparesSoDeliveryId());
			query.setParameter("deliveryStatusMstId", sparesSoDeliveryInputDTO.getDeliveryStatusMstId());
			query.setMaxResults(25);
			List<SparesSoDelivery> resultList = (List<SparesSoDelivery>) query.getResultList();
			return resultList;
		} finally {
			// TODO: handle finally clause
			em.close();
			fromDate = null;
			toDate = null;
		}
		
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DeliveryStatusMst> getDeliveryStatusListNotIndelStatusCode(List<String> delStatusCodeList) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("DeliveryStatusMst.findNotIndelStatusCode");
			query.setParameter("delStatusCode", delStatusCodeList);
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			return (List<DeliveryStatusMst>) query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public SparesSoDelivery saveSparesSoDelivery(SparesSoDelivery delivery) {
		// TODO Auto-generated method stub

		delivery.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		String dispatchDate = DateUtil.convertDateToSqlDate(delivery.getDispatchDate());
		//String addate = DateUtil.convertDateToSqlDate(delivery.getAddate());
		String eddate = DateUtil.convertDateToSqlDate(delivery.getEddate());
		delivery.setDispatchDate(dispatchDate);
		//delivery.setAddate(addate);
		delivery.setEddate(eddate);

		SparesSoDelivery deliveryNew = em.merge(delivery);

		if (delivery.getSparesSoDeliveryId() == null) {
			em.refresh(deliveryNew);
		}
		return deliveryNew;
	}

	@Override
	public void savesparesSoDeliveryTracker(SparesSoDeliveryTracker sparesSoDeliveryTracker) {
		// TODO Auto-generated method stub
		em.merge(sparesSoDeliveryTracker);
	}

	@Override
	public void saveSparesSoDeliveryPodTracker(SparesSoDeliveryPodTracker sparesSoDeliveryPodTracker) {
		// TODO Auto-generated method stub
		em.merge(sparesSoDeliveryPodTracker);
	}

	@SuppressWarnings("unchecked")
	@Override
	public String getSparesSoEmailString(SparesSoDelivery sparesSoDelivery) {
		// TODO Auto-generated method stub
		List<UserEmailDetailsBean> beanList = new ArrayList<UserEmailDetailsBean>();
		query = em.createNativeQuery("select um.user_mst_id,um.user_email from spares_so_delivery ssd inner join spares_so ss " + 
				" on ssd.spares_req_id = ss.uniq_id " + 
				" inner join spares_so_user_map ssum " + 
				" on ss.spares_so_id = ssum.spares_so_id " + 
				" inner join user_mst um " + 
				" on ssum.user_mst_id = um.user_mst_id where ssd.spares_req_id = :spares_req_id ");
		query.setParameter("spares_req_id", sparesSoDelivery.getSparesReqId());
		List<Object[]> result = (List<Object[]>) query.getResultList();
		for (Object[] objects : result) {
			UserEmailDetailsBean uBean = new UserEmailDetailsBean();
			uBean.setUserMstId((Integer)objects[0]);
			uBean.setUserMail((String)objects[1]);
			beanList.add(uBean);
		}
		
		query = em.createNativeQuery("select um.user_mst_id,um.user_email,fm.franchise_zone_email "
				+ " from spares_so_delivery ssd inner join user_to_region_mst utr "
				+ " on ssd.state_mst_id = utr.region_code "
				+ " inner join user_mst um on utr.user_id = um.user_mst_id "
				+ " inner join cs_user_franchise_zone_mapping_mst fzm on utr.user_id = fzm.user_mst_id "
				+ " inner join franchise_zone_mst fm on fzm.franchise_zone_mst_id = fm.franchise_zone_mst_id "
				+ " where ssd.state_mst_id = :state_mst_id and ssd.spares_so_delivery_id = :spares_so_delivery_id");
		query.setParameter("state_mst_id", sparesSoDelivery.getStateMstId());
		query.setParameter("spares_so_delivery_id", sparesSoDelivery.getSparesSoDeliveryId());
		List<Object[]> csResultList = (List<Object[]>) query.getResultList();
		for (Object[] objects : csResultList) {
			UserEmailDetailsBean uBean = new UserEmailDetailsBean();
			uBean.setUserMstId((Integer)objects[0]);
			uBean.setUserMail((String)objects[1]);
			beanList.add(uBean);
			
			//adding zone email in the same list
			uBean = new UserEmailDetailsBean();
			uBean.setUserMstId((Integer)objects[0]);
			uBean.setUserMail((String)objects[2]);
			beanList.add(uBean);
		}
		
		String finalEmailListString = beanList .stream() .map(beanObj -> String.valueOf(beanObj.getUserMail())) .collect(Collectors.joining(";"));
		return finalEmailListString;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppUploadDetail> setOppUploadDetailsBySparesSoDeliveryId(
			SparesSoPodUploadDTO sparesSoPodUploadInputDTO) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("OppUploadDetail.getOppUploadDetailsBySparesSoDeliveryId");
			query.setParameter("sparesSoDeliveryId", sparesSoPodUploadInputDTO.getSparesSoDeliveryId());
			List<OppUploadDetail> resultList = (List<OppUploadDetail>) query.getResultList();
			return resultList;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public void updatePodStatusInSparesSoDelivery(Integer uploadedStatusNumber, Integer sparesSoDeliveryId) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("SparesSoDelivery.updatePodStatusByDeliveryId");
			query.setParameter("podStatusMstId", uploadedStatusNumber);
			query.setParameter("sparesSoDeliveryId", sparesSoDeliveryId);
			query.executeUpdate();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

}
