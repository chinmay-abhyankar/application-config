/**
 * 
 */
package com.nelco.o2c.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.UserDTO;
import com.nelco.o2c.dto.UserManagementDTO;
import com.nelco.o2c.model.DeptMst;
import com.nelco.o2c.model.FranchiseeMaster;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.RoleMst;
import com.nelco.o2c.model.StateMst;
import com.nelco.o2c.model.SubDeptMst;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.model.UserRegionMaster;
import com.nelco.o2c.model.UserToFranchisee;
import com.nelco.o2c.model.UserToHub;
import com.nelco.o2c.model.ZoneMst;
import com.nelco.o2c.utility.DateUtil;
import com.nelco.o2c.utility.RecordNotFoundException;

/**
 * @author Chinmay A
 *
 */
@Repository
public class UserManagementDaoImpl implements UserManagementDao {

	@PersistenceContext
	EntityManager em;
	
	Query query;
	
	@Autowired
	UserToReportDao userReportDao;
	
	@Autowired
	CommonPotentialsDao commonDao;
	


	@Override
	public UserManagementDTO getAllDropDowns() {
		try {
			List<DeptMst> deptMstList = em.createQuery("from DeptMst",DeptMst.class).getResultList();
			List<SubDeptMst> subDeptMstList = em.createQuery("from SubDeptMst",SubDeptMst.class).getResultList();
			List<RoleMst> roleMstList = em.createQuery("from RoleMst",RoleMst.class).getResultList();
			List<ZoneMst> zoneMstList =  em.createQuery("from ZoneMst",ZoneMst.class).getResultList();
			List<StateMst> stateMstList =  em.createQuery("from StateMst",StateMst.class).getResultList();  
			List<HubMst> hubMstList =  userReportDao.allActiveHubs();
			List<FranchiseeMaster> franchiseeList = em.createQuery("from FranchiseeMaster",FranchiseeMaster.class).getResultList();
			
			UserManagementDTO um = new UserManagementDTO();
			um.setDeptMstList(deptMstList);
			um.setHubMstList(hubMstList);
			um.setRoleMstList(roleMstList);
			um.setStateMstList(stateMstList);
			um.setSubDeptMstList(subDeptMstList);
			um.setZoneMstList(zoneMstList);
			um.setFranchiseeList(franchiseeList);
			
			return um!=null?um:new UserManagementDTO();
		}catch (Exception e) {
			e.printStackTrace();
			return new UserManagementDTO();
		}
	}

	
	@Override
	public List<UserDTO> getUserDetails() {
		List<UserDTO> userList = new ArrayList<UserDTO>();
		try {
			query = em.createNativeQuery("select * from user_details");
			
			List<Object[]> result = (List<Object[]>) query.getResultList();
			for (Object[] objects : result) {
				UserDTO userDTO = new UserDTO();
				userDTO.setUserMstId((Integer)objects[0]);
				userDTO.setUserName((String)objects[1]);
				userDTO.setEmail((String)objects[2]);
				userDTO.setDeptMstId((Integer)objects[3]);
				userDTO.setDeptCode((String)objects[4]);
				userDTO.setDeptName((String)objects[5]);
				userDTO.setSubDeptMstId((String)objects[6]);
				userDTO.setSubDeptCode((String)objects[7]);
				userDTO.setSubDeptName((String)objects[8]);
				userDTO.setLoginId((String)objects[9]);
				userDTO.setRoleMstId((Integer)objects[10]);
				userDTO.setRoleCode((String)objects[11]);
				userDTO.setRoleDesc((String)objects[12]);
				userDTO.setZoneMstId((Integer)objects[13]);
				userDTO.setZoneMstCode((String)objects[14]);
				userDTO.setZoneDesc((String)objects[15]);
				if(objects[16]!=null) {
					Timestamp createdDate = (Timestamp) objects[16];
					userDTO.setCreatedDate(DateUtil.getSimpleUIDateFormat((createdDate.toString())));
				}
				if(objects[17]!=null) {
					Timestamp updatedDate = (Timestamp)objects[17];
					userDTO.setUpdatedDate(DateUtil.getSimpleUIDateFormat((updatedDate.toString())));
				}
				//userDTO.setUpdatedDate((String)objects[13]);
				userDTO.setIsActive((Character)objects[18]);
				
				userList.add(userDTO);
			}
			
			if(userList.isEmpty() || (userList==null)) {
				throw new RecordNotFoundException("No records Found !!");
			}
			else {
				return userList;
			}
		
		}catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<UserDTO>();
		}finally {
			em.close();
		}
	}



	@Override
	@Transactional
	public boolean addUserToHub(UserMst userMst,UserDTO user) {
		try {
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
				UserToHub userToHub = new UserToHub();
				userToHub.setHubMstId(user.getHubMstId());
				userToHub.setUserMstId(userMst.getUserMstId());
				userToHub.setCreatedDate(currTime);
				userToHub = em.merge(userToHub);
			return true;
		}catch (Exception e) {
		e.printStackTrace();
			return false;
		}finally {
			em.close();
		}
		
	}

	@Override
	@Transactional
	public boolean addUserToRegionMaster(UserMst userMst,String stateIds) {
		try {
			UserRegionMaster regionMaster = new UserRegionMaster();
			regionMaster.setRegion_code(stateIds);
			regionMaster.setUser_id(String.valueOf(userMst.getUserMstId()));
			
			regionMaster = em.merge(regionMaster);
			return true;
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}finally {
			em.close();
		}
	}


	@Override
	public Integer getCountOfUser(UserMst user, UserDTO userDTO, String table, String column1, Integer value1,
			String column2, String value2) {
		try {
			String lQuery = "select count(*) from " + table + " where " + column1 + "=?1 and " +column2 + " =?2 ";
			query = em.createNativeQuery(lQuery);
			query.setParameter(1, value1);
			query.setParameter(2, value2);
			int num = (int) query.getSingleResult();
			return num;
		}catch (Exception e) {
		
		}
		return null;
	}



	@Override
	public boolean addUserToFranchiseMst(UserMst userMst, UserDTO userDTO) {
		try {
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			query = em.createQuery("delete UserToFranchisee u where u.userMstId = ?1");
			query.setParameter(1, userMst.getUserMstId());
			query.executeUpdate();
			
			UserToFranchisee franchisee = new UserToFranchisee();
			franchisee.setUserMstId(userMst.getUserMstId());
			franchisee.setFranchiseeId(userDTO.getFranchiseMstId());
			franchisee.setCreatedDate(currTime);
			franchisee = em.merge(franchisee);
			return true;
		}catch (Exception e) {
			return false;
		}
	}

	@Override
	public Integer getFranchiseByUserMstId(UserMst user, UserDTO userDTO) {
		try {
			query = em.createQuery("from UserToFranchisee u where u.userMstId = ?1",UserToFranchisee.class);
			query.setParameter(1, user.getUserMstId());
			
			UserToFranchisee  uf = (UserToFranchisee) query.getSingleResult();
			
			return uf.getFranchiseeId();
		}catch (Exception e) {
				e.printStackTrace();
				return null;
		}
	}



}
