package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the delivery_status_mst database table.
 * 
 */
@Entity
@Table(name="delivery_status_mst")
@NamedQueries({
	@NamedQuery(name="DeliveryStatusMst.findAll", query="SELECT d FROM DeliveryStatusMst d"),
	@NamedQuery(name="DeliveryStatusMst.findNotIndelStatusCode", query="SELECT d FROM DeliveryStatusMst d where d.delStatusCode not in :delStatusCode ")
})
public class DeliveryStatusMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="delivery_status_mst_id")
	private Integer deliveryStatusMstId;

	@Column(name="del_status_code")
	private String delStatusCode;

	@Column(name="del_status_name")
	private String delStatusName;

	public DeliveryStatusMst() {
	}

	public Integer getDeliveryStatusMstId() {
		return deliveryStatusMstId;
	}

	public void setDeliveryStatusMstId(Integer deliveryStatusMstId) {
		this.deliveryStatusMstId = deliveryStatusMstId;
	}

	public String getDelStatusCode() {
		return delStatusCode;
	}

	public void setDelStatusCode(String delStatusCode) {
		this.delStatusCode = delStatusCode;
	}

	public String getDelStatusName() {
		return delStatusName;
	}

	public void setDelStatusName(String delStatusName) {
		this.delStatusName = delStatusName;
	}

}