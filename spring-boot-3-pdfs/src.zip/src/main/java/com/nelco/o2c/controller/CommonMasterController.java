/**
 * 
 */
package com.nelco.o2c.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.service.CommonMasterService;

/**
 * @author Amol.l
 *
 */
@RestController
public class CommonMasterController {
	@Autowired
	CommonMasterService commonMasterService;
	
	
	

}
