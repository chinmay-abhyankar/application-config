package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the relocation_type_mst database table.
 * 
 */
@Entity
@Table(name="relocation_type_mst")
@NamedQuery(name="RelocationTypeMst.findAll", query="SELECT r FROM RelocationTypeMst r where r.isActive = 'Y' ")
public class RelocationTypeMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="relocation_type_mst_id")
	private Integer relocationTypeMstId;

	@Column(name="relocation_type_code")
	private String relocationTypeCode;

	@Column(name="relocation_type_val")
	private String relocationTypeVal;
	
	@Column(name = "is_active")
	private String isActive;
	
	

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public RelocationTypeMst() {
	}

	public Integer getRelocationTypeMstId() {
		return this.relocationTypeMstId;
	}

	public void setRelocationTypeMstId(Integer relocationTypeMstId) {
		this.relocationTypeMstId = relocationTypeMstId;
	}

	public String getRelocationTypeCode() {
		return this.relocationTypeCode;
	}

	public void setRelocationTypeCode(String relocationTypeCode) {
		this.relocationTypeCode = relocationTypeCode;
	}

	public String getRelocationTypeVal() {
		return this.relocationTypeVal;
	}

	public void setRelocationTypeVal(String relocationTypeVal) {
		this.relocationTypeVal = relocationTypeVal;
	}

}