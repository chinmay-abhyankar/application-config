/**
 * 
 */
package com.nelco.o2c.dto;

/**
 * @author Jayashankar.r
 *
 */
public class CustomerInputDTO {

	private String kunnr;
	private String name;
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
