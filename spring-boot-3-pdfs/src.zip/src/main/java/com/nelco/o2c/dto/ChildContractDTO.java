/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.ChildContract;
import com.nelco.o2c.model.OppUploadDetail;

/**
 * @author Amol.l
 *
 */
public class ChildContractDTO implements Serializable {

	private static final long serialVersionUID = 75L;
	private Integer childContractId;
	private Integer contractId;
	private ChildContract childContract = new ChildContract();
	private String isSave;
	private String sapContractNum;
	private List<OppUploadDetail> oppUploadDetails;
	private Integer userMstId;
	private String accManagerName;
	
	
	
	public String getAccManagerName() {
		return accManagerName;
	}

	public void setAccManagerName(String accManagerName) {
		this.accManagerName = accManagerName;
	}

	public Integer getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}

	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}

	public String getSapContractNum() {
		return sapContractNum;
	}

	public void setSapContractNum(String sapContractNum) {
		this.sapContractNum = sapContractNum;
	}

	public Integer getChildContractId() {
		return childContractId;
	}

	public void setChildContractId(Integer childContractId) {
		this.childContractId = childContractId;
	}

	public Integer getContractId() {
		return contractId;
	}

	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}

	public ChildContract getChildContract() {
		return childContract;
	}

	public void setChildContract(ChildContract childContract) {
		this.childContract = childContract;
	}

	public String getIsSave() {
		return isSave;
	}

	public void setIsSave(String isSave) {
		this.isSave = isSave;
	}
	
}
