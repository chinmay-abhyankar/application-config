package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the portallink_mst database table.
 * 
 */
@Entity
@Table(name="portallink_mst")
@NamedQuery(name="PortallinkMst.findAll", query="SELECT p FROM PortallinkMst p")
public class PortallinkMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="portallink_mst_id")
	private int portallinkMstId;

	private String actflag;

	private String link;

	private String type;

	public PortallinkMst() {
	}

	public int getPortallinkMstId() {
		return this.portallinkMstId;
	}

	public void setPortallinkMstId(int portallinkMstId) {
		this.portallinkMstId = portallinkMstId;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public String getLink() {
		return this.link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

}