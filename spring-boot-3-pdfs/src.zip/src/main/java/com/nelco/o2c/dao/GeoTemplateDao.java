/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.GeoTempDTO;
import com.nelco.o2c.dto.GeoTemplateDTO;
import com.nelco.o2c.model.GeoTemplate;
import com.nelco.o2c.model.GeoTemplateStatusTracker;

/**
 * @author Amol.l
 *
 */
public interface GeoTemplateDao {

	public List<GeoTempDTO> getGeoTemplateListByBrfId(GeoTemplateDTO geoTemplateDTO);

	public GeoTemplate getGeoTempByGeoTempId(Integer geoTemplateId);

	public GeoTemplate saveGeoTemplate(GeoTemplate geoTemplate);

	public GeoTemplateStatusTracker saveGeoTemplateStatusTracker(GeoTemplateStatusTracker geoTemplateStatusTracker);

}
