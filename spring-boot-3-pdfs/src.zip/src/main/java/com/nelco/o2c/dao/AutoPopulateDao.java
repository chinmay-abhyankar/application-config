/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.AutoCompleteDTO;
import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.model.HsoDetail;
import com.nelco.o2c.model.MaterialContract;
import com.nelco.o2c.model.MaterialSapmst;
import com.nelco.o2c.model.PayTermsMst;
import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.SoOrders;
import com.nelco.o2c.model.StorageSapmst;

/**
 * @author Jayashankar.r
 *
 */
public interface AutoPopulateDao {

	List<MaterialSapmst> searchMaterial(String material);

	List<CustomerSapmst> searchSoldToParty(String soldToParty);

	List<PlantSapmst> searchPlant(String plant);

	List<StorageSapmst> searchStorage(String storage);

	List<MaterialContract> searchMaterialMasterContract(String material, Integer contractId);

	List<MaterialSapmst> searchMaterialBySalesOrg(String material, String salesOrg);

	List<MaterialSapmst> searchMaterialByPlant(String material, String plant);

	List<CustomerSapmst> searchAccountMgrCode(String accMgrCode);

	List<PayTermsMst> searchPaymentTerms(String payTermsCode);

	List<SoOrders> searchSObySoNumber(String soNumber);
	
	List<CustomerSapmst> searchSoldToPartySparesSo(String soldToParty);

	List<CustomerSapmst> searchShipToPartySparesSo(String shipToParty);

	List<MaterialSapmst> searchMaterialSparesSo(String material);

	List<SoOrders> searchSObySoNumberForRelocation(String soNumber);

	List<HsoDetail> searchIp(String ip);
	
	String getBillToParty(AutoCompleteDTO auto);
	
}
