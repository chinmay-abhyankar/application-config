/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.jsonbeanmap.EmailBean;
import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.ActivityTypeMst;
import com.nelco.o2c.model.AntennaLocationMst;
import com.nelco.o2c.model.AntennaSizeMaster;
import com.nelco.o2c.model.AntennaTypeMst;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.IncAttributionMst;
import com.nelco.o2c.model.InstallationStatusMst;
import com.nelco.o2c.model.KmApplMst;
import com.nelco.o2c.model.NonFeasibleOptionMst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.SiteSurveyCost;
import com.nelco.o2c.model.SsEngVisitDetail;
import com.nelco.o2c.model.TechnologyMaster;
import com.nelco.o2c.model.WorkCompletionStatusMst;

/**
 * @author Jayashankar.r
 *
 */
/**
 * @author Jayashankar.r
 *
 */
public class VisitCommonDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 50L;
	private SsEngVisitDetail ssEngVisitDetail = new SsEngVisitDetail();
	private Integer ssEngVisitDetailsId;
	private Integer siteSurveyMstId;
	private List<SsEngVisitDetail> ssEngVisitDetailList = new ArrayList<SsEngVisitDetail>();
	private List<AntennaSizeMaster> antennaSizeList = new ArrayList<AntennaSizeMaster>();
	private List<WorkCompletionStatusMst> workCompletionStatusList = new ArrayList<WorkCompletionStatusMst>();
	private Boolean isSaved = false;
	private List<SiteSurveyCost> siteSurveyCostList = new ArrayList<SiteSurveyCost>();
	private List<KmApplMst> kmApplMstList;
	private Integer userMstId;
	private String roleCode;
	private String fromDate;
	private String toDate;
	private SiteSurveyCost siteSurveyCost;
	private String apprRejFlag;
	private List<OppUploadDetail> oppUploadDetails = new ArrayList<OppUploadDetail>();
	private List<FileTypeMst> fileList = new ArrayList<FileTypeMst>();
	private List<TechnologyMaster> techList;
	private List<HubMst> hubList;
	private Integer siteSurveyCostId;
	private SiteSurveyDTO siteSurveyDTO;
	private List<NonFeasibleOptionMst> nonFeasibleList;
	private EmailBean emailBean;
	private List<AntennaTypeMst> antennaTypeList;
	private List<AntennaLocationMst> antennaLocationList;
	private Integer franchiseInvReqId;
	private List<UserEmailDetailsBean> cseUsers;
	private List<InstallationStatusMst> installationStatusList;
	private List<IncAttributionMst> incAttributionList;
	private List<ActivityTypeMst> lstActivityTypeMst;

	public List<ActivityTypeMst> getLstActivityTypeMst() {
		return lstActivityTypeMst;
	}

	public void setLstActivityTypeMst(List<ActivityTypeMst> lstActivityTypeMst) {
		this.lstActivityTypeMst = lstActivityTypeMst;
	}

	public List<InstallationStatusMst> getInstallationStatusList() {
		return installationStatusList;
	}

	public void setInstallationStatusList(List<InstallationStatusMst> installationStatusList) {
		this.installationStatusList = installationStatusList;
	}

	public List<IncAttributionMst> getIncAttributionList() {
		return incAttributionList;
	}

	public void setIncAttributionList(List<IncAttributionMst> incAttributionList) {
		this.incAttributionList = incAttributionList;
	}

	public List<UserEmailDetailsBean> getCseUsers() {
		return cseUsers;
	}

	public void setCseUsers(List<UserEmailDetailsBean> cseUsers) {
		this.cseUsers = cseUsers;
	}

	public Integer getFranchiseInvReqId() {
		return franchiseInvReqId;
	}

	public void setFranchiseInvReqId(Integer franchiseInvReqId) {
		this.franchiseInvReqId = franchiseInvReqId;
	}

	public List<AntennaTypeMst> getAntennaTypeList() {
		return antennaTypeList;
	}

	public void setAntennaTypeList(List<AntennaTypeMst> antennaTypeList) {
		this.antennaTypeList = antennaTypeList;
	}

	public List<AntennaLocationMst> getAntennaLocationList() {
		return antennaLocationList;
	}

	public void setAntennaLocationList(List<AntennaLocationMst> antennaLocationList) {
		this.antennaLocationList = antennaLocationList;
	}

	public EmailBean getEmailBean() {
		return emailBean;
	}

	public void setEmailBean(EmailBean emailBean) {
		this.emailBean = emailBean;
	}

	public List<NonFeasibleOptionMst> getNonFeasibleList() {
		return nonFeasibleList;
	}

	public void setNonFeasibleList(List<NonFeasibleOptionMst> nonFeasibleList) {
		this.nonFeasibleList = nonFeasibleList;
	}

	public SiteSurveyDTO getSiteSurveyDTO() {
		return siteSurveyDTO;
	}

	public void setSiteSurveyDTO(SiteSurveyDTO siteSurveyDTO) {
		this.siteSurveyDTO = siteSurveyDTO;
	}

	public Integer getSiteSurveyCostId() {
		return siteSurveyCostId;
	}

	public void setSiteSurveyCostId(Integer siteSurveyCostId) {
		this.siteSurveyCostId = siteSurveyCostId;
	}

	public List<TechnologyMaster> getTechList() {
		return techList;
	}

	public void setTechList(List<TechnologyMaster> techList) {
		this.techList = techList;
	}

	public List<HubMst> getHubList() {
		return hubList;
	}

	public void setHubList(List<HubMst> hubList) {
		this.hubList = hubList;
	}

	public List<FileTypeMst> getFileList() {
		return fileList;
	}

	public void setFileList(List<FileTypeMst> fileList) {
		this.fileList = fileList;
	}

	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}

	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}

	public String getApprRejFlag() {
		return apprRejFlag;
	}

	public void setApprRejFlag(String apprRejFlag) {
		this.apprRejFlag = apprRejFlag;
	}

	public SiteSurveyCost getSiteSurveyCost() {
		return siteSurveyCost;
	}

	public void setSiteSurveyCost(SiteSurveyCost siteSurveyCost) {
		this.siteSurveyCost = siteSurveyCost;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public List<KmApplMst> getKmApplMstList() {
		return kmApplMstList;
	}

	public void setKmApplMstList(List<KmApplMst> kmApplMstList) {
		this.kmApplMstList = kmApplMstList;
	}

	public Integer getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public List<SiteSurveyCost> getSiteSurveyCostList() {
		return siteSurveyCostList;
	}

	public void setSiteSurveyCostList(List<SiteSurveyCost> siteSurveyCostList) {
		this.siteSurveyCostList = siteSurveyCostList;
	}

	public SsEngVisitDetail getSsEngVisitDetail() {
		return ssEngVisitDetail;
	}

	public void setSsEngVisitDetail(SsEngVisitDetail ssEngVisitDetail) {
		this.ssEngVisitDetail = ssEngVisitDetail;
	}

	public Integer getSsEngVisitDetailsId() {
		return ssEngVisitDetailsId;
	}

	public void setSsEngVisitDetailsId(Integer ssEngVisitDetailsId) {
		this.ssEngVisitDetailsId = ssEngVisitDetailsId;
	}

	public Integer getSiteSurveyMstId() {
		return siteSurveyMstId;
	}

	public void setSiteSurveyMstId(Integer siteSurveyMstId) {
		this.siteSurveyMstId = siteSurveyMstId;
	}

	public List<SsEngVisitDetail> getSsEngVisitDetailList() {
		return ssEngVisitDetailList;
	}

	public void setSsEngVisitDetailList(List<SsEngVisitDetail> ssEngVisitDetailList) {
		this.ssEngVisitDetailList = ssEngVisitDetailList;
	}

	public List<AntennaSizeMaster> getAntennaSizeList() {
		return antennaSizeList;
	}

	public void setAntennaSizeList(List<AntennaSizeMaster> antennaSizeList) {
		this.antennaSizeList = antennaSizeList;
	}

	public List<WorkCompletionStatusMst> getWorkCompletionStatusList() {
		return workCompletionStatusList;
	}

	public void setWorkCompletionStatusList(List<WorkCompletionStatusMst> workCompletionStatusList) {
		this.workCompletionStatusList = workCompletionStatusList;
	}

	public Boolean getIsSaved() {
		return isSaved;
	}

	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}

}
