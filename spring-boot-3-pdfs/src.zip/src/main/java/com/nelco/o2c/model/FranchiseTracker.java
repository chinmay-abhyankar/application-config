package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the franchise_tracker database table.
 * 
 */
@Entity
@Table(name="franchise_tracker")
@NamedQuery(name="FranchiseTracker.findAll", query="SELECT f FROM FranchiseTracker f")
public class FranchiseTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="franchise_tracker_id")
	private Integer franchiseTrackerId;

	@Column(name="franchise_proc_type_mst_id")
	private Integer franchiseProcTypeMstId;

	@Column(name="franchisee_id")
	private Integer franchiseeId;

	@Column(name="req_by_id")
	private Integer reqById;

	@Column(name="req_date")
	private String reqDate;

	@Column(name="site_survey_id")
	private Integer siteSurveyId;

	public FranchiseTracker() {
	}

	public Integer getFranchiseTrackerId() {
		return this.franchiseTrackerId;
	}

	public void setFranchiseTrackerId(Integer franchiseTrackerId) {
		this.franchiseTrackerId = franchiseTrackerId;
	}

	public Integer getFranchiseProcTypeMstId() {
		return this.franchiseProcTypeMstId;
	}

	public void setFranchiseProcTypeMstId(Integer franchiseProcTypeMstId) {
		this.franchiseProcTypeMstId = franchiseProcTypeMstId;
	}

	public Integer getFranchiseeId() {
		return this.franchiseeId;
	}

	public void setFranchiseeId(Integer franchiseeId) {
		this.franchiseeId = franchiseeId;
	}

	public Integer getReqById() {
		return this.reqById;
	}

	public void setReqById(Integer reqById) {
		this.reqById = reqById;
	}

	public String getReqDate() {
		return this.reqDate;
	}

	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}

	public Integer getSiteSurveyId() {
		return this.siteSurveyId;
	}

	public void setSiteSurveyId(Integer siteSurveyId) {
		this.siteSurveyId = siteSurveyId;
	}

}