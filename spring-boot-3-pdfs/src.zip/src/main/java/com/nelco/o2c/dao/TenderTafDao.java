/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.EmailDocDTO;
import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.BidTypeMst;
import com.nelco.o2c.model.ClauseMst;
import com.nelco.o2c.model.EmdRequestDetails;
import com.nelco.o2c.model.EvalTypeMst;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.LeadBidderMst;
import com.nelco.o2c.model.LeaseMst;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.PreCriteria;
import com.nelco.o2c.model.RiskMst;
import com.nelco.o2c.model.StatusMst;
import com.nelco.o2c.model.Taf;
import com.nelco.o2c.model.TafDetails;
import com.nelco.o2c.model.TafMst;
import com.nelco.o2c.model.TafStatusTracker;
import com.nelco.o2c.model.TendBidDet;

/**
 * @author Jayashankar.r
 *
 */
public interface TenderTafDao {
	public List<OppDetails> getOppDetailsByOppId(Integer oppId);

	public TendBidDet getTenderBidDetailsByOppId(Integer oppId);

	public List<PreCriteria> getPreCriteriaByOppId(Integer oppId);
	
	public List<OppUploadDetail> getOppUploadDetailsByOppId(Integer oppId);

	public List<FileTypeMst> getFileTypeList();

	public List<UserEmailDetailsBean> getVerticalHeads();

	public List<UserEmailDetailsBean> getSalesHeads();

	public List<LeadBidderMst> getLeadBidderList();

	public List<LeaseMst> getLeaseList();

	public List<ClauseMst> getClauseList();

	public void saveTenderBidDetails(TendBidDet tenderBidDetails, String sbu);

	public List<PreCriteria> savePreCriteriaDetails(List<PreCriteria> preCriterias);

	public OppUploadDetail saveOppUploadDetails(OppUploadDetail oppUploadDetail);

	public List<BidTypeMst> getBidTypeList();

	public List<EvalTypeMst> getEvalTypeList();

	public List<RiskMst> getRiskList();

	public Taf getTafHeaderByOppId(CommonDTO commonDTO);

	public List<TafMst> getTafList();

	List<TafDetails> getTafDetails(Integer tafId);

	public StatusMst getTafStatus(Integer tafId);

	public Taf saveTafHeader(Taf tafHeader);

	public List<TafMst> saveTafList(List<TafMst> tafList, Taf taf);

	List<UserEmailDetailsBean> getPreBidResource();

	public TafStatusTracker saveTafStatusTracker(TafStatusTracker tafStatusTracker);

	public Taf getTafById(Integer tafId);

	public void updateEmailSentFlag(EmailDocDTO emailDocDTO);
	
	
}
