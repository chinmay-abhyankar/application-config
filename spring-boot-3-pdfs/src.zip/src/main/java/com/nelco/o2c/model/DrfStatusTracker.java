package com.nelco.o2c.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 * The persistent class for the drf_status_tracker database table.
 * 
 */
@Entity
@Table(name = "drf_status_tracker")
@NamedQueries({
@NamedQuery(name = "DrfStatusTracker.findAll", query = "SELECT d FROM DrfStatusTracker d"),
@NamedQuery(name = "DrfStatusTracker.getDrfStatusTrackerDetailsByDrfId", query = "select dst from DrfStatusTracker dst where dst.drfDetailsId =?1  ORDER BY dst.reqDate DESC"),
@NamedQuery(name = "DrfStatusTracker.checkDrfRejectStatus", query = "select dst from DrfStatusTracker dst where dst.drfDetailsId =?1  and dst.statusMstId=5")})
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "drfStatusTrackerId")
public class DrfStatusTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "drf_status_tracker_id")
	private Integer drfStatusTrackerId;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "drf_details_id")
	private Integer drfDetailsId;

	@Column(name = "status_mst_id")
	private Integer statusMstId;
	
	@Column(name = "req_date")
	private String reqDate;
	
	@Column(name = "created_by_id")
	private Integer createdById;
	
	@Column(name = "appr_rej_reason")
	private String apprRejReason;
	
	
	
	public String getApprRejReason() {
		return apprRejReason;
	}

	public void setApprRejReason(String apprRejReason) {
		this.apprRejReason = apprRejReason;
	}

	public Integer getCreatedById() {
		return createdById;
	}

	public void setCreatedById(Integer createdById) {
		this.createdById = createdById;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "drf_details_id", referencedColumnName = "drf_details_id", insertable = false, updatable = false)
	private DrfDetails drfDetails;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_mst_id", referencedColumnName = "status_mst_id", insertable = false, updatable = false)
	private StatusMst statusMst;

	public Integer getDrfStatusTrackerId() {
		return drfStatusTrackerId;
	}

	public void setDrfStatusTrackerId(Integer drfStatusTrackerId) {
		this.drfStatusTrackerId = drfStatusTrackerId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}

	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}

	public Integer getStatusMstId() {
		return statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}

	public StatusMst getStatusMst() {
		return statusMst;
	}

	public void setStatusMst(StatusMst statusMst) {
		this.statusMst = statusMst;
	}

	

	public String getReqDate() {
		return reqDate;
	}

	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}

	public DrfDetails getDrfDetails() {
		return drfDetails;
	}

	public void setDrfDetails(DrfDetails drfDetails) {
		this.drfDetails = drfDetails;
	}

	@Override
	public String toString() {
		return "DrfStatusTracker [drfStatusTrackerId=" + drfStatusTrackerId + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + ", drfDetailsId=" + drfDetailsId + ", statusMstId=" + statusMstId
				+ ", reqDate=" + reqDate + ", drfDetails=" + drfDetails + ", statusMst=" + statusMst + "]";
	}
		
}