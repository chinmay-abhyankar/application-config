/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.ConditionTypeMst;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.PayTermsMst;
import com.nelco.o2c.model.PricingGroupMst;
import com.nelco.o2c.model.QuarterMst;
import com.nelco.o2c.model.SegmentMst;

/**
 * @author Amol.l
 *
 */
public class ChildContractDropDownDTO implements Serializable {

	private static final long serialVersionUID = 75L;
	
	
	private List<SegmentMst> segmentMstList = new ArrayList<SegmentMst>();
	private List<QuarterMst> quarterMstList = new ArrayList<QuarterMst>();
	private List<ConditionTypeMst> conditionTypeList = new ArrayList<ConditionTypeMst>();
	private List<PricingGroupMst> pricingGroupList = new ArrayList<PricingGroupMst>();
	private List<PayTermsMst> payTermsList = new ArrayList<PayTermsMst>();
	private List<FileTypeMst> fileList;
	
	
	public List<FileTypeMst> getFileList() {
		return fileList;
	}
	public void setFileList(List<FileTypeMst> fileList) {
		this.fileList = fileList;
	}
	public List<PayTermsMst> getPayTermsList() {
		return payTermsList;
	}
	public void setPayTermsList(List<PayTermsMst> payTermsList) {
		this.payTermsList = payTermsList;
	}
	public List<ConditionTypeMst> getConditionTypeList() {
		return conditionTypeList;
	}
	public void setConditionTypeList(List<ConditionTypeMst> conditionTypeList) {
		this.conditionTypeList = conditionTypeList;
	}
	public List<PricingGroupMst> getPricingGroupList() {
		return pricingGroupList;
	}
	public void setPricingGroupList(List<PricingGroupMst> pricingGroupList) {
		this.pricingGroupList = pricingGroupList;
	}
	public List<SegmentMst> getSegmentMstList() {
		return segmentMstList;
	}
	public void setSegmentMstList(List<SegmentMst> segmentMstList) {
		this.segmentMstList = segmentMstList;
	}
	public List<QuarterMst> getQuarterMstList() {
		return quarterMstList;
	}
	public void setQuarterMstList(List<QuarterMst> quarterMstList) {
		this.quarterMstList = quarterMstList;
	}

}
