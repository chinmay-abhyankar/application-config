/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.DrfApprovalDTO;
import com.nelco.o2c.dto.DrfInfoDTO;
import com.nelco.o2c.dto.MaterialDTO;
import com.nelco.o2c.dto.PlantSapmstDTO;
import com.nelco.o2c.dto.UserDTO;
import com.nelco.o2c.model.ClauseContractMst;
import com.nelco.o2c.model.DeptMst;
import com.nelco.o2c.model.DrfApproverDetail;
import com.nelco.o2c.model.DrfTypeMst;
import com.nelco.o2c.model.MaterialSapmst;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.UserMst;

/**
 * @author Jayashankar.r
 *
 */
public interface CommonPotentialsDao {

	public List<OppDetails> getPreSalesPotentialList(CommonDTO commonDTO);
	
	public List<OppDetails> getSalesCoordPotentialList(CommonDTO commonDTO);
	
	public List<OppDetails> getHeadPotentialList(CommonDTO commonDTO);
	
	public UserMst getUserDetailsById(Integer userMstId);

	public List<UserMst> getUserListByJobCode(String roleCd);

	public List<OppDetails> preBidResponsibilityMatrix(CommonDTO commonDTO);
	
	public List<OppDetails> getRespMatrix(CommonDTO commonDTO);
	
	public List<OppDetails> commonPreBidTasks(CommonDTO commonDTO);
	
	public List<DeptMst> getAllDeptList(DeptMst deptMst);
	
	public List<DrfTypeMst> getAllDrfTypeList(DrfTypeMst drfTypeMst);
	
	public List<UserDTO> getUserListDeptwise(DeptMst deptMst);
	
	public DeptMst getDeptBydeptMstId(Integer deptMstId);
	
	public String getPotentialNameByOppId(Integer oppId);
	
	public String getCustomerNameByOppId(Integer oppId);

	public String getNatureByOppId(Integer oppId);

	public DrfApprovalDTO getDrfApprovalInfo(DrfInfoDTO drfInfoDTO);

	public List<DrfApproverDetail> headApprovalInfo(List<Integer> drfIds);

	public UserMst getUserDetByLoginId(String loginId);

	public MaterialSapmst uniqueMaterial(MaterialDTO materialDTO);
	
	public List<ClauseContractMst> allClauseContList(ClauseContractMst clauseContractMst);

	public List<PlantSapmst> allPlantList(PlantSapmstDTO plantSapmstDTO);

	public List<OppDetails> getVpsPotentialList(CommonDTO commonDTO);

	public List<OppDetails> getEboHeadPotentialList(CommonDTO commonDTO);

	public List<OppDetails> getMdPotentialList(CommonDTO commonDTO);
	
	public UserMst getUserByBusinessLine(String businessline);
}
