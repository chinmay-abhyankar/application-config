package com.nelco.o2c.dao;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.nelco.o2c.dto.DisconnectionOnCRDTO;
import com.nelco.o2c.dto.DisconnectionReconnectionDatesToCSVDTO;
import com.nelco.o2c.model.DisconnectionRequestOnCrMst;
import com.nelco.o2c.model.TemplateDownloadRequest;


public interface DisconnectionOnCRDao {

	List<DisconnectionOnCRDTO> getSoListForDisconnection(HttpServletRequest request);

	String generateTemplate(List<TemplateDownloadRequest> templateDownloadRequest);

	int getCount(String string, String string2, String valueOf);

	List<DisconnectionOnCRDTO> uploadFile(MultipartFile file, String userId, HashMap<String, String> resultMap) throws IOException;

	DisconnectionRequestOnCrMst disconnectSite(DisconnectionRequestOnCrMst toBeStatuses);

	List<DisconnectionReconnectionDatesToCSVDTO> getBillingEndDate(String requestId);

	List<DisconnectionOnCRDTO> getDisconnectionForCustomerRequestReport(HttpServletRequest request);

	String validateIpforDisconnection(String valueOf);

	DisconnectionRequestOnCrMst createDisconnectionRequestOnCR(DisconnectionRequestOnCrMst toBeStatuses);

	void sendDisconnectionOnCRIntimation(String commonId);

}
