/**
 * 
 */
package com.nelco.o2c.dto;

/**
 * @author Jayshankar.r
 *
 */
public class PoPendingDTO {

	private Integer proposalId;
	private String zohoId;
	private String proposalGenId;
	private String poNumber;
	private String statusName;
	private String statusCode;
	private String createdDate;
	private Integer statusMstId;
	private String customerName;
	private String potentialName;
	private String businessLine;
	private String potentialOwner;
    private Integer oppId;
    private String zohoStatus;

	public Integer getOppId() {
		return oppId;
	}
	public void setOppId(Integer oppId) {
		this.oppId = oppId;
	}
	public String getZohoStatus() {
		return zohoStatus;
	}
	public void setZohoStatus(String zohoStatus) {
		this.zohoStatus = zohoStatus;
	}
	public Integer getProposalId() {
		return proposalId;
	}
	public void setProposalId(Integer proposalId) {
		this.proposalId = proposalId;
	}
	public String getZohoId() {
		return zohoId;
	}
	public void setZohoId(String zohoId) {
		this.zohoId = zohoId;
	}
	public String getProposalGenId() {
		return proposalGenId;
	}
	public void setProposalGenId(String proposalGenId) {
		this.proposalGenId = proposalGenId;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getStatusMstId() {
		return statusMstId;
	}
	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPotentialName() {
		return potentialName;
	}
	public void setPotentialName(String potentialName) {
		this.potentialName = potentialName;
	}
	public String getBusinessLine() {
		return businessLine;
	}
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}
	public String getPotentialOwner() {
		return potentialOwner;
	}
	public void setPotentialOwner(String potentialOwner) {
		this.potentialOwner = potentialOwner;
	}
	
	
	
}
