/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.UserMst;

/**
 * @author Amol.l
 *
 */
public class UserRoleListDTO implements Serializable {
	
	private static final long serialVersionUID = 19L;
	private List<UserMst> preSalesMgrLst = new ArrayList<UserMst>();
	private List<UserMst> programMgrLst = new ArrayList<UserMst>();
	private List<UserMst> pmgtHeadLst = new ArrayList<UserMst>();
	private List<UserMst> operationsHeadLst = new ArrayList<UserMst>();
	private List<UserMst> nocMgrLst = new ArrayList<UserMst>();//NOC mgr and technically approved are same
	private List<UserMst> preSalesHeadLst = new ArrayList<UserMst>();
	private List<UserMst> accountMgrLst = new ArrayList<UserMst>();
	private List<UserMst> financeLst = new ArrayList<UserMst>();
	private List<UserMst> RegHeadLst = new ArrayList<UserMst>();
	
	public List<UserMst> getPreSalesMgrLst() {
		return preSalesMgrLst;
	}
	public void setPreSalesMgrLst(List<UserMst> preSalesMgrLst) {
		this.preSalesMgrLst = preSalesMgrLst;
	}

	public List<UserMst> getProgramMgrLst() {
		return programMgrLst;
	}
	public void setProgramMgrLst(List<UserMst> programMgrLst) {
		this.programMgrLst = programMgrLst;
	}
	public List<UserMst> getPmgtHeadLst() {
		return pmgtHeadLst;
	}
	public void setPmgtHeadLst(List<UserMst> pmgtHeadLst) {
		this.pmgtHeadLst = pmgtHeadLst;
	}
	public List<UserMst> getOperationsHeadLst() {
		return operationsHeadLst;
	}
	public void setOperationsHeadLst(List<UserMst> operationsHeadLst) {
		this.operationsHeadLst = operationsHeadLst;
	}
	public List<UserMst> getNocMgrLst() {
		return nocMgrLst;
	}
	public void setNocMgrLst(List<UserMst> nocMgrLst) {
		this.nocMgrLst = nocMgrLst;
	}
	public List<UserMst> getPreSalesHeadLst() {
		return preSalesHeadLst;
	}
	public void setPreSalesHeadLst(List<UserMst> preSalesHeadLst) {
		this.preSalesHeadLst = preSalesHeadLst;
	}
	public List<UserMst> getAccountMgrLst() {
		return accountMgrLst;
	}
	public void setAccountMgrLst(List<UserMst> accountMgrLst) {
		this.accountMgrLst = accountMgrLst;
	}
	public List<UserMst> getFinanceLst() {
		return financeLst;
	}
	public void setFinanceLst(List<UserMst> financeLst) {
		this.financeLst = financeLst;
	}
	public List<UserMst> getRegHeadLst() {
		return RegHeadLst;
	}
	public void setRegHeadLst(List<UserMst> regHeadLst) {
		RegHeadLst = regHeadLst;
	}
	
}
