package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the hso_status_change_tracker database table.
 * 
 */
@Entity
@Table(name="hso_status_change_tracker")
@NamedQuery(name="HsoStatusChangeTracker.findAll", query="SELECT h FROM HsoStatusChangeTracker h")
public class HsoStatusChangeTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="hso_status_change_tracker_id")
	private Integer hsoStatusChangeTrackerId;

	@Column(name="hso_transaction_details_id")
	private Integer hsoTransactionDetailsId;

	@Column(name="hso_transaction_status_mst_id")
	private Integer hsoTransactionStatusMstId;

	@Column(name="req_by")
	private Integer reqBy;

	@Column(name="req_date")
	private String reqDate;

	public HsoStatusChangeTracker() {
	}

	public Integer getHsoStatusChangeTrackerId() {
		return hsoStatusChangeTrackerId;
	}

	public void setHsoStatusChangeTrackerId(Integer hsoStatusChangeTrackerId) {
		this.hsoStatusChangeTrackerId = hsoStatusChangeTrackerId;
	}

	public Integer getHsoTransactionDetailsId() {
		return hsoTransactionDetailsId;
	}

	public void setHsoTransactionDetailsId(Integer hsoTransactionDetailsId) {
		this.hsoTransactionDetailsId = hsoTransactionDetailsId;
	}

	public Integer getHsoTransactionStatusMstId() {
		return hsoTransactionStatusMstId;
	}

	public void setHsoTransactionStatusMstId(Integer hsoTransactionStatusMstId) {
		this.hsoTransactionStatusMstId = hsoTransactionStatusMstId;
	}

	public Integer getReqBy() {
		return reqBy;
	}

	public void setReqBy(Integer reqBy) {
		this.reqBy = reqBy;
	}

	public String getReqDate() {
		return reqDate;
	}

	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}

	

}