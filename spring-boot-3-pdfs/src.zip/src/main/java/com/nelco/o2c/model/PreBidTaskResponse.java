/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.dto.UserDTO;

/**
 * @author Amol.l
 *
 */

@Entity
@Table(name="pre_bid_task_response")
@NamedQueries({
@NamedQuery(name="PreBidTaskResponse.findAll", query="SELECT pbr FROM PreBidTaskResponse pbr"),
@NamedQuery(name="PreBidTaskResponse.getByPreBidTaskResponseId", query="SELECT pbr from PreBidTaskResponse pbr where pbr.preBidTaskResponseId=?1")
})
public class PreBidTaskResponse implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pre_bid_task_response_id")
	private Integer preBidTaskResponseId;

	@Column(name="pre_bid_resp_matrix_id")
	private Integer preBidRespMatrixId;

	@Column(name="opportunity_id")
	private Integer opportunityId;

	@Column(name="query_response")
	private String queryResponse;
	
	@Column(name="created_date")
	private String createdDate;
	
	@Transient
	private DeptMst deptMst;
	
	@Transient
	private UserDTO respPerson;

	public Integer getPreBidTaskResponseId() {
		return preBidTaskResponseId;
	}

	public void setPreBidTaskResponseId(Integer preBidTaskResponseId) {
		this.preBidTaskResponseId = preBidTaskResponseId;
	}

	public Integer getPreBidRespMatrixId() {
		return preBidRespMatrixId;
	}

	public void setPreBidRespMatrixId(Integer preBidRespMatrixId) {
		this.preBidRespMatrixId = preBidRespMatrixId;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getQueryResponse() {
		return queryResponse;
	}

	public void setQueryResponse(String queryResponse) {
		this.queryResponse = queryResponse;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public DeptMst getDeptMst() {
		return deptMst;
	}

	public void setDeptMst(DeptMst deptMst) {
		this.deptMst = deptMst;
	}

	public UserDTO getRespPerson() {
		return respPerson;
	}

	public void setRespPerson(UserDTO respPerson) {
		this.respPerson = respPerson;
	}

}
