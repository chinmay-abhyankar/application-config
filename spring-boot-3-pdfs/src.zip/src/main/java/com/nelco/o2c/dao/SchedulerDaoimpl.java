/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nelco.o2c.dto.OldSoDTO;
import com.nelco.o2c.dto.OppDetailsDTO;
import com.nelco.o2c.model.ChildContract;
import com.nelco.o2c.model.ContractCsvTemp;
import com.nelco.o2c.model.NewOppDetails;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.Opportunity;
import com.nelco.o2c.model.PoStatusTracker;
import com.nelco.o2c.model.Proposal;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class SchedulerDaoimpl implements SchedulerDao {

	@PersistenceContext
	private EntityManager em;

	Query query;
	StoredProcedureQuery spQuery;

	@SuppressWarnings("unchecked")
	@Override
	public Opportunity getExistingOpportunity(String zohoId) {
		query = em.createQuery("select opp from Opportunity opp where opp.zohoId=?1");
		query.setParameter(1, zohoId);
		List<Opportunity> oppObjs = (List<Opportunity>) query.getResultList();
		return oppObjs != null && oppObjs.size() > 0 ? oppObjs.get(0) : null;
	}

	@Override
	public Opportunity insertOpportunity(Opportunity insertObj) {
		// TODO Auto-generated method stub
		return em.merge(insertObj);
	}

	@SuppressWarnings("unchecked")
	@Override
	public OppDetails getExistingOppDet(String val, Opportunity oppObj) {
		// TODO Auto-generated method stub
		query = em.createQuery("select oppDet from OppDetails oppDet where oppDet.opportunityId=?1 and oppDet.val=?2");
		query.setParameter(1, oppObj.getOpportunityId());
		query.setParameter(2, val);
		List<OppDetails> oppDetObjs = (List<OppDetails>) query.getResultList();
		return oppDetObjs != null && oppDetObjs.size() > 0 ? oppDetObjs.get(0) : null;
	}
	
	@Override
	public void insertUpdateOppDet(OppDetails oppDetails) {
		// TODO Auto-generated method stub
		em.merge(oppDetails);
	}

	@Override
	public Proposal getExistingProposalByOpportunity(Integer opportunityId) {
		try {
			query = em.createNamedQuery("Proposal.getExistingProposalByOpportunity");
			query.setParameter(1, opportunityId);
			List<Proposal> proposals = (List<Proposal>) query.getResultList();
			return proposals != null && proposals.size() > 0 ? proposals.get(0) : null;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public void saveProposal(Proposal existingProposal) {
		try {
			// TODO Auto-generated method stub
			existingProposal.setStatusMstId(Constants.PONOTSUBMITTEDSTATUS);
			Proposal prop = em.merge(existingProposal);
			PoStatusTracker poStatusTracker = new PoStatusTracker();

			// added this user id for scheduler
			poStatusTracker.setCreatedById(Constants.SCHEDULERUSERID);

			poStatusTracker.setProposalId(prop.getProposalId());

			// added this status id for not submitted
			poStatusTracker.setStatusMstId(Constants.PONOTSUBMITTEDSTATUS);

			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			poStatusTracker.setReqDate(currTime);

			em.merge(poStatusTracker);
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public Integer getMaxProposalnumber() {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("Proposal.getMaxProposalnumber");
			Integer maxNum = (Integer) query.getSingleResult();
			return maxNum != null ? maxNum : 1;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	public UserMst getHeadByDeptId(Integer deptId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("UserMst.getHeadByDeptId");
			query.setParameter(1, deptId);
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<UserMst> userMstList = (List<UserMst>) query.getResultList();
			return userMstList != null && userMstList.size() > 0 ? userMstList.get(0) : null;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			em.close();
		}

	}

	public UserMst getHeadBySubDeptId(Integer subDeptId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("UserMst.getHeadBySubDeptId");
			query.setParameter(1, subDeptId);
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<UserMst> userMstList = (List<UserMst>) query.getResultList();
			return userMstList != null && userMstList.size() > 0 ? userMstList.get(0) : null;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ContractCsvTemp> getContractCsvBeans(Integer childContractId) {
		// TODO Auto-generated method stub
		try {
			if (childContractId != null) {
				query = em.createNamedQuery("ContractCsvTemp.findByChildContract");
				query.setParameter(1, childContractId.toString());
			} else {
				query = em.createNamedQuery("ContractCsvTemp.findAll");
			}
			List<ContractCsvTemp> results = (List<ContractCsvTemp>) query.getResultList();
			List<ContractCsvTemp> returnResults = new ArrayList<ContractCsvTemp>();
			if (results.size() > 0) {
				ContractCsvTemp contractCsvTemp = new ContractCsvTemp("Sales Document Type", "Sales Organization",
						"Distribution Channel", "Sales Office", "Customer purchase order number",
						"Customer purchase order date", "Sold-to party", "Nelco Account Manager", "Contract start date",
						"Contract end date", "Item No", "Material Number", "Order Quantity", "Plant", "Condition Type",
						"Rate", "Warranty Period", "order no", "Portal Master Contract No", "Portal Child Contract No",
						"Proposal Id", "Division", "Segment", "Quarter", "Incoterms", "terms of payment",
						"Pricing group", "Description", "Cust purch order no", "Subsegment", "Notice period");
				returnResults.add(contractCsvTemp);
				returnResults.addAll(results);
			}
			return returnResults != null && returnResults.size() > 0 ? returnResults : null;
		} finally {
			em.close();
		}
	}

	@Transactional
	@Override
	public void deleteTempContractTable(Integer childContractId) {
		// TODO Auto-generated method stub
		try {
			if (childContractId != null) {
				query = em.createNamedQuery("ContractCsvTemp.deleteByChildContract");
				query.setParameter(1, childContractId.toString());
			} else {
				query = em.createNamedQuery("ContractCsvTemp.deleteAll");
			}
			query.executeUpdate();
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ChildContract> getChilContracts() {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("ChildContract.findAll");
		return (List<ChildContract>) query.getResultList();
	}

	@Transactional
	@Override
	public void saveFileName(Integer childContractId, String fileNameFinal) {
		// TODO Auto-generated method stub
		query = em.createNativeQuery(
				"update child_contract set child_contract_filename = ?1 where child_contract_id = ?2");
		query.setParameter(1, fileNameFinal);
		query.setParameter(2, childContractId);
		query.executeUpdate();
	}

	@Transactional
	@Override
	public void updateSentFileFlag(List<OldSoDTO> oldSoList) {
		// TODO Auto-generated method stub
		for (OldSoDTO oldSoDTO : oldSoList) {
			query = em.createNativeQuery("update brf_so_details set is_file_sent = 'Y' where old_so_num = ?1 ");
			query.setParameter(1, oldSoDTO.getOldSoNum());
			query.executeUpdate();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public OppDetails getOppDetByOppIdAndVal(Integer opportunityId,String val) {
		// TODO Auto-generated method stub
		query = em.createQuery("select oppDet from OppDetails oppDet where oppDet.opportunityId=?1 and oppDet.val=?2");
		query.setParameter(1, opportunityId);
		query.setParameter(2, val);
		List<OppDetails> oppDetObjs = (List<OppDetails>) query.getResultList();
		return oppDetObjs != null && oppDetObjs.size() > 0 ? oppDetObjs.get(0) : null;
	} 
	
	@SuppressWarnings("unchecked")
	@Override
	public List<OppDetails> getNewOppDetailsListByIds(String newOppDetailsIds) {
		spQuery = em.createStoredProcedureQuery("isp_getNewOppDetailsByNewOppDetailsIds")
				.registerStoredProcedureParameter("newOppDetailsIds", String.class, ParameterMode.IN);
		spQuery.setParameter("newOppDetailsIds", newOppDetailsIds);
		List<Object[]> resultList=spQuery.getResultList();
		List<OppDetails> oppDetailsList = new ArrayList<OppDetails>();
		
		OppDetailsDTO oppDetailsDTO = null;
		OppDetails oppDetails = null;
		OppDetails oppDetailsNew = new OppDetails();
		for (Object[] objects : resultList) {
			oppDetailsDTO = new OppDetailsDTO();
			oppDetails = new OppDetails();
			oppDetailsDTO.setOppDetailsId((Integer) objects[0]);
			oppDetailsDTO.setZohoId((String) objects[1]);
			oppDetailsDTO.setOpportunityId((Integer) objects[2]);
			oppDetailsDTO.setVal((String) objects[3]);
			oppDetailsDTO.setContent((String) objects[4]);
			oppDetails = this.getOppDetByOppIdAndVal(oppDetailsDTO.getOpportunityId(), oppDetailsDTO.getVal());
			if(oppDetails == null) {
				oppDetails = new OppDetails();
			}
			oppDetails.setOpportunityId(oppDetailsDTO.getOpportunityId());
			oppDetails.setVal(oppDetailsDTO.getVal());
			oppDetails.setContent(oppDetailsDTO.getContent());
			oppDetailsNew = em.merge(oppDetails);
			oppDetailsList.add(oppDetailsNew);
		}
		
		return oppDetailsList;
	}

	@Override
	public NewOppDetails saveNewOppDetails(NewOppDetails newOppDetails) {
		// TODO Auto-generated method stub
		try {
			NewOppDetails newOppDetailsObj = em.merge(newOppDetails);
	/*		if (newOppDetails.getNewOppDetailsId() == null) {
				em.refresh(newOppDetailsObj);
			}*/
			return newOppDetailsObj;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public NewOppDetails getNewOppDetailsByZohoId(String zohoId) {
		query = em.createQuery("select nod from NewOppDetails nod where nod.zohoId=?1 ");
		query.setParameter(1, zohoId);
		List<NewOppDetails> newOppDetails = (List<NewOppDetails>) query.getResultList();
		return newOppDetails != null && newOppDetails.size() > 0 ? newOppDetails.get(0) : null;
	}
	
//	comment start for new classes
/*	
	@SuppressWarnings("unchecked")
	@Override
	public NewOpportunity getExistingNewOpportunity(String zohoId) {
		query = em.createQuery("select opp from NewOpportunity opp where opp.zohoId=?1 ");
		query.setParameter(1, zohoId);
		List<NewOpportunity> oppObjs = (List<NewOpportunity>) query.getResultList();
		return oppObjs != null && oppObjs.size() > 0 ? oppObjs.get(0) : null;
	}

	@Override
	public NewProposal getExistingNewProposalByOpportunity(Integer opportunityId) {
		try {
			query = em.createNamedQuery("NewProposal.getExistingNewProposalByOpportunity");
			query.setParameter(1, opportunityId);
			List<NewProposal> proposals = (List<NewProposal>) query.getResultList();
			return proposals != null && proposals.size() > 0 ? proposals.get(0) : null;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}
	
	@Override
	public void saveNewProposal(NewProposal existingProposal) {
		try {
			// TODO Auto-generated method stub
			existingProposal.setStatusMstId(Constants.PONOTSUBMITTEDSTATUS);
			NewProposal prop = em.merge(existingProposal);
			NewPoStatusTracker poStatusTracker = new NewPoStatusTracker();

			// added this user id for scheduler
			poStatusTracker.setCreatedById(Constants.SCHEDULERUSERID);

			poStatusTracker.setProposalId(prop.getProposalId());

			// added this status id for not submitted
			poStatusTracker.setStatusMstId(Constants.PONOTSUBMITTEDSTATUS);

			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			poStatusTracker.setReqDate(currTime);

			em.merge(poStatusTracker);
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}
	
	@Override
	public NewOpportunity insertNewOpportunity(NewOpportunity insertObj) {
		// TODO Auto-generated method stub
		return em.merge(insertObj);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public CopyOppDetail getCopyOppDetByOppIdAndVal(Integer opportunityId,String val) {
		// TODO Auto-generated method stub
		query = em.createQuery("select oppDet from CopyOppDetail oppDet where oppDet.opportunityId=?1 and oppDet.val=?2");
		query.setParameter(1, opportunityId);
		query.setParameter(2, val);
		List<CopyOppDetail> oppDetObjs = (List<CopyOppDetail>) query.getResultList();
		return oppDetObjs != null && oppDetObjs.size() > 0 ? oppDetObjs.get(0) : null;
	} 
	
	@Override
	public Integer getMaxNewProposalnumber() {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("NewProposal.getMaxNewProposalnumber");
			Integer maxNum = (Integer) query.getSingleResult();
			return maxNum != null ? maxNum : 1;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}
	
	*/
//		comment start for new classes

}
