package com.nelco.o2c.dto;

public class TafStatusTrackerDTO {
	private Integer tafId;
	private String bidManagerComments;
	private String isRejected;
	private String statusCode;
	private String statusName;
	public Integer getTafId() {
		return tafId;
	}
	public void setTafId(Integer tafId) {
		this.tafId = tafId;
	}
	public String getBidManagerComments() {
		return bidManagerComments;
	}
	public void setBidManagerComments(String bidManagerComments) {
		this.bidManagerComments = bidManagerComments;
	}
	public String getIsRejected() {
		return isRejected;
	}
	public void setIsRejected(String isRejected) {
		this.isRejected = isRejected;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	@Override
	public String toString() {
		return "TafStatusTrackerDTO [tafId=" + tafId + ", bidManagerComments=" + bidManagerComments + ", isRejected="
				+ isRejected + ", statusCode=" + statusCode + ", statusName=" + statusName + "]";
	}
	
	
}
