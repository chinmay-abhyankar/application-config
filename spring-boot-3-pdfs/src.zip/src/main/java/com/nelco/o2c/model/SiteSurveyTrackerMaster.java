package com.nelco.o2c.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="site_survey_tracker_mst")
public class SiteSurveyTrackerMaster {
	private static final long serialVersionUID = 76L;
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name="site_survey_id")
	private Integer site_survey_id;
	
	@Column(name="status")
	private Integer status;
	
	@Column(name="user_id")
	private Integer user_id;
	
	@Column(name="comm_date")
	private String comm_date;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getSite_survey_id() {
		return site_survey_id;
	}

	public void setSite_survey_id(Integer site_survey_id) {
		this.site_survey_id = site_survey_id;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public String getComm_date() {
		return comm_date;
	}

	public void setComm_date(String comm_date) {
		this.comm_date = comm_date;
	}

	
	
	
}
