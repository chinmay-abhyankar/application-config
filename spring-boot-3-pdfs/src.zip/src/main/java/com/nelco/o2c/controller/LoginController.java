/**
 * 
 */
package com.nelco.o2c.controller;

import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.nelco.o2c.dto.LoginDTO;
import com.nelco.o2c.dto.ManagePwdDTO;
import com.nelco.o2c.service.LoginService;

/**
 * @author Jayashankar.r
 *
 */
@RestController
public class LoginController {

	@Autowired
	HttpSession session;

	@Autowired
	LoginService loginService;
	
	@Autowired
	private Environment env;

	@RequestMapping("/")
	public ModelAndView welcome() {
		System.out.println("HELLO Login");
		return new ModelAndView("index");
	}

	@RequestMapping(value = "/authenticateUser.do", method = RequestMethod.POST)
	public LoginDTO authenticateUser(@RequestBody LoginDTO loginDTO) {
		return loginService.authenticateUser(loginDTO);
	}

	@RequestMapping(value = "/managePwd.do", method = RequestMethod.POST)
	public ManagePwdDTO managePwd(@RequestBody ManagePwdDTO managePwdDTO) {
		return loginService.managePwd(managePwdDTO);
	}

	@CrossOrigin
	@RequestMapping(value = "/sessionExpired.do", method = RequestMethod.GET)
	public ModelAndView sessionExpired() {
		//// SDCommonUtil.deleteAllTempFiles();
		session.setAttribute("workArea", null);
		session.invalidate();
		String resulSet = "sessionExpired";
		ModelAndView mv = new ModelAndView(resulSet);
		mv.addObject("link", env.getProperty("emaillink"));
		return mv;
	}

	@CrossOrigin
	@RequestMapping(value = "/sessionExpiredUser.do", method = RequestMethod.GET)
	public ModelAndView sessionExpiredUser() {
		session.setAttribute("workArea", null);
		session.invalidate();
		String resulSet = "sessionExpiredUser";
		ModelAndView mv = new ModelAndView(resulSet);
		mv.addObject("link", env.getProperty("emaillink"));
		return mv;
	}

	@CrossOrigin
	@RequestMapping(value = "/logout.do", method = RequestMethod.GET)
	@ResponseBody
	public String logout(/* ModelMap model, HttpServletRequest request, LoginDTO workArea */)
			throws JSONException {/*
									 * if (session != null) { LoginDTO bean = (LoginDTO)
									 * session.getAttribute("workArea"); if (bean != null) {
									 * bean.getUserMst().setLoginId(""); } session.invalidate(); }
									 */
		
		LoginDTO loginDTO = (LoginDTO) session.getAttribute("workArea");
		if(loginDTO!=null) {
			loginService.logoutActionUpdate(loginDTO);
		}
		
		
		session.setAttribute("workArea", null);
		session.invalidate();
		JSONObject obj = new JSONObject();
		obj.put("status", "success");
		return obj.toString();
		// return "login";
	}
}
