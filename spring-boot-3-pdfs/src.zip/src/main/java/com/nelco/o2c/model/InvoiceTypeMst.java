package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the invoice_type_mst database table.
 * 
 */
@Entity
@Table(name="invoice_type_mst")
@NamedQuery(name="InvoiceTypeMst.findAll", query="SELECT i.text+' - '+i.type,i.type FROM InvoiceTypeMst i")
public class InvoiceTypeMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private int typeid;

	@Column(length=2)
	private String actflag;

	@Column(length=80)
	private String text;

	@Column(length=50)
	private String type;

	public InvoiceTypeMst() {
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public String getText() {
		return this.text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

}