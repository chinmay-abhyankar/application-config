package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the service_order_mst database table.
 * 
 */
@Entity
@Table(name = "service_order_mst")
@NamedQuery(name = "ServiceOrderMst.findAll", query = "SELECT s FROM ServiceOrderMst s where s.isActive='Y'")
public class ServiceOrderMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "service_order_det_id")
	private Integer serviceOrderDetId;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "is_active")
	private String isActive;

	@Column(name = "service_order_desc")
	private String serviceOrderDesc;

	@Column(name = "service_order_num")
	private String serviceOrderNum;

	@Column(name = "service_type_code")
	private String serviceTypeCode;
	
	@Transient
	private List<UserMst> financeList;
	
	public List<UserMst> getFinanceList() {
		return financeList;
	}

	public void setFinanceList(List<UserMst> financeList) {
		this.financeList = financeList;
	}

	public Integer getServiceOrderDetId() {
		return serviceOrderDetId;
	}

	public void setServiceOrderDetId(Integer serviceOrderDetId) {
		this.serviceOrderDetId = serviceOrderDetId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getServiceOrderDesc() {
		return serviceOrderDesc;
	}

	public void setServiceOrderDesc(String serviceOrderDesc) {
		this.serviceOrderDesc = serviceOrderDesc;
	}

	public String getServiceOrderNum() {
		return serviceOrderNum;
	}

	public void setServiceOrderNum(String serviceOrderNum) {
		this.serviceOrderNum = serviceOrderNum;
	}

	public String getServiceTypeCode() {
		return serviceTypeCode;
	}

	public void setServiceTypeCode(String serviceTypeCode) {
		this.serviceTypeCode = serviceTypeCode;
	}

}