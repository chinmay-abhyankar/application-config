package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the po_query_details database table.
 * 
 */
@Entity
@Table(name = "po_query_details")
@NamedQueries({@NamedQuery(name = "PoQueryDetail.findAll", query = "SELECT pq FROM PoQueryDetail pq"),
	@NamedQuery(name = "PoQueryDetail.findByPoId", query = "SELECT pq FROM PoQueryDetail pq where pq.proposalId=?1")})
public class PoQueryDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "po_query_details_id")
	private Integer poQueryDetailsId;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "proposal_id")
	private Integer proposalId;

	@Column(name = "query_str")
	private String queryStr;

	@Column(name = "user_mst_id")
	private Integer userMstId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_mst_id", referencedColumnName = "user_mst_id", insertable = false, updatable = false)
	private UserMst userMst;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "po_query_details_id", referencedColumnName = "po_query_details_id", insertable = false, updatable = false)
	private List<PoResponseDetail> responses;

	public UserMst getUserMst() {
		return userMst;
	}

	public void setUserMst(UserMst userMst) {
		this.userMst = userMst;
	}

	public List<PoResponseDetail> getResponses() {
		return responses;
	}

	public void setResponses(List<PoResponseDetail> responses) {
		this.responses = responses;
	}

	public Integer getPoQueryDetailsId() {
		return poQueryDetailsId;
	}

	public void setPoQueryDetailsId(Integer poQueryDetailsId) {
		this.poQueryDetailsId = poQueryDetailsId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getProposalId() {
		return proposalId;
	}

	public void setProposalId(Integer proposalId) {
		this.proposalId = proposalId;
	}

	public String getQueryStr() {
		return queryStr;
	}

	public void setQueryStr(String queryStr) {
		this.queryStr = queryStr;
	}

	public Integer getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

}