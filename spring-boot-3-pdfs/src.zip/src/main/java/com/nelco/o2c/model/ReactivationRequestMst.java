package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the reactivation_request_mst database table.
 * 
 */
@Entity
@Table(name="reactivation_request_mst")
@NamedQueries({
@NamedQuery(name="ReactivationRequestMst.findAll", query="SELECT r FROM ReactivationRequestMst r"),
@NamedQuery(name="ReactivationRequestMst.updateBusineddHeadAppStatus", query="UPDATE ReactivationRequestMst r SET r.businessheadAppStatus=:requestStatus WHERE r.requestId=:requestId"),
@NamedQuery(name="ReactivationRequestMst.reactivateSite", query="UPDATE ReactivationRequestMst r SET r.reactivationStatus='1' WHERE r.requestId=:requestId"),
@NamedQuery(name="ReactivationRequestMst.reactivateSiteOnCR", query="UPDATE ReactivationRequestMst r SET r.reactivationStatus='1' WHERE r.disconnectionRequestId=:requestId"),
@NamedQuery(name="ReactivationRequestMst.getInvoiceNoFromRequestId", query="SELECT r.invoiceNo FROM ReactivationRequestMst r WHERE r.disconnectionRequestId=:requestId")
})

@NamedNativeQueries({
	@NamedNativeQuery(name = "ReactivationRequestMst.getRequestId", query = "SELECT 'REC'+FORMAT(GETDATE(),'dd')+'_'+FORMAT(GETDATE(),'MM')+'_'+FORMAT(GETDATE(),'yyyy')+'_'+CAST(COALESCE(MAX(typeid),0)+1 AS VARCHAR)FROM reactivation_request_mst"),
	
	})
public class ReactivationRequestMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private int typeid;

	@Column(length=2)
	private String actflag;

	@Column(name="businesshead_app_status", length=2)
	private String businessheadAppStatus;

	@Column(name="disconnection_request_id", length=20)
	private String disconnectionRequestId;

	@Column(name="invoice_no", length=20)
	private String invoiceNo;

	@Column(name="reactivation_status", length=2)
	private String reactivationStatus;

	@Column(name="request_date")
	private String requestDate;
	
	@Column(name="common_id", length=20)
	private String commonId;

	@Column(name="request_id", length=20)
	private String requestId;

	@Column(name="request_status", length=2)
	private String requestStatus;

	@Column(name="user_id", length=50)
	private String userId;
	
	@Column(name="reactivation_type", length=2)
	private String reactivationType;
	
	
	@Transient
	private String appRemark;

	public String getCommonId() {
		return commonId;
	}

	public void setCommonId(String commonId) {
		this.commonId = commonId;
	}

	public String getReactivationType() {
		return reactivationType;
	}

	public void setReactivationType(String reactivationType) {
		this.reactivationType = reactivationType;
	}

	public String getAppRemark() {
		return appRemark;
	}

	public void setAppRemark(String appRemark) {
		this.appRemark = appRemark;
	}

	public ReactivationRequestMst() {
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public String getBusinessheadAppStatus() {
		return this.businessheadAppStatus;
	}

	public void setBusinessheadAppStatus(String businessheadAppStatus) {
		this.businessheadAppStatus = businessheadAppStatus;
	}

	public String getDisconnectionRequestId() {
		return this.disconnectionRequestId;
	}

	public void setDisconnectionRequestId(String disconnectionRequestId) {
		this.disconnectionRequestId = disconnectionRequestId;
	}

	public String getInvoiceNo() {
		return this.invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getReactivationStatus() {
		return this.reactivationStatus;
	}

	public void setReactivationStatus(String reactivationStatus) {
		this.reactivationStatus = reactivationStatus;
	}

	public String getRequestDate() {
		return this.requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getRequestId() {
		return this.requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getRequestStatus() {
		return this.requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}