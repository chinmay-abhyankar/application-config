/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.nelco.o2c.dto.SparesDTO;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.SparesSo;
import com.nelco.o2c.model.SparesSoDetail;
import com.nelco.o2c.model.SparesSoUserMap;

/**
 * @author Jayshankar.r
 *
 */
public interface SparesSoDao {

	List<SparesSo> getSparesSoList(SparesDTO sparesInputDTO);

	SparesSo getSparesSoById(Integer sparesSoId);

	List<OppUploadDetail> getOppUploadBySparesSoId(Integer sparesSoId);

	SparesSo saveSparesSo(SparesSo sparesSo);

	SparesSoDetail saveSparesSoDetail(SparesSoDetail sparesSoDetail);

	SparesSoUserMap saveSparesSoUserMap(SparesSoUserMap sparesSoUserMap);

	boolean checkAlreadyUserEnteredSparesSoMap(Integer sparesSoId, Integer userMstId);
	
	public List<FileTypeMst> getFileListByCode(List<String> fileIdList);

	void deleteSparesSoMaterialById(Integer sparesSoDetailsId);

	List<PlantSapmst> getPlantList();

	public SparesSo getSparesSoByIncidentId(String incidentId);

	public List<SparesSo> uploadSparesSoReq(MultipartFile file, String userMstId, String roleCode) throws Exception;

}
