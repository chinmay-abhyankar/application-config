/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

/**
 * @author Jayshankar.r
 *
 */
public class DrfExtBean {
	private Integer drfDetailsId;
	private String custName;
	private String marketSegment;
	private String demoStart;
	private String demoEnd;
	private String createdDate;
	private String reqDate;
	private String statusName;
	private String statusCode;
	private Integer statusMstId;
	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}
	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getMarketSegment() {
		return marketSegment;
	}
	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}
	public String getDemoStart() {
		return demoStart;
	}
	public void setDemoStart(String demoStart) {
		this.demoStart = demoStart;
	}
	public String getDemoEnd() {
		return demoEnd;
	}
	public void setDemoEnd(String demoEnd) {
		this.demoEnd = demoEnd;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getReqDate() {
		return reqDate;
	}
	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public Integer getStatusMstId() {
		return statusMstId;
	}
	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}
	
	
}
