/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.DrfExtComment;

/**
 * @author Jayshankar.r
 *
 */
public class ExtendDemoDTO implements Serializable {
	private static final long serialVersionUID = 50L;
	private Integer userMstId;
	private String roleCode;
	private Integer drfDetailsId;
	private String demoStart;
	private String demoEnd;
	private Boolean isSaved;
	private String comment;
	private String userName;
	private List<DrfExtComment> commentList;
	
	
	public List<DrfExtComment> getCommentList() {
		return commentList;
	}
	public void setCommentList(List<DrfExtComment> commentList) {
		this.commentList = commentList;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public Boolean getIsSaved() {
		return isSaved;
	}
	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}
	public String getDemoStart() {
		return demoStart;
	}
	public void setDemoStart(String demoStart) {
		this.demoStart = demoStart;
	}
	public String getDemoEnd() {
		return demoEnd;
	}
	public void setDemoEnd(String demoEnd) {
		this.demoEnd = demoEnd;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}
	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}
	
	
	
	
}
