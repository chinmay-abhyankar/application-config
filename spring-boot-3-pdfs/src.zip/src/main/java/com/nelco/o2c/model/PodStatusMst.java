package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the pod_status_mst database table.
 * 
 */
@Entity
@Table(name="pod_status_mst")
@NamedQuery(name="PodStatusMst.findAll", query="SELECT p FROM PodStatusMst p")
public class PodStatusMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pod_status_mst_id")
	private Integer podStatusMstId;

	@Column(name="pod_status_code")
	private String podStatusCode;

	@Column(name="pod_status_name")
	private String podStatusName;

	public PodStatusMst() {
	}

	public Integer getPodStatusMstId() {
		return podStatusMstId;
	}

	public void setPodStatusMstId(Integer podStatusMstId) {
		this.podStatusMstId = podStatusMstId;
	}

	public String getPodStatusCode() {
		return podStatusCode;
	}

	public void setPodStatusCode(String podStatusCode) {
		this.podStatusCode = podStatusCode;
	}

	public String getPodStatusName() {
		return podStatusName;
	}

	public void setPodStatusName(String podStatusName) {
		this.podStatusName = podStatusName;
	}

}