package com.nelco.o2c.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nelco.o2c.dto.ReportsDTO;
import com.nelco.o2c.service.ReportMstService;
import com.nelco.o2c.utility.GenJasperReportUtility;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;

@Controller
public class OrderManagementReportsController {
	@Autowired
	DataSource ds;
	
	@Autowired
	ReportMstService reportsMstService;
	
	public ReportsDTO utility(@RequestParam("inputJson") String ipJson) throws SQLException, JsonParseException, JsonMappingException, IOException {
		
		 ObjectMapper mapper = new ObjectMapper();
		 ReportsDTO reportsDTO = mapper.readValue(ipJson, ReportsDTO.class);
	     return reportsDTO;
	}
	
	
	public Map<String, String> dateFormatting(String fromDate,String toDate){
		Map<String,String> dates = new HashMap<String,String>();
		try {
				//System.out.println("in date fromattinf"+fromDate+"| "+ toDate);
				DateTimeFormatter oldPattern = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				DateTimeFormatter newPattern = DateTimeFormatter.ofPattern("yyyy-MM-dd");

				LocalDate dateFromDate = LocalDate.parse(fromDate, oldPattern);
				LocalDate dateToDate = LocalDate.parse(toDate, oldPattern);
				
				dates.put("fromDate", dateFromDate.format(newPattern));
				dates.put("toDate", dateToDate.format(newPattern));
				dates.put("revfromDate", dateFromDate.format(oldPattern));
				dates.put("revtoDate", dateToDate.format(oldPattern));
				//System.out.println("map"+dates);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return dates;
	}
	
	/**Method to generate ORDER PENDENCY REPORT
	 */
	@RequestMapping(value="/orderPendency.do",method=RequestMethod.GET)
	public String orderPendencyReport(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) throws JsonParseException, JsonMappingException, SQLException, IOException, JRException, NamingException {
		String reportFileName = "Order_Pendency_Report";
		ReportsDTO reportsDTO = utility(ipJson);
		
		Connection conn = ds.getConnection();
		Map<String, Object> parameter = new HashMap<String,Object>();
		parameter.put("cont_num", reportsDTO.getField());
		parameter.put("fileName", reportFileName);
		JasperReport jasperReport = GenJasperReportUtility.getCompiledFile(reportFileName, request);
		
		if("pdf".equalsIgnoreCase(reportsDTO.getType())) {
			GenJasperReportUtility.generateReportPDF(response, parameter, jasperReport, conn); 
		}else {
			GenJasperReportUtility.generateReportXLS(response, parameter, jasperReport, conn);
		}
		conn.close();		
		return null;	
	}
	
	///AM WISE OB BOOKING
	@RequestMapping(value="/amWiseOBBooking.do",method=RequestMethod.GET)
	public String amWiseOBBooking(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) throws JsonParseException, JsonMappingException, SQLException, IOException, JRException, NamingException {
		String reportFileName = "AM_Wise_OB_Report";
		ReportsDTO reportsDTO = utility(ipJson);
		
		Connection conn = ds.getConnection();
		
		Map<String,String> dates=dateFormatting(reportsDTO.getFromDate(),reportsDTO.getToDate());
		Map<String, Object> parameter = new HashMap<String,Object>();
		
		parameter.put("fromDate",dates.get("fromDate") );
		parameter.put("toDate",dates.get("toDate") );
		parameter.put("fileName", reportFileName);
		
		JasperReport jasperReport = GenJasperReportUtility.getCompiledFile(reportFileName, request);
		
		if("pdf".equalsIgnoreCase(reportsDTO.getType())) {
			GenJasperReportUtility.generateReportPDF(response, parameter, jasperReport, conn); 
		}else {
			GenJasperReportUtility.generateReportXLS(response, parameter, jasperReport, conn);
		}
		conn.close();		
		return null;	
	}
	
	
	//Segment_Wise_OB_Booking_Report
	@RequestMapping(value="/segmentWiseOBBooking.do",method=RequestMethod.GET)
	public String segmentWiseOBBooking(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) throws JsonParseException, JsonMappingException, SQLException, IOException, JRException, NamingException {
		String reportFileName = "Segment_Wise_OB_Booking_Report";
		ReportsDTO reportsDTO = utility(ipJson);
		
		Connection conn = ds.getConnection();
		
		Map<String,String> dates=dateFormatting(reportsDTO.getFromDate(),reportsDTO.getToDate());
		Map<String, Object> parameter = new HashMap<String,Object>();
		
		parameter.put("fromDate",dates.get("fromDate") );
		parameter.put("toDate",dates.get("toDate") );
		parameter.put("fileName", reportFileName);
		JasperReport jasperReport = GenJasperReportUtility.getCompiledFile(reportFileName, request);
		
		if("pdf".equalsIgnoreCase(reportsDTO.getType())) {
			GenJasperReportUtility.generateReportPDF(response, parameter, jasperReport, conn); 
		}else {
			GenJasperReportUtility.generateReportXLS(response, parameter, jasperReport, conn);
		}
		conn.close();		
		return null;	
	}
	
	
	//pm get excel report
	@RequestMapping(value="/pmgtExcelReport.do", method = RequestMethod.GET)
	public String pmgtExcelReport(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) //@RequestParam String cust_id
	throws SQLException, NamingException,JRException,IOException{
		
		Connection conn = ds.getConnection();
		String reportFileName = "pmgt-data";
	
		ReportsDTO reportsDTO = utility(ipJson);
		
		Map<String,String> dates=dateFormatting(reportsDTO.getFromDate(),reportsDTO.getToDate());
		
		
		Map<String, Object> parameter = new HashMap<String,Object>();
		
		parameter.put("fromDate",dates.get("fromDate") );
		parameter.put("toDate",dates.get("toDate") );
		parameter.put("fileName", reportFileName);
		
		JasperReport jasperReport = GenJasperReportUtility.getCompiledFile(reportFileName, request);
		if("pdf".equalsIgnoreCase(reportsDTO.getType())) {
			GenJasperReportUtility.generateReportPDF(response, parameter, jasperReport, conn); 
		}else {
			GenJasperReportUtility.generateReportXLS(response, parameter, jasperReport, conn);
		}
		conn.close();		
		return null;		
		}
	
	//OB PLAN
	@RequestMapping(value="/obplan.do", method = RequestMethod.GET)
	public String obplan(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) //@RequestParam String cust_id
	throws SQLException, NamingException,JRException,IOException{
		
		Connection conn = ds.getConnection();
		String reportFileName = "OB_Plan";
	
		ReportsDTO reportsDTO = utility(ipJson);
		
		Map<String,String> dates=dateFormatting(reportsDTO.getFromDate(),reportsDTO.getToDate());
		
		
		Map<String, Object> parameter = new HashMap<String,Object>();
		//parameter.put("month", reportsDTO.getField());
		parameter.put("fromDate",dates.get("fromDate") );
		parameter.put("toDate",dates.get("toDate") );
		parameter.put("fileName", reportFileName);
		
		JasperReport jasperReport = GenJasperReportUtility.getCompiledFile(reportFileName, request);
		if("pdf".equalsIgnoreCase(reportsDTO.getType())) {
			GenJasperReportUtility.generateReportPDF(response, parameter, jasperReport, conn); 
		}else {
			GenJasperReportUtility.generateReportXLS(response, parameter, jasperReport, conn);
		}
		conn.close();		
		return null;		
		}
	
		
	///customer wise ob am report
	@RequestMapping(value = "/custwiseObAmPmReport.do", method = RequestMethod.GET)
	public String custwiseObAmPmReport(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) //@RequestParam String cc_id
	    throws ParseException, SQLException, JRException, NamingException, IOException {
	
	Connection conn = ds.getConnection();

	String reportFileName = "Customer_wise_OB_for_AM-PM";
	
	ReportsDTO reportsDTO = utility(ipJson);
	
	try {
		Map<String,String> dates=dateFormatting(reportsDTO.getFromDate(),reportsDTO.getToDate());
	
		Map<String, Object> parameter = new HashMap<String,Object>();
		parameter.put("fromDate",dates.get("fromDate") );
		parameter.put("toDate",dates.get("toDate") );
		parameter.put("fileName", reportFileName);
		
		JasperReport jasperReport = GenJasperReportUtility.getCompiledFile(reportFileName, request);
		
		if("pdf".equalsIgnoreCase(reportsDTO.getType())) {
			GenJasperReportUtility.generateReportPDF(response, parameter, jasperReport, conn); 
		}else {
			GenJasperReportUtility.generateReportXLS(response, parameter, jasperReport, conn);
		}
	
	
	}catch (Exception e) {
		e.printStackTrace();
	}
		conn.close();
		return null;
	}
	
	///sap contract no 
	@RequestMapping(value="/sapcontnoreport.do", method = RequestMethod.GET)
	public String sapcontnoreport(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) //@RequestParam String cust_no
	throws SQLException,JRException,NamingException,IOException	{
		Connection conn = ds.getConnection();
		String reportFileName = "SAP_Contract_no_JFM_19";
		
		ReportsDTO reportsDTO = utility(ipJson);
		
		ReportsDTO reportsDTONew = new ReportsDTO();
		reportsDTONew.setField(reportsDTO.getField());
		reportsDTONew.setType(reportsDTO.getType());
		
		Map<String,Object> parameter = new HashMap<String, Object>();
		parameter.put("cust_no", reportsDTONew.getField());
		parameter.put("fileName", reportFileName);
		JasperReport jasperReport = GenJasperReportUtility.getCompiledFile(reportFileName, request);
		if("pdf".equalsIgnoreCase(reportsDTONew.getType())) {
			GenJasperReportUtility.generateReportPDF(response, parameter, jasperReport, conn); 
		}else {
			GenJasperReportUtility.generateReportXLS(response, parameter, jasperReport, conn);
		}
		conn.close();
		return null;		
	}
	
	//Short_Term_Orders_Report
	@RequestMapping(value="/shortTermOrders.do",method = RequestMethod.GET)
	public String shortTermOrders(HttpServletRequest request, HttpServletResponse response, @RequestParam("inputJson") String ipJson) throws SQLException, JRException, IOException, NamingException {
	
		String reportFileName = "Short_Term_Orders_Report";
		//System.out.println(request.getRequestURL()+" | "+request.getParameterNames());
		ReportsDTO reportsDTO = utility(ipJson);
		
		ReportsDTO reportsDTONew = new ReportsDTO();
		reportsDTONew.setField(reportsDTO.getField());
		reportsDTONew.setType(reportsDTO.getType());
		
		Connection conn = ds.getConnection();
		
		Map<String, Object> parameter = new HashMap<String,Object>();
	
		parameter.put("sold_to_party", reportsDTONew.getField());
		parameter.put("fileName", reportFileName);
		JasperReport jasperReport = GenJasperReportUtility.getCompiledFile(reportFileName, request);
		
		
		if("pdf".equalsIgnoreCase(reportsDTONew.getType())) {
			GenJasperReportUtility.generateReportPDF(response, parameter, jasperReport, conn); 
		}else {
			GenJasperReportUtility.generateReportXLS(response, parameter, jasperReport, conn);
		}
		conn.close();		
		return null;		
	}
	
	// fy 19 ob till date
	@RequestMapping(value="/fyObTillDate.do",method = RequestMethod.GET)
	public String fyObTillDate(HttpServletRequest request, HttpServletResponse response, 
			@RequestParam("inputJson") String ipJson) throws SQLException, JRException, IOException, NamingException {
	
		String reportFileName = "FY19_OB_Till_Date_Report_MainReport";
		//System.out.println(request.getRequestURL()+" | "+request.getParameterNames());
		ReportsDTO reportsDTO = utility(ipJson);
		
		Connection conn = ds.getConnection();
		Map<String,String> dates=dateFormatting(reportsDTO.getFromDate(),reportsDTO.getToDate());
		Map<String, Object> parameter = new HashMap<String,Object>();
	
	    parameter.put("fromDate",dates.get("fromDate") );

        parameter.put("toDate",dates.get("toDate") );
        parameter.put("fileName", reportFileName);
		JasperReport jasperReport = GenJasperReportUtility.getCompiledFile(reportFileName, request);
		
		
		if("pdf".equalsIgnoreCase(reportsDTO.getType())) {
			GenJasperReportUtility.generateReportPDF(response, parameter, jasperReport, conn); 
		}else {
			GenJasperReportUtility.generateReportXLS(response, parameter, jasperReport, conn);
		}
		conn.close();		
		return null;		
	}
	
	@RequestMapping(value="/brfReportByDate.do",method = RequestMethod.GET)
	public void brfReportByDate(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("inputJson") String ipJson) throws JsonParseException, JsonMappingException, SQLException, IOException, JRException, NamingException {
			/////////// BRF REPORT BY DATE/////////////////////////////
		ReportsDTO reportsDTO = utility(ipJson);
		reportsMstService.brfReportByDate(request, response, reportsDTO);
	}
	
	
}
