package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the hub_tech_mst database table.
 * 
 */
@Entity
@Table(name="hub_tech_mst")
@NamedQuery(name="HubTechMst.findAll", query="SELECT h FROM HubTechMst h")
public class HubTechMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="hub_tech_mst_id")
	private Integer hubTechMstId;

	@Column(name="hub_tech_code")
	private String hubTechCode;

	@Column(name="hub_tech_val")
	private String hubTechVal;

	public HubTechMst() {
	}

	public Integer getHubTechMstId() {
		return this.hubTechMstId;
	}

	public void setHubTechMstId(Integer hubTechMstId) {
		this.hubTechMstId = hubTechMstId;
	}

	public String getHubTechCode() {
		return this.hubTechCode;
	}

	public void setHubTechCode(String hubTechCode) {
		this.hubTechCode = hubTechCode;
	}

	public String getHubTechVal() {
		return this.hubTechVal;
	}

	public void setHubTechVal(String hubTechVal) {
		this.hubTechVal = hubTechVal;
	}

}