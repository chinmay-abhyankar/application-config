package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the proforma_invoice_sapmst database table.
 * 
 */
@Entity
@Table(name="proforma_invoice_sapmst")
@NamedQuery(name="ProformaInvoiceSapmst.findAll", query="SELECT p FROM ProformaInvoiceSapmst p")
public class ProformaInvoiceSapmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="proforma_invoice_sapmst_id")
	private int proformaInvoiceSapmstId;

	@Column(name="billing_type")
	private String billingType;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="delivery_num")
	private String deliveryNum;

	@Column(name="invoice_num")
	private String invoiceNum;

	public ProformaInvoiceSapmst() {
	}

	public int getProformaInvoiceSapmstId() {
		return this.proformaInvoiceSapmstId;
	}

	public void setProformaInvoiceSapmstId(int proformaInvoiceSapmstId) {
		this.proformaInvoiceSapmstId = proformaInvoiceSapmstId;
	}

	public String getBillingType() {
		return this.billingType;
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDeliveryNum() {
		return this.deliveryNum;
	}

	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}

	public String getInvoiceNum() {
		return this.invoiceNum;
	}

	public void setInvoiceNum(String invoiceNum) {
		this.invoiceNum = invoiceNum;
	}

}