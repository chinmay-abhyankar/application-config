/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.model.DrfQueryUserMap;
import com.nelco.o2c.model.Response;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class QueryDaoImpl implements QueryDao {

	@PersistenceContext
	private EntityManager em;

	Query query;

	@SuppressWarnings("unchecked")
	@Override
	public List<com.nelco.o2c.model.Query> getQueryDetails(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("Queries.findByDrfId", com.nelco.o2c.model.Query.class);
		query.setParameter(1, commonDTO.getDrfDetailsId());
		query.setParameter(2, commonDTO.getUserMstId());
		return query.getResultList();
	}

	@Override
	public com.nelco.o2c.model.Query postQuery(com.nelco.o2c.model.Query querySaveObj) {
		// TODO Auto-generated method stub
		com.nelco.o2c.model.Query queryObj = em.merge(querySaveObj);
		if(querySaveObj.getQueryId()==null) {
			em.refresh(queryObj);
		}
		return queryObj;
	}

	@Override
	public void postResponse(Response responseSaveObj) {
		// TODO Auto-generated method stub
		Response responseObj = em.merge(responseSaveObj);
		if(responseSaveObj.getResponseId()==null)
			em.refresh(responseObj);
	}

	@Override
	public com.nelco.o2c.model.Query getQueryDetailsByQuertId(Integer queryId) {
		// TODO Auto-generated method stub
				try {

					query = em.createNamedQuery("Queries.getByQueryId");
					query.setParameter(1, queryId);
					com.nelco.o2c.model.Query queryObj = (com.nelco.o2c.model.Query) query.getSingleResult();
					return queryObj;
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
					return new com.nelco.o2c.model.Query();
				} finally {
					em.close();
				}
	}

	@Override
	public void updateInsertDrfQueryUserMap(DrfQueryUserMap drfQueryUserMap) {
		// TODO Auto-generated method stub
		if(drfQueryUserMap.getQueryUserId()!=null && drfQueryUserMap.getQueryId()!=null) {
			/*query = em.createQuery("select case when d.drfQueryUserMapId is not null "
					+ " then 'Y' else 'N' end "
					+ " from DrfQueryUserMap d where d.queryId = :queryId "
					+ " and d.queryUserId = :queryUserId and d.isActive = 'Y' ");*/
			
			query = em.createQuery("select count(d) "
					+ " from DrfQueryUserMap d where d.queryId = :queryId "
					+ " and d.queryUserId = :queryUserId and d.isActive = 'Y' ");
			
			query.setParameter("queryId", drfQueryUserMap.getQueryId());
			query.setParameter("queryUserId", drfQueryUserMap.getQueryUserId());
			
			Long maxNumber = (Long) query.getSingleResult();
			
			if(maxNumber.intValue() == 0) {
				em.merge(drfQueryUserMap);
			}
			
		}
		
	}
}
