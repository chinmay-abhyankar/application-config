/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.DeptMst;

/**
 * @author Amol.l
 *
 */
public class DeptListDTO implements Serializable  {

	private static final long serialVersionUID = 33L;
	
	private List<DeptMst> deptMstList = new ArrayList<DeptMst>();

	public List<DeptMst> getDeptMstList() {
		return deptMstList;
	}

	public void setDeptMstList(List<DeptMst> deptMstList) {
		this.deptMstList = deptMstList;
	}
	
	
}
