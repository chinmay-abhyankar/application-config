package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the cont_rel_status_sapmst database table.
 * 
 */
@Entity
@Table(name = "cont_rel_status_sapmst")
@NamedQuery(name = "ContRelStatusSapmst.findAll", query = "SELECT c FROM ContRelStatusSapmst c")
public class ContRelStatusSapmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cont_rel_status_sapmst_id")
	private Integer contRelStatusSapmstId;

	@Column(name = "cont_doc_num")
	private String contDocNum;

	@Column(name = "cont_status")
	private String contStatus;

	@Column(name = "cont_status_desc")
	private String contStatusDesc;

	@Column(name = "created_date")
	private String createdDate;
	
	@Column(name = "modified_date")
	private String modifiedDate;
	
	@Column(name = "is_mail_sent")
	private String isMailSent;

	public Integer getContRelStatusSapmstId() {
		return contRelStatusSapmstId;
	}

	public void setContRelStatusSapmstId(Integer contRelStatusSapmstId) {
		this.contRelStatusSapmstId = contRelStatusSapmstId;
	}

	public String getContDocNum() {
		return contDocNum;
	}

	public void setContDocNum(String contDocNum) {
		this.contDocNum = contDocNum;
	}

	public String getContStatus() {
		return contStatus;
	}

	public void setContStatus(String contStatus) {
		this.contStatus = contStatus;
	}

	public String getContStatusDesc() {
		return contStatusDesc;
	}

	public void setContStatusDesc(String contStatusDesc) {
		this.contStatusDesc = contStatusDesc;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getIsMailSent() {
		return isMailSent;
	}

	public void setIsMailSent(String isMailSent) {
		this.isMailSent = isMailSent;
	}

}