/**
 * 
 */
package com.nelco.o2c.dto;

import org.springframework.stereotype.Component;

import com.nelco.o2c.model.DrfApproverDetail;

/**
 * @author Jayashankar.r
 *
 */
@Component
public class DrfApprDetailsDTO {
	private DrfApproverDetail drfApproverDetail;

	public DrfApproverDetail getDrfApproverDetail() {
		return drfApproverDetail;
	}

	public void setDrfApproverDetail(DrfApproverDetail drfApproverDetail) {
		this.drfApproverDetail = drfApproverDetail;
	}
	
}
