package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

public class InvoiceSubmissionRequestDetailsDTO {
private String requestId="";
private String invoiceNo="";
private String submissionDate="";
private String userId="";
private String requestType="";
private String requestDate="";
private List<OppUploadDetailDTO> uploadedDocuments=new ArrayList<OppUploadDetailDTO>();

public List<OppUploadDetailDTO> getUploadedDocuments() {
	return uploadedDocuments;
}
public void setUploadedDocuments(List<OppUploadDetailDTO> uploadedDocuments) {
	this.uploadedDocuments = uploadedDocuments;
}
public String getRequestType() {
	return requestType;
}
public void setRequestType(String requestType) {
	this.requestType = requestType;
}
public String getRequestDate() {
	return requestDate;
}
public void setRequestDate(String requestDate) {
	this.requestDate = requestDate;
}
public String getRequestId() {
	return requestId;
}
public void setRequestId(String requestId) {
	this.requestId = requestId;
}
public String getInvoiceNo() {
	return invoiceNo;
}
public void setInvoiceNo(String invoiceNo) {
	this.invoiceNo = invoiceNo;
}
public String getSubmissionDate() {
	return submissionDate;
}
public void setSubmissionDate(String submissionDate) {
	this.submissionDate = submissionDate;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}

}
