/**
 * 
 */
package com.nelco.o2c.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.BrfDTO;
import com.nelco.o2c.dto.BrfDetailsDTO;
import com.nelco.o2c.dto.BrfDetailsListDTO;
import com.nelco.o2c.dto.BrfStatusTrackerDTO;
import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.model.Brf;
import com.nelco.o2c.service.BrfService;
import com.nelco.o2c.service.DrfBrfService;

/**
 * @author Amol.l
 *
 */
@RestController
public class DrfBrfController {

	@Autowired
	DrfBrfService drfBrfService;
	
	@Autowired
	BrfService brfService;
	
	@RequestMapping(value = "/getDrfBrfListByDate.do", method = RequestMethod.POST)
	public BrfDetailsListDTO getBrfListByDate(@RequestBody BrfDetailsListDTO brfDetailsListDTO) {
		BrfDetailsListDTO brfDetailsListDTONew = new BrfDetailsListDTO();
		List<BrfDetailsDTO> brfDetailsDTOList = new ArrayList<BrfDetailsDTO>();
		brfDetailsDTOList = drfBrfService.getDrfBrfListByDate(brfDetailsListDTO);
		brfDetailsListDTONew.setToDate(brfDetailsListDTO.getToDate());
		brfDetailsListDTONew.setFromDate(brfDetailsListDTO.getFromDate());
		brfDetailsListDTONew.setBrfDetailsDTOList(brfDetailsDTOList);
		return brfDetailsListDTONew;
	}
	
	@RequestMapping(value = "/brfListBySONumAndDate.do", method = RequestMethod.POST)
	public BrfDetailsListDTO brfListBySONumAndDate(@RequestBody BrfDetailsListDTO brfDetailsListDTO) {
		BrfDetailsListDTO brfDetailsListDTONew = new BrfDetailsListDTO();
		List<BrfDetailsDTO> brfDetailsDTOList = new ArrayList<BrfDetailsDTO>();
		brfDetailsDTOList = drfBrfService.brfListBySONumAndDate(brfDetailsListDTO);
		brfDetailsListDTONew.setToDate(brfDetailsListDTO.getToDate());
		brfDetailsListDTONew.setFromDate(brfDetailsListDTO.getFromDate());
		brfDetailsListDTONew.setBrfDetailsDTOList(brfDetailsDTOList);
		brfDetailsListDTONew.setDrfDetailsId(brfDetailsListDTO.getDrfDetailsId());
		return brfDetailsListDTONew;
	}
	
	@RequestMapping(value = "/drfBrfByBrfId.do", method = RequestMethod.POST)
	public BrfDTO getBrfByBrfId(@RequestBody BrfDTO brfDTO) {
		BrfDTO brfDTONew = new BrfDTO();
		Brf brf = new Brf();
		brf = drfBrfService.drfBrfByBrfId(brfDTO.getBrfId());
		brfDTONew.setBrfId(brfDTO.getBrfId());
		brfDTONew.setBrf(brf);
		brfDTONew.setOppUploadDetails(brfService.getUploadDetailsByBrfId(brfDTO.getBrfId()));
		return brfDTONew;
	}
	
	@RequestMapping(value = "/saveDrfBrf.do", method = RequestMethod.POST)
	public BrfDTO saveDrfBrf(@RequestBody BrfDTO brfDTO) {
		BrfDTO brfDTONew = new BrfDTO();
		Brf brf = new Brf();
		brf = drfBrfService.saveDrfBrf(brfDTO);
		brfDTONew.setBrf(brf);
		brfDTONew.setIsSaved(true);
		return brfDTONew;
	}
	
	@RequestMapping(value = "/drfBrfApprRej.do", method = RequestMethod.POST)
	public BrfStatusTrackerDTO drfBrfApprRej(@RequestBody CommonDTO commonDTO) {

		return drfBrfService.drfBrfApprRej(commonDTO);
	}
	
	
}
