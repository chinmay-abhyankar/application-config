package com.nelco.o2c.dto;

public class DisconnectionReconnectionDatesToCSVDTO {
private String so_no="";
private String startDate="";
private String endDate="";
public String getSo_no() {
	return so_no;
}
public void setSo_no(String so_no) {
	this.so_no = so_no;
}
public String getStartDate() {
	return startDate;
}
public void setStartDate(String startDate) {
	this.startDate = startDate;
}
public String getEndDate() {
	return endDate;
}
public void setEndDate(String endDate) {
	this.endDate = endDate;
}

}
