package com.nelco.o2c.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.JasperException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.nelco.o2c.dto.DisconnectionFormDTO;
import com.nelco.o2c.dto.DisconnectionOnCRFormDTO;
import com.nelco.o2c.dto.ResponseDTO;
import com.nelco.o2c.service.DisconnectionOnCRService;

import net.sf.jasperreports.engine.JRException;

@RestController
public class DisconnectionOnCustomerRequestController {
	@Autowired
	DisconnectionOnCRService disconnectionOnCRService;

	@RequestMapping(value = "/getSoListForDisconnection.do", method = RequestMethod.GET)
	public DisconnectionOnCRFormDTO getSoListForDisconnection(DisconnectionOnCRFormDTO disconnectionOnCRFormDTO,
			HttpServletRequest request) {
		return disconnectionOnCRService.getSoListForDisconnection(disconnectionOnCRFormDTO, request);
	}

	@RequestMapping(value = "/sendTemplateDetails.do", method = RequestMethod.POST)
	public DisconnectionOnCRFormDTO sendTemplateDetails(@RequestBody DisconnectionOnCRFormDTO disconnectionOnCRFormDTO,
			HttpServletRequest request, HttpServletResponse response) {
		return disconnectionOnCRService.insertTemplateDetails(disconnectionOnCRFormDTO, request, response);
	}
	
	@RequestMapping(value = "/downloadDisconnectionTemplate.do", method = RequestMethod.GET)
	public void downloadDisconnectionTemplate(DisconnectionOnCRFormDTO disconnectionOnCRFormDTO,
			HttpServletRequest request, HttpServletResponse response) {
		try {
			disconnectionOnCRService.downloadDisconnectionTemplate(request, response);
		} catch (JasperException | IOException | SQLException | JRException | NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@RequestMapping(value = "/uploadDisconnectionRequestOnCR.do", method = RequestMethod.POST)
	public DisconnectionOnCRFormDTO uploadDisconnectionRequestOnCR(DisconnectionOnCRFormDTO disconnectionOnCRFormDTO,MultipartHttpServletRequest request, @RequestParam String userId)
			throws IOException {
		ResponseDTO responseDTO = new ResponseDTO();
		MultipartFile file = request.getFile("theFile");
		responseDTO= disconnectionOnCRService.validateFile(file, userId, responseDTO);
		disconnectionOnCRFormDTO=disconnectionOnCRService.uploadFile(file, userId,disconnectionOnCRFormDTO,responseDTO.getResultMap());
		
		return disconnectionOnCRFormDTO;
	}
	
	@RequestMapping(value = "/createDisconnectionRequestOnCR.do", method = RequestMethod.POST)
	public DisconnectionOnCRFormDTO createDisconnectionRequestOnCR(@RequestBody DisconnectionOnCRFormDTO disconnectionOnCRFormDTO,
			HttpServletRequest request) {
		try {
			disconnectionOnCRService.createDisconnectionRequestOnCR(disconnectionOnCRFormDTO,request);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return disconnectionOnCRFormDTO;
	}
	
	@RequestMapping(value = "/disconnectionOnCRRequestDetails.do", method = RequestMethod.GET)
	public DisconnectionOnCRFormDTO disconnectionOnCRRequestDetails(DisconnectionOnCRFormDTO disconnectionOnCRFormDTO, HttpServletRequest request) {
		return disconnectionOnCRFormDTO;
	}
	
	@RequestMapping(value = "/updateDisconnectionRequestOnCRStatus.do", method = RequestMethod.POST)
	public DisconnectionOnCRFormDTO updateDisconnectionRequestOnCRStatus(@RequestBody DisconnectionOnCRFormDTO disconnectionFormDTO, HttpServletRequest request) {
		return disconnectionOnCRService.updateDisconnectionRequestOnCRStatus(disconnectionFormDTO,request);
	}
	
	@RequestMapping(value = "/getDisconnectionForCustomerRequestReport.do", method = RequestMethod.GET)
	public DisconnectionOnCRFormDTO getDisconnectionForCustomerRequestReport(DisconnectionOnCRFormDTO disconnectionOnCRFormDTO,
			HttpServletRequest request) {
		return disconnectionOnCRService.getDisconnectionForCustomerRequestReport(disconnectionOnCRFormDTO, request);
	}
	
	
}
