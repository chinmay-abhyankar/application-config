/**
 * 
 */
package com.nelco.o2c.dto;

/**
 * @author Jayashankar.r
 *
 */
public class SapResponseDTO {

	private Boolean isSaved = false;

	public Boolean getIsSaved() {
		return isSaved;
	}

	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}
	
	
}
