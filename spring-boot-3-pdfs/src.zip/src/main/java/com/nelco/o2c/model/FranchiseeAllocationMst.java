package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;


/**
 * The persistent class for the franchisee_allocation_mst database table.
 * 
 */
@Entity
@Table(name="franchisee_allocation_mst")
@NamedQueries({ @NamedQuery(name="FranchiseeAllocationMst.findAll", query="SELECT f FROM FranchiseeAllocationMst f"),
	@NamedQuery(name = "FranchiseeAllocationMst.getCurrentDayMaxCount", query = " select (count(s)+1) from FranchiseeAllocationMst "
			+ " s where s.creationDate between ?1 and ?2 ")
,@NamedQuery(name = "FranchiseeAllocationMst.updateFrachisee", query = " update FranchiseeAllocationMst e"
		+ " set e.franchisee_id=?1 ,e.status=?2 where e.id=?3")
,@NamedQuery(name = "FranchiseeAllocationMst.findById", query = " SELECT f FROM FranchiseeAllocationMst f where f.id=?1")
,@NamedQuery(name="FranchiseeAllocationMst.updateEngineerAllocatedStatus",query="update FranchiseeAllocationMst e"
		+ " set e.status=?1 where id=?2")
})
//@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class FranchiseeAllocationMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Integer id;

	@Column(name="activity_type")
	private Integer activityType;
	
	@Column(name="user_id",updatable = false)
	private Integer user_id;
		
	@Column(name="contact_person_number")
	private String contactPersonNumber;

	@Column(name="creation_date")
	private String creationDate;
	
	@Column(name="site_survey_id")
	private Integer site_survey_id;

	@Column(name="delivery_num")
	private String deliveryNum;
	
	@Column(name="delivery_id")
	private Integer delivery_id;

	@Column(name="installation_address")
	private String installationAddress;

	@Column(name="site_contact_person")
	private String siteContactPerson;

	@Column(name="site_survey_done")
	private String siteSurveyDone;

	@Column(name="site_survey_uniq_id")
	private String siteSurveyUniqId;

	@Column(name="so_number")
	private String soNumber;

	private Integer status;

	@Column(name="uniq_id")
	private String uniqId;

	@Column(name="vsat_id")
	private String vsatId;

	@Column(name="vsat_ip")
	private String vsatIp;
	
	@Column(name="franchisee_id")
	private Integer franchisee_id;
	
	@Column(name = "installation_type_mst_id")
	private Integer installationTypeMstId;
	
	@Column(name = "item",updatable=false)
	private String item;
	
	@Column(name = "tentative_date")
	private String tentativeDate;
	
	@Column(name = "hub_mst_id")
	private Integer hubMstId;
	
	@Column(name = "additional_remarks")
	private String additionalRemarks;
	
	@Column(name = "technology_mst_id")
	private Integer technologyMstId;
	
	@Column(name = "sub_customer")
	private String subCustomer;
	
	
	
	
public String getSubCustomer() {
		return subCustomer;
	}

	public void setSubCustomer(String subCustomer) {
		this.subCustomer = subCustomer;
	}

public String getTentativeDate() {
		return tentativeDate;
	}

	public void setTentativeDate(String tentativeDate) {
		this.tentativeDate = tentativeDate;
	}

	public Integer getHubMstId() {
		return hubMstId;
	}

	public void setHubMstId(Integer hubMstId) {
		this.hubMstId = hubMstId;
	}

	public String getAdditionalRemarks() {
		return additionalRemarks;
	}

	public void setAdditionalRemarks(String additionalRemarks) {
		this.additionalRemarks = additionalRemarks;
	}

	public Integer getTechnologyMstId() {
		return technologyMstId;
	}

	public void setTechnologyMstId(Integer technologyMstId) {
		this.technologyMstId = technologyMstId;
	}

public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

public Integer getInstallationTypeMstId() {
		return installationTypeMstId;
	}

	public void setInstallationTypeMstId(Integer installationTypeMstId) {
		this.installationTypeMstId = installationTypeMstId;
	}

	//	@OneToMany(fetch = FetchType.LAZY, mappedBy="franchiseeAllocationMst")
//	@JsonManagedReference
////	@JoinColumn(name = "delivery_id", referencedColumnName = "delivery_id", insertable = false, updatable = false
////	)
//	private List<Delivery> delivery;
//	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "site_survey_id", referencedColumnName = "id", insertable = false, updatable = false)
	private SiteSurveyMaster siteSurveyMaster;	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "franchisee_id", referencedColumnName = "franchise_mst_id", insertable = false, updatable = false)
	private FranchiseeMaster franchiseeMaster;	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status", referencedColumnName = "status_mst_id", insertable = false, updatable = false)
	private StatusMst statusMst;	

	public FranchiseeMaster getFranchiseeMaster() {
		return franchiseeMaster;
	}

	public void setFranchiseeMaster(FranchiseeMaster franchiseeMaster) {
		this.franchiseeMaster = franchiseeMaster;
	}

	public SiteSurveyMaster getSiteSurveyMaster() {
		return siteSurveyMaster;
	}

	public void setSiteSurveyMaster(SiteSurveyMaster siteSurveyMaster) {
		this.siteSurveyMaster = siteSurveyMaster;
	}

	public StatusMst getStatusMst() {
		return statusMst;
	}

	public void setStatusMst(StatusMst statusMst) {
		this.statusMst = statusMst;
	}

	public Integer getFranchisee_id() {
		return franchisee_id;
	}

	public void setFranchisee_id(Integer franchisee_id) {
		this.franchisee_id = franchisee_id;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}



	



	public Integer getDelivery_id() {
		return delivery_id;
	}

	

	public Integer getSite_survey_id() {
		return site_survey_id;
	}



	public void setSite_survey_id(Integer site_survey_id) {
		this.site_survey_id = site_survey_id;
	}



	



	

	public void setDelivery_id(Integer delivery_id) {
		this.delivery_id = delivery_id;
	}

	public FranchiseeAllocationMst() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getActivityType() {
		return this.activityType;
	}

	public void setActivityType(Integer activityType) {
		this.activityType = activityType;
	}

	public String getContactPersonNumber() {
		return this.contactPersonNumber;
	}

	public void setContactPersonNumber(String contactPersonNumber) {
		this.contactPersonNumber = contactPersonNumber;
	}

	public String getCreationDate() {
		return this.creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getDeliveryNum() {
		return this.deliveryNum;
	}

	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}

	public String getInstallationAddress() {
		return this.installationAddress;
	}

	public void setInstallationAddress(String installationAddress) {
		this.installationAddress = installationAddress;
	}

	public String getSiteContactPerson() {
		return this.siteContactPerson;
	}

	public void setSiteContactPerson(String siteContactPerson) {
		this.siteContactPerson = siteContactPerson;
	}

	public String getSiteSurveyDone() {
		return this.siteSurveyDone;
	}

	public void setSiteSurveyDone(String siteSurveyDone) {
		this.siteSurveyDone = siteSurveyDone;
	}

	public String getSiteSurveyUniqId() {
		return this.siteSurveyUniqId;
	}

	public void setSiteSurveyUniqId(String siteSurveyUniqId) {
		this.siteSurveyUniqId = siteSurveyUniqId;
	}

	public String getSoNumber() {
		return this.soNumber;
	}

	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}

	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getUniqId() {
		return this.uniqId;
	}

	public void setUniqId(String uniqId) {
		this.uniqId = uniqId;
	}

	public String getVsatId() {
		return this.vsatId;
	}

	public void setVsatId(String vsatId) {
		this.vsatId = vsatId;
	}

	public String getVsatIp() {
		return this.vsatIp;
	}

	public void setVsatIp(String vsatIp) {
		this.vsatIp = vsatIp;
	}

	@Override
	public String toString() {
		return "FranchiseeAllocationMst [id=" + id + ", activityType=" + activityType + ", user_id=" + user_id
				+ ", contactPersonNumber=" + contactPersonNumber + ", creationDate=" + creationDate
				+ ", site_survey_id=" + site_survey_id + ", deliveryNum=" + deliveryNum + ", delivery_id=" + delivery_id
				+ ", installationAddress=" + installationAddress + ", siteContactPerson=" + siteContactPerson
				+ ", siteSurveyDone=" + siteSurveyDone + ", siteSurveyUniqId=" + siteSurveyUniqId + ", soNumber="
				+ soNumber + ", status=" + status + ", uniqId=" + uniqId + ", vsatId=" + vsatId + ", vsatIp=" + vsatIp
				+ ", franchisee_id=" + franchisee_id + ", installationTypeMstId=" + installationTypeMstId + ", item="
				+ item + ", tentativeDate=" + tentativeDate + ", hubMstId=" + hubMstId + ", additionalRemarks="
				+ additionalRemarks + ", technologyMstId=" + technologyMstId + ", siteSurveyMaster=" + siteSurveyMaster
				+ ", franchiseeMaster=" + franchiseeMaster + ", statusMst=" + statusMst + "]";
	}
	
}