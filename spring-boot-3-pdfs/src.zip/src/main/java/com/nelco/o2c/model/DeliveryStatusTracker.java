package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the delivery_status_tracker database table.
 * 
 */
@Entity
@Table(name="delivery_status_tracker")
@NamedQuery(name="DeliveryStatusTracker.findAll", query="SELECT d FROM DeliveryStatusTracker d")
public class DeliveryStatusTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="delivery_status_tracker_id")
	private Integer deliveryStatusTrackerId;

	@Column(name = "delivery_status_mst_id")
	private Integer deliveryStatusMstId;

	@Column(name="delivery_id")
	private int deliveryId;

	@Column(name="req_by")
	private Integer reqBy;

	@Column(name="status_req_date")
	private String statusReqDate;

	public DeliveryStatusTracker() {
	}

	public Integer getDeliveryStatusTrackerId() {
		return deliveryStatusTrackerId;
	}

	public void setDeliveryStatusTrackerId(Integer deliveryStatusTrackerId) {
		this.deliveryStatusTrackerId = deliveryStatusTrackerId;
	}

	public int getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(int deliveryId) {
		this.deliveryId = deliveryId;
	}

	public Integer getReqBy() {
		return reqBy;
	}

	public void setReqBy(Integer reqBy) {
		this.reqBy = reqBy;
	}

	public String getStatusReqDate() {
		return statusReqDate;
	}

	public void setStatusReqDate(String statusReqDate) {
		this.statusReqDate = statusReqDate;
	}

	public Integer getDeliveryStatusMstId() {
		return deliveryStatusMstId;
	}

	public void setDeliveryStatusMstId(Integer deliveryStatusMstId) {
		this.deliveryStatusMstId = deliveryStatusMstId;
	}

	
}