package com.nelco.o2c.dto;

public class RecurringInvoiceReportDTO {
	private String soldToParty = "";
	private String nameOfSoldToParty = "";
	private String bankName = "";
	private String soNumber = "";
	private String userName = "";
	private String contractType = "";
	private String poNumber = "";
	private String soNo = "";
	private String installationDate = "";
	private String billingType = "";
	private String technology = "";
	private String billingPlant = "";
	private String shippingPlant = "";
	private String address = "";
	private String state = "";
	private String hubName  = "";
	private String netValue = "";
	private String billingDate = "";

	public String getSoldToParty() {
		return soldToParty;
	}

	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}

	public String getNameOfSoldToParty() {
		return nameOfSoldToParty;
	}

	public void setNameOfSoldToParty(String nameOfSoldToParty) {
		this.nameOfSoldToParty = nameOfSoldToParty;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getSoNumber() {
		return soNumber;
	}

	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getSoNo() {
		return soNo;
	}

	public void setSoNo(String soNo) {
		this.soNo = soNo;
	}

	public String getInstallationDate() {
		return installationDate;
	}

	public void setInstallationDate(String installationDate) {
		this.installationDate = installationDate;
	}

	public String getBillingType() {
		return billingType;
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getBillingPlant() {
		return billingPlant;
	}

	public void setBillingPlant(String billingPlant) {
		this.billingPlant = billingPlant;
	}

	public String getShippingPlant() {
		return shippingPlant;
	}

	public void setShippingPlant(String shippingPlant) {
		this.shippingPlant = shippingPlant;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getHubName() {
		return hubName;
	}

	public void setHubName(String hubName) {
		this.hubName = hubName;
	}

	public String getNetValue() {
		return netValue;
	}

	public void setNetValue(String netValue) {
		this.netValue = netValue;
	}

	public String getBillingDate() {
		return billingDate;
	}

	public void setBillingDate(String billingDate) {
		this.billingDate = billingDate;
	}

}
