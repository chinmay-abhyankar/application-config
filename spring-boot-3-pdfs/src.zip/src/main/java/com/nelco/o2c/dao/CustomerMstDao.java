/**
 * 
 */
package com.nelco.o2c.dao;

import com.nelco.o2c.dto.CustomerMstDTO;
import com.nelco.o2c.model.CustomerSapmst;

/**
 * @author Amol.l
 *
 */
public interface CustomerMstDao {

		public CustomerSapmst getCustomerdetailsByCustomerNum(CustomerMstDTO customerMstDTO);

		public String getCustomerName(String soldToParty); 
}
