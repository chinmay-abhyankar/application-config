package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the invoice_submission_feedback_mst database table.
 * 
 */
@Entity
@Table(name="invoice_submission_feedback_mst")
@NamedQuery(name="InvoiceSubmissionFeedbackMst.findAll", query="SELECT i FROM InvoiceSubmissionFeedbackMst i")
public class InvoiceSubmissionFeedbackMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private int typeid;

	@Column(insertable=false, updatable=false, length=2)
	private String actflag;

	@Column(length=3000)
	private String feedback;

	@Column(name="feedback_subtype", length=50)
	private String feedbackSubtype;

	@Column(name="feedback_type", length=50)
	private String feedbackType;

	@Column(name="request_date")
	private String requestDate;

	@Column(name="request_id", length=50)
	private String requestId;

	@Column(name="user_id", length=50)
	private String userId;
	
	@Transient
	private String invoiceNo="";

	public InvoiceSubmissionFeedbackMst() {
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public String getFeedback() {
		return this.feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public String getFeedbackSubtype() {
		return this.feedbackSubtype;
	}

	public void setFeedbackSubtype(String feedbackSubtype) {
		this.feedbackSubtype = feedbackSubtype;
	}

	public String getFeedbackType() {
		return this.feedbackType;
	}

	public void setFeedbackType(String feedbackType) {
		this.feedbackType = feedbackType;
	}

	public String getRequestDate() {
		return this.requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getRequestId() {
		return this.requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}