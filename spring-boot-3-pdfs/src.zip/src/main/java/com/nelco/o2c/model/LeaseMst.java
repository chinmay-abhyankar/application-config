package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the lease_mst database table.
 * 
 */
@Entity
@Table(name="lease_mst")
@NamedQuery(name="LeaseMst.findAll", query="SELECT l FROM LeaseMst l")
public class LeaseMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="lease_mst_id")
	private Integer leaseMstId;

	@Column(name="lease_code")
	private String leaseCode;

	@Column(name="lease_val")
	private String leaseVal;

	public Integer getLeaseMstId() {
		return leaseMstId;
	}

	public void setLeaseMstId(Integer leaseMstId) {
		this.leaseMstId = leaseMstId;
	}

	public String getLeaseCode() {
		return leaseCode;
	}

	public void setLeaseCode(String leaseCode) {
		this.leaseCode = leaseCode;
	}

	public String getLeaseVal() {
		return leaseVal;
	}

	public void setLeaseVal(String leaseVal) {
		this.leaseVal = leaseVal;
	}

	

}