package com.nelco.o2c.dao;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nelco.o2c.dto.AllDeliveryListDTO;
import com.nelco.o2c.dto.CommonMailDTO;
import com.nelco.o2c.dto.DeliveryDTO;
import com.nelco.o2c.dto.DeliveryListDTO;
import com.nelco.o2c.dto.FileUploadDTO;
import com.nelco.o2c.model.AddressTracker;
import com.nelco.o2c.model.Delivery;
import com.nelco.o2c.model.DeliveryStatusMst;
import com.nelco.o2c.model.DeliveryStatusTracker;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.PodStatusMst;
import com.nelco.o2c.model.PodStatusTracker;
import com.nelco.o2c.model.PodUploadDetails;
import com.nelco.o2c.model.SoOrders;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Amol.l
 *
 */
@Repository
public class DeliveryDaoImpl implements DeliveryDao {

	@PersistenceContext
	private EntityManager em;

	Query query;

	@Override
	public Delivery getDelByDelId(Integer deliveryId) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("Delivery.getDelByDelId");
			query.setParameter(1, deliveryId);
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			Delivery delivery = (Delivery) query.getSingleResult();
			return delivery;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new Delivery();
		} finally {
			em.close();
		}
	}

	@Override
	public List<Delivery> getDelListByDate(DeliveryListDTO deliveryListDTO) {
		// TODO Auto-generated method stub

		try {
			
			//String queryString = "";
			String fromDate = DateUtil.convertDateToSqlDate(deliveryListDTO.getFromDate()) + Constants.MINDAYTIME;
			String toDate = DateUtil.convertDateToSqlDate(deliveryListDTO.getToDate()) + Constants.MAXDAYTIME;
			//queryString = "select d.delivery_num,d.dispatch_date,d.docket_num,d.courier_name,d.eddate,d.boxes,d.receiv_name,d.receiv_contact,psm.pod_status_mst_id,psm.pod_status_code,psm.pod_status_name,dsm.delivery_status_mst_id,dsm.del_status_code,dsm.del_status_name,d.sap_del_date,d.anteena_type,d.cbl,d.weight,d.dan_raised_by,d.idu_serial_num,d.buc_serial_num,d.lnb_serial_num,so.contract_num,so.so_number,d.month,d.challan_num,d.tax_invoice,d.addate,d.cust_name,d.state,d.material_num,d.dispatch_type,d.model_desc,d.quantity,d.delivery_id,d.delivery_status_mst_id as deliveryStatusMstId,d.pod_status_mst_id as podStatusMstId,d.ship_to_party,d.location,d.mod_of_transp,d.value,d.contact_person,d.contact_pers_mob,d.contact_pers_address,d.wbs_element,d.is_sales_return,d.plant from delivery d inner join delivery_status_mst dsm on d.delivery_status_mst_id = dsm.delivery_status_mst_id inner join pod_status_mst psm on d.pod_status_mst_id = psm.pod_status_mst_id inner join so_orders so on ( d.so_number = so.so_number and d.wbs_element = so.wbs_element) where d.sap_del_date between ?1 and ?2 ";
			query = em.createStoredProcedureQuery("isp_getOrderDeliveryUpdate").
					registerStoredProcedureParameter("fromDate", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("toDate", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("rowNum", Integer.class, ParameterMode.IN)
					.registerStoredProcedureParameter("plantCode", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("isNext", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("multiplier", Integer.class, ParameterMode.IN);

			if(deliveryListDTO.getIsNext().equals("Y")) {
				
				query.setParameter("fromDate", fromDate);
				query.setParameter("toDate", toDate);
				query.setParameter("rowNum", deliveryListDTO.getRowNum());
				query.setParameter("isNext", "Y");
				query.setParameter("multiplier", 1);
			
				if (!(deliveryListDTO.getPlant().trim().equals("") || deliveryListDTO.getPlant().trim().equals("null"))) {
					if(!deliveryListDTO.getPlant().trim().equals("ALL")) {
						query.setParameter("plantCode", deliveryListDTO.getPlant());
					}
				}
/*				queryString = queryString + "  and d.delivery_id > ?3 ";
				if (!(deliveryListDTO.getPlant().trim().equals("") || deliveryListDTO.getPlant().trim().equals("null"))) {
					if(!deliveryListDTO.getPlant().trim().equals("ALL")) {
					queryString = queryString + "  and d.plant =?4 ";
					}
				}
				queryString = queryString + " order by d.delivery_id asc ";
				query = em.createNativeQuery(queryString);
				query.setHint("org.hibernate.cacheable", Boolean.TRUE);
				query.setParameter(1, fromDate + Constants.MINDAYTIME);
				query.setParameter(2, toDate + Constants.MAXDAYTIME);
				query.setParameter(3, deliveryListDTO.getDeliveryId());
				if (!(deliveryListDTO.getPlant().trim().equals("")
						|| deliveryListDTO.getPlant().trim().equals("null"))) {
					if(!deliveryListDTO.getPlant().trim().equals("ALL")) {
					query.setParameter(4, deliveryListDTO.getPlant());
					}
				}
				query.setMaxResults(20);
				query = em.createNamedQuery("Delivery.getDelListByDateNext");*/
				
				}
				if(deliveryListDTO.getIsNext().equals("N")) {
					
					query.setParameter("fromDate", fromDate);
					query.setParameter("toDate", toDate);
					query.setParameter("rowNum", deliveryListDTO.getRowNum());
					query.setParameter("isNext", "N");
					query.setParameter("multiplier", -1);
				
					if (!(deliveryListDTO.getPlant().trim().equals("") || deliveryListDTO.getPlant().trim().equals("null"))) {
						if(!deliveryListDTO.getPlant().trim().equals("ALL")) {
							query.setParameter("plantCode", deliveryListDTO.getPlant());
						}
					}
					
					/*queryString = queryString + "  and d.delivery_id < ?3 ";
					if (!(deliveryListDTO.getPlant().trim().equals("") || deliveryListDTO.getPlant().trim().equals("null"))) {
						if(!deliveryListDTO.getPlant().trim().equals("ALL")) {
						queryString = queryString + "  and d.plant =?4 ";
						}
					}
					queryString = queryString + " order by d.delivery_id asc ";
					query = em.createNativeQuery(queryString);
					query.setHint("org.hibernate.cacheable", Boolean.TRUE);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, deliveryListDTO.getDeliveryId());
					if (!(deliveryListDTO.getPlant().trim().equals("")
							|| deliveryListDTO.getPlant().trim().equals("null"))) {
						if(!deliveryListDTO.getPlant().trim().equals("ALL")) {
						query.setParameter(4, deliveryListDTO.getPlant());
						}
					}*/
					//query.setMaxResults(20);
//			    	query = em.createNamedQuery("Delivery.getDelListByDatePrev");
				}
			
				//query.executeUpdate();
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			List<Delivery> deliveryList = new ArrayList<Delivery>();
			for (Object[] objects : resultList) {
				Delivery delivery = new Delivery();
				delivery.setDeliveryNum(objects[0]!=null?(String)objects[0]:"");
				delivery.setDispatchDate(objects[1]!=null?DateUtil.convertDateTimeToString(objects[1].toString()):"");
				delivery.setDocketNum(objects[2]!=null?(String)objects[2]:"");
				delivery.setCourierName(objects[3]!=null?(String)objects[3]:"");
				delivery.setEddate(objects[4]!=null?DateUtil.convertDateTimeToString(objects[4].toString()):"");//DateUtil.convertDateTimeToString(this.eddate)
				delivery.setBoxes(objects[5]!=null?(String)objects[5]:"");
				delivery.setReceivName(objects[6]!=null?(String)objects[6]:"");
				delivery.setReceivContact(objects[7]!=null?(String)objects[7]:"");
				PodStatusMst podStatusMst = new PodStatusMst();
				podStatusMst.setPodStatusMstId(objects[8]!=null?(Integer)objects[8]:null);
				podStatusMst.setPodStatusCode(objects[9]!=null?(String)objects[9]:"");
				podStatusMst.setPodStatusName(objects[10]!=null?(String)objects[10]:"");
				delivery.setPodStatusMst(podStatusMst);
				DeliveryStatusMst deliveryStatusMst = new DeliveryStatusMst();
				deliveryStatusMst.setDeliveryStatusMstId(objects[11]!=null?(Integer)objects[11]:null);
				deliveryStatusMst.setDelStatusCode(objects[12]!=null?(String)objects[12]:"");
				deliveryStatusMst.setDelStatusName(objects[13]!=null?(String)objects[13]:"");
				delivery.setDeliveryStatusMst(deliveryStatusMst);
				delivery.setSapDelDate(objects[14]!=null?DateUtil.convertDateTimeToString(objects[14].toString()):"");//
				delivery.setAnteenaType(objects[15]!=null?(String)objects[15]:"");
				delivery.setCbl(objects[16]!=null?(String)objects[16]:"");
				delivery.setWeight(objects[17]!=null?(String)objects[17]:"");
				delivery.setDanRaisedBy(objects[18]!=null?(String)objects[18]:"");
				delivery.setIduSerialNum(objects[19]!=null?(String)objects[19]:"");
				delivery.setBucSerialNum(objects[20]!=null?(String)objects[20]:"");
				delivery.setLnbSerialNum(objects[21]!=null?(String)objects[21]:"");
				SoOrders soOrders = new SoOrders();
				soOrders.setContractNum(objects[22]!=null?(String)objects[22]:"");
				soOrders.setSoNumber(objects[23]!=null?(String)objects[23]:"");
				delivery.setSoNumber(soOrders.getSoNumber());
				delivery.setSoOrders(soOrders);
				delivery.setMonth(objects[24]!=null?(String)objects[24]:"");
				delivery.setChallanNum(objects[25]!=null?(String)objects[25]:"");
				delivery.setTaxInvoice(objects[26]!=null?(String)objects[26]:"");
				delivery.setAddate(objects[27]!=null?DateUtil.convertDateTimeToString(objects[27].toString()):"");//
				delivery.setCustName(objects[28]!=null?(String)objects[28]:"");
				delivery.setState(objects[29]!=null?(String)objects[29]:"");
				delivery.setMaterialNum(objects[30]!=null?(String)objects[30]:"");
				delivery.setDispatchType(objects[31]!=null?(String)objects[31]:"");
				delivery.setModelDesc(objects[32]!=null?(String)objects[32]:"");
				delivery.setQuantity(objects[33]!=null?(String)objects[33]:"");
				delivery.setDeliveryId((Integer)objects[34]);
				delivery.setDeliveryStatusMstId(objects[35]!=null?(Integer)objects[35]:0);
				delivery.setPodStatusMstId(objects[36]!=null?(Integer)objects[36]:0);
				delivery.setShipToParty(objects[37]!=null?(String)objects[37]:"");
				delivery.setLocation(objects[38]!=null?(String)objects[38]:"");
				delivery.setModOfTransp(objects[39]!=null?(String)objects[39]:"");
				delivery.setValue(objects[40]!=null?(String)objects[40]:"");
				delivery.setContactPerson(objects[41]!=null?(String)objects[41]:"");
				delivery.setContactPersMob(objects[42]!=null?(String)objects[42]:"");
				delivery.setContactPersAddress(objects[43]!=null?(String)objects[43]:"");
				delivery.setWbsElement(objects[44]!=null?(String)objects[44]:"");
				delivery.setIsSalesReturn(objects[45]!=null?(String)objects[45]:"");
				delivery.setPlant(objects[46]!=null?(String)objects[46]:"");
				delivery.setRowNumber(((BigInteger) objects[47]).intValue());
				delivery.setChallanDate(objects[48]!=null?DateUtil.convertDateTimeToString(objects[48].toString()):"");
				
				deliveryList.add(delivery);
			}
			return deliveryList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<Delivery>();
		} finally {
			em.close();
		}
	}

	@Override
	public Delivery saveDelivery(Delivery delivery) {
		// TODO Auto-generated method stub
		if(delivery.getDeliveryId()==null)
			delivery.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		String dispatchDate = DateUtil.convertDateToSqlDate(delivery.getDispatchDate());
		String addate = DateUtil.convertDateToSqlDate(delivery.getAddate());
		String eddate = DateUtil.convertDateToSqlDate(delivery.getEddate());
		delivery.setDispatchDate(dispatchDate);
		delivery.setAddate(addate);
		delivery.setEddate(eddate);
		delivery.setSoOrders(null);
		Delivery deliveryNew = em.merge(delivery);
		
		if (delivery.getDeliveryId() == null) {
			em.refresh(deliveryNew);
		}
		return deliveryNew;
	}

	@Override
	public List<FileTypeMst> getPODfileList(FileUploadDTO fileUploadDTO) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("FileTypeMst.getPODfileList");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<FileTypeMst> fileTypeMstList = (List<FileTypeMst>) query.getResultList();
			return fileTypeMstList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<FileTypeMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public PodUploadDetails saveUpPodFile(PodUploadDetails podUploadDetails) {
		// TODO Auto-generated method stub
		return em.merge(podUploadDetails);
	}

	@Override
	public PodUploadDetails getUpPodFileDet(Integer deliveryId) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("PodUploadDetails.getUpPodFileDetByDeliveryId");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			query.setParameter(1, deliveryId);
			PodUploadDetails podUploadDetails = (PodUploadDetails) query.getSingleResult();
			return podUploadDetails;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new PodUploadDetails();
		} finally {
			em.close();
		}
	}

//	@Transactional
	@Override
	public void updatePodStatusByDelId(Integer deliveryId) {
		try {
			// TODO Auto-generated method stub
			if (deliveryId != null) {
				query = em.createQuery("update Delivery d set d.podStatusMstId='2' where d.deliveryId=?1");
				query.setParameter(1, deliveryId);
			}
			query.executeUpdate();
		} finally {
			// TODO: handle finally clause
			em.close();
		}

	}

	@Override
	public PodStatusTracker savePodStatusTracker(PodStatusTracker podStatusTracker) {
		// TODO Auto-generated method stub
		podStatusTracker.setStatusReqDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));

		PodStatusTracker podStatusTrackerNew = em.merge(podStatusTracker);
		if (podStatusTracker.getPodStatusTrackerId() == null) {
			em.refresh(podStatusTrackerNew);
		}
		return podStatusTrackerNew;
	}

	@Override
	public DeliveryStatusTracker saveDeliveryStatusTracker(DeliveryStatusTracker deliveryStatusTracker) {
		// TODO Auto-generated method stub
		deliveryStatusTracker.setStatusReqDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));

		DeliveryStatusTracker deliveryStatusTrackerNew = em.merge(deliveryStatusTracker);
		if (deliveryStatusTracker.getDeliveryStatusTrackerId() == null) {
			em.refresh(deliveryStatusTrackerNew);
		}
		return deliveryStatusTrackerNew;
	}

	@Override
	public List<Delivery> getWrongAddressList(DeliveryListDTO deliveryListDTO) {
		try {
//			String fromDate = DateUtil.convertDateToSqlDate(deliveryListDTO.getFromDate());
//			String toDate = DateUtil.convertDateToSqlDate(deliveryListDTO.getToDate());

			query = em.createNamedQuery("Delivery.getWrongAddressList");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
//			query.setParameter(1, fromDate);
//			query.setParameter(2, toDate + " 23:59:59");
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			List<Delivery> deliveryList = new ArrayList<Delivery>();
			for (Object[] objects : resultList) {
				Delivery delivery = new Delivery();
				delivery.setDeliveryNum(objects[0]!=null?(String)objects[0]:"");
				delivery.setDispatchDate(objects[1]!=null?(String)objects[1]:"");
				delivery.setDocketNum(objects[2]!=null?(String)objects[2]:"");
				delivery.setCourierName(objects[3]!=null?(String)objects[3]:"");
				delivery.setEddate(objects[4]!=null?DateUtil.convertDateTimeToString((String)objects[4]):"");//DateUtil.convertDateTimeToString(this.eddate)
				delivery.setBoxes(objects[5]!=null?(String)objects[5]:"");
				delivery.setReceivName(objects[6]!=null?(String)objects[6]:"");
				delivery.setReceivContact(objects[7]!=null?(String)objects[7]:"");
				PodStatusMst podStatusMst = new PodStatusMst();
				podStatusMst.setPodStatusMstId(objects[8]!=null?(Integer)objects[8]:null);
				podStatusMst.setPodStatusCode(objects[9]!=null?(String)objects[9]:"");
				podStatusMst.setPodStatusName(objects[10]!=null?(String)objects[10]:"");
				delivery.setPodStatusMst(podStatusMst);
				DeliveryStatusMst deliveryStatusMst = new DeliveryStatusMst();
				deliveryStatusMst.setDeliveryStatusMstId(objects[11]!=null?(Integer)objects[11]:null);
				deliveryStatusMst.setDelStatusCode(objects[12]!=null?(String)objects[12]:"");
				deliveryStatusMst.setDelStatusName(objects[13]!=null?(String)objects[13]:"");
				delivery.setDeliveryStatusMst(deliveryStatusMst);
				delivery.setCreatedDate(objects[14]!=null?DateUtil.convertDateTimeToString((String)objects[14]):"");//
				delivery.setAnteenaType(objects[15]!=null?(String)objects[15]:"");
				delivery.setCbl(objects[16]!=null?(String)objects[16]:"");
				delivery.setWeight(objects[17]!=null?(String)objects[17]:"");
				delivery.setDanRaisedBy(objects[18]!=null?(String)objects[18]:"");
				delivery.setIduSerialNum(objects[19]!=null?(String)objects[19]:"");
				delivery.setBucSerialNum(objects[20]!=null?(String)objects[20]:"");
				delivery.setLnbSerialNum(objects[21]!=null?(String)objects[21]:"");
				SoOrders soOrders = new SoOrders();
				soOrders.setContractNum(objects[22]!=null?(String)objects[22]:"");
				soOrders.setSoNumber(objects[23]!=null?(String)objects[23]:"");
				delivery.setSoNumber(soOrders.getSoNumber());
				delivery.setSoOrders(soOrders);
				delivery.setMonth(objects[24]!=null?(String)objects[24]:"");
				delivery.setChallanNum(objects[25]!=null?(String)objects[25]:"");
				delivery.setTaxInvoice(objects[26]!=null?(String)objects[26]:"");
				delivery.setAddate(objects[27]!=null?DateUtil.convertDateTimeToString((String)objects[27]):"");//
				delivery.setCustName(objects[28]!=null?(String)objects[28]:"");
				delivery.setState(objects[29]!=null?(String)objects[29]:"");
				delivery.setMaterialNum(objects[30]!=null?(String)objects[30]:"");
				delivery.setDispatchType(objects[31]!=null?(String)objects[31]:"");
				delivery.setModelDesc(objects[32]!=null?(String)objects[32]:"");
				delivery.setQuantity(objects[33]!=null?(String)objects[33]:"");
				delivery.setDeliveryId((Integer)objects[34]);
				delivery.setDeliveryStatusMstId(objects[35]!=null?(Integer)objects[35]:0);
				delivery.setPodStatusMstId(objects[36]!=null?(Integer)objects[36]:0);
				delivery.setShipToParty(objects[37]!=null?(String)objects[37]:"");
				delivery.setLocation(objects[38]!=null?(String)objects[38]:"");
				delivery.setModOfTransp(objects[39]!=null?(String)objects[39]:"");
				delivery.setValue(objects[40]!=null?(String)objects[40]:"");
				delivery.setContactPerson(objects[41]!=null?(String)objects[41]:"");
				delivery.setContactPersMob(objects[42]!=null?(String)objects[42]:"");
				delivery.setContactPersAddress(objects[43]!=null?(String)objects[43]:"");
				delivery.setWbsElement(objects[44]!=null?(String)objects[44]:"");
				delivery.setIsSalesReturn(objects[45]!=null?(String)objects[45]:"");
				delivery.setPlant(objects[46]!=null?(String)objects[46]:"");
				
				deliveryList.add(delivery);
			}

			return deliveryList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<Delivery>();
		} finally {
			em.close();
		}
	}

	@Override
	public AddressTracker saveAddressTracker(AddressTracker addressTracker) {
		// TODO Auto-generated method stub
		addressTracker.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));

		AddressTracker addressTrackerNew = em.merge(addressTracker);
		if (addressTracker.getAddressTrackerId() == null) {
			em.refresh(addressTrackerNew);
		}
		return addressTrackerNew;
	}

	@Override
	public CommonMailDTO getDeliveryMail(Integer deliveryId) {
		// TODO Auto-generated method stub
		try {
            
			query = em.createQuery("select c.pmId,so.soNumber,c.childContractId,c.contractId,c.conStartDate,c.conEndDate,c.sapContractNum,d.deliveryId,d.addate,d.eddate,d.deliveryNum ,d.receivName,d.receivContact,d.contactPerson,d.contactPersMob,d.contactPersAddress,sold.customerName  from Delivery d inner join SoOrders so on (d.soNumber = so.soNumber and d.wbsElement = so.wbsElement) inner join ChildContract c on so.contractNum = c.sapContractNum inner join CustomerSapmst sold on so.soldToParty = sold.soldToParty and so.distChannel = sold.distChannel and so.division = sold.division and so.salesOrg = sold.salesOrg  where d.deliveryId =?1 ");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE); 
			query.setParameter(1, deliveryId);
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			CommonMailDTO commonMailDTO=null;
			for (Object[] objects : resultList) {
				commonMailDTO = new CommonMailDTO();
				commonMailDTO.setProgramMgrId(objects[0]!=null?(Integer)objects[0]:null);
				commonMailDTO.setSoNumber((String) objects[1]);
				commonMailDTO.setChildContractId((Integer) objects[2]);
				commonMailDTO.setContractId((Integer) objects[3]);
				commonMailDTO.setConStartDate((String) objects[4]);
				commonMailDTO.setConEndDate((String) objects[5]);
				commonMailDTO.setSapContractNum((String) objects[6]);
				commonMailDTO.setDeliveryId((Integer) objects[7]);
				commonMailDTO.setAddate((String) objects[8]);
				commonMailDTO.setEddate((String) objects[9]);
				commonMailDTO.setDeliveryNum((String) objects[10]);
				commonMailDTO.setReceivName((String) objects[11]);
				commonMailDTO.setReceivContact((String) objects[12]);
				commonMailDTO.setContactPerson((String) objects[13]);
				commonMailDTO.setContactPersMob((String) objects[14]);
				commonMailDTO.setContactPersAddress((String) objects[15]);
				commonMailDTO.setCustomerName((String) objects[16]);
			}
			if(commonMailDTO != null) {
			return commonMailDTO;
			}else {
				return commonMailDTO = new CommonMailDTO();
			}
						
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new CommonMailDTO(); 
		} finally {
			em.close();
		}
	}

	@Override
	public List<Delivery> getDelListByDateAndDelStatusCode(AllDeliveryListDTO allDeliveryListDTO) {
		// TODO Auto-generated method stub
		try {
			String fromDate = DateUtil.convertDateToSqlDate(allDeliveryListDTO.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(allDeliveryListDTO.getToDate());
			query = em.createNativeQuery("select del_status_code from delivery_status_mst");
			List<String> status = query.getResultList();
			
			query = em.createNamedQuery("Delivery.getDelListByDateAndDelStatusCode");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			query.setParameter(1, fromDate + Constants.MINDAYTIME);
			query.setParameter(2, toDate + Constants.MAXDAYTIME);
			if("All".equalsIgnoreCase(allDeliveryListDTO.getDelStatusCode())) {
				//List<String> status = Arrays.asList("ITR","NA","DLV","WDA");
				query.setParameter("status", status);
			}else {
				query.setParameter("status", allDeliveryListDTO.getDelStatusCode());
			}
			
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			List<Delivery> deliveryList = new ArrayList<Delivery>();
			for (Object[] objects : resultList) {
				Delivery delivery = new Delivery();
				delivery.setDeliveryNum(objects[0]!=null?(String)objects[0]:"");
				delivery.setDispatchDate(objects[1]!=null?(String)objects[1]:"");
				delivery.setDocketNum(objects[2]!=null?(String)objects[2]:"");
				delivery.setCourierName(objects[3]!=null?(String)objects[3]:"");
				delivery.setEddate(objects[4]!=null?DateUtil.convertDateTimeToString((String)objects[4]):"");//DateUtil.convertDateTimeToString(this.eddate)
				delivery.setBoxes(objects[5]!=null?(String)objects[5]:"");
				delivery.setReceivName(objects[6]!=null?(String)objects[6]:"");
				delivery.setReceivContact(objects[7]!=null?(String)objects[7]:"");
				PodStatusMst podStatusMst = new PodStatusMst();
				podStatusMst.setPodStatusMstId(objects[8]!=null?(Integer)objects[8]:null);
				podStatusMst.setPodStatusCode(objects[9]!=null?(String)objects[9]:"");
				podStatusMst.setPodStatusName(objects[10]!=null?(String)objects[10]:"");
				delivery.setPodStatusMst(podStatusMst);
				DeliveryStatusMst deliveryStatusMst = new DeliveryStatusMst();
				deliveryStatusMst.setDeliveryStatusMstId(objects[11]!=null?(Integer)objects[11]:null);
				deliveryStatusMst.setDelStatusCode(objects[12]!=null?(String)objects[12]:"");
				deliveryStatusMst.setDelStatusName(objects[13]!=null?(String)objects[13]:"");
				delivery.setDeliveryStatusMst(deliveryStatusMst);
				delivery.setCreatedDate(objects[14]!=null?DateUtil.convertDateTimeToString((String)objects[14]):"");//
				delivery.setAnteenaType(objects[15]!=null?(String)objects[15]:"");
				delivery.setCbl(objects[16]!=null?(String)objects[16]:"");
				delivery.setWeight(objects[17]!=null?(String)objects[17]:"");
				delivery.setDanRaisedBy(objects[18]!=null?(String)objects[18]:"");
				delivery.setIduSerialNum(objects[19]!=null?(String)objects[19]:"");
				delivery.setBucSerialNum(objects[20]!=null?(String)objects[20]:"");
				delivery.setLnbSerialNum(objects[21]!=null?(String)objects[21]:"");
				SoOrders soOrders = new SoOrders();
				soOrders.setContractNum(objects[22]!=null?(String)objects[22]:"");
				soOrders.setSoNumber(objects[23]!=null?(String)objects[23]:"");
				delivery.setSoNumber(soOrders.getSoNumber());
				delivery.setSoOrders(soOrders);
				delivery.setMonth(objects[24]!=null?(String)objects[24]:"");
				delivery.setChallanNum(objects[25]!=null?(String)objects[25]:"");
				delivery.setTaxInvoice(objects[26]!=null?(String)objects[26]:"");
				delivery.setAddate(objects[27]!=null?DateUtil.convertDateTimeToString((String)objects[27]):"");//
				delivery.setCustName(objects[28]!=null?(String)objects[28]:"");
				delivery.setState(objects[29]!=null?(String)objects[29]:"");
				delivery.setMaterialNum(objects[30]!=null?(String)objects[30]:"");
				delivery.setDispatchType(objects[31]!=null?(String)objects[31]:"");
				delivery.setModelDesc(objects[32]!=null?(String)objects[32]:"");
				delivery.setQuantity(objects[33]!=null?(String)objects[33]:"");
				delivery.setDeliveryId((Integer)objects[34]);
				delivery.setDeliveryStatusMstId(objects[35]!=null?(Integer)objects[35]:0);
				delivery.setPodStatusMstId(objects[36]!=null?(Integer)objects[36]:0);
				delivery.setShipToParty(objects[37]!=null?(String)objects[37]:"");
				delivery.setLocation(objects[38]!=null?(String)objects[38]:"");
				delivery.setModOfTransp(objects[39]!=null?(String)objects[39]:"");
				delivery.setValue(objects[40]!=null?(String)objects[40]:"");
				delivery.setContactPerson(objects[41]!=null?(String)objects[41]:"");
				delivery.setContactPersMob(objects[42]!=null?(String)objects[42]:"");
				delivery.setContactPersAddress(objects[43]!=null?(String)objects[43]:"");
				delivery.setWbsElement(objects[44]!=null?(String)objects[44]:"");
				delivery.setIsSalesReturn(objects[45]!=null?(String)objects[45]:"");
				delivery.setPlant(objects[46]!=null?(String)objects[46]:"");
				delivery.setChallanDate(objects[47]!=null?DateUtil.convertDateTimeToString((String)objects[47]):"");
				//objects[14]!=null?DateUtil.convertDateTimeToString((String)objects[14]):""
				deliveryList.add(delivery);
			}

			return deliveryList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<Delivery>();
		} finally {
			em.close();
		}
	}

	@Override
	public Delivery getDelByDelNum(String deliveryNum) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("Delivery.getDelByDelNum");
			query.setParameter(1, deliveryNum);
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			Delivery delivery = (Delivery) query.getSingleResult();
			return delivery;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new Delivery();
		} finally {
			em.close();
		}
	}

	@Override
	public DeliveryDTO mailForSalesReturn(DeliveryDTO deliveryDTO) {
		// TODO Auto-generated method stub
		DeliveryDTO deliveryDTONew = new DeliveryDTO();
		try {
			String queryString = "";
			queryString = "select distinct cc.pm_id,so.so_number,cc.child_contract_id,cc.contract_id,cc.con_start_date,cc.con_end_date,cc.sap_contract_num,del.delivery_id,del.addate,del.eddate,del.delivery_num,del.receiv_name,del.receiv_contact,del.contact_person,del.contact_pers_mob,del.contact_pers_address,shtp.customer_name,del.challan_num,del.tax_invoice,p.proposal_id,p.proposal_gen_id,am.user_mst_id as am_id,am.user_name as am_name,am.user_email as am_email,pm.user_name,pm.user_email,del.material_num,del.model_desc from [dbo].[delivery] del inner join [dbo].[so_orders] so	on (del.so_number = so.so_number and del.wbs_element = so.wbs_element) inner join [dbo].[child_contract] cc on so.contract_num = cc.sap_contract_num inner join [dbo].[contract] con on cc.contract_id = con.contract_id inner join [dbo].[proposal] p on con.proposal_id = p.proposal_id inner join [dbo].[user_mst] am on p.smowner_id = am.sm_owner_id inner join [dbo].[user_mst] pm on cc.pm_id = pm.user_mst_id inner join [dbo].[customer_sapmst] shtp	on (so.ship_to_party = shtp.customer_num and so.dist_channel = shtp.dist_channel and so.division = shtp.division and so.sales_org = shtp.sales_org ) left join [dbo].[material_sapmst] mat on (so.material_num = mat.material_num and so.plant = mat.plant) inner join delivery_status_mst dsm on del.delivery_status_mst_id=dsm.delivery_status_mst_id where del.delivery_id in ("+ deliveryDTO.getDeliveryIdList() +") ";
			if(true) {
			queryString = queryString + "  and dsm.del_status_code in ( 'DLV','WDA') and   (del.is_sales_return = 'N'or del.is_sales_return='' or del.is_sales_return=null) ";
			}
			query = em.createNativeQuery(queryString);
			query.setHint("org.hibernate.cacheable", Boolean.TRUE); 
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			List<CommonMailDTO> commonMailDTOList = new ArrayList<CommonMailDTO>();
			
			CommonMailDTO commonMailDTO=null;
			for (Object[] objects : resultList) {
				commonMailDTO = new CommonMailDTO();
				commonMailDTO.setProgramMgrId(objects[0]!=null?(Integer)objects[0]:null);
				commonMailDTO.setSoNumber((String) objects[1]);
				commonMailDTO.setChildContractId((Integer) objects[2]);
				commonMailDTO.setContractId((Integer) objects[3]);
				commonMailDTO.setConStartDate(DateUtil.convertDateTimeToString(objects[4].toString()));
				commonMailDTO.setConEndDate(DateUtil.convertDateTimeToString(objects[5].toString()));
				commonMailDTO.setSapContractNum((String) objects[6]);
				commonMailDTO.setDeliveryId((Integer) objects[7]);
				commonMailDTO.setAddate(DateUtil.convertDateTimeToString(objects[8].toString()));
				commonMailDTO.setEddate(DateUtil.convertDateTimeToString(objects[9].toString()));
				commonMailDTO.setDeliveryNum((String) objects[10]);
				commonMailDTO.setReceivName((String) objects[11]);
				commonMailDTO.setReceivContact((String) objects[12]);
				commonMailDTO.setContactPerson((String) objects[13]);
				commonMailDTO.setContactPersMob((String) objects[14]);
				commonMailDTO.setContactPersAddress((String) objects[15]);
				commonMailDTO.setCustomerName((String) objects[16]);
				commonMailDTO.setChallanNum((String) objects[17]);
				commonMailDTO.setTaxInvoice((String) objects[18]);
				commonMailDTO.setProposalId((Integer) objects[19]);
				commonMailDTO.setProposalGenId((String) objects[20]);
				commonMailDTO.setAccountMgrId(objects[21]!=null?(Integer)objects[21]:null);
				commonMailDTO.setAmName((String) objects[22]);
				commonMailDTO.setAmEmail((String) objects[23]);
				commonMailDTO.setPmName((String) objects[24]);
				commonMailDTO.setPmEmail((String) objects[25]);
				commonMailDTO.setMaterialNo((String) objects[26]);
				commonMailDTO.setMaterialDesc((String) objects[27]);
				
				commonMailDTOList.add(commonMailDTO);
			}
			if(commonMailDTOList != null) {
				deliveryDTONew.setCommonMailDTOList(commonMailDTOList);
			}
			return deliveryDTONew;
		} catch (Exception e) {
			// TODO: handle exception
			deliveryDTONew = new DeliveryDTO();
			e.printStackTrace();
			deliveryDTONew.setIsSRMailSent("Failed");
			return deliveryDTONew; 
		} finally {
			em.close();
		}
	}
	
	@Transactional
	@Override
	public void updateDelSalesReturn(Integer deliveryId) {
		query = em.createNativeQuery(" update delivery set is_sales_return='Y' where delivery_id= ?1 ");
		query.setParameter(1, deliveryId);
		query.executeUpdate();
	}

}
