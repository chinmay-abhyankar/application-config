package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the invoice_submission_alltypes_mst database table.
 * 
 */
@Entity
@Table(name="invoice_submission_alltypes_mst")
@NamedQueries({
	@NamedQuery(name="InvoiceSubmissionAlltypesMst.findAll", query="SELECT i FROM InvoiceSubmissionAlltypesMst i"),
	@NamedQuery(name="InvoiceSubmissionAlltypesMst.getTypes", query="SELECT i FROM InvoiceSubmissionAlltypesMst i WHERE type=:type"),
})

public class InvoiceSubmissionAlltypesMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private int typeid;

	@Column(length=2)
	private String actflag;

	@Column(length=50)
	private String label;

	@Column(length=50)
	private String type;

	@Column(length=50)
	private String value;

	public InvoiceSubmissionAlltypesMst() {
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public String getLabel() {
		return this.label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}