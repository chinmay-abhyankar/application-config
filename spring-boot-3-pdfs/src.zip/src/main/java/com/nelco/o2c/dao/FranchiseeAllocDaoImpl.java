package com.nelco.o2c.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.ConstantProperties;
import com.nelco.o2c.dto.FranchiseDropDownDTO;
import com.nelco.o2c.dto.FranchiseeAllocEngineerDTO;
import com.nelco.o2c.dto.FranchiseeAllocFormDTO;
import com.nelco.o2c.dto.FranchiseeDTO;
import com.nelco.o2c.dto.FranchiseeListFormDTO;
import com.nelco.o2c.dto.MaterialDTO;
import com.nelco.o2c.dto.SiteSurveyDTO;
import com.nelco.o2c.dto.UpdateFranchiseDTO;
import com.nelco.o2c.jsonbeanmap.EmailBean;
import com.nelco.o2c.jsonbeanmap.FranchiseAllocEmailDetails;
import com.nelco.o2c.model.ActivityTypeMst;
import com.nelco.o2c.model.ChildContract;
import com.nelco.o2c.model.Contract;
import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.model.Delivery;
import com.nelco.o2c.model.FranchiseAllocationTracker;
import com.nelco.o2c.model.FranchiseToState;
import com.nelco.o2c.model.FranchiseeAllocEngMst;
import com.nelco.o2c.model.FranchiseeAllocationMst;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.InstallationTypeMst;
import com.nelco.o2c.model.MaterialChildContract;
import com.nelco.o2c.model.MaterialContract;
import com.nelco.o2c.model.MaterialSapmst;
import com.nelco.o2c.model.SiteSurveyMaster;
import com.nelco.o2c.model.StateMst;
import com.nelco.o2c.model.StatusMst;
import com.nelco.o2c.model.TechnologyMaster;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.service.CommonMasterService;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;
import com.nelco.o2c.utility.SDCommonUtil;
@Repository
public class FranchiseeAllocDaoImpl implements FranchiseeAllocDao {
	@PersistenceContext
	EntityManager em;

	Query query;

	@Autowired
	HttpSession session;
	
	@Autowired
	CallSpDao callSpDao;
	
	@Autowired
	private Environment env;
	
	@Autowired
	EngVisitDao engVisitDao;
	
	@Autowired
	ConstantProperties constantProperties;
	
	@Autowired
	CommonMasterDao commonMasterDao;
	
	@Autowired
	DeliveryDao deliveryDao;
	
	@Autowired
	ConstantProperties properties;
	
	@Autowired
	SiteSurveyDao siteSurveyDao;
	
	@Autowired
	CommonMasterService commonMasterService;
 
	@Override
	public List<SiteSurveyMaster> getListSiteSurveyMaster(HttpServletRequest request) {
		
		query = em.createNamedQuery("SiteSurveyMaster.getSiteSurveyListAutoComplete");
		query.setMaxResults(10);
		query.setParameter(1, "%" + request.getParameter("input") + "%");
		query.setParameter(2, "%" + request.getParameter("input") + "%");
		List<SiteSurveyMaster> custList = (List<SiteSurveyMaster>) query.getResultList();
		return custList != null ? custList : new ArrayList<SiteSurveyMaster>();
	}

	@SuppressWarnings("unchecked")
	@Override
	public FranchiseeAllocFormDTO getFranchiseeFormMasters(FranchiseeAllocFormDTO franchiseeAllocFormDTO) {
		try {
			query = em.createNamedQuery("ActivityFranchiseProcMapping.findFranchiseDropDown");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<ActivityTypeMst> actitvityTypeMstList = (List<ActivityTypeMst>) query.getResultList();
			franchiseeAllocFormDTO.setLstActivityTypeMst(actitvityTypeMstList != null ? actitvityTypeMstList : new ArrayList<ActivityTypeMst>());
			
			query = em.createNamedQuery("InstallationTypeMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<InstallationTypeMst> installationTypeList = (List<InstallationTypeMst>) query.getResultList();
			franchiseeAllocFormDTO.setInstallationTypeList(installationTypeList != null ? installationTypeList : new ArrayList<InstallationTypeMst>());
			
			franchiseeAllocFormDTO.setTechList(engVisitDao.getTechList());
			franchiseeAllocFormDTO.setHubList(engVisitDao.getHubList());
			
		} finally {
			em.close();
		}
		return franchiseeAllocFormDTO;
	
	}

	@Override
	public List<FranchiseeListFormDTO> getDeliveryListForPMGT(FranchiseeAllocFormDTO franchiseeAllocFormDTO,HttpServletRequest request) {
		List<FranchiseeListFormDTO> lst = new ArrayList<FranchiseeListFormDTO>();
		int flag=0;
		
		String status = request.getParameter("status");
		
		String startDate = request.getParameter("start_date");
		String endDate = request.getParameter("end_date");
		String installationStatusId = request.getParameter("installationStatusId");
		String uniqId = request.getParameter("f_uniq_id");
		String soNumber = request.getParameter("so_number");
		
		String lQuery = "SELECT distinct d.delivery_id,d.delivery_num,oder.so_number , convert(varchar, addate, 105) as addate ,"
				+ " m.material_num,m.material_desc,m.material_sapmst_id ,cs.customer_name as ship_to_party,"
				+ " cs.customer_num as ship_to_party_id ,sold.customer_name as customer_name ,"
				+ " cs.street1,cs.street2,cs.street3,cs.street4,cs.street5,cs.pin,cs.city_name ,st.state_val,"
				+ " 'INDIA' as country ,f.id as f_id,f.uniq_id as f_uniq_id,f.delivery_id as f_delivery_id,"
				+ " f.delivery_num as f_delivery_num ,f.installation_address as f_installation_address ,"
				+ " f.site_contact_person as f_site_contact_person,f.contact_person_number as f_contact_person_number ,"
				+ " f.vsat_id as f_vsat_id,f.vsat_ip as f_vsat_ip,f.so_number as f_so_number ,"
				+ " f.site_survey_done as f_site_survey_done ,f.site_survey_uniq_id as f_site_survey_uniq_id,"
				+ " f.activity_type ,f.status as f_status,convert(varchar, f.creation_date, 105) as f_creation_date ,"
				+ " fe.id as eng_id,fe.name as eng_name,fe.mobile_no as eng_mobile_no, email_id as eng_email_id,"
				+ " fe.creation_date as eng_creation_date ,d.receiv_name,d.receiv_contact,s.status_code,"
				+ " s.status_name ,fr.franchise_mst_id,fr.franchise_name,f.site_survey_id,oder.item,convert(varchar, oder.creation_date, 105) as so_creation_date,"
				+ "cs.contact_number,convert(varchar, f.tentative_date, 105) as tentative_date,f.hub_mst_id,"
				+ "f.additional_remarks,f.technology_mst_id,itm.installation_type_val,"
				+ " ism.installation_status_mst_id,ism.installation_status_code,ism.installation_status_val,rs.old_shtp_address,f.sub_customer "
				+ " FROM so_orders oder inner join material_sapmst m "
				+ " on oder.material_num=m.material_num and oder.plant=m.plant and oder.sales_org=m.sales_org and oder.dist_channel = m.dist_channel "
				+ " inner join customer_sapmst cs on oder.ship_to_party=cs.customer_num "
				+ " and oder.dist_channel=cs.dist_channel and oder.division=cs.division "
				+ " and oder.sales_org=cs.sales_org "
				+ " inner join customer_sapmst sold on oder.sold_to_party=sold.customer_num "
				+ " and oder.dist_channel=sold.dist_channel and oder.division=sold.division "
				+ " and oder.sales_org=sold.sales_org "
				+ " inner join child_contract cc "
				+ " on oder.contract_num = cc.sap_contract_num "
				+ " left outer join delivery d on d.so_number=oder.so_number "
				+ " and d.wbs_element=oder.wbs_element "
				+ " left outer join delivery_status_mst ds on d.delivery_status_mst_id=ds.delivery_status_mst_id "
				+ " left outer join franchisee_allocation_mst f on oder.so_number = f.so_number "
				+ " and oder.item = f.item left outer join franchise_mst fr on f.franchisee_id=fr.franchise_mst_id "
				+ " left outer join installation_type_mst itm on f.installation_type_mst_id = itm.installation_type_mst_id "
				+ " left join status_mst s on f.status=s.status_mst_id inner join state_mst st on cs.region_code=st.state_code "
				+ " left outer join(select franchisee_alloc_id,id,franchisee_id,name,mobile_no,email_id,creation_date "
				+ " from (SELECT franchisee_alloc_id,id,franchisee_id,name,mobile_no,email_id,creation_date ,"
				+ " ROW_NUMBER() over(partition by franchisee_alloc_id order by creation_date desc) as cnt "
				+ " FROM franchisee_alloc_eng_mst group by franchisee_alloc_id,id,franchisee_id ,"
				+ " name,mobile_no,email_id,creation_date)tbl where cnt=1)fe on f.id=fe.franchisee_alloc_id "
				+ " left outer join (select franchisee_alloc_id,installation_status_mst_id,created_date from (select franchisee_alloc_id,installation_status_mst_id,created_date,ROW_NUMBER() over(partition by franchisee_alloc_id order by created_date desc) as cntvisit from fa_eng_visit_details group by franchisee_alloc_id,installation_status_mst_id,created_date) fav  where cntvisit=1) vtbl "
				+ " on f.id = vtbl.franchisee_alloc_id "
				+ " left outer join installation_status_mst ism "
				+ " on vtbl.installation_status_mst_id = ism.installation_status_mst_id "
				+" left outer join relocation_so rs on oder.reloc_so_req_id = rs.uniq_id "
				+ " where oder.item_category = 'TADV' and oder.material_num in ('120100004','120100463') and cc.pm_id = :pm_id and st.state_mst_id = isnull(:stateMstId,st.state_mst_id) "
				+(startDate!=null && !startDate.equalsIgnoreCase("null") && endDate!=null && !endDate.equalsIgnoreCase("null")?" and oder.creation_date between :start_date and :end_date  ":"")
				+(status!=null && !status.equalsIgnoreCase("null")?" and f.status = isnull(:status,f.status) ":"")
				+(installationStatusId!=null && !installationStatusId.equalsIgnoreCase("null")?" and ism.installation_status_mst_id = :installation_status_mst_id ":"")
				+(uniqId !=null && !uniqId.equalsIgnoreCase("null") ? " and f.uniq_id = isnull(:uniqId,f.uniq_id)":"")
				+(soNumber !=null && !soNumber.equalsIgnoreCase("null")? " and oder.so_number = isnull(:soNumber,oder.so_number)":"")
				+ " union "
				+ " SELECT distinct d.delivery_id,d.delivery_num,oder.so_number , convert(varchar, addate, 105) as addate ,"//query for spares so
				+ " m.material_num,m.material_desc,m.material_sapmst_id ,cs.customer_name as ship_to_party,"
				+ " cs.customer_num as ship_to_party_id ,sold.customer_name as customer_name ,"
				+ " cs.street1,cs.street2,cs.street3,cs.street4,cs.street5,cs.pin,cs.city_name ,st.state_val,"
				+ " 'INDIA' as country ,f.id as f_id,f.uniq_id as f_uniq_id,f.delivery_id as f_delivery_id,"
				+ " f.delivery_num as f_delivery_num ,f.installation_address as f_installation_address ,"
				+ " f.site_contact_person as f_site_contact_person,f.contact_person_number as f_contact_person_number ,"
				+ " f.vsat_id as f_vsat_id,f.vsat_ip as f_vsat_ip,f.so_number as f_so_number ,"
				+ " f.site_survey_done as f_site_survey_done ,f.site_survey_uniq_id as f_site_survey_uniq_id,"
				+ " f.activity_type ,f.status as f_status,convert(varchar, f.creation_date, 105) as f_creation_date ,"
				+ " fe.id as eng_id,fe.name as eng_name,fe.mobile_no as eng_mobile_no, email_id as eng_email_id,"
				+ " fe.creation_date as eng_creation_date ,d.receiv_name,d.receiv_contact,s.status_code,"
				+ " s.status_name ,fr.franchise_mst_id,fr.franchise_name,f.site_survey_id,oder.item,convert(varchar, oder.creation_date, 105) as so_creation_date,"
				+ "cs.contact_number,convert(varchar, f.tentative_date, 105) as tentative_date,f.hub_mst_id,"
				+ "f.additional_remarks,f.technology_mst_id,itm.installation_type_val,"
				+ " ism.installation_status_mst_id,ism.installation_status_code,ism.installation_status_val,rs.old_shtp_address,f.sub_customer "
				+ " FROM so_orders oder inner join material_sapmst m "
				+ " on oder.material_num=m.material_num and oder.plant=m.plant and oder.sales_org=m.sales_org and oder.dist_channel = m.dist_channel"
				+ " inner join customer_sapmst cs on oder.ship_to_party=cs.customer_num "
				+ " and oder.dist_channel=cs.dist_channel and oder.division=cs.division "
				+ " and oder.sales_org=cs.sales_org "
				+ " inner join customer_sapmst sold on oder.sold_to_party=sold.customer_num "
				+ " and oder.dist_channel=sold.dist_channel and oder.division=sold.division "
				+ " and oder.sales_org=sold.sales_org "
				+ " inner join spares_so_del_pgi ssdp "
				+ " on oder.so_number = ssdp.so_number and oder.item = ssdp.so_item "
				+ " inner join spares_so ss "
				+ " on ssdp.spares_req_id = ss.uniq_id "
				+ " left outer join delivery d on d.so_number=oder.so_number "
				+ " and d.wbs_element=oder.wbs_element "
				+ " left outer join delivery_status_mst ds on d.delivery_status_mst_id=ds.delivery_status_mst_id "
				+ " left outer join franchisee_allocation_mst f on oder.so_number = f.so_number "
				+ " and oder.item = f.item left outer join franchise_mst fr on f.franchisee_id=fr.franchise_mst_id "
				+ " left outer join installation_type_mst itm on f.installation_type_mst_id = itm.installation_type_mst_id "
				+ " left join status_mst s on f.status=s.status_mst_id inner join state_mst st on cs.region_code=st.state_code "
				+" left outer join relocation_so rs on oder.reloc_so_req_id = rs.uniq_id "
				+ " left outer join(select franchisee_alloc_id,id,franchisee_id,name,mobile_no,email_id,creation_date "
				+ " from (SELECT franchisee_alloc_id,id,franchisee_id,name,mobile_no,email_id,creation_date ,"
				+ " ROW_NUMBER() over(partition by franchisee_alloc_id order by creation_date desc) as cnt "
				+ " FROM franchisee_alloc_eng_mst group by franchisee_alloc_id,id,franchisee_id ,"
				+ " name,mobile_no,email_id,creation_date)tbl where cnt=1)fe on f.id=fe.franchisee_alloc_id "
				+ " left outer join (select franchisee_alloc_id,installation_status_mst_id,created_date from (select franchisee_alloc_id,installation_status_mst_id,created_date,ROW_NUMBER() over(partition by franchisee_alloc_id order by created_date desc) as cntvisit from fa_eng_visit_details group by franchisee_alloc_id,installation_status_mst_id,created_date) fav  where cntvisit=1) vtbl "
				+ " on f.id = vtbl.franchisee_alloc_id "
				+ " left outer join installation_status_mst ism "
				+ " on vtbl.installation_status_mst_id = ism.installation_status_mst_id "
				+ " where oder.item_category = 'TADV' and oder.material_num in ('120100004','120100463') and ss.created_by_id = :pm_id and st.state_mst_id = isnull(:stateMstId,st.state_mst_id) "
				+(startDate!=null && !startDate.equalsIgnoreCase("null") && endDate!=null && !endDate.equalsIgnoreCase("null")?" and oder.creation_date between :start_date and :end_date  ":"")
				+(status!=null && !status.equalsIgnoreCase("null")?" and f.status = isnull(:status,f.status) ":"")
				+(installationStatusId!=null && !installationStatusId.equalsIgnoreCase("null")?" and ism.installation_status_mst_id = :installation_status_mst_id ":"")
				+(uniqId !=null && !uniqId.equalsIgnoreCase("null") ? " and f.uniq_id = isnull(:uniqId,f.uniq_id)":"")
				+(soNumber !=null && !soNumber.equalsIgnoreCase("null")? " and oder.so_number = isnull(:soNumber,oder.so_number)":"")
				+ " union "
				+ " SELECT distinct d.delivery_id,d.delivery_num,oder.so_number , convert(varchar, addate, 105) as addate ,"//query for relocation so
				+ " m.material_num,m.material_desc,m.material_sapmst_id ,cs.customer_name as ship_to_party,"
				+ " cs.customer_num as ship_to_party_id ,sold.customer_name as customer_name ,"
				+ " cs.street1,cs.street2,cs.street3,cs.street4,cs.street5,cs.pin,cs.city_name ,st.state_val,"
				+ " 'INDIA' as country ,f.id as f_id,f.uniq_id as f_uniq_id,f.delivery_id as f_delivery_id,"
				+ " f.delivery_num as f_delivery_num ,f.installation_address as f_installation_address ,"
				+ " f.site_contact_person as f_site_contact_person,f.contact_person_number as f_contact_person_number ,"
				+ " f.vsat_id as f_vsat_id,f.vsat_ip as f_vsat_ip,f.so_number as f_so_number ,"
				+ " f.site_survey_done as f_site_survey_done ,f.site_survey_uniq_id as f_site_survey_uniq_id,"
				+ " f.activity_type ,f.status as f_status,convert(varchar, f.creation_date, 105) as f_creation_date ,"
				+ " fe.id as eng_id,fe.name as eng_name,fe.mobile_no as eng_mobile_no, email_id as eng_email_id,"
				+ " fe.creation_date as eng_creation_date ,d.receiv_name,d.receiv_contact,s.status_code,"
				+ " s.status_name ,fr.franchise_mst_id,fr.franchise_name,f.site_survey_id,oder.item,convert(varchar, oder.creation_date, 105) as so_creation_date,"
				+ " cs.contact_number,convert(varchar, f.tentative_date, 105) as tentative_date,f.hub_mst_id,"
				+ " f.additional_remarks,f.technology_mst_id,itm.installation_type_val,"
				+ " ism.installation_status_mst_id,ism.installation_status_code,ism.installation_status_val,rs.old_shtp_address,f.sub_customer "
				+ " FROM so_orders oder inner join material_sapmst m "
				+ " on oder.material_num=m.material_num and oder.plant=m.plant and oder.sales_org=m.sales_org and oder.dist_channel = m.dist_channel"
				+ " inner join customer_sapmst cs on oder.ship_to_party=cs.customer_num "
				+ " and oder.dist_channel=cs.dist_channel and oder.division=cs.division "
				+ " and oder.sales_org=cs.sales_org "
				+ " inner join customer_sapmst sold on oder.sold_to_party=sold.customer_num "
				+ " and oder.dist_channel=sold.dist_channel and oder.division=sold.division "
				+ " and oder.sales_org=sold.sales_org "
				/*+ " inner join relocation_so rs "
				+ " on oder.reloc_so_req_id = rs.uniq_id "*/
				+ " left outer join delivery d on d.so_number=oder.so_number "
				+ " and d.wbs_element=oder.wbs_element "
				+ " left outer join delivery_status_mst ds on d.delivery_status_mst_id=ds.delivery_status_mst_id "
				+ " left outer join franchisee_allocation_mst f on oder.so_number = f.so_number "
				+ " and oder.item = f.item left outer join franchise_mst fr on f.franchisee_id=fr.franchise_mst_id "
				+ " left outer join installation_type_mst itm on f.installation_type_mst_id = itm.installation_type_mst_id "
				+ " left join status_mst s on f.status=s.status_mst_id inner join state_mst st on cs.region_code=st.state_code "
				+" left outer join relocation_so rs on oder.reloc_so_req_id = rs.uniq_id "
				+ " left outer join(select franchisee_alloc_id,id,franchisee_id,name,mobile_no,email_id,creation_date "
				+ " from (SELECT franchisee_alloc_id,id,franchisee_id,name,mobile_no,email_id,creation_date ,"
				+ " ROW_NUMBER() over(partition by franchisee_alloc_id order by creation_date desc) as cnt "
				+ " FROM franchisee_alloc_eng_mst group by franchisee_alloc_id,id,franchisee_id ,"
				+ " name,mobile_no,email_id,creation_date)tbl where cnt=1)fe on f.id=fe.franchisee_alloc_id "
				+ " left outer join (select franchisee_alloc_id,installation_status_mst_id,created_date from (select franchisee_alloc_id,installation_status_mst_id,created_date,ROW_NUMBER() over(partition by franchisee_alloc_id order by created_date desc) as cntvisit from fa_eng_visit_details group by franchisee_alloc_id,installation_status_mst_id,created_date) fav  where cntvisit=1) vtbl "
				+ " on f.id = vtbl.franchisee_alloc_id "
				+ " left outer join installation_status_mst ism "
				+ " on vtbl.installation_status_mst_id = ism.installation_status_mst_id "
				+ " where oder.item_category = 'TADV' and oder.material_num in ('120100004','120100463','120100163') and rs.created_by = :pm_id and st.state_mst_id = isnull(:stateMstId,st.state_mst_id) "
				+ (startDate!=null && !startDate.equalsIgnoreCase("null") && endDate!=null && !endDate.equalsIgnoreCase("null")?" and oder.creation_date between :start_date and :end_date  ":"")
				+(status!=null && !status.equalsIgnoreCase("null")?" and f.status = isnull(:status,f.status) ":"")
				+(installationStatusId!=null && !installationStatusId.equalsIgnoreCase("null")?" and ism.installation_status_mst_id = :installation_status_mst_id ":"")
				+(uniqId !=null && !uniqId.equalsIgnoreCase("null") ? " and f.uniq_id = isnull(:uniqId,f.uniq_id)":"")
				+(soNumber !=null && !soNumber.equalsIgnoreCase("null")? " and oder.so_number = isnull(:soNumber,oder.so_number)":"");
		FranchiseeListFormDTO bean = null;

		query = em.createNativeQuery(lQuery);
		
		query.setParameter("pm_id", Integer.valueOf(request.getParameter("userMstId")));
		
		if(startDate!=null && !startDate.equalsIgnoreCase("null") && endDate!=null && !endDate.equalsIgnoreCase("null")) {
			query.setParameter("start_date", DateUtil.convertDateToSqlDate(startDate));
			query.setParameter("end_date", DateUtil.convertDateToSqlDate(endDate)+Constants.MAXDAYTIME);
		}
		
		//query.setParameter("stateMstId", Integer.valueOf(request.getParameter("stateMstId"))); commented to give all state selection
		String stateId = request.getParameter("stateMstId");
		query.setParameter("stateMstId", stateId!=null && !stateId.equalsIgnoreCase("null")?Integer.valueOf(stateId):null);
		//setting parameter for installation status
		if(installationStatusId!=null && !installationStatusId.equalsIgnoreCase("null")) {
			query.setParameter("installation_status_mst_id", Integer.valueOf(installationStatusId));
		}
		
		if(status!=null && !"null".equalsIgnoreCase(status)) {
			query.setParameter("status",status!=null && !status.equalsIgnoreCase("null") ?Integer.valueOf(status):null);
		}
		
			if(uniqId!=null && !"null".equalsIgnoreCase(uniqId))
			query.setParameter("uniqId", uniqId!=null  && !uniqId.equalsIgnoreCase("null")?uniqId:null);
			
			if(soNumber!=null && !"null".equalsIgnoreCase(soNumber))
			query.setParameter("soNumber", soNumber!=null  && !soNumber.equalsIgnoreCase("null")?soNumber:null);
		
		
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			flag++;
			bean = new FranchiseeListFormDTO();
			bean.setDelivery_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setDelivery_num(SDCommonUtil.convertNullToBlank(String.valueOf(o[1]), false));
			bean.setSo_number(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
			bean.setAddate(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
			bean.setMaterial_num(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
			bean.setMaterial_desc(SDCommonUtil.convertNullToBlank(String.valueOf(o[5]), false));
			bean.setMaterial_sapmst_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false));
			bean.setShip_to_party(SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false));
			bean.setShip_to_party_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[8]), false));
			bean.setCustomer_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[9]), false));
			bean.setStreet1(SDCommonUtil.convertNullToBlank(String.valueOf(o[10]), false));
			bean.setStreet2(SDCommonUtil.convertNullToBlank(String.valueOf(o[11]), false));
			bean.setStreet3(SDCommonUtil.convertNullToBlank(String.valueOf(o[12]), false));
			bean.setStreet4(SDCommonUtil.convertNullToBlank(String.valueOf(o[13]), false));
			bean.setStreet5(SDCommonUtil.convertNullToBlank(String.valueOf(o[14]), false));
			bean.setPin(SDCommonUtil.convertNullToBlank(String.valueOf(o[15]), false));
			bean.setCity_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[16]), false));
			bean.setState_val(SDCommonUtil.convertNullToBlank(String.valueOf(o[17]), false));
			bean.setCountry(SDCommonUtil.convertNullToBlank(String.valueOf(o[18]), false));
			bean.setF_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[19]), false));
			bean.setF_uniq_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[20]), false));
			bean.setF_delivery_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[21]), false));
			bean.setF_delivery_num(SDCommonUtil.convertNullToBlank(String.valueOf(o[22]), false));
			bean.setF_installation_address(SDCommonUtil.convertNullToBlank(String.valueOf(o[23]), false));
			bean.setF_site_contact_person(SDCommonUtil.convertNullToBlank(String.valueOf(o[24]), false));
			bean.setF_contact_person_number(SDCommonUtil.convertNullToBlank(String.valueOf(o[25]), false));
			bean.setF_vsat_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[26]), false));
			bean.setF_vsat_ip(SDCommonUtil.convertNullToBlank(String.valueOf(o[27]), false));
			bean.setF_so_number(SDCommonUtil.convertNullToBlank(String.valueOf(o[28]), false));
			bean.setF_site_survey_done(SDCommonUtil.convertNullToBlank(String.valueOf(o[29]), false));
			bean.setF_site_survey_uniq_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[30]), false));
			bean.setActivity_type(SDCommonUtil.convertNullToBlank(String.valueOf(o[31]), false));
			bean.setF_status(SDCommonUtil.convertNullToBlank(String.valueOf(o[32]), false));
			bean.setF_creation_date(SDCommonUtil.convertNullToBlank(String.valueOf(o[33]), false));
			bean.setEng_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[34]), false));
			bean.setEng_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[35]), false));
			bean.setEng_mobile_no(SDCommonUtil.convertNullToBlank(String.valueOf(o[36]), false));
			bean.setEng_email_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[37]), false));
			bean.setEng_creation_date(SDCommonUtil.convertNullToBlank(String.valueOf(o[38]), false));
			bean.setReceive_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[39]), false));
			bean.setReceive_contact(SDCommonUtil.convertNullToBlank(String.valueOf(o[40]), false));
			bean.setStatus_code(SDCommonUtil.convertNullToBlank(String.valueOf(o[41]), false));
			bean.setStatus_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[42]), false));
			bean.setFranchisee_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[43]), false));
			bean.setFranchisee_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[44]), false));
			bean.setSiteSurveyId(SDCommonUtil.convertNullToBlank(String.valueOf(o[45]), false));
			bean.setItem(SDCommonUtil.convertNullToBlank(String.valueOf(o[46]), false));
			bean.setSoCreationDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[47]), false));
			bean.setContactNumber(SDCommonUtil.convertNullToBlank(String.valueOf(o[48]), false));
			bean.setTentativeDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[49]), false));
			bean.setHubMstId(o[50]!=null?(Integer)o[50]:null);
			bean.setAdditionalRemarks(SDCommonUtil.convertNullToBlank(String.valueOf(o[51]), false));
			bean.setTechnologyMstId(o[52]!=null?(Integer)o[52]:null);
			bean.setInstallationTypeVal(SDCommonUtil.convertNullToBlank(String.valueOf(o[53]), false));
			bean.setInstallationStatusMstId(o[54]!=null?(Integer)o[54]:null);
			bean.setInstallationStatusCode(SDCommonUtil.convertNullToBlank(String.valueOf(o[55]), false));
			bean.setInstallationStatusVal(SDCommonUtil.convertNullToBlank(String.valueOf(o[56]), false));
			bean.setOldShtpAddress(SDCommonUtil.convertNullToBlank(String.valueOf(o[57]), false));
			bean.setSubCustomer(SDCommonUtil.convertNullToBlank(String.valueOf(o[58]), false));
			lst.add(bean);
		}
		if(flag>0){
			return lst;	
		}else{
			//lst.add(new FranchiseeListFormDTO());
			return lst;
		}
	}

	@Override
	public List<FranchiseeListFormDTO> getDeliveryById(HttpServletRequest request) {
		List<FranchiseeListFormDTO> lst = new ArrayList<FranchiseeListFormDTO>();
		String lQuery = "SELECT distinct d.delivery_id,d.delivery_num,oder.so_number"+""
				+", convert(varchar, addate, 105) as addate"		
				+",m.material_num,m.material_desc,m.material_sapmst_id"
				+",cs.customer_name as ship_to_party,cs.customer_num as ship_to_party_id"
				+",sold.customer_name as customer_name"
				+",cs.street1,cs.street2,cs.street3,cs.street4,cs.street5,cs.pin,cs.city_name"
				+",st.state_val,'INDIA' as country"
				+",f.id as f_id,f.uniq_id as f_uniq_id,f.delivery_id as f_delivery_id,f.delivery_num as f_delivery_num"
				+",f.installation_address as f_installation_address"
				+",f.site_contact_person as f_site_contact_person,f.contact_person_number as f_contact_person_number"
				+",f.vsat_id as f_vsat_id,f.vsat_ip as f_vsat_ip,f.so_number as f_so_number"
				+",f.site_survey_done as f_site_survey_done"
				+",f.site_survey_uniq_id as f_site_survey_uniq_id,f.activity_type"
				+",f.status as f_status,convert(varchar, f.creation_date, 105) as f_creation_date"
				+",fe.id as eng_id,fe.name as eng_name,fe.mobile_no as eng_mobile_no,"
				 +" email_id as eng_email_id,fe.creation_date as eng_creation_date"
				 +",d.receiv_name,d.receiv_contact,s.status_code,s.status_name"
				 +",fr.franchise_mst_id,fr.franchise_name,f.site_survey_id,f.installation_type_mst_id,oder.item,convert(varchar, oder.creation_date, 105) as so_creation_date,cs.contact_number,convert(varchar, f.tentative_date, 105) as tentative_date,f.hub_mst_id,f.additional_remarks,f.technology_mst_id,rs.old_shtp_address,f.sub_customer  "
				+" FROM so_orders oder "
				+" inner join material_sapmst m on oder.material_num=m.material_num and oder.plant=m.plant and oder.dist_channel = m.dist_channel "
				+" and oder.sales_org=m.sales_org "
				+" inner join customer_sapmst cs on oder.ship_to_party=cs.customer_num"
				+" and oder.dist_channel=cs.dist_channel"
				+" and oder.division=cs.division"
				+" and oder.sales_org=cs.sales_org "
				+ " inner join customer_sapmst sold on oder.ship_to_party=sold.customer_num "
				+" and oder.dist_channel=sold.dist_channel"
				+" and oder.division=sold.division"
				+" and oder.sales_org=sold.sales_org "
				+ "left outer join delivery d  on d.so_number=oder.so_number and d.wbs_element=oder.wbs_element"
				+" left outer join delivery_status_mst ds on d.delivery_status_mst_id=ds.delivery_status_mst_id "
				+" left outer join franchisee_allocation_mst f on oder.so_number = f.so_number and oder.item = f.item "
				+" left outer join franchise_mst fr on f.franchisee_id=fr.franchise_mst_id"
				+" left join status_mst s on f.status=s.status_mst_id"
				+" inner join state_mst st on cs.region_code=st.state_code"
				+" left outer join franchisee_allocation_mst fa on d.delivery_id=f.delivery_id "
				+" left outer join relocation_so rs on oder.reloc_so_req_id = rs.uniq_id "
				+" left outer join (select franchisee_alloc_id,id,franchisee_id,name,mobile_no,email_id,creation_date from"
				+"(SELECT franchisee_alloc_id,id,franchisee_id,name,mobile_no,email_id,creation_date"
				+",ROW_NUMBER() over(partition by franchisee_alloc_id order by creation_date desc) as cnt"
				+" FROM franchisee_alloc_eng_mst  group by franchisee_alloc_id,id,franchisee_id"
				+",name,mobile_no,email_id,creation_date)tbl"
				+" where cnt=1)fe on f.id=fe.franchisee_alloc_id"
				+" where f.id=:id ";
		int flag=0;
		FranchiseeListFormDTO bean = null;
		query = em.createNativeQuery(lQuery);	
		query.setParameter("id", request.getParameter("franchisee_alloc_id"));
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			flag++;
			bean = new FranchiseeListFormDTO();
			bean.setDelivery_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setDelivery_num(SDCommonUtil.convertNullToBlank(String.valueOf(o[1]), false));
			bean.setSo_number(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
			bean.setAddate(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
			bean.setMaterial_num(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
			bean.setMaterial_desc(SDCommonUtil.convertNullToBlank(String.valueOf(o[5]), false));
			bean.setMaterial_sapmst_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false));
			bean.setShip_to_party(SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false));
			bean.setShip_to_party_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[8]), false));
			bean.setCustomer_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[9]), false));
			bean.setStreet1(SDCommonUtil.convertNullToBlank(String.valueOf(o[10]), false));
			bean.setStreet2(SDCommonUtil.convertNullToBlank(String.valueOf(o[11]), false));
			bean.setStreet3(SDCommonUtil.convertNullToBlank(String.valueOf(o[12]), false));
			bean.setStreet4(SDCommonUtil.convertNullToBlank(String.valueOf(o[13]), false));
			bean.setStreet5(SDCommonUtil.convertNullToBlank(String.valueOf(o[14]), false));
			bean.setPin(SDCommonUtil.convertNullToBlank(String.valueOf(o[15]), false));
			bean.setCity_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[16]), false));
			bean.setState_val(SDCommonUtil.convertNullToBlank(String.valueOf(o[17]), false));
			bean.setCountry(SDCommonUtil.convertNullToBlank(String.valueOf(o[18]), false));
			bean.setF_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[19]), false));
			bean.setF_uniq_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[20]), false));
			bean.setF_delivery_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[21]), false));
			bean.setF_delivery_num(SDCommonUtil.convertNullToBlank(String.valueOf(o[22]), false));
			bean.setF_installation_address(SDCommonUtil.convertNullToBlank(String.valueOf(o[23]), false));
			bean.setF_site_contact_person(SDCommonUtil.convertNullToBlank(String.valueOf(o[24]), false));
			bean.setF_contact_person_number(SDCommonUtil.convertNullToBlank(String.valueOf(o[25]), false));
			bean.setF_vsat_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[26]), false));
			bean.setF_vsat_ip(SDCommonUtil.convertNullToBlank(String.valueOf(o[27]), false));
			bean.setF_so_number(SDCommonUtil.convertNullToBlank(String.valueOf(o[28]), false));
			bean.setF_site_survey_done(SDCommonUtil.convertNullToBlank(String.valueOf(o[29]), false));
			bean.setF_site_survey_uniq_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[30]), false));
			bean.setActivity_type(SDCommonUtil.convertNullToBlank(String.valueOf(o[31]), false));
			bean.setF_status(SDCommonUtil.convertNullToBlank(String.valueOf(o[32]), false));
			bean.setF_creation_date(SDCommonUtil.convertNullToBlank(String.valueOf(o[33]), false));
			bean.setEng_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[34]), false));
			bean.setEng_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[35]), false));
			bean.setEng_mobile_no(SDCommonUtil.convertNullToBlank(String.valueOf(o[36]), false));
			bean.setEng_email_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[37]), false));
			bean.setEng_creation_date(SDCommonUtil.convertNullToBlank(String.valueOf(o[38]), false));
			bean.setReceive_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[39]), false));
			bean.setReceive_contact(SDCommonUtil.convertNullToBlank(String.valueOf(o[40]), false));
			bean.setStatus_code(SDCommonUtil.convertNullToBlank(String.valueOf(o[41]), false));
			bean.setStatus_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[42]), false));
			bean.setFranchisee_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[43]), false));
			bean.setFranchisee_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[44]), false));
			bean.setSiteSurveyId(SDCommonUtil.convertNullToBlank(String.valueOf(o[45]), false));
			bean.setInstallationTypeMstId(o[46]!=null?(Integer)o[46]:null);
			bean.setItem(SDCommonUtil.convertNullToBlank(String.valueOf(o[47]), false));
			bean.setSoCreationDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[48]), false));
			bean.setContactNumber(SDCommonUtil.convertNullToBlank(String.valueOf(o[49]), false));
			bean.setTentativeDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[50]), false));
			bean.setHubMstId(o[51]!=null?(Integer)o[51]:null);
			bean.setAdditionalRemarks(SDCommonUtil.convertNullToBlank(String.valueOf(o[52]), false));
			bean.setTechnologyMstId(o[53]!=null?(Integer)o[53]:null);
			bean.setOldShtpAddress(SDCommonUtil.convertNullToBlank(String.valueOf(o[54]), false));
			bean.setSubCustomer(SDCommonUtil.convertNullToBlank(String.valueOf(o[55]), false));
			lst.add(bean);
		}
		if(flag>0){
			return lst;	
		}else{
			lst.add(new FranchiseeListFormDTO());
			return lst;
		}
		
	}

	@Override
	public FranchiseeAllocationMst saveFranchiseeAllocation(FranchiseeDTO franchiseeDTO) {
		String uniq_id = "";
		System.out.println("Id:"+franchiseeDTO.getId());
		System.out.println("Uniq Id:"+franchiseeDTO.getUniq_id());
		if (franchiseeDTO.getId() == null) {
			synchronized (this) {
				Integer maxProposalNumber = getCurrentDayCountSiteSurveyMaster();
				uniq_id = "FRA_ALL_" + (DateUtil.getCurrentISTDateAsString(DateUtil.SIMPLE_DATE_FORMAT)
						.replace("-", "_").concat("_").concat(maxProposalNumber.toString()));
			}
			franchiseeDTO.setUniq_id(uniq_id);
		}else{
			franchiseeDTO.setUniq_id(franchiseeDTO.getUniq_id());
		}
		FranchiseeAllocationMst franchiseeAllocationMst=new FranchiseeAllocationMst();
		FranchiseeAllocationMst franchiseeAllocationMstNew = new FranchiseeAllocationMst();
		franchiseeAllocationMst.setId(franchiseeDTO.getId());
		franchiseeAllocationMst.setActivityType(franchiseeDTO.getActivityType());
		franchiseeAllocationMst.setContactPersonNumber(franchiseeDTO.getContactPersonNumber());
		franchiseeAllocationMst.setCreationDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		franchiseeAllocationMst.setDelivery_id(franchiseeDTO.getDeliveryId());
		franchiseeAllocationMst.setDeliveryNum(franchiseeDTO.getDeliveryNum());		
		franchiseeAllocationMst.setInstallationAddress(franchiseeDTO.getInstallationAddress());
		franchiseeAllocationMst.setSiteContactPerson(franchiseeDTO.getSiteContactPerson());
		franchiseeAllocationMst.setSiteSurveyDone(franchiseeDTO.getSiteSurveyDone());
		franchiseeAllocationMst.setSiteSurveyUniqId(franchiseeDTO.getSiteSurveyUniqId());
		franchiseeAllocationMst.setSoNumber(franchiseeDTO.getSoNumber());
		franchiseeAllocationMst.setSite_survey_id(franchiseeDTO.getSite_survey_id());
		franchiseeAllocationMst.setStatus(34);
		franchiseeAllocationMst.setUniqId(franchiseeDTO.getUniq_id());
		franchiseeAllocationMst.setUser_id(franchiseeDTO.getUser_id());
		franchiseeAllocationMst.setVsatId(franchiseeDTO.getVsatId());
		franchiseeAllocationMst.setVsatIp(franchiseeDTO.getVsatIp());
		franchiseeAllocationMst.setInstallationTypeMstId(franchiseeDTO.getInstallationTypeMstId());
		franchiseeAllocationMst.setItem(franchiseeDTO.getItem());
		franchiseeAllocationMst.setTentativeDate(DateUtil.convertDateToSqlDate(franchiseeDTO.getTentativeDate()));
		franchiseeAllocationMst.setHubMstId(franchiseeDTO.getHubMstId());
		franchiseeAllocationMst.setAdditionalRemarks(franchiseeDTO.getAdditionalRemarks());
		franchiseeAllocationMst.setTechnologyMstId(franchiseeDTO.getTechnologyMstId());
		franchiseeAllocationMst.setSubCustomer(franchiseeDTO.getSubCustomer());
		
		franchiseeAllocationMstNew = em.merge(franchiseeAllocationMst);
		  if (franchiseeAllocationMst.getId() == null) {
			  em.refresh(franchiseeAllocationMstNew); 
			  }
		return franchiseeAllocationMstNew;
	}
		
	public Integer getCurrentDayCountSiteSurveyMaster() {
		try {
			String currentDate = DateUtil.getCurrentISTDateOnlyAsString(DateUtil.DATE_ONLY_FORMAT_MSSQL);
			query = em.createNamedQuery("FranchiseeAllocationMst.getCurrentDayMaxCount");
			query.setParameter(1, currentDate);
			query.setParameter(2, currentDate + " 23:59:59.999");
			Long maxNumber = (Long) query.getSingleResult();
			return maxNumber.intValue();
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public FranchiseeAllocationMst submitFranchiseeAllocation(FranchiseeDTO franchiseeDTO) {
		String uniq_id = "";
		FranchiseeAllocationMst franchiseeAllocationMst=new FranchiseeAllocationMst();
		franchiseeAllocationMst.setId(franchiseeDTO.getId());
		franchiseeAllocationMst.setSite_survey_id(franchiseeDTO.getSite_survey_id());		
		franchiseeAllocationMst.setActivityType(franchiseeDTO.getActivityType());
		franchiseeAllocationMst.setContactPersonNumber(franchiseeDTO.getContactPersonNumber());
		franchiseeAllocationMst.setCreationDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		franchiseeAllocationMst.setDelivery_id(franchiseeDTO.getDeliveryId());
		franchiseeAllocationMst.setDeliveryNum(franchiseeDTO.getDeliveryNum());		
		franchiseeAllocationMst.setInstallationAddress(franchiseeDTO.getInstallationAddress());
		franchiseeAllocationMst.setSiteContactPerson(franchiseeDTO.getSiteContactPerson());
		franchiseeAllocationMst.setSiteSurveyDone(franchiseeDTO.getSiteSurveyDone());
		franchiseeAllocationMst.setSiteSurveyUniqId(franchiseeDTO.getSiteSurveyUniqId());
		franchiseeAllocationMst.setSoNumber(franchiseeDTO.getSoNumber());
		franchiseeAllocationMst.setUser_id(franchiseeDTO.getUser_id());
		franchiseeAllocationMst.setUniqId(franchiseeDTO.getUniq_id());
		franchiseeAllocationMst.setStatus(35);		
		franchiseeAllocationMst.setVsatId(franchiseeDTO.getVsatId());
		franchiseeAllocationMst.setVsatIp(franchiseeDTO.getVsatIp());
		franchiseeAllocationMst.setInstallationTypeMstId(franchiseeDTO.getInstallationTypeMstId());
		franchiseeAllocationMst.setItem(franchiseeDTO.getItem());
		franchiseeAllocationMst.setTentativeDate(DateUtil.convertDateToSqlDate(franchiseeDTO.getTentativeDate()));
		franchiseeAllocationMst.setHubMstId(franchiseeDTO.getHubMstId());
		franchiseeAllocationMst.setAdditionalRemarks(franchiseeDTO.getAdditionalRemarks());
		franchiseeAllocationMst.setTechnologyMstId(franchiseeDTO.getTechnologyMstId());
		franchiseeAllocationMst.setSubCustomer(franchiseeDTO.getSubCustomer());
		
		franchiseeAllocationMst = em.merge(franchiseeAllocationMst);
		
		// email sending for franchise allocation begins
		query = em.createNativeQuery("select ur.user_id,u.user_name, "
				+ " u.user_email,fzm.franchise_zone_email "
				+ " from franchisee_allocation_mst f  "
				+ " inner join so_orders so "
				+ " on (f.so_number = so.so_number and f.item = so.item) "
				+ " inner join customer_sapmst cs "
				+ " on (so.ship_to_party = cs.customer_num and so.dist_channel = cs.dist_channel "
				+ " and so.division = cs.division and so.sales_org = cs.sales_org) "
				+ " inner join state_mst sm "
				+ " on cs.region_code = sm.state_code "
				+ " inner join user_to_region_mst ur "
				+ " on sm.state_mst_id = ur.region_code "
				+ " inner join cs_user_franchise_zone_mapping_mst cufzm "
				+ " on ur.user_id = cufzm.user_mst_id "
				+ " inner join user_mst u "
				+ " on ur.user_id = u.user_mst_id "
				+ " inner join franchise_zone_mst fzm "
				+ " on cufzm.franchise_zone_mst_id = fzm.franchise_zone_mst_id "
				+ " inner join role_mst r "
				+ " on r.role_mst_id = u.role_mst_id "
				+ " left outer join delivery d "
				+ " on f.delivery_id = d.delivery_id "
				+ " where r.role_cd in ('SUPEXE') and  f.id = "+franchiseeDTO.getId());
		List<Object[]> result = (List<Object[]>) query.getResultList();
		String csUserName = null;
		String csEmail = null;
		Integer userId = null;
		String zoneEmail = null;
		for (Object[] objects : result) {
			userId = (Integer)objects[0];
			csUserName = (String)objects[1];
			csEmail = (csEmail==null?"":csEmail+";") + (String)objects[2];
			zoneEmail = (String)objects[3];
		}
		
		Integer requestUserId = franchiseeDTO.getUser_id();
		query = em.createNamedQuery("UserMst.getUserEmailById");
		query.setParameter(1, requestUserId);
		List<UserMst> userList = (List<UserMst>) query.getResultList();
		
		//query to get franchise allocation details begins
		query = em.createNativeQuery(" select so.sold_to_party,stp.customer_name,so.ship_to_party,"
				+ " COALESCE(shtp.street1,'')+' '+COALESCE(shtp.street2,'') +' '+COALESCE(shtp.street3,'')+' '+COALESCE(shtp.street4,'') +' '+COALESCE(shtp.street5,'')+' '+COALESCE(shtp.city_name,'') +'-'+COALESCE(shtp.pin,'')+' '+COALESCE(sm.state_val,'')+','+COALESCE(cm.country_val,'') as shtp_address, "
				+ " fam.so_number,d.delivery_num,fam.installation_address,itm.installation_type_val,"
				+ " fam.vsat_id,fam.vsat_ip,fam.contact_person_number,fam.site_contact_person,"
				+ " fam.additional_remarks,tm.value,hm.hub_desc,fam.sub_customer "
				+ " from franchisee_allocation_mst fam inner join installation_type_mst itm on fam.installation_type_mst_id = itm.installation_type_mst_id inner join so_orders so on fam.so_number = so.so_number and fam.item = so.item inner join customer_sapmst shtp on so.ship_to_party = shtp.customer_num and so.dist_channel = shtp.dist_channel and so.division = shtp.division and so.sales_org = shtp.sales_org inner join customer_sapmst stp on so.sold_to_party = stp.customer_num and so.dist_channel = stp.dist_channel and so.division = stp.division and so.sales_org = stp.sales_org inner join country_mst cm on shtp.country_code = cm.country_code inner join state_mst sm on shtp.region_code = sm.state_code left outer join delivery d on fam.delivery_id = d.delivery_id left outer join hub_mst hm on fam.hub_mst_id = hm.hub_mst_id left outer join technology_mst tm on fam.technology_mst_id = tm.id " + 
				" where fam.id = :famId ");
		query.setParameter("famId", franchiseeAllocationMst.getId());
		List<Object[]> soDetailsResult = (List<Object[]>) query.getResultList();
		FranchiseAllocEmailDetails emailDetails = new FranchiseAllocEmailDetails();
		for (Object[] objects : soDetailsResult) {
			emailDetails.setSoldToParty(objects[0]!=null?(String)objects[0]:"");
			emailDetails.setCustomerName(objects[1]!=null?(String)objects[1]:"");
			emailDetails.setShipToParty(objects[2]!=null?(String)objects[2]:"");
			emailDetails.setShtpAddress(objects[3]!=null?(String)objects[3]:"");
			emailDetails.setSoNumber(objects[4]!=null?(String)objects[4]:"");
			emailDetails.setDeliverNumber(objects[5]!=null?(String)objects[5]:"");
			emailDetails.setAdditionalAddress(objects[6]!=null?(String)objects[6]:"");
			emailDetails.setInstallationType(objects[7]!=null?(String)objects[7]:"");
			emailDetails.setVsatId(objects[8]!=null?(String)objects[8]:"");
			emailDetails.setVsatIp(objects[9]!=null?(String)objects[9]:"");
			emailDetails.setContactPersonNumber(objects[10]!=null?(String)objects[10]:"");
			emailDetails.setSiteContactPerson(objects[11]!=null?(String)objects[11]:"");
			emailDetails.setAdditionalRemarks(objects[12]!=null?(String)objects[12]:"");
			emailDetails.setTechnology(objects[13]!=null?(String)objects[13]:"");
			emailDetails.setHubDesc(objects[14]!=null?(String)objects[14]:"");
			emailDetails.setSubCustomer(objects[15]!=null?(String)objects[15]:"");
		}
		//query to get franchise allocation details ends
		
		if(userId!=null) {
			EmailBean emailBean = new EmailBean();
			emailBean.setToMail((csEmail!=null?csEmail+";":"")+(zoneEmail!=null?zoneEmail:""));
			
			if(userList!=null && userList.size()>0) {
				emailBean.setCopyRecepients(userList.get(0).getUserEmail());
			}
			emailBean.setSubject("I&C Request raised : " + franchiseeDTO.getUniq_id());
			emailBean.setEmailBody("Dear User,"
					+ "<br>I&C Request has been raised with id : " + franchiseeDTO.getUniq_id() + "."
					+ "<br>So Number : " + franchiseeDTO.getSoNumber()
					+ "<br>Customer Name : " + emailDetails.getCustomerName()
					+ "<br>Sub Customer Name : " + emailDetails.getSubCustomer()
					+ "<br>Ship To Party Address : " + emailDetails.getShtpAddress()
					+ "<br>Additional Address : " + emailDetails.getAdditionalAddress()
					+ "<br>Installation Type : " + emailDetails.getInstallationType()
					+ "<br>VSAT ID : " + emailDetails.getVsatId()
					+ "<br>IP : " + emailDetails.getVsatIp()
					+ "<br>Contact Person : " + emailDetails.getSiteContactPerson()
					+ "<br>Contact Person Number : " + emailDetails.getContactPersonNumber()
					+ "<br>Hub : " + emailDetails.getHubDesc()
					+ "<br>Additional Remarks : " + emailDetails.getAdditionalRemarks()
					+ "<br>Technology : " + emailDetails.getTechnology()
					+ "<br>Please login to know more." + "<br> Click here to login :  <a href="
					+ env.getProperty("emaillink") + ">O2C portal link</a>  " + "<br><br>Sincerely");
			callSpDao.sendEmail(emailBean);
		}
		
		// email sending for franchise allocation ends
		
		return franchiseeAllocationMst;		
	}

	@Override
	public List<FranchiseeListFormDTO> getFranchiseeAllocListForCS(HttpServletRequest request) {
		List<FranchiseeListFormDTO> lst = new ArrayList<FranchiseeListFormDTO>();
		int flag=0;
		
		String status = request.getParameter("status");
		
		String startDate = request.getParameter("start_date");
		String endDate = request.getParameter("end_date");
		
		String installationStatusId = request.getParameter("installationStatusId");
		
		String lQuery = "SELECT distinct d.delivery_id,d.delivery_num,oder.so_number , convert(varchar, addate, 105) as addate "
				+ " ,m.material_num,m.material_desc,m.material_sapmst_id ,cs.customer_name as ship_to_party,"
				+ " cs.customer_num as ship_to_party_id ,sold.customer_name as customer_name ,"
				+ " cs.street1,cs.street2,cs.street3,cs.street4,cs.street5,cs.pin,cs.city_name ,"
				+ " st.state_val,'INDIA' as country ,f.id as f_id,f.uniq_id as f_uniq_id,f.delivery_id as f_delivery_id,"
				+ " f.delivery_num as f_delivery_num ,f.installation_address as f_installation_address ,"
				+ " f.site_contact_person as f_site_contact_person,f.contact_person_number as f_contact_person_number ,"
				+ " f.vsat_id as f_vsat_id,f.vsat_ip as f_vsat_ip,f.so_number as f_so_number ,"
				+ " f.site_survey_done as f_site_survey_done ,f.site_survey_uniq_id as f_site_survey_uniq_id,"
				+ " f.activity_type ,f.status as f_status,convert(varchar, f.creation_date, 105) as f_creation_date ,"
				+ " fe.id as eng_id,fe.name as eng_name,fe.mobile_no as eng_mobile_no, email_id as eng_email_id,"
				+ " fe.creation_date as eng_creation_date ,d.receiv_name,d.receiv_contact,s.status_code,s.status_name ,"
				+ " fr.franchise_mst_id,fr.franchise_name,f.site_survey_id,fe.cs_accept_flag,"
				+ " f.item,convert(varchar, oder.creation_date, 105) as so_creation_date,cs.contact_number,"
				+ " convert(varchar, f.tentative_date, 105) as tentative_date,f.hub_mst_id,f.additional_remarks,"
				+ " f.technology_mst_id,itm.installation_type_val, "
				+ " ism.installation_status_mst_id,ism.installation_status_code,ism.installation_status_val,rs.old_shtp_address,f.sub_customer "
				+ " FROM so_orders oder inner join material_sapmst m "
				+ " on oder.material_num=m.material_num and oder.plant=m.plant and oder.sales_org=m.sales_org and oder.dist_channel = m.dist_channel "
				+ " inner join customer_sapmst cs "
				+ " on oder.ship_to_party=cs.customer_num and oder.dist_channel=cs.dist_channel "
				+ " and oder.division=cs.division and oder.sales_org=cs.sales_org "
				+ " inner join customer_sapmst sold on oder.sold_to_party = sold.customer_num "
				+ " and oder.dist_channel=sold.dist_channel and oder.division=sold.division and oder.sales_org=sold.sales_org "
				+ " left outer join delivery d on d.so_number=oder.so_number and d.wbs_element=oder.wbs_element "
				+ " left outer join delivery_status_mst ds on d.delivery_status_mst_id=ds.delivery_status_mst_id "
				+ " left outer join user_to_region_mst ur on cs.region_code=ur.region_code "
				+ " left outer join franchisee_allocation_mst f on oder.so_number=f.so_number and oder.item = f.item "
				+ " left outer join installation_type_mst itm on f.installation_type_mst_id = itm.installation_type_mst_id "
				+ " left outer join franchise_mst fr on f.franchisee_id=fr.franchise_mst_id "
				+" left outer join relocation_so rs on oder.reloc_so_req_id = rs.uniq_id "
				+ " inner join status_mst s on f.status=s.status_mst_id inner join state_mst st "
				+ " on cs.region_code=st.state_code left outer join(select franchisee_alloc_id,id,franchisee_id,name,"
				+ " mobile_no,email_id,creation_date,cs_accept_flag from (SELECT franchisee_alloc_id,id,franchisee_id,"
				+ " name,mobile_no,email_id,creation_date,cs_accept_flag ,ROW_NUMBER() "
				+ " over(partition by franchisee_alloc_id order by creation_date desc) as cnt "
				+ " FROM franchisee_alloc_eng_mst group by franchisee_alloc_id,id,franchisee_id ,name,mobile_no,"
				+ " email_id,creation_date,cs_accept_flag) tbl where cnt=1)fe on f.id=fe.franchisee_alloc_id "
				+ " left outer join (select franchisee_alloc_id,installation_status_mst_id,created_date from (select franchisee_alloc_id,installation_status_mst_id,created_date,ROW_NUMBER() over(partition by franchisee_alloc_id order by created_date desc) as cntvisit from fa_eng_visit_details group by franchisee_alloc_id,installation_status_mst_id,created_date) fav  where cntvisit=1) vtbl "
				+ " on f.id = vtbl.franchisee_alloc_id "
				+ " left outer join installation_status_mst ism "
				+ " on vtbl.installation_status_mst_id = ism.installation_status_mst_id "
				+ " where st.state_mst_id = isnull(:stateMstId,st.state_mst_id) and ur.user_id=:user_id "
				+(startDate!=null && !startDate.equalsIgnoreCase("null") && endDate!=null && !endDate.equalsIgnoreCase("null")?" and f.creation_date between :start_date and :end_date  ":"")
				+(status!=null && !status.equalsIgnoreCase("NA")?" and f.status = :status ":" and f.status is null ")
				+(installationStatusId!=null && !installationStatusId.equalsIgnoreCase("null")?" and ism.installation_status_mst_id = :installation_status_mst_id ":"");
				//+ " and s.status_code in ('SSSTCS','SSSTFR','SSEA','SSS')";
		FranchiseeListFormDTO bean = null;
		query = em.createNativeQuery(lQuery);

		query.setParameter("user_id", DateUtil.convertDateToSqlDate(request.getParameter("user_id")));
		//query.setParameter("stateMstId", Integer.valueOf(request.getParameter("stateMstId"))); commented to give all state selection
				String stateId = request.getParameter("stateMstId");
				query.setParameter("stateMstId", stateId!=null && !stateId.equalsIgnoreCase("null")?Integer.valueOf(stateId):null);
		
		if(startDate!=null && !startDate.equalsIgnoreCase("null") && endDate!=null && !endDate.equalsIgnoreCase("null")) {
			query.setParameter("start_date", DateUtil.convertDateToSqlDate(startDate));
			query.setParameter("end_date", DateUtil.convertDateToSqlDate(endDate)+Constants.MAXDAYTIME);
		}
		
		//setting parameter for installation status
		if(installationStatusId!=null && !installationStatusId.equalsIgnoreCase("null")) {
			query.setParameter("installation_status_mst_id", Integer.valueOf(installationStatusId));
		}
		
		if(status!=null && !status.equalsIgnoreCase("NA")) {
			query.setParameter("status", Integer.valueOf(status));
		}
		
		
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			flag++;
			bean = new FranchiseeListFormDTO();
			bean.setDelivery_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setDelivery_num(SDCommonUtil.convertNullToBlank(String.valueOf(o[1]), false));
			bean.setSo_number(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
			bean.setAddate(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
			bean.setMaterial_num(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
			bean.setMaterial_desc(SDCommonUtil.convertNullToBlank(String.valueOf(o[5]), false));
			bean.setMaterial_sapmst_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false));
			bean.setShip_to_party(SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false));
			bean.setShip_to_party_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[8]), false));
			bean.setCustomer_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[9]), false));
			bean.setStreet1(SDCommonUtil.convertNullToBlank(String.valueOf(o[10]), false));
			bean.setStreet2(SDCommonUtil.convertNullToBlank(String.valueOf(o[11]), false));
			bean.setStreet3(SDCommonUtil.convertNullToBlank(String.valueOf(o[12]), false));
			bean.setStreet4(SDCommonUtil.convertNullToBlank(String.valueOf(o[13]), false));
			bean.setStreet5(SDCommonUtil.convertNullToBlank(String.valueOf(o[14]), false));
			bean.setPin(SDCommonUtil.convertNullToBlank(String.valueOf(o[15]), false));
			bean.setCity_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[16]), false));
			bean.setState_val(SDCommonUtil.convertNullToBlank(String.valueOf(o[17]), false));
			bean.setCountry(SDCommonUtil.convertNullToBlank(String.valueOf(o[18]), false));
			bean.setF_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[19]), false));
			bean.setF_uniq_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[20]), false));
			bean.setF_delivery_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[21]), false));
			bean.setF_delivery_num(SDCommonUtil.convertNullToBlank(String.valueOf(o[22]), false));
			bean.setF_installation_address(SDCommonUtil.convertNullToBlank(String.valueOf(o[23]), false));
			bean.setF_site_contact_person(SDCommonUtil.convertNullToBlank(String.valueOf(o[24]), false));
			bean.setF_contact_person_number(SDCommonUtil.convertNullToBlank(String.valueOf(o[25]), false));
			bean.setF_vsat_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[26]), false));
			bean.setF_vsat_ip(SDCommonUtil.convertNullToBlank(String.valueOf(o[27]), false));
			bean.setF_so_number(SDCommonUtil.convertNullToBlank(String.valueOf(o[28]), false));
			bean.setF_site_survey_done(SDCommonUtil.convertNullToBlank(String.valueOf(o[29]), false));
			bean.setF_site_survey_uniq_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[30]), false));
			bean.setActivity_type(SDCommonUtil.convertNullToBlank(String.valueOf(o[31]), false));
			bean.setF_status(SDCommonUtil.convertNullToBlank(String.valueOf(o[32]), false));
			bean.setF_creation_date(SDCommonUtil.convertNullToBlank(String.valueOf(o[33]), false));
			bean.setEng_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[34]), false));
			bean.setEng_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[35]), false));
			bean.setEng_mobile_no(SDCommonUtil.convertNullToBlank(String.valueOf(o[36]), false));
			bean.setEng_email_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[37]), false));
			bean.setEng_creation_date(SDCommonUtil.convertNullToBlank(String.valueOf(o[38]), false));
			bean.setReceive_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[39]), false));
			bean.setReceive_contact(SDCommonUtil.convertNullToBlank(String.valueOf(o[40]), false));
			bean.setStatus_code(SDCommonUtil.convertNullToBlank(String.valueOf(o[41]), false));
			bean.setStatus_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[42]), false));
			bean.setFranchisee_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[43]), false));
			bean.setFranchisee_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[44]), false));
			bean.setSiteSurveyId(SDCommonUtil.convertNullToBlank(String.valueOf(o[45]), false));
			bean.setCsAcceptFlag(SDCommonUtil.convertNullToBlank(String.valueOf(o[46]), false));
			bean.setItem(SDCommonUtil.convertNullToBlank(String.valueOf(o[47]), false));
			bean.setSoCreationDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[48]), false));
			bean.setContactNumber(SDCommonUtil.convertNullToBlank(String.valueOf(o[49]), false));
			bean.setTentativeDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[50]), false));
			bean.setHubMstId(o[51]!=null?(Integer)o[51]:null);
			bean.setAdditionalRemarks(SDCommonUtil.convertNullToBlank(String.valueOf(o[52]), false));
			bean.setTechnologyMstId(o[53]!=null?(Integer)o[53]:null);
			bean.setInstallationTypeVal(SDCommonUtil.convertNullToBlank(String.valueOf(o[54]), false));
			bean.setInstallationStatusMstId(o[55]!=null?(Integer)o[55]:null);
			bean.setInstallationStatusCode(SDCommonUtil.convertNullToBlank(String.valueOf(o[56]), false));
			bean.setInstallationStatusVal(SDCommonUtil.convertNullToBlank(String.valueOf(o[57]), false));
			bean.setOldShtpAddress(SDCommonUtil.convertNullToBlank(String.valueOf(o[58]), false));
			bean.setSubCustomer(SDCommonUtil.convertNullToBlank(String.valueOf(o[59]), false));
			lst.add(bean);
		}
		if(flag>0){
			return lst;	
		}else{
			//lst.add(new FranchiseeListFormDTO());
			return lst;
		}
	}

	@Override
	public FranchiseeAllocationMst updateFranchiseeAllocFranchisee(UpdateFranchiseDTO updateFranchiseDTO) {
		Integer franchisee_id = updateFranchiseDTO.getFranchiseId();//Integer.parseInt(request.getParameter("franchisee_id"));
		Integer franchisee_alloc_id = updateFranchiseDTO.getFranchiseeAllocId();//Integer.parseInt(request.getParameter("site_survey_id"));
		/*try {*/
			
		String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
		
		EmailBean emailBean = null;
		
		query = em.createNamedQuery("FranchiseeAllocationMst.findById");
		query.setParameter(1, franchisee_alloc_id);
		FranchiseeAllocationMst franchiseeAllocationMst = (FranchiseeAllocationMst) query.getSingleResult();
		
			query = em.createQuery("select ft from FranchiseAllocationTracker ft "
					+ " where ft.franchiseeAllocationMstId = :franchiseeAllocationMstId "
					+ " order by ft.reqTime desc ");
			query.setParameter("franchiseeAllocationMstId", franchisee_alloc_id);
			query.setMaxResults(1);
			List<FranchiseAllocationTracker> resultFt = (List<FranchiseAllocationTracker>) query.getResultList();
			
			if(resultFt!=null && resultFt.size()>0) {
				query = em.createNativeQuery("select u.user_mst_id,u.user_name,u.user_email from user_to_franchisee_mst uf inner join user_mst u on uf.user_mst_id = u.user_mst_id where uf.franchisee_id="+resultFt.get(0).getFranchiseMstId());
				List<Object[]> results = (List<Object[]>) query.getResultList();
				String frUserName = null;
				String frEmail = null;
				Integer fruserId = null;
				for (Object[] objects : results) {
					fruserId = (Integer)objects[0];
					frUserName = (String)objects[1];
					frEmail = (frEmail==null?"":frEmail+";")+(String)objects[2];
					
				}
				
				
				emailBean = new EmailBean();
				emailBean.setToMail(frEmail+";");
				
				emailBean.setSubject("I&C Request Allocation changed for id : " + franchiseeAllocationMst.getUniqId());
				emailBean.setEmailBody("Dear User,"
						+ "<br>This is to inform that I&C Request with id : " + franchiseeAllocationMst.getUniqId() + " has been allocated to other franchise. "
						+ "<br>Please login to know more." + "<br> Click here to login :  <a href="
						+ env.getProperty("emaillink") + ">O2C portal link</a>  " + "<br><br>Sincerely");
				callSpDao.sendEmail(emailBean);
				
			}
			
			FranchiseAllocationTracker franchiseAllocationTracker = new FranchiseAllocationTracker();
			franchiseAllocationTracker.setFranchiseeAllocationMstId(franchisee_alloc_id);
			franchiseAllocationTracker.setFranchiseMstId(franchisee_id);
			franchiseAllocationTracker.setReqTime(currTime);
			
			em.merge(franchiseAllocationTracker);
			
			query = em.createNamedQuery("FranchiseeAllocationMst.updateFrachisee");
			query.setParameter(1, franchisee_id);
			query.setParameter(2, 36);
			query.setParameter(3, franchisee_alloc_id);
			int i = query.executeUpdate();
			
			query = em.createNamedQuery("FranchiseeAllocationMst.findById");
			query.setParameter(1, franchisee_alloc_id);
			franchiseeAllocationMst = (FranchiseeAllocationMst) query.getSingleResult();
			
			//getting the state
			query = em.createNativeQuery("select distinct sm.state_mst_id "
					+ " from franchisee_allocation_mst f  "
					+ " inner join so_orders so "
					+ " on (f.so_number = so.so_number and f.item = so.item) "
					+ " inner join customer_sapmst cs "
					+ " on (so.ship_to_party = cs.customer_num and so.dist_channel = cs.dist_channel "
					+ " and so.division = cs.division and so.sales_org = cs.sales_org) "
					+ " inner join state_mst sm "
					+ " on cs.region_code = sm.state_code where f.id = :id ");
			query.setParameter("id", franchisee_alloc_id);
			
			Integer stateId = (Integer) query.getSingleResult();
			
			
			//checking whether state combination there or not begins
			query = em.createQuery(" select count(fts) from FranchiseToState fts "
					+ " where fts.franchiseMstId = :franchiseMstId and fts.stateMstId = :stateMstId ");
			query.setParameter("franchiseMstId", franchisee_id);
			query.setParameter("stateMstId", stateId);
			Long maxNumber = (Long) query.getSingleResult();
			Integer ftsCount = maxNumber.intValue();
			
			
			if(ftsCount==0) {
				FranchiseToState franchiseToState = new FranchiseToState();
				franchiseToState.setFranchiseMstId(franchisee_id);
				franchiseToState.setStateMstId(stateId);
				em.merge(franchiseToState);
			}
			//checking whether state combination there or not ends
			
			// email sending for franchise allocation begins
			query = em.createNativeQuery("select ur.user_id,u.user_name, "
					+ " u.user_email,fzm.franchise_zone_email "
					+ " from franchisee_allocation_mst f  "
					+ " inner join so_orders so "
					+ " on (f.so_number = so.so_number and f.item = so.item) "
					+ " inner join customer_sapmst cs "
					+ " on (so.ship_to_party = cs.customer_num and so.dist_channel = cs.dist_channel "
					+ " and so.division = cs.division and so.sales_org = cs.sales_org) "
					+ " inner join state_mst sm "
					+ " on cs.region_code = sm.state_code "
					+ " inner join user_to_region_mst ur "
					+ " on sm.state_mst_id = ur.region_code "
					+ " inner join cs_user_franchise_zone_mapping_mst cufzm "
					+ " on ur.user_id = cufzm.user_mst_id "
					+ " inner join user_mst u "
					+ " on ur.user_id = u.user_mst_id "
					+ " inner join franchise_zone_mst fzm "
					+ " on cufzm.franchise_zone_mst_id = fzm.franchise_zone_mst_id "
					+ " inner join role_mst r "
					+ " on r.role_mst_id = u.role_mst_id "
					+ " left outer join delivery d "
					+ " on f.delivery_id = d.delivery_id "
					+ " where r.role_cd in ('SUPEXE') and  f.id = "+franchisee_alloc_id);
			List<Object[]> result = (List<Object[]>) query.getResultList();
			String csUserName = null;
			String csEmail = null;
			Integer userId = null;
			String zoneEmail = null;
			for (Object[] objects : result) {
				userId = (Integer)objects[0];
				csUserName = (String)objects[1];
				csEmail = (csEmail==null?"":csEmail+";") + (String)objects[2];
				zoneEmail = (String)objects[3];
			}
			
			query = em.createNativeQuery("select u.user_mst_id,u.user_name,u.user_email from user_to_franchisee_mst uf inner join user_mst u on uf.user_mst_id = u.user_mst_id where uf.franchisee_id="+franchisee_id);
			List<Object[]> results = (List<Object[]>) query.getResultList();
			String frUserName = null;
			String frEmail = null;
			Integer fruserId = null;
			for (Object[] objects : results) {
				fruserId = (Integer)objects[0];
				frUserName = (String)objects[1];
				frEmail = (frEmail==null?"":frEmail+";")+(String)objects[2];
				
			}
			
			Integer requestUserId = franchiseeAllocationMst.getUser_id();
			query = em.createNamedQuery("UserMst.getUserEmailById");
			query.setParameter(1, requestUserId);
			List<UserMst> userList = (List<UserMst>) query.getResultList();
			
			//query to get franchise allocation details begins
			query = em.createNativeQuery(" select so.sold_to_party,stp.customer_name,so.ship_to_party,"
					+ " COALESCE(shtp.street1,'')+' '+COALESCE(shtp.street2,'') +' '+COALESCE(shtp.street3,'')+' '+COALESCE(shtp.street4,'') +' '+COALESCE(shtp.street5,'')+' '+COALESCE(shtp.city_name,'') +'-'+COALESCE(shtp.pin,'')+' '+COALESCE(sm.state_val,'')+','+COALESCE(cm.country_val,'') as shtp_address, "
					+ " fam.so_number,d.delivery_num,fam.installation_address,itm.installation_type_val,"
					+ " fam.vsat_id,fam.vsat_ip,fam.contact_person_number,fam.site_contact_person,"
					+ " fam.additional_remarks,tm.value,hm.hub_desc,fam.sub_customer "
					+ " from franchisee_allocation_mst fam inner join installation_type_mst itm on fam.installation_type_mst_id = itm.installation_type_mst_id inner join so_orders so on fam.so_number = so.so_number and fam.item = so.item inner join customer_sapmst shtp on so.ship_to_party = shtp.customer_num and so.dist_channel = shtp.dist_channel and so.division = shtp.division and so.sales_org = shtp.sales_org inner join customer_sapmst stp on so.sold_to_party = stp.customer_num and so.dist_channel = stp.dist_channel and so.division = stp.division and so.sales_org = stp.sales_org inner join country_mst cm on shtp.country_code = cm.country_code inner join state_mst sm on shtp.region_code = sm.state_code left outer join delivery d on fam.delivery_id = d.delivery_id left outer join hub_mst hm on fam.hub_mst_id = hm.hub_mst_id left outer join technology_mst tm on fam.technology_mst_id = tm.id " + 
					" where fam.id = :famId ");
			query.setParameter("famId", franchiseeAllocationMst.getId());
			List<Object[]> soDetailsResult = (List<Object[]>) query.getResultList();
			FranchiseAllocEmailDetails emailDetails = new FranchiseAllocEmailDetails();
			for (Object[] objects : soDetailsResult) {
				emailDetails.setSoldToParty(objects[0]!=null?(String)objects[0]:"");
				emailDetails.setCustomerName(objects[1]!=null?(String)objects[1]:"");
				emailDetails.setShipToParty(objects[2]!=null?(String)objects[2]:"");
				emailDetails.setShtpAddress(objects[3]!=null?(String)objects[3]:"");
				emailDetails.setSoNumber(objects[4]!=null?(String)objects[4]:"");
				emailDetails.setDeliverNumber(objects[5]!=null?(String)objects[5]:"");
				emailDetails.setAdditionalAddress(objects[6]!=null?(String)objects[6]:"");
				emailDetails.setInstallationType(objects[7]!=null?(String)objects[7]:"");
				emailDetails.setVsatId(objects[8]!=null?(String)objects[8]:"");
				emailDetails.setVsatIp(objects[9]!=null?(String)objects[9]:"");
				emailDetails.setContactPersonNumber(objects[10]!=null?(String)objects[10]:"");
				emailDetails.setSiteContactPerson(objects[11]!=null?(String)objects[11]:"");
				emailDetails.setAdditionalRemarks(objects[12]!=null?(String)objects[12]:"");
				emailDetails.setTechnology(objects[13]!=null?(String)objects[13]:"");
				emailDetails.setHubDesc(objects[14]!=null?(String)objects[14]:"");
				emailDetails.setSubCustomer(objects[15]!=null?(String)objects[15]:"");
			}
			//query to get franchise allocation details ends
			
			
			if(userId!=null) {
				emailBean = new EmailBean();
				emailBean.setToMail(frEmail+";");
				
				if(userList!=null && userList.size()>0) {
					emailBean.setCopyRecepients(userList.get(0).getUserEmail()+";"+(csEmail!=null?csEmail+";":"")+(zoneEmail!=null?zoneEmail:""));
				}
				emailBean.setSubject("I&C Request Allocated : " + franchiseeAllocationMst.getUniqId());
				emailBean.setEmailBody("Dear User,"
						+ "<br>I&C Request has been allocated with id : " + franchiseeAllocationMst.getUniqId() + "."
								+ "<br>Customer Name : " + emailDetails.getCustomerName()
								+ "<br>Sub Customer Name : " + emailDetails.getSubCustomer()
								+ "<br>Ship To Party Address : " + emailDetails.getShtpAddress()
								+ "<br>Additional Address : " + emailDetails.getAdditionalAddress()
								+ "<br>Installation Type : " + emailDetails.getInstallationType()
								+ "<br>So Number : " + emailDetails.getSoNumber()
								+ "<br>VSAT ID : " + emailDetails.getVsatId()
								+ "<br>IP : " + emailDetails.getVsatIp()
								+ "<br>Contact Person : " + emailDetails.getSiteContactPerson()
								+ "<br>Contact Person Number : " + emailDetails.getContactPersonNumber()
								+ "<br>Hub : " + emailDetails.getHubDesc()
								+ "<br>Additional Remarks : " + emailDetails.getAdditionalRemarks()
								+ "<br>Technology : " + emailDetails.getTechnology()
						+ "<br>Please login to know more." + "<br> Click here to login :  <a href="
						+ env.getProperty("emaillink") + ">O2C portal link</a>  " + "<br><br>Sincerely");
				callSpDao.sendEmail(emailBean);
			}
			
			// email sending for franchise allocation ends
			
			return franchiseeAllocationMst;
		/*} finally {
			em.close();
		}*/
	}
	//For getting list for franchisee co-ordinator
	@Override
	public List<FranchiseeListFormDTO> getFranchiseeAllocListForFranhisee(HttpServletRequest request) {
		List<FranchiseeListFormDTO> lst = new ArrayList<FranchiseeListFormDTO>();
		
		String status = request.getParameter("status");
		
		String startDate = request.getParameter("start_date");
		String endDate = request.getParameter("end_date");
		
		String installationStatusId = request.getParameter("installationStatusId");
		
		String lQuery = "SELECT distinct d.delivery_id,d.delivery_num,f.so_number , convert(varchar, addate, 105) as addate ,"
				+ " m.material_num,m.material_desc,m.material_sapmst_id ,cs.customer_name as ship_to_party,"
				+ " cs.customer_num as ship_to_party_id ,sold.customer_name as customer_name ,cs.street1,cs.street2,"
				+ " cs.street3,cs.street4,cs.street5,cs.pin,cs.city_name ,st.state_val,'INDIA' as country ,"
				+ " f.id as f_id,f.uniq_id as f_uniq_id,f.delivery_id as f_delivery_id,f.delivery_num as f_delivery_num ,"
				+ " f.installation_address as f_installation_address ,f.site_contact_person as f_site_contact_person,"
				+ " f.contact_person_number as f_contact_person_number ,f.vsat_id as f_vsat_id,f.vsat_ip as f_vsat_ip,"
				+ " f.so_number as f_so_number ,f.site_survey_done as f_site_survey_done ,"
				+ " f.site_survey_uniq_id as f_site_survey_uniq_id,f.activity_type ,f.status as f_status,"
				+ " convert(varchar, f.creation_date, 105) as f_creation_date ,fe.id as eng_id,fe.name as eng_name,"
				+ " fe.mobile_no as eng_mobile_no, email_id as eng_email_id,fe.creation_date as eng_creation_date ,"
				+ " d.receiv_name,d.receiv_contact,s.status_code,s.status_name ,fr.franchise_mst_id,fr.franchise_name,"
				+ " f.site_survey_id,fe.cs_accept_flag,f.item,convert(varchar, oder.creation_date, 105) as so_creation_date,"
				+ " cs.contact_number,convert(varchar, f.tentative_date, 105) as tentative_date,f.hub_mst_id,"
				+ " f.additional_remarks,f.technology_mst_id, "
				+ " ism.installation_status_mst_id,ism.installation_status_code,ism.installation_status_val,rs.old_shtp_address,f.sub_customer "
				+ " FROM so_orders oder "
				+ " inner join material_sapmst m on oder.material_num=m.material_num and oder.plant=m.plant and oder.dist_channel = m.dist_channel"
				+ " and oder.sales_org=m.sales_org "
				+ " inner join customer_sapmst cs on oder.ship_to_party=cs.customer_num "
				+ " and oder.dist_channel=cs.dist_channel and oder.division=cs.division and oder.sales_org=cs.sales_org "
				+ " inner join customer_sapmst sold on oder.sold_to_party=sold.customer_num "
				+ " and oder.dist_channel=sold.dist_channel and oder.division=sold.division "
				+ " and oder.sales_org=sold.sales_org "
				+ " left outer join delivery d on d.so_number=oder.so_number and d.wbs_element=oder.wbs_element "
				+ " left outer join delivery_status_mst ds on d.delivery_status_mst_id=ds.delivery_status_mst_id "
				+ " left outer join franchisee_allocation_mst f on oder.so_number = f.so_number and oder.item = f.item "
				+ " left outer join franchise_mst fr on f.franchisee_id=fr.franchise_mst_id "
				+" left outer join relocation_so rs on oder.reloc_so_req_id = rs.uniq_id "
				+ " inner join user_to_franchisee_mst u_f on f.franchisee_id=u_f.franchisee_id and u_f.user_mst_id=:user_id "
				+ " inner join status_mst s on f.status=s.status_mst_id "
				+ " inner join state_mst st on cs.region_code=st.state_code "
				+ " left outer join(select franchisee_alloc_id,id,franchisee_id,name,mobile_no,email_id,creation_date,"
				+ " cs_accept_flag from (SELECT franchisee_alloc_id,id,franchisee_id,name,mobile_no,email_id,creation_date,"
				+ " cs_accept_flag ,ROW_NUMBER() over(partition by franchisee_alloc_id order by creation_date desc) as cnt "
				+ " FROM franchisee_alloc_eng_mst group by franchisee_alloc_id,id,franchisee_id ,name,mobile_no,"
				+ " email_id,creation_date,cs_accept_flag) tbl where cnt=1)fe on f.id=fe.franchisee_alloc_id "
				+ " left outer join (select franchisee_alloc_id,installation_status_mst_id,created_date from (select franchisee_alloc_id,installation_status_mst_id,created_date,ROW_NUMBER() over(partition by franchisee_alloc_id order by created_date desc) as cntvisit from fa_eng_visit_details group by franchisee_alloc_id,installation_status_mst_id,created_date) fav  where cntvisit=1) vtbl "
				+ " on f.id = vtbl.franchisee_alloc_id "
				+ " left outer join installation_status_mst ism "
				+ " on vtbl.installation_status_mst_id = ism.installation_status_mst_id "
				+ " where st.state_mst_id = isnull(:stateMstId,st.state_mst_id) "
				+(startDate!=null && !startDate.equalsIgnoreCase("null") && endDate!=null && !endDate.equalsIgnoreCase("null")?" and f.creation_date between :start_date and :end_date  ":"")
				+(status!=null && !status.equalsIgnoreCase("NA")?" and f.status = :status ":" and f.status is null ")
				+(installationStatusId!=null && !installationStatusId.equalsIgnoreCase("null")?" and ism.installation_status_mst_id = :installation_status_mst_id ":"");	
		FranchiseeListFormDTO bean = null;
		int flag=0;
		query = em.createNativeQuery(lQuery);
		
		query.setParameter("user_id", DateUtil.convertDateToSqlDate(request.getParameter("user_id")));
		//query.setParameter("stateMstId", Integer.valueOf(request.getParameter("stateMstId"))); commented to give all state selection
				String stateId = request.getParameter("stateMstId");
				query.setParameter("stateMstId", stateId!=null && !stateId.equalsIgnoreCase("null")?Integer.valueOf(stateId):null);
		
		if(startDate!=null && !startDate.equalsIgnoreCase("null") && endDate!=null && !endDate.equalsIgnoreCase("null")) {
			query.setParameter("start_date", DateUtil.convertDateToSqlDate(startDate));
			query.setParameter("end_date", DateUtil.convertDateToSqlDate(endDate)+Constants.MAXDAYTIME);
		}
		
		//setting parameter for installation status
		if(installationStatusId!=null && !installationStatusId.equalsIgnoreCase("null")) {
			query.setParameter("installation_status_mst_id", Integer.valueOf(installationStatusId));
		}
		
		if(status!=null && !status.equalsIgnoreCase("NA")) {
			query.setParameter("status", Integer.valueOf(status));
		}
		
		
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			flag++;
			bean = new FranchiseeListFormDTO();
			bean = new FranchiseeListFormDTO();
			bean.setDelivery_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setDelivery_num(SDCommonUtil.convertNullToBlank(String.valueOf(o[1]), false));
			bean.setSo_number(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
			bean.setAddate(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
			bean.setMaterial_num(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
			bean.setMaterial_desc(SDCommonUtil.convertNullToBlank(String.valueOf(o[5]), false));
			bean.setMaterial_sapmst_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false));
			bean.setShip_to_party(SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false));
			bean.setShip_to_party_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[8]), false));
			bean.setCustomer_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[9]), false));
			bean.setStreet1(SDCommonUtil.convertNullToBlank(String.valueOf(o[10]), false));
			bean.setStreet2(SDCommonUtil.convertNullToBlank(String.valueOf(o[11]), false));
			bean.setStreet3(SDCommonUtil.convertNullToBlank(String.valueOf(o[12]), false));
			bean.setStreet4(SDCommonUtil.convertNullToBlank(String.valueOf(o[13]), false));
			bean.setStreet5(SDCommonUtil.convertNullToBlank(String.valueOf(o[14]), false));
			bean.setPin(SDCommonUtil.convertNullToBlank(String.valueOf(o[15]), false));
			bean.setCity_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[16]), false));
			bean.setState_val(SDCommonUtil.convertNullToBlank(String.valueOf(o[17]), false));
			bean.setCountry(SDCommonUtil.convertNullToBlank(String.valueOf(o[18]), false));
			bean.setF_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[19]), false));
			bean.setF_uniq_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[20]), false));
			bean.setF_delivery_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[21]), false));
			bean.setF_delivery_num(SDCommonUtil.convertNullToBlank(String.valueOf(o[22]), false));
			bean.setF_installation_address(SDCommonUtil.convertNullToBlank(String.valueOf(o[23]), false));
			bean.setF_site_contact_person(SDCommonUtil.convertNullToBlank(String.valueOf(o[24]), false));
			bean.setF_contact_person_number(SDCommonUtil.convertNullToBlank(String.valueOf(o[25]), false));
			bean.setF_vsat_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[26]), false));
			bean.setF_vsat_ip(SDCommonUtil.convertNullToBlank(String.valueOf(o[27]), false));
			bean.setF_so_number(SDCommonUtil.convertNullToBlank(String.valueOf(o[28]), false));
			bean.setF_site_survey_done(SDCommonUtil.convertNullToBlank(String.valueOf(o[29]), false));
			bean.setF_site_survey_uniq_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[30]), false));
			bean.setActivity_type(SDCommonUtil.convertNullToBlank(String.valueOf(o[31]), false));
			bean.setF_status(SDCommonUtil.convertNullToBlank(String.valueOf(o[32]), false));
			bean.setF_creation_date(SDCommonUtil.convertNullToBlank(String.valueOf(o[33]), false));
			bean.setEng_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[34]), false));
			bean.setEng_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[35]), false));
			bean.setEng_mobile_no(SDCommonUtil.convertNullToBlank(String.valueOf(o[36]), false));
			bean.setEng_email_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[37]), false));
			bean.setEng_creation_date(SDCommonUtil.convertNullToBlank(String.valueOf(o[38]), false));
			bean.setReceive_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[39]), false));
			bean.setReceive_contact(SDCommonUtil.convertNullToBlank(String.valueOf(o[40]), false));
			bean.setStatus_code(SDCommonUtil.convertNullToBlank(String.valueOf(o[41]), false));
			bean.setStatus_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[42]), false));
			bean.setFranchisee_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[43]), false));
			bean.setFranchisee_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[44]), false));
			bean.setSiteSurveyId(SDCommonUtil.convertNullToBlank(String.valueOf(o[45]), false));
			bean.setCsAcceptFlag(SDCommonUtil.convertNullToBlank(String.valueOf(o[46]), false));
			bean.setItem(SDCommonUtil.convertNullToBlank(String.valueOf(o[47]), false));
			bean.setSoCreationDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[48]), false));
			bean.setContactNumber(SDCommonUtil.convertNullToBlank(String.valueOf(o[49]), false));
			bean.setTentativeDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[50]), false));
			bean.setHubMstId(o[51]!=null?(Integer)o[51]:null);
			bean.setAdditionalRemarks(SDCommonUtil.convertNullToBlank(String.valueOf(o[52]), false));
			bean.setTechnologyMstId(o[53]!=null?(Integer)o[53]:null);
			bean.setInstallationStatusMstId(o[54]!=null?(Integer)o[54]:null);
			bean.setInstallationStatusCode(SDCommonUtil.convertNullToBlank(String.valueOf(o[55]), false));
			bean.setInstallationStatusVal(SDCommonUtil.convertNullToBlank(String.valueOf(o[56]), false));
			bean.setOldShtpAddress(SDCommonUtil.convertNullToBlank(String.valueOf(o[57]), false));
			bean.setSubCustomer(SDCommonUtil.convertNullToBlank(String.valueOf(o[58]), false));
			lst.add(bean);
		}
		if(flag>0){
			return lst;	
		}else{
			//lst.add(new FranchiseeListFormDTO());
			return lst;
		}
	}

	@Override
	public FranchiseeAllocEngMst saveFranchiseeAllocSurveyEngineer(FranchiseeAllocEngineerDTO franchiseeAllocEngineerDTO) {
		FranchiseeAllocEngMst franchiseeAllocEngMst = new FranchiseeAllocEngMst();
		franchiseeAllocEngMst.setCreation_date(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		franchiseeAllocEngMst.setEmail_id(franchiseeAllocEngineerDTO.getEmail_id());
		franchiseeAllocEngMst.setFranchisee_id(franchiseeAllocEngineerDTO.getFranchisee_id());
		franchiseeAllocEngMst.setId(franchiseeAllocEngineerDTO.getId());
		franchiseeAllocEngMst.setMobile_no(franchiseeAllocEngineerDTO.getMobile_no());
		franchiseeAllocEngMst.setName(franchiseeAllocEngineerDTO.getName());
		franchiseeAllocEngMst.setFranchisee_alloc_id(franchiseeAllocEngineerDTO.getFranchisee_alloc_id());
		String currTime = DateUtil.convertDateToSqlDate(franchiseeAllocEngineerDTO.getEngVisitDate());
		franchiseeAllocEngMst.setEngVisitDate(currTime);
		franchiseeAllocEngMst.setEngVisitTiming(franchiseeAllocEngineerDTO.getEngVisitTiming());
		franchiseeAllocEngMst = em.merge(franchiseeAllocEngMst);
		
		Query query = em.createNamedQuery("FranchiseeAllocationMst.updateEngineerAllocatedStatus");
		query.setParameter(1, 37);
		query.setParameter(2, franchiseeAllocEngMst.getFranchisee_alloc_id());
		int i = query.executeUpdate();
		
		
		query = em.createNamedQuery("FranchiseeAllocationMst.findById");
		query.setParameter(1, franchiseeAllocEngineerDTO.getFranchisee_alloc_id());
		FranchiseeAllocationMst franchiseeAllocationMst = (FranchiseeAllocationMst) query.getSingleResult();
		
		// email sending for franchise allocation begins
				query = em.createNativeQuery("select ur.user_id,u.user_name, "
						+ " u.user_email,fzm.franchise_zone_email,cs.city_name, "
						+ " cs.street1,cs.street2,cs.street3,cs.street4,cs.street5,sm.state_val,cs.pin "
						+ " from franchisee_allocation_mst f  "
						+ " inner join so_orders so "
						+ " on (f.so_number = so.so_number and f.item = so.item) "
						+ " inner join customer_sapmst cs "
						+ " on (so.ship_to_party = cs.customer_num and so.dist_channel = cs.dist_channel "
						+ " and so.division = cs.division and so.sales_org = cs.sales_org) "
						+ " inner join state_mst sm "
						+ " on cs.region_code = sm.state_code "
						+ " inner join user_to_region_mst ur "
						+ " on sm.state_mst_id = ur.region_code "
						+ " inner join cs_user_franchise_zone_mapping_mst cufzm "
						+ " on ur.user_id = cufzm.user_mst_id "
						+ " inner join user_mst u "
						+ " on ur.user_id = u.user_mst_id "
						+ " inner join franchise_zone_mst fzm "
						+ " on cufzm.franchise_zone_mst_id = fzm.franchise_zone_mst_id "
						+ " inner join role_mst r "
						+ " on r.role_mst_id = u.role_mst_id "
						+ " left outer join delivery d "
						+ " on f.delivery_id = d.delivery_id "
						+ " where r.role_cd in ('SUPEXE') and f.id = "+franchiseeAllocationMst.getId());
				List<Object[]> result = (List<Object[]>) query.getResultList();
				String csUserName = null;
				String csEmail = null;
				Integer userId = null;
				String zoneEmail = null;
				CustomerSapmst customerSapmst = new CustomerSapmst();
				for (Object[] objects : result) {
					userId = (Integer)objects[0];
					csUserName = (String)objects[1];
					csEmail = (csEmail==null?"":csEmail+";") + (String)objects[2];
					zoneEmail = (String)objects[3];
					customerSapmst.setCityName(objects[4]!=null?(String)objects[4]:"");
					customerSapmst.setStreet1(objects[5]!=null?(String)objects[5]:"");
					customerSapmst.setStreet2(objects[6]!=null?(String)objects[6]:"");
					customerSapmst.setStreet3(objects[7]!=null?(String)objects[7]:"");
					customerSapmst.setStreet4(objects[8]!=null?(String)objects[8]:"");
					customerSapmst.setStreet5(objects[9]!=null?(String)objects[9]:"");
					
					//setting state name
					customerSapmst.setCustomerName(objects[10]!=null?(String)objects[10]:"");
					
					customerSapmst.setPin(objects[11]!=null?(String)objects[11]:"");
				}
				
				Integer requestUserId = franchiseeAllocationMst.getUser_id();
				query = em.createNamedQuery("UserMst.getUserEmailById");
				query.setParameter(1, requestUserId);
				List<UserMst> userList = (List<UserMst>) query.getResultList();
				
				
				//query to get franchise allocation details begins
				query = em.createNativeQuery(" select so.sold_to_party,stp.customer_name,so.ship_to_party,"
						+ " COALESCE(shtp.street1,'')+' '+COALESCE(shtp.street2,'') +' '+COALESCE(shtp.street3,'')+' '+COALESCE(shtp.street4,'') +' '+COALESCE(shtp.street5,'')+' '+COALESCE(shtp.city_name,'') +'-'+COALESCE(shtp.pin,'')+' '+COALESCE(sm.state_val,'')+','+COALESCE(cm.country_val,'') as shtp_address, "
						+ " fam.so_number,d.delivery_num,fam.installation_address,itm.installation_type_val,"
						+ " fam.vsat_id,fam.vsat_ip,fam.contact_person_number,fam.site_contact_person,"
						+ " fam.additional_remarks,tm.value,hm.hub_desc,fam.sub_customer "
						+ " from franchisee_allocation_mst fam inner join installation_type_mst itm on fam.installation_type_mst_id = itm.installation_type_mst_id inner join so_orders so on fam.so_number = so.so_number and fam.item = so.item inner join customer_sapmst shtp on so.ship_to_party = shtp.customer_num and so.dist_channel = shtp.dist_channel and so.division = shtp.division and so.sales_org = shtp.sales_org inner join customer_sapmst stp on so.sold_to_party = stp.customer_num and so.dist_channel = stp.dist_channel and so.division = stp.division and so.sales_org = stp.sales_org inner join country_mst cm on shtp.country_code = cm.country_code inner join state_mst sm on shtp.region_code = sm.state_code left outer join delivery d on fam.delivery_id = d.delivery_id left outer join hub_mst hm on fam.hub_mst_id = hm.hub_mst_id left outer join technology_mst tm on fam.technology_mst_id = tm.id " + 
						" where fam.id = :famId ");
				query.setParameter("famId", franchiseeAllocationMst.getId());
				List<Object[]> soDetailsResult = (List<Object[]>) query.getResultList();
				FranchiseAllocEmailDetails emailDetails = new FranchiseAllocEmailDetails();
				for (Object[] objects : soDetailsResult) {
					emailDetails.setSoldToParty(objects[0]!=null?(String)objects[0]:"");
					emailDetails.setCustomerName(objects[1]!=null?(String)objects[1]:"");
					emailDetails.setShipToParty(objects[2]!=null?(String)objects[2]:"");
					emailDetails.setShtpAddress(objects[3]!=null?(String)objects[3]:"");
					emailDetails.setSoNumber(objects[4]!=null?(String)objects[4]:"");
					emailDetails.setDeliverNumber(objects[5]!=null?(String)objects[5]:"");
					emailDetails.setAdditionalAddress(objects[6]!=null?(String)objects[6]:"");
					emailDetails.setInstallationType(objects[7]!=null?(String)objects[7]:"");
					emailDetails.setVsatId(objects[8]!=null?(String)objects[8]:"");
					emailDetails.setVsatIp(objects[9]!=null?(String)objects[9]:"");
					emailDetails.setContactPersonNumber(objects[10]!=null?(String)objects[10]:"");
					emailDetails.setSiteContactPerson(objects[11]!=null?(String)objects[11]:"");
					emailDetails.setAdditionalRemarks(objects[12]!=null?(String)objects[12]:"");
					emailDetails.setTechnology(objects[13]!=null?(String)objects[13]:"");
					emailDetails.setHubDesc(objects[14]!=null?(String)objects[14]:"");
					emailDetails.setSubCustomer(objects[15]!=null?(String)objects[14]:"");
				}
				//query to get franchise allocation details ends
				
				EmailBean emailBean = new EmailBean();
				if(userId!=null) {
					
					emailBean.setToMail((csEmail!=null?csEmail+";":"")+(zoneEmail!=null?zoneEmail:""));
					
					if(userList!=null && userList.size()>0) {
						emailBean.setCopyRecepients(userList.get(0).getUserEmail());
					}
					emailBean.setSubject("I&C Request Engineer Allocated : " + franchiseeAllocationMst.getUniqId());
					emailBean.setEmailBody("Dear User,"// +finance.getUserName()+","
							+ "<br>Engineer has been saved for I&C Request." + "<br>I&C Request ID:"
							+ franchiseeAllocationMst.getUniqId() + "<br>Engineer Name : " + franchiseeAllocEngineerDTO.getName()
							+ "<br>Engineer Mobile Number : " + franchiseeAllocEngineerDTO.getMobile_no() + "<br>Engineer Email : "
							+ franchiseeAllocEngineerDTO.getEmail_id() 
							+ "<br>So Number : " + emailDetails.getSoNumber()
							+ "<br>Customer Name : " + emailDetails.getCustomerName()
							+ "<br>Sub Customer Name : " + emailDetails.getSubCustomer()
							+ "<br>So Number : " + emailDetails.getSoNumber()
							+ "<br>Ship To Party Address : " + emailDetails.getShtpAddress()
							+ "<br>Additional Address : " + emailDetails.getAdditionalAddress()
							+ "<br>Installation Type : " + emailDetails.getInstallationType()
							+ "<br>VSAT ID : " + emailDetails.getVsatId()
							+ "<br>IP : " + emailDetails.getVsatIp()
							+ "<br>Contact Person : " + emailDetails.getSiteContactPerson()
							+ "<br>Contact Person Number : " + emailDetails.getContactPersonNumber()
							+ "<br>Hub : " + emailDetails.getHubDesc()
							+ "<br>Additional Remarks : " + emailDetails.getAdditionalRemarks()
							+ "<br>Technology : " + emailDetails.getTechnology()
							+ "<br>Please login and accept to process further to know more."
							+ "<br> Click here to login :  <a href=" + env.getProperty("emaillink") + ">O2C portal link</a>  "
							+ "<br><br>Sincerely");
					callSpDao.sendEmail(emailBean);
				}
				
				// email sending for franchise allocation ends
				
				//email to allocated engineer begins
				emailBean = new EmailBean();
				emailBean.setToMail(franchiseeAllocEngMst.getEmail_id());
				emailBean.setSubject("I&C Request assigned : " + franchiseeAllocationMst.getUniqId());
				emailBean.setEmailBody("Dear User,"// +finance.getUserName()+","
						+ "<br>I&C Request task has been assigned." + "<br>I&C Request ID:" + franchiseeAllocationMst.getUniqId()
						+ "<br>Site Person Contact Name : " + franchiseeAllocationMst.getSiteContactPerson() 
						+ "<br>Customer Name : " + emailDetails.getCustomerName()
						+ "<br>Sub Customer Name : " + emailDetails.getSubCustomer()
						+ "<br>Ship To Party Address : " + emailDetails.getShtpAddress()
						+ "<br>Additional Address : " + emailDetails.getAdditionalAddress()
						+ "<br>Installation Type : " + emailDetails.getInstallationType()
						+ "<br>VSAT ID : " + emailDetails.getVsatId()
						+ "<br>IP : " + emailDetails.getVsatIp()
						+ "<br>Contact Person : " + emailDetails.getSiteContactPerson()
						+ "<br>Contact Person Number : " + emailDetails.getContactPersonNumber()
						+ "<br>Hub : " + emailDetails.getHubDesc()
						+ "<br>Additional Remarks : " + emailDetails.getAdditionalRemarks()
						+ "<br>Technology : " + emailDetails.getTechnology()
						+"<br><br>Sincerely");
				callSpDao.sendEmail(emailBean);	
		//email to allocated engineer ends
		
		return franchiseeAllocEngMst;
	}

	@Override
	public FranchiseeAllocEngMst getEngineerById(HttpServletRequest request) {
		Integer franchisee_id = Integer.parseInt(request.getParameter("engineer_id"));
		try {
			query = em.createNamedQuery("FranchiseeAllocEngMst.findById");
			query.setParameter(1, Integer.parseInt(request.getParameter("engineer_id")));
			return (FranchiseeAllocEngMst) query.getSingleResult();
		} catch (Exception e) {
			return new FranchiseeAllocEngMst();
		} finally {
			em.close();
		}
	}

	@Override
	public List<FranchiseeAllocEngMst> getEngineerListBySiteIdFrachiseeId(HttpServletRequest request) {
		try {
			query = em.createNamedQuery("FranchiseeAllocEngMst.findByFranchiseeAllocId");
			query.setParameter(1, Integer.parseInt(request.getParameter("franchisee_alloc_id")));			
			List<FranchiseeAllocEngMst> siteSurveyEngineerMst = query.getResultList();			
			return siteSurveyEngineerMst != null ? siteSurveyEngineerMst : new ArrayList<FranchiseeAllocEngMst>();
		} catch (Exception e) {
			return new ArrayList<FranchiseeAllocEngMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<Delivery> getDeliveryList() {
		try {
			query = em.createNamedQuery("Delivery.findAll");
			List<Delivery> siteSurveyEngineerMst = query.getResultList();			
			return siteSurveyEngineerMst != null ? siteSurveyEngineerMst : new ArrayList<Delivery>();
		} catch (Exception e) {
			return new ArrayList<Delivery>();
		} finally {
			em.close();
		}
	}

	@Override
	public void acceptFranchiseEngineer(CommonDTO commonDTOInput) {
		// TODO Auto-generated method stub
		
		try {
			
			//updating the engineer accepted flag
			query = em.createNativeQuery("update franchisee_alloc_eng_mst set cs_accept_flag = :flag where id=:id");
			query.setParameter("id", commonDTOInput.getFranchiseeAllocEngMstId());
			query.setParameter("flag", commonDTOInput.getFlag());
			query.executeUpdate();
			//updating the engineer accepted flag ends
			
			query = em.createNamedQuery("FranchiseeAllocEngMst.findById");
			query.setParameter(1, commonDTOInput.getFranchiseeAllocEngMstId());
			FranchiseeAllocEngMst franchiseeAllocEngMst = (FranchiseeAllocEngMst) query.getSingleResult();
			
			//email sending to franchise informing the acceptance of engineer begins
			query = em.createNamedQuery("FranchiseeAllocationMst.findById");
			query.setParameter(1, commonDTOInput.getFranchiseAllocId());
			FranchiseeAllocationMst franchiseeAllocationMst = (FranchiseeAllocationMst) query.getSingleResult();
			
			
			
					query = em.createNativeQuery("select ur.user_id,u.user_name, "
							+ " u.user_email,fzm.franchise_zone_email,cs.city_name, "
							+ " cs.street1,cs.street2,cs.street3,cs.street4,cs.street5,sm.state_val,cs.pin "
							+ " from franchisee_allocation_mst f  "
							+ " inner join so_orders so "
							+ " on (f.so_number = so.so_number and f.item = so.item) "
							+ " inner join customer_sapmst cs "
							+ " on (so.ship_to_party = cs.customer_num and so.dist_channel = cs.dist_channel "
							+ " and so.division = cs.division and so.sales_org = cs.sales_org) "
							+ " inner join state_mst sm "
							+ " on cs.region_code = sm.state_code "
							+ " inner join user_to_region_mst ur "
							+ " on sm.state_mst_id = ur.region_code "
							+ " inner join cs_user_franchise_zone_mapping_mst cufzm "
							+ " on ur.user_id = cufzm.user_mst_id "
							+ " inner join user_mst u "
							+ " on ur.user_id = u.user_mst_id "
							+ " inner join franchise_zone_mst fzm "
							+ " on cufzm.franchise_zone_mst_id = fzm.franchise_zone_mst_id "
							+ " inner join role_mst r "
							+ " on r.role_mst_id = u.role_mst_id "
							+ " left outer join delivery d "
							+ " on f.delivery_id = d.delivery_id "
							+ " where r.role_cd in ('SUPEXE') and f.id = "+franchiseeAllocationMst.getId());
					List<Object[]> result = (List<Object[]>) query.getResultList();
					String csUserName = null;
					String csEmail = null;
					Integer userId = null;
					String zoneEmail = null;
					CustomerSapmst customerSapmst = new CustomerSapmst();
					for (Object[] objects : result) {
						userId = (Integer)objects[0];
						csUserName = (String)objects[1];
						csEmail = (csEmail==null?"":csEmail+";")+(String)objects[2];
						zoneEmail = (String)objects[3];
						customerSapmst.setCityName(objects[4]!=null?(String)objects[4]:"");
						customerSapmst.setStreet1(objects[5]!=null?(String)objects[5]:"");
						customerSapmst.setStreet2(objects[6]!=null?(String)objects[6]:"");
						customerSapmst.setStreet3(objects[7]!=null?(String)objects[7]:"");
						customerSapmst.setStreet4(objects[8]!=null?(String)objects[8]:"");
						customerSapmst.setStreet5(objects[9]!=null?(String)objects[9]:"");
						
						//setting state name
						customerSapmst.setCustomerName(objects[10]!=null?(String)objects[10]:"");
						
						customerSapmst.setPin(objects[11]!=null?(String)objects[11]:"");
					}
					
					Integer requestUserId = franchiseeAllocationMst.getUser_id();
					query = em.createNamedQuery("UserMst.getUserEmailById");
					query.setParameter(1, requestUserId);
					List<UserMst> userList = (List<UserMst>) query.getResultList();
					
					query = em.createNativeQuery("select u.user_mst_id,u.user_name,u.user_email from user_to_franchisee_mst uf inner join user_mst u on uf.user_mst_id = u.user_mst_id where uf.franchisee_id="+franchiseeAllocationMst.getFranchisee_id());
					List<Object[]> results = (List<Object[]>) query.getResultList();
					String frUserName = null;
					String frEmail = null;
					Integer fruserId = null;
					for (Object[] objects : results) {
						fruserId = (Integer)objects[0];
						frUserName = (String)objects[1];
						frEmail = (frEmail==null?"":frEmail+";")+(String)objects[2];
						
					}
					
					//query to get franchise allocation details begins
					query = em.createNativeQuery(" select so.sold_to_party,stp.customer_name,so.ship_to_party,"
							+ " COALESCE(shtp.street1,'')+' '+COALESCE(shtp.street2,'') +' '+COALESCE(shtp.street3,'')+' '+COALESCE(shtp.street4,'') +' '+COALESCE(shtp.street5,'')+' '+COALESCE(shtp.city_name,'') +'-'+COALESCE(shtp.pin,'')+' '+COALESCE(sm.state_val,'')+','+COALESCE(cm.country_val,'') as shtp_address, "
							+ " fam.so_number,d.delivery_num,fam.installation_address,itm.installation_type_val,"
							+ " fam.vsat_id,fam.vsat_ip,fam.contact_person_number,fam.site_contact_person,"
							+ " fam.additional_remarks,tm.value,hm.hub_desc,fam.sub_customer "
							+ " from franchisee_allocation_mst fam inner join installation_type_mst itm on fam.installation_type_mst_id = itm.installation_type_mst_id inner join so_orders so on fam.so_number = so.so_number and fam.item = so.item inner join customer_sapmst shtp on so.ship_to_party = shtp.customer_num and so.dist_channel = shtp.dist_channel and so.division = shtp.division and so.sales_org = shtp.sales_org inner join customer_sapmst stp on so.sold_to_party = stp.customer_num and so.dist_channel = stp.dist_channel and so.division = stp.division and so.sales_org = stp.sales_org inner join country_mst cm on shtp.country_code = cm.country_code inner join state_mst sm on shtp.region_code = sm.state_code left outer join delivery d on fam.delivery_id = d.delivery_id left outer join hub_mst hm on fam.hub_mst_id = hm.hub_mst_id left outer join technology_mst tm on fam.technology_mst_id = tm.id " + 
							" where fam.id = :famId ");
					query.setParameter("famId", franchiseeAllocationMst.getId());
					List<Object[]> soDetailsResult = (List<Object[]>) query.getResultList();
					FranchiseAllocEmailDetails emailDetails = new FranchiseAllocEmailDetails();
					for (Object[] objects : soDetailsResult) {
						emailDetails.setSoldToParty(objects[0]!=null?(String)objects[0]:"");
						emailDetails.setCustomerName(objects[1]!=null?(String)objects[1]:"");
						emailDetails.setShipToParty(objects[2]!=null?(String)objects[2]:"");
						emailDetails.setShtpAddress(objects[3]!=null?(String)objects[3]:"");
						emailDetails.setSoNumber(objects[4]!=null?(String)objects[4]:"");
						emailDetails.setDeliverNumber(objects[5]!=null?(String)objects[5]:"");
						emailDetails.setAdditionalAddress(objects[6]!=null?(String)objects[6]:"");
						emailDetails.setInstallationType(objects[7]!=null?(String)objects[7]:"");
						emailDetails.setVsatId(objects[8]!=null?(String)objects[8]:"");
						emailDetails.setVsatIp(objects[9]!=null?(String)objects[9]:"");
						emailDetails.setContactPersonNumber(objects[10]!=null?(String)objects[10]:"");
						emailDetails.setSiteContactPerson(objects[11]!=null?(String)objects[11]:"");
						emailDetails.setAdditionalRemarks(objects[12]!=null?(String)objects[12]:"");
						emailDetails.setTechnology(objects[13]!=null?(String)objects[13]:"");
						emailDetails.setHubDesc(objects[14]!=null?(String)objects[14]:"");
						emailDetails.setSubCustomer(objects[15]!=null?(String)objects[15]:"");
					}
					//query to get franchise allocation details ends
					
					
					EmailBean emailBean = new EmailBean();
					
					if(commonDTOInput.getFlag().equals("A")) {
						if(userId!=null) {
							
							emailBean.setToMail((frEmail!=null?frEmail+";":"")+(csEmail!=null?csEmail+";":"")+(zoneEmail!=null?zoneEmail:""));
							
							if(userList!=null && userList.size()>0) {
								emailBean.setCopyRecepients(userList.get(0).getUserEmail());
							}
							emailBean.setSubject("I&C Request Engineer Allocated : " + franchiseeAllocationMst.getUniqId());
							emailBean.setEmailBody("Dear User,"// +finance.getUserName()+","
									+ "<br>Engineer has been accepted for I&C Request." + "<br>I&C Request ID:"
									+ franchiseeAllocationMst.getUniqId() + "<br>Engineer Name : " + franchiseeAllocEngMst.getName()
									+ "<br>Engineer Mobile Number : " + franchiseeAllocEngMst.getMobile_no() + "<br>Engineer Email : "
									+ franchiseeAllocEngMst.getEmail_id() + "<br>Please login and accept to process further to know more."
									+ "<br> Click here to login :  <a href=" + env.getProperty("emaillink") + ">O2C portal link</a>  "
									+ "<br><br>Sincerely");
							callSpDao.sendEmail(emailBean);
						}
				
				//email sending to franchise informing the acceptance of engineer ends
				
				
				//email to allocated engineer begins
						emailBean = new EmailBean();
						emailBean.setToMail(franchiseeAllocEngMst.getEmail_id());
						emailBean.setSubject("I&C Request assigned : " + franchiseeAllocationMst.getUniqId());
						emailBean.setEmailBody("Dear User,"// +finance.getUserName()+","
								+ "<br>I&C Request task has been assigned." + "<br>I&C Request ID:" + franchiseeAllocationMst.getUniqId()
								+ "<br>Site Person Contact Name : " + franchiseeAllocationMst.getSiteContactPerson() 
								+ "<br>Customer Name : " + emailDetails.getCustomerName()
								+ "<br>Sub Customer Name : " + emailDetails.getSubCustomer()
								+ "<br>So Number : " + emailDetails.getSoNumber()
								+ "<br>Ship To Party Address : " + emailDetails.getShtpAddress()
								+ "<br>Additional Address : " + emailDetails.getAdditionalAddress()
								+ "<br>Installation Type : " + emailDetails.getInstallationType()
								+ "<br>VSAT ID : " + emailDetails.getVsatId()
								+ "<br>IP : " + emailDetails.getVsatIp()
								+ "<br>Contact Person : " + emailDetails.getSiteContactPerson()
								+ "<br>Contact Person Number : " + emailDetails.getContactPersonNumber()
								+ "<br>Hub : " + emailDetails.getHubDesc()
								+ "<br>Additional Remarks : " + emailDetails.getAdditionalRemarks()
								+ "<br>Technology : " + emailDetails.getTechnology()
								+"<br><br>Sincerely");
						callSpDao.sendEmail(emailBean);	
				//email to allocated engineer ends		
						
					} else {
						//email sending to franchise in case of rejection begins
						if(userId!=null) {
							
							emailBean.setToMail((frEmail!=null?frEmail+";":"")+(csEmail!=null?csEmail+";":"")+(zoneEmail!=null?zoneEmail:""));
							
							if(userList!=null && userList.size()>0) {
								emailBean.setCopyRecepients(userList.get(0).getUserEmail());
							}
							emailBean.setSubject("I&C Request Allocated Engineer Rejected : " + franchiseeAllocationMst.getUniqId());
							emailBean.setEmailBody("Dear User,"// +finance.getUserName()+","
									+ "<br>Engineer has been rejected for I&C Request." + "<br>I&C Request ID:"
									+ franchiseeAllocationMst.getUniqId() + "<br>Engineer Name : " + franchiseeAllocEngMst.getName()
									+ "<br>Engineer Mobile Number : " + franchiseeAllocEngMst.getMobile_no() + "<br>Engineer Email : "
									+ franchiseeAllocEngMst.getEmail_id()
									+ "<br>Customer Name : " + emailDetails.getCustomerName()
									+ "<br>Sub Customer Name : " + emailDetails.getSubCustomer()
									+ "<br>Ship To Party Address : " + emailDetails.getShtpAddress()
									+ "<br>Additional Address : " + emailDetails.getAdditionalAddress()
									+ "<br>Installation Type : " + emailDetails.getInstallationType()
									+ "<br>VSAT ID : " + emailDetails.getVsatId()
									+ "<br>IP : " + emailDetails.getVsatIp()
									+ "<br>Contact Person : " + emailDetails.getSiteContactPerson()
									+ "<br>Contact Person Number : " + emailDetails.getContactPersonNumber()
									+ "<br>Hub : " + emailDetails.getHubDesc()
									+ "<br>Additional Remarks : " + emailDetails.getAdditionalRemarks()
									+ "<br>Technology : " + emailDetails.getTechnology()
									+ "<br>Please login and accept to process further to know more."
									+ "<br> Click here to login :  <a href=" + env.getProperty("emaillink") + ">O2C portal link</a>  "
									+ "<br><br>Sincerely");
							callSpDao.sendEmail(emailBean);
						}
				
				//email sending to franchise informing the rejection of engineer ends
					
						
					}
					
						
			//email to allocated engineer ends
					
					
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StatusMst> getFranchiseStatusList(List<String> statusList) {
		try {
			query = em.createNamedQuery("StatusMst.findByCode");
			query.setParameter("statusCodeList", statusList);
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);

			return (List<StatusMst>) query.getResultList();
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StateMst> getStateListByRoleCode(FranchiseDropDownDTO inputFranchiseDropDownDTO) {
		try {
			// TODO Auto-generated method stub
			List<StateMst> stateList = new ArrayList<StateMst>();
			if (inputFranchiseDropDownDTO.getRoleCode().equalsIgnoreCase(constantProperties.getSuppExecRoleCode())
					|| inputFranchiseDropDownDTO.getRoleCode()
							.equalsIgnoreCase(constantProperties.getSuppMgrRoleCode())) {
				query = em.createNativeQuery(
						"select distinct sm.state_mst_id,sm.state_code,sm.state_val,sm.country_code from state_mst sm inner join user_to_region_mst utr on sm.state_mst_id = utr.region_code where utr.user_id = :userId ");
				query.setParameter("userId", inputFranchiseDropDownDTO.getUserMstId());
				List<Object[]> resultList = (List<Object[]>) query.getResultList();
				for (Object[] objects : resultList) {
					StateMst stateMst = new StateMst();
					stateMst.setStateMstId((Integer) objects[0]);
					stateMst.setStateCode((String) objects[1]);
					stateMst.setStateVal((String) objects[2]);
					stateMst.setCountryCode((String) objects[3]);

					stateList.add(stateMst);
				}
			} else if (inputFranchiseDropDownDTO.getRoleCode()
					.equalsIgnoreCase(constantProperties.getFranCoordRoleCode())) {
				query = em.createNativeQuery(
						"select distinct sm.state_mst_id,sm.state_code,sm.state_val,sm.country_code from user_mst u inner join user_to_franchisee_mst utf on u.user_mst_id = utf.user_mst_id inner join franchise_to_state fts on utf.franchisee_id = fts.franchise_mst_id inner join state_mst sm on fts.state_mst_id = sm.state_mst_id where utf.user_mst_id = :userId");
				query.setParameter("userId", inputFranchiseDropDownDTO.getUserMstId());
				List<Object[]> resultList = (List<Object[]>) query.getResultList();
				for (Object[] objects : resultList) {
					StateMst stateMst = new StateMst();
					stateMst.setStateMstId((Integer) objects[0]);
					stateMst.setStateCode((String) objects[1]);
					stateMst.setStateVal((String) objects[2]);
					stateMst.setCountryCode((String) objects[3]);

					stateList.add(stateMst);
				}
			} else {
				query = em.createNamedQuery("StateMst.findAll");
				stateList = (List<StateMst>) query.getResultList();
			}
			return stateList;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Transactional(rollbackFor = Exception.class)
	@Override
	public List<FranchiseeAllocationMst> uploadINCRequest(MultipartFile file, String userMstId) throws Exception {
		// TODO Auto-generated method stub
		HSSFWorkbook workbook = new HSSFWorkbook(file.getInputStream());
		HSSFRow row = null;
		int i = 1;
		Integer j = null;
		BigDecimal deliveryNum = null;
		BigDecimal soNumber = null;
		BigDecimal itemQty = null;
		BigDecimal contactPersonNumber = null;
		Contract contract = new Contract();
		List<FranchiseeAllocationMst> franchiseeAllocaMstList = new ArrayList<FranchiseeAllocationMst>();
		FranchiseeAllocationMst franchiseeAllocaMst = null;
		FranchiseeAllocationMst franchiseeAllocaMstNew = null;
		FranchiseeDTO franchiseeDTO = null;
		InstallationTypeMst installTypeMst = null;
		HubMst hubMst = null;
		TechnologyMaster techMaster = null;
		Delivery delivery = null;
		SiteSurveyDTO siteSurveyDTO = null;
		SiteSurveyMaster siteSurveyMaster = new SiteSurveyMaster();
		HSSFSheet worksheet = workbook.getSheetAt(0);
		while (i <= worksheet.getLastRowNum()) {
			row = worksheet.getRow(i++);
			franchiseeAllocaMst = new FranchiseeAllocationMst();
			franchiseeAllocaMstNew = new FranchiseeAllocationMst();
			installTypeMst = new InstallationTypeMst();
			hubMst = new HubMst();
			techMaster = new TechnologyMaster();
			franchiseeDTO = new FranchiseeDTO();
			delivery = new Delivery();

			soNumber = new BigDecimal(String.valueOf(row.getCell(0)).trim());
			Double soNum = Double.parseDouble(soNumber.toPlainString());

			itemQty = new BigDecimal(String.valueOf(row.getCell(1)).trim());
			Double itemQuantity = Double.parseDouble(itemQty.toPlainString());

			if (commonMasterService.getCount("franchisee_allocation_mst", "so_number",
					soNumber.toPlainString(), "item", itemQty.toPlainString()) <= 0) {
				franchiseeDTO.setSoNumber(soNumber.toPlainString());
				franchiseeDTO.setItem(itemQty.toPlainString());
			} else {
				throw new Exception("Error of Line No : " + i
						+ " . Duplicate Installation and Commissioning material item. So Number : "
						+ soNumber.toPlainString() + " Item quantity : " + itemQty.toPlainString());
			}

			if (!(String.valueOf(row.getCell(2)).trim().equals("") || String.valueOf(row.getCell(2)).equals("null"))) {
				deliveryNum = new BigDecimal(String.valueOf(row.getCell(2)).trim());
				Double delNumber = Double.parseDouble(deliveryNum.toPlainString());
				delivery = deliveryDao.getDelByDelNum(deliveryNum.toPlainString());
				franchiseeDTO.setDeliveryId(delivery.getDeliveryId());
				;
				franchiseeDTO.setDeliveryNum(delivery.getDeliveryNum());
			}
			franchiseeDTO.setInstallationAddress(String.valueOf(row.getCell(3)).trim());
			franchiseeDTO.setSiteContactPerson(String.valueOf(row.getCell(4)).trim());
			if (!(String.valueOf(row.getCell(5)).trim().equals("") || String.valueOf(row.getCell(5)).equals("null"))) {
				try {
					contactPersonNumber = new BigDecimal(String.valueOf(row.getCell(5)).trim());
					franchiseeDTO.setContactPersonNumber(contactPersonNumber.toPlainString());
				} catch (NumberFormatException e) {
					franchiseeDTO.setContactPersonNumber(String.valueOf(row.getCell(5)).trim());
				}
			}
			franchiseeDTO.setVsatId(String.valueOf(row.getCell(6)).trim());
			franchiseeDTO.setVsatIp(String.valueOf(row.getCell(7)).trim());
			installTypeMst = commonMasterDao.getInstallTypeMstByDesc(String.valueOf(row.getCell(8)).trim());
			franchiseeDTO.setInstallationTypeMstId(installTypeMst.getInstallationTypeMstId());
			hubMst = commonMasterDao.getHubByDesc(String.valueOf(row.getCell(9)).trim());
			franchiseeDTO.setHubMstId(hubMst.getHubMstId());
			techMaster = commonMasterDao.getTechnologyByDesc(String.valueOf(row.getCell(10)).trim());
			franchiseeDTO.setTechnologyMstId(techMaster.getId());
			if (!(String.valueOf(row.getCell(11)).trim().equals("")
					|| String.valueOf(row.getCell(11)).equals("null"))) {
				String tentativeDate = DateUtil.convertDateToSqlDate(String.valueOf(row.getCell(11)).trim());
				franchiseeDTO.setTentativeDate(tentativeDate);
			}

			franchiseeDTO.setAdditionalRemarks(String.valueOf(row.getCell(12)).trim());
			franchiseeDTO.setSiteSurveyDone(String.valueOf(row.getCell(13)).trim());

			if (String.valueOf(row.getCell(13)).trim().equalsIgnoreCase(properties.getYesFlag())) {
				siteSurveyDTO = new SiteSurveyDTO();
				siteSurveyDTO.setUniq_id(String.valueOf(row.getCell(14)).trim());
				siteSurveyMaster = siteSurveyDao.getSiteSurveyByUniqId(siteSurveyDTO);
				franchiseeDTO.setSiteSurveyUniqId(siteSurveyMaster.getUniq_id());
				franchiseeDTO.setSite_survey_id(siteSurveyMaster.getId());
			}
			franchiseeDTO.setSubCustomer(String.valueOf(row.getCell(15)).trim());
			franchiseeDTO.setUser_id(Integer.parseInt(userMstId));

			franchiseeAllocaMstNew = this.saveFranchiseeAllocation(franchiseeDTO);

			franchiseeAllocaMstList.add(franchiseeAllocaMstNew);
		}

		return franchiseeAllocaMstList;
	}	
}
