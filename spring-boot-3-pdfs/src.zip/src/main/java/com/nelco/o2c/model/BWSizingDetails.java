/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;

/**
 * @author Amol.l
 *
 */

@Entity
@Table(name = "bw_sizing_details")
@NamedQueries({
		@NamedQuery(name = "BWSizingDetails.findByDrfId", query = "SELECT bw FROM BWSizingDetails bw where bw.drfDetailsId=?1") })
public class BWSizingDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bw_sizing_details_id")
	private Integer bwSizingDetailsId;

	@Column(name = "drf_details_id")
	private Integer drfDetailsId;

	@Column(name = "cust_name", length = 200)
	private String customerName;

	@Column(name = "cust_code", length = 50)
	private String customerNum;

	@Column(name = "street_1", length = 200)
	private String street1;

	@Column(name = "street_2", length = 200)
	private String street2;

	@Column(name = "street_3", length = 200)
	private String street3;

	@Column(name = "street_4", length = 200)
	private String street4;

	@Column(name = "street_5", length = 200)
	private String street5;

	@Column(name = "city_name")
	private String cityName;

	@Column(name = "state_mst_id")
	private Integer stateMstId;

	@Column(name = "country_mst_id")
	private Integer countryMstId;

	@Column(name = "location_mst_id")
	private Integer locationMstId;

	@Column(name = "add_bw")
	private String addBw;

	@Column(name = "vsat_ip", length = 50)
	private String vsatIp;

	@Column(name = "demo_dur", length = 50)
	private String demoDur;

	@Column(name = "demo_date")
	private String demoDate;

	@Column(name = "created_date")
	private String createdDate;
	
	private String pin;
	

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	/*@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "city_mst_id", referencedColumnName = "city_mst_id", insertable = false, updatable = false)
	private CityMst cityMst;*/

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "state_mst_id", referencedColumnName = "state_mst_id", insertable = false, updatable = false)
	private StateMst stateMst;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "country_mst_id", referencedColumnName = "country_mst_id", insertable = false, updatable = false)
	private CountryMst countryMst;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "location_mst_id", referencedColumnName = "location_mst_id", insertable = false, updatable = false)
	private LocationMst locationMst;

	/*public CityMst getCityMst() {
		return cityMst;
	}

	public void setCityMst(CityMst cityMst) {
		this.cityMst = cityMst;
	}*/

	public StateMst getStateMst() {
		return stateMst;
	}

	public void setStateMst(StateMst stateMst) {
		this.stateMst = stateMst;
	}

	public CountryMst getCountryMst() {
		return countryMst;
	}

	public void setCountryMst(CountryMst countryMst) {
		this.countryMst = countryMst;
	}

	public LocationMst getLocationMst() {
		return locationMst;
	}

	public void setLocationMst(LocationMst locationMst) {
		this.locationMst = locationMst;
	}

	public Integer getBwSizingDetailsId() {
		return bwSizingDetailsId;
	}

	public void setBwSizingDetailsId(Integer bwSizingDetailsId) {
		this.bwSizingDetailsId = bwSizingDetailsId;
	}

	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}

	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}


	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	

	public String getCustomerNum() {
		return customerNum;
	}

	public void setCustomerNum(String customerNum) {
		this.customerNum = customerNum;
	}

	public String getStreet1() {
		return street1;
	}

	public void setStreet1(String street1) {
		this.street1 = street1;
	}

	public String getStreet2() {
		return street2;
	}

	public void setStreet2(String street2) {
		this.street2 = street2;
	}

	public String getStreet3() {
		return street3;
	}

	public void setStreet3(String street3) {
		this.street3 = street3;
	}

	public String getStreet4() {
		return street4;
	}

	public void setStreet4(String street4) {
		this.street4 = street4;
	}

	public String getStreet5() {
		return street5;
	}

	public void setStreet5(String street5) {
		this.street5 = street5;
	}

	
	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Integer getStateMstId() {
		return stateMstId;
	}

	public void setStateMstId(Integer stateMstId) {
		this.stateMstId = stateMstId;
	}

	public Integer getCountryMstId() {
		return countryMstId;
	}

	public void setCountryMstId(Integer countryMstId) {
		this.countryMstId = countryMstId;
	}

	public Integer getLocationMstId() {
		return locationMstId;
	}

	public void setLocationMstId(Integer locationMstId) {
		this.locationMstId = locationMstId;
	}

	public String getAddBw() {
		return addBw;
	}

	public void setAddBw(String addBw) {
		this.addBw = addBw;
	}

	public String getVsatIp() {
		return vsatIp;
	}

	public void setVsatIp(String vsatIp) {
		this.vsatIp = vsatIp;
	}

	public String getDemoDur() {
		return demoDur;
	}

	public void setDemoDur(String demoDur) {
		this.demoDur = demoDur;
	}

	public String getDemoDate() {
		//System.out.println(demoDate+"DEMODATETTTTTTT");
		return DateUtil.convertDateTimeToString(demoDate);
		//return demoDate;
	}

	public void setDemoDate(String demoDate) {
		this.demoDate = DateUtil.convertDateToSqlDate(demoDate);
	}

	public String getCreatedDate() {
		return DateUtil.convertDateTimeToString(createdDate);
		//return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

}
