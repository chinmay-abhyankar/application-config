package com.nelco.o2c.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.HtmlUtils;

import com.nelco.o2c.dto.SiteSurveyDTO;
import com.nelco.o2c.dto.SiteSurveyEngineerDTO;
import com.nelco.o2c.dto.SiteSurveyFormDTO;
import com.nelco.o2c.dto.SiteSurveyListDTO;
import com.nelco.o2c.dto.UpdateFranchiseDTO;
import com.nelco.o2c.jsonbeanmap.EmailBean;
import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.AntennaSizeMaster;
import com.nelco.o2c.model.CountryMst;
import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.model.FranchiseTracker;
import com.nelco.o2c.model.FranchiseeMaster;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.SiteSurveyEngineerMst;
import com.nelco.o2c.model.SiteSurveyMaster;
import com.nelco.o2c.model.SiteSurveyTrackerMaster;
import com.nelco.o2c.model.StateMst;
import com.nelco.o2c.model.TechnologyMaster;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;
import com.nelco.o2c.utility.SDCommonUtil;

@Repository
public class SiteSurveyDaoImpl implements SiteSurveyDao {
	@PersistenceContext
	EntityManager em;
	Query query;
	@Autowired
	HttpSession session;
	@Autowired
	CallSpDao callSpDao;
	
	@Autowired
	EngVisitDao engVisitDao;
	
	@Autowired
	private Environment env;

	@Override
	public SiteSurveyFormDTO getSiteSurveyFormMasters(SiteSurveyFormDTO siteSurveyFormDTO) {
		try {
			query = em.createNamedQuery("AntennaSizeMaster.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<AntennaSizeMaster> antennaSize = query.getResultList();
			siteSurveyFormDTO
					.setAntennaSizeMaster(antennaSize != null ? antennaSize : new ArrayList<AntennaSizeMaster>());
			query = em.createNamedQuery("TechnologyMaster.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<TechnologyMaster> technologyMaster = query.getResultList();
			siteSurveyFormDTO.setTechnologyMaster(
					technologyMaster != null ? technologyMaster : new ArrayList<TechnologyMaster>());
			query = em.createNamedQuery("CountryMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<CountryMst> countryMaster = query.getResultList();
			siteSurveyFormDTO.setCountryMaster(countryMaster != null ? countryMaster : new ArrayList<CountryMst>());
			query = em.createNamedQuery("StateMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<StateMst> stateMst = query.getResultList();
			siteSurveyFormDTO.setStateMst(stateMst != null ? stateMst : new ArrayList<StateMst>());
			query = em.createNamedQuery("HubMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<HubMst> hubMst = query.getResultList();
			siteSurveyFormDTO.setHubMaster(hubMst != null ? hubMst : new ArrayList<HubMst>());
		} finally {
			em.close();
		}
		return siteSurveyFormDTO;
	}

	@Override
	public List<CustomerSapmst> getListCustomerAutoComplete(HttpServletRequest request) {
		query = em.createNamedQuery("CustomerSapmst.searchShipToParty");
		query.setMaxResults(10);
		query.setParameter(1, "%" + request.getParameter("input") + "%");
		query.setParameter(2, "%" + request.getParameter("input") + "%");
		List<CustomerSapmst> custList = (List<CustomerSapmst>) query.getResultList();
		return custList != null ? custList : new ArrayList<CustomerSapmst>();
	}

	@Override
	public SiteSurveyMaster saveSiteSurveyDTO(SiteSurveyDTO siteSurveyDTO) {
		String uniq_id = "";
		if (siteSurveyDTO.getId() == null) {
			synchronized (this) {
				Integer maxProposalNumber = getCurrentDayCountSiteSurveyMaster();
				uniq_id = "SIT_SUR_" + (DateUtil.getCurrentISTDateAsString(DateUtil.SIMPLE_DATE_FORMAT)
						.replace("-", "_").concat("_").concat(maxProposalNumber.toString()));
			}
			siteSurveyDTO.setUniq_id(uniq_id);
		}
		SiteSurveyMaster siteSurveyMaster = new SiteSurveyMaster();
		siteSurveyMaster.setId(siteSurveyDTO.getId());
		siteSurveyMaster.setAntenna_size_id(siteSurveyDTO.getAntenna_size_id());
		siteSurveyMaster.setBillable(siteSurveyDTO.getBillable());
		siteSurveyMaster.setCity(siteSurveyDTO.getCity());
		siteSurveyMaster.setContact_person_no(siteSurveyDTO.getContact_person_no());
		siteSurveyMaster.setCountry_id(siteSurveyDTO.getCountry_id());
		siteSurveyMaster.setCustomer_id(siteSurveyDTO.getCustomer_id());
		siteSurveyMaster.setHub_id(siteSurveyDTO.getHub_id());
		siteSurveyMaster.setPin(siteSurveyDTO.getPin());
		siteSurveyMaster.setSite_person_contact_name(siteSurveyDTO.getSite_person_contact_name());
		siteSurveyMaster.setUniq_id(siteSurveyDTO.getUniq_id());
		siteSurveyMaster.setStatus(34);
		siteSurveyMaster.setStreet_1(siteSurveyDTO.getStreet_1());
		siteSurveyMaster.setStreet_2(siteSurveyDTO.getStreet_2());
		siteSurveyMaster.setStreet_3(siteSurveyDTO.getStreet_3());
		siteSurveyMaster.setStreet_4(siteSurveyDTO.getStreet_4());
		siteSurveyMaster.setStreet_5(siteSurveyDTO.getStreet_5());
		siteSurveyMaster.setState_id(siteSurveyDTO.getState_id());
		siteSurveyMaster.setUser_id(siteSurveyDTO.getUser_id());
		siteSurveyMaster.setTechnology_id(siteSurveyDTO.getTechnology_id());
		siteSurveyMaster.setCreation_date(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		siteSurveyMaster.setCustomerName(siteSurveyDTO.getCustomerName());
		siteSurveyMaster.setSub_customer(siteSurveyDTO.getSub_customer());
		siteSurveyMaster.setAlternative_mobile_no(siteSurveyDTO.getAlternative_mobile_no());
		siteSurveyMaster.setTentative_date(DateUtil.convertDateToSqlDate(siteSurveyDTO.getTentative_date()));
		siteSurveyMaster.setTentative_timing(siteSurveyDTO.getTentative_timing());
		siteSurveyMaster.setRemarks(siteSurveyDTO.getRemarks());
		siteSurveyMaster=em.merge(siteSurveyMaster);
		this.updateTracker(siteSurveyMaster.getId(), 34, siteSurveyMaster.getUser_id());
		return siteSurveyMaster; 
	}

	@SuppressWarnings("unchecked")
	@Override
	public SiteSurveyMaster submitSiteSurveyDTO(SiteSurveyDTO siteSurveyDTO) {
		SiteSurveyMaster siteSurveyMaster = new SiteSurveyMaster();
		siteSurveyMaster.setId(siteSurveyDTO.getId());
		siteSurveyMaster.setUniq_id(siteSurveyDTO.getUniq_id());
		siteSurveyMaster.setAntenna_size_id(siteSurveyDTO.getAntenna_size_id());
		siteSurveyMaster.setBillable(siteSurveyDTO.getBillable());
		siteSurveyMaster.setCity(siteSurveyDTO.getCity());
		siteSurveyMaster.setContact_person_no(siteSurveyDTO.getContact_person_no());
		siteSurveyMaster.setCountry_id(siteSurveyDTO.getCountry_id());
		siteSurveyMaster.setCustomer_id(siteSurveyDTO.getCustomer_id());
		siteSurveyMaster.setHub_id(siteSurveyDTO.getHub_id());
		siteSurveyMaster.setPin(siteSurveyDTO.getPin());
		siteSurveyMaster.setSite_person_contact_name(siteSurveyDTO.getSite_person_contact_name());
		siteSurveyMaster.setStatus(35);
		siteSurveyMaster.setStreet_1(siteSurveyDTO.getStreet_1());
		siteSurveyMaster.setStreet_2(siteSurveyDTO.getStreet_2());
		siteSurveyMaster.setStreet_3(siteSurveyDTO.getStreet_3());
		siteSurveyMaster.setStreet_4(siteSurveyDTO.getStreet_4());
		siteSurveyMaster.setStreet_5(siteSurveyDTO.getStreet_5());
		siteSurveyMaster.setTechnology_id(siteSurveyDTO.getTechnology_id());
		siteSurveyMaster.setState_id(siteSurveyDTO.getState_id());
		siteSurveyMaster.setUser_id(siteSurveyDTO.getUser_id());
		siteSurveyMaster.setCreation_date(DateUtil.getCurrentUTCDateAsString());
		siteSurveyMaster.setCustomerName(siteSurveyDTO.getCustomerName());
		siteSurveyMaster.setSub_customer(siteSurveyDTO.getSub_customer());
		siteSurveyMaster.setAlternative_mobile_no(siteSurveyDTO.getAlternative_mobile_no());
		siteSurveyMaster.setTentative_date(DateUtil.convertDateToSqlDate(siteSurveyDTO.getTentative_date()));
		siteSurveyMaster.setTentative_timing(siteSurveyDTO.getTentative_timing());
		siteSurveyMaster.setRemarks(siteSurveyDTO.getRemarks());		
		siteSurveyMaster =em.merge(siteSurveyMaster);
		this.updateTracker(siteSurveyMaster.getId(), 35, siteSurveyMaster.getUser_id());
		
		
		// email sending to site survey request begins
		query = em.createNativeQuery("select user_id,user_name,user_email,fzm.franchise_zone_email from user_to_region_mst ur inner join user_mst u on ur.user_id = u.user_mst_id left join cs_user_franchise_zone_mapping_mst cuzm on u.user_mst_id = cuzm.user_mst_id left join franchise_zone_mst fzm on cuzm.franchise_zone_mst_id = fzm.franchise_zone_mst_id where region_code ="+siteSurveyMaster.getState_id());
		List<Object[]> result = (List<Object[]>) query.getResultList();
		String csUserName = null;
		String csEmail = null;
		Integer userId = null;
		String zoneEmail = null;
		for (Object[] objects : result) {
			userId = (Integer)objects[0];
			csUserName = (String)objects[1];
			csEmail = (String)objects[2];
			zoneEmail = (String)objects[3];
		}
		
		Integer requestUserId = siteSurveyDTO.getUser_id();
		query = em.createNamedQuery("UserMst.getUserEmailById");
		query.setParameter(1, requestUserId);
		List<UserMst> userList = (List<UserMst>) query.getResultList();
		
		
		if(userId!=null) {
			EmailBean emailBean = new EmailBean();
			emailBean.setToMail((csEmail!=null?csEmail+";":"")+(zoneEmail!=null?zoneEmail:""));
			
			if(userList!=null && userList.size()>0) {
				emailBean.setCopyRecepients(userList.get(0).getUserEmail());
			}
			emailBean.setSubject("Site survey request raised : " + siteSurveyDTO.getUniq_id());
			emailBean.setEmailBody("Dear User,"// +finance.getUserName()+","
					+ "<br> Site Survey is Request has been raised with id : " + siteSurveyDTO.getUniq_id() + "."
					+ "<br> Customer Name - "
					+ (siteSurveyDTO.getCustomerName() != null && siteSurveyDTO.getCustomerName() != "" ? siteSurveyDTO.getCustomerName() : "")
					+ "<br> Sub Customer Name - "
					+ (siteSurveyDTO.getSub_customer() != null && siteSurveyDTO.getSub_customer() != "" ? siteSurveyDTO.getSub_customer() : "")
					+ "<br> Site Address - " + (siteSurveyDTO.getStreet_1() != null && siteSurveyDTO.getStreet_1() != "" ? siteSurveyDTO.getStreet_1() : "")
					+ " "+ (siteSurveyDTO.getStreet_2() != null && siteSurveyDTO.getStreet_2() != "" ? siteSurveyDTO.getStreet_2() : "")
					+ " "+ (siteSurveyDTO.getStreet_3() != null && siteSurveyDTO.getStreet_3() != "" ? siteSurveyDTO.getStreet_3() : "")
					+ " "+ (siteSurveyDTO.getStreet_4() != null && siteSurveyDTO.getStreet_4() != "" ? siteSurveyDTO.getStreet_4() : "")
					+ " "+ (siteSurveyDTO.getStreet_5() != null && siteSurveyDTO.getStreet_5() != "" ? siteSurveyDTO.getStreet_5() : "")
					+ "<br> City - "
					+ (siteSurveyDTO.getCity() != null && siteSurveyDTO.getCity() != "" ? siteSurveyDTO.getCity() : "")
					+ "<br> Pin - "
					+ (siteSurveyDTO.getPin() != null && siteSurveyDTO.getPin() != "" ? siteSurveyDTO.getPin() : "")
					+ "<br> State - "
					+ (siteSurveyDTO.getStateName() != null && siteSurveyDTO.getStateName() != "" ? siteSurveyDTO.getStateName() : "")
					+ "<br> Country - "
					+ (siteSurveyDTO.getCountryName() != null && siteSurveyDTO.getCountryName() != "" ? siteSurveyDTO.getCountryName() : "")
					+ "<br> Site Contact Person Name - "
					+ (siteSurveyDTO.getSite_person_contact_name() != null && siteSurveyDTO.getSite_person_contact_name() != "" ? siteSurveyDTO.getSite_person_contact_name() : "")	
					+ "<br> Contact person Number - "
					+ (siteSurveyDTO.getContact_person_no() != null && siteSurveyDTO.getContact_person_no() != "" ? siteSurveyDTO.getContact_person_no() : "")
					+ "<br> Alternative Number - "
					+ (siteSurveyDTO.getAlternative_mobile_no() != null && siteSurveyDTO.getAlternative_mobile_no() != "" ? siteSurveyDTO.getAlternative_mobile_no() : "")
					+ "<br> Tentative Date - "
					+ (siteSurveyDTO.getTentative_date() != null && siteSurveyDTO.getTentative_date() != "" ? siteSurveyDTO.getTentative_date() : "")
					+ "<br> Tentative Time - "
					+ (siteSurveyDTO.getTentative_timing() != null && siteSurveyDTO.getTentative_timing() != "" ? siteSurveyDTO.getTentative_timing() : "")
					+ "<br> Technology - "
					+ (siteSurveyDTO.getTechnologyName() != null && siteSurveyDTO.getTechnologyName() != "" ? siteSurveyDTO.getTechnologyName() : "")
					+ "<br> Hub - "
					+ (siteSurveyDTO.getHubName() != null && siteSurveyDTO.getHubName() != "" ? siteSurveyDTO.getHubName() : "")
					+ "<br> Antenna Size - "
					+ (siteSurveyDTO.getAntennaSizeName() != null && siteSurveyDTO.getAntennaSizeName() != "" ? siteSurveyDTO.getAntennaSizeName() : "")
					+ "<br> Billable / Non-Billable - "
					+ (siteSurveyDTO.getBillable() != null && siteSurveyDTO.getBillable() != "" ? siteSurveyDTO.getBillable() : "")
					+ "<br> Remark - "
					+ (siteSurveyDTO.getRemarks() != null && siteSurveyDTO.getRemarks() != "" ? siteSurveyDTO.getRemarks() : "")
					+ "<br> Click here to login :  <a href=" + env.getProperty("emaillink") + ">O2C portal link</a>  "
					+ "<br><br>Sincerely,");
			callSpDao.sendEmail(emailBean);
		}		
		// email sending to site survey request ends
		
		return siteSurveyMaster;
	}

	@Override
	public Integer getCurrentDayCountSiteSurveyMaster() {
		try {
			String currentDate = DateUtil.getCurrentISTDateOnlyAsString(DateUtil.DATE_ONLY_FORMAT_MSSQL);
			query = em.createNamedQuery("SiteSurveyMaster.getCurrentDayMaxCount");
			query.setParameter(1, currentDate);
			query.setParameter(2, currentDate + " 23:59:59.999");
			Long maxNumber = (Long) query.getSingleResult();
			return maxNumber.intValue();
		} finally {
			em.close();
		}
	}

	@Override
	public List<FranchiseeMaster> getFranchiseeList() {
		try {
			query = em.createNamedQuery("FranchiseeMaster.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<FranchiseeMaster> antennaSize = query.getResultList();
			return antennaSize != null ? antennaSize : new ArrayList<FranchiseeMaster>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<SiteSurveyListDTO> getSiteSurveyListCS(HttpServletRequest request) {
		List<SiteSurveyListDTO> lst = new ArrayList<SiteSurveyListDTO>();
		String lQuery = "select s.id,s.uniq_id,f.franchise_mst_id,f.franchise_name,convert(varchar, s.creation_date, 105)"
				+ " as creation_date,se.name as eng_name,se.mobile_no as eng_mobile_no,se.email_id as eng_email_id"
				+ ",sm.status_mst_id,sm.status_code,sm.status_name,se.id as eng_id"
				+ " from site_survey_mst s left outer join customer_sapmst cs on"
				+ " s.customer_id=cs.customer_sapmst_id left outer join user_to_region_mst ur"
				+ " on s.state_id=ur.region_code" + " left outer join status_mst sm on s.status=sm.status_mst_id"
				+ " left outer join franchise_mst f on s.franchisee_id=f.franchise_mst_id"
				+ " left outer join (select site_survey_id,id,franchisee_id,name,mobile_no,email_id,creation_date from"
				+" (SELECT site_survey_id,id,franchisee_id,name,mobile_no,email_id,creation_date"
				+" ,ROW_NUMBER() over(partition by site_survey_id order by creation_date desc) as cnt"
				+" FROM site_survey_eng_mst  group by site_survey_id,id,franchisee_id,name,mobile_no,email_id,creation_date)tbl"
				+" where cnt=1)se on s.id=se.site_survey_id"
				+ " where ur.user_id=:user_id and s.creation_date between :start_date and :end_date " + " "
				+ " and status !=:status";
		SiteSurveyListDTO bean = null;
		query = em.createNativeQuery(lQuery);
		query.setParameter("user_id", Integer.parseInt(request.getParameter("user_id")));
		query.setParameter("start_date", DateUtil.convertDateToSqlDate(request.getParameter("start_date")));
		query.setParameter("end_date",
				DateUtil.convertDateToSqlDate(request.getParameter("end_date")) + " 23:59:59.999");
		query.setParameter("status", "34");
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			bean = new SiteSurveyListDTO();
			bean.setSite_survey_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setSite_survey_uniq_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[1]), false));
			bean.setFranchisee_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
			bean.setFranchisee_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
			bean.setCreation_date(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
			bean.setEngineer_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[5]), false));
			bean.setEngineer_mobile_no(SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false));
			bean.setEngineer_email_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false));
			bean.setStatus_mst_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[8]), false));
			bean.setStatus_mst_code((SDCommonUtil.convertNullToBlank(String.valueOf(o[9]), false)));
			bean.setStatus_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[10]), false));
			bean.setEngineer_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[11]), false));
			lst.add(bean);
		}
		return lst;
	}

	// This is for PMGT Team to Fetch
	@Override
	public List<SiteSurveyListDTO> getSitSurveyListByUser(HttpServletRequest request) {
		List<SiteSurveyListDTO> lst = new ArrayList<SiteSurveyListDTO>();
		String lQuery = "select s.id,s.uniq_id,f.franchise_mst_id,f.franchise_name,convert(varchar, s.creation_date, 105)"
				+ " as creation_date,se.name as eng_name,se.mobile_no as eng_mobile_no,se.email_id as eng_email_id"
				+ ",sm.status_mst_id,sm.status_code,sm.status_name,se.id as eng_id,convert(varchar, s.tentative_date, 105), "
				+ " s.customer_name,cs.customer_num,"
				+ " s.sub_customer,s.street_1,s.street_2,s.street_3,s.street_4,s.street_5,s.city,stm.state_val,s.pin, "
				+ " cm.country_val "
				+ " from site_survey_mst s left join customer_sapmst cs on" + " s.customer_id=cs.customer_sapmst_id"
				// + " inner join user_to_region_mst ur" + " on
				// cs.region_code=ur.region_code"
				+ " inner join status_mst sm on s.status=sm.status_mst_id "
				+ " inner join state_mst stm on s.state_id = stm.state_mst_id "
				+ " inner join country_mst cm on s.country_id = cm.country_mst_id "
				+ " left outer join franchise_mst f on s.franchisee_id=f.franchise_mst_id"
				+ " left outer join (select site_survey_id,id,franchisee_id,name,mobile_no,email_id,creation_date from"
				+" (SELECT site_survey_id,id,franchisee_id,name,mobile_no,email_id,creation_date"
				+" ,ROW_NUMBER() over(partition by site_survey_id order by creation_date desc) as cnt"
				+" FROM site_survey_eng_mst  group by site_survey_id,id,franchisee_id,name,mobile_no,email_id,creation_date)tbl"
				+" where cnt=1) se on s.id=se.site_survey_id"
				+ " where s.user_id=:user_id and s.creation_date between :start_date and :end_date " + " " + " ";
		SiteSurveyListDTO bean = null;
		query = em.createNativeQuery(lQuery);
		query.setParameter("user_id", Integer.parseInt(request.getParameter("user_id")));
		query.setParameter("start_date", DateUtil.convertDateToSqlDate(request.getParameter("start_date")));
		query.setParameter("end_date",
				DateUtil.convertDateToSqlDate(request.getParameter("end_date")) + " 23:59:59.999");
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			bean = new SiteSurveyListDTO();
			bean.setSite_survey_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setSite_survey_uniq_id(SDCommonUtil.convertNullToBlank((String) o[1], false));
			bean.setFranchisee_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
			bean.setFranchisee_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
			bean.setCreation_date(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
			bean.setEngineer_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[5]), false));
			bean.setEngineer_mobile_no(SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false));
			bean.setEngineer_email_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false));
			bean.setStatus_mst_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[8]), false));
			bean.setStatus_mst_code((SDCommonUtil.convertNullToBlank(String.valueOf(o[9]), false)));
			bean.setStatus_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[10]), false));
			bean.setEngineer_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[11]), false));
			bean.setTentative_date(SDCommonUtil.convertNullToBlank(String.valueOf(o[12]), false));
			bean.setCustomer_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[13]), false));
			bean.setShip_to_party(SDCommonUtil.convertNullToBlank(String.valueOf(o[14]), false));
			bean.setSub_customer(SDCommonUtil.convertNullToBlank(String.valueOf(o[15]), false));
			bean.setStreet_1(SDCommonUtil.convertNullToBlank(String.valueOf(o[16]), false));
			bean.setStreet_2(SDCommonUtil.convertNullToBlank(String.valueOf(o[17]), false));
			bean.setStreet_3(SDCommonUtil.convertNullToBlank(String.valueOf(o[18]), false));
			bean.setStreet_4(SDCommonUtil.convertNullToBlank(String.valueOf(o[19]), false));
			bean.setStreet_5(SDCommonUtil.convertNullToBlank(String.valueOf(o[20]), false));
			bean.setCity(SDCommonUtil.convertNullToBlank(String.valueOf(o[21]), false));
			bean.setState_val(SDCommonUtil.convertNullToBlank(String.valueOf(o[22]), false));
			bean.setPin(SDCommonUtil.convertNullToBlank(String.valueOf(o[23]), false));
			bean.setCountry_val(SDCommonUtil.convertNullToBlank(String.valueOf(o[24]), false));
			lst.add(bean);
		}
		return lst;
	}

	@SuppressWarnings("unchecked")
	@Override
	public SiteSurveyMaster updateFranchisee(UpdateFranchiseDTO input) {
		Integer franchisee_id = input.getFranchiseId();//Integer.parseInt(request.getParameter("franchisee_id"));
		Integer site_survey_id = input.getSiteSurveyId();//Integer.parseInt(request.getParameter("site_survey_id"));
		try {
			query = em.createNamedQuery("SiteSurveyMaster.updateFranchisee");
			query.setParameter(1, franchisee_id);
			query.setParameter(2, 36);
			query.setParameter(3, site_survey_id);
			int i = query.executeUpdate();
			Query query = em.createNamedQuery("SiteSurveyMaster.findById");
			query.setParameter(1, site_survey_id);
			SiteSurveyMaster siteSurveyMaster = (SiteSurveyMaster) query.getSingleResult();
			this.updateTracker(siteSurveyMaster.getId(), 36, siteSurveyMaster.getUser_id());
			// email sending to site survey request begins
			query = em.createNativeQuery("select u.user_mst_id,u.user_name,u.user_email from user_to_franchisee_mst uf inner join user_mst u on uf.user_mst_id = u.user_mst_id where uf.franchisee_id="+franchisee_id);
			List<Object[]> results = (List<Object[]>) query.getResultList();
			String frUserName = null;
			String frEmail = null;
			Integer userId = null;
			for (Object[] objects : results) {
				userId = (Integer)objects[0];
				frUserName = (String)objects[1];
				frEmail = (String)objects[2];
				
			}
			
			query = em.createNativeQuery("select u.user_mst_id,u.user_name,u.user_email from site_survey_mst ssm inner join user_mst u on ssm.user_id = u.user_mst_id where ssm.id ="+siteSurveyMaster.getId());
			List<Object[]> resultsPm = (List<Object[]>) query.getResultList();
			String pmUserName = null;
			String pmEmail = null;
			Integer pmuserId = null;
			for (Object[] objects : resultsPm) {
				pmuserId = (Integer)objects[0];
				pmUserName = (String)objects[1];
				pmEmail = (String)objects[2];
				
			}
			
			if(userId!=null) {
				EmailBean emailBean = new EmailBean();
				emailBean.setToMail(frEmail);
				if(pmuserId!=null)
					emailBean.setCopyRecepients(pmEmail);
				emailBean.setSubject("Franchise has been allocated for site survey : " + siteSurveyMaster.getUniq_id());
				emailBean.setEmailBody("Dear User,"// +finance.getUserName()+","
						+ "<br>Franchise has been allocated for : " + siteSurveyMaster.getUniq_id() + "."
						+ "<br>Please login to know more." + "<br> Click here to login :  <a href="
						+ env.getProperty("emaillink") + ">O2C portal link</a>  " + "<br><br>Sincerely");
				callSpDao.sendEmail(emailBean);
			}
			// email sending to site survey request ends
			
			//entry into franchise tracker table begins
			UserEmailDetailsBean userCsBean = engVisitDao.getCsUser(siteSurveyMaster);
			FranchiseTracker franchiseTracker = new FranchiseTracker();
			franchiseTracker.setFranchiseeId(franchisee_id);
			franchiseTracker.setFranchiseProcTypeMstId(1);
			Integer userCSId = null;
			if(userCsBean.getUserId()!=null)
				userCSId = Integer.valueOf(userCsBean.getUserId()); 
			
			franchiseTracker.setReqById(userCSId);
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			franchiseTracker.setReqDate(currTime);
			em.merge(franchiseTracker);
			//entry into franchise tracker table ends
			return siteSurveyMaster;
		} finally {
			em.close();
		}
	}

	@Override
	public SiteSurveyMaster getSiteSurveyById(HttpServletRequest request) {
		try {
			query = em.createNamedQuery("SiteSurveyMaster.findById");
			query.setParameter(1, Integer.parseInt(request.getParameter("id")));
			SiteSurveyMaster siteSurveyMaster = (SiteSurveyMaster) query.getSingleResult();
			return siteSurveyMaster;
		} catch (Exception e) {
			return new SiteSurveyMaster();
		} finally {
			em.close();
		}

	}

	@Override
	public List<SiteSurveyListDTO> getSitSurveyListForFranchisee(HttpServletRequest request) {
		List<SiteSurveyListDTO> lst = new ArrayList<SiteSurveyListDTO>();
		SiteSurveyListDTO bean = null;
		String fromDate = HtmlUtils.htmlEscape(DateUtil.convertDateToSqlDate(request.getParameter("start_date"))) + Constants.MINDAYTIME;
		String toDate   = HtmlUtils.htmlEscape(DateUtil.convertDateToSqlDate(request.getParameter("end_date"))) + Constants.MAXDAYTIME;
		String userMstId   = HtmlUtils.htmlEscape(request.getParameter("user_id"));
		String state_code = null;
		if(!request.getParameter("state_code").equalsIgnoreCase("null") && request.getParameter("state_code").length()>0) {
			state_code = HtmlUtils.htmlEscape(request.getParameter("state_code"));
		}
		String status_mst_code = null;
		if(!request.getParameter("status_mst_code").equalsIgnoreCase("null") && request.getParameter("status_mst_code").length()>0) {
			status_mst_code = HtmlUtils.htmlEscape(request.getParameter("status_mst_code"));
		}
		query = em.createStoredProcedureQuery("isp_getSitSurveyListForFranchisee").
				registerStoredProcedureParameter("fromDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("toDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("userMstId", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("statusCode", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("stateNameCode", String.class, ParameterMode.IN);
		
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		query.setParameter("userMstId", Integer.valueOf(userMstId));
		query.setParameter("statusCode", status_mst_code!=null?status_mst_code.trim():null);
		query.setParameter("stateNameCode", state_code!=null?state_code.trim():null);	
		//exec isp_getSitSurveyListForFranchisee '2020-02-05','2020-02-12',99,null,null;
/*		String lQuery = "select s.id,s.uniq_id,f.franchise_mst_id,f.franchise_name,convert(varchar, s.creation_date, 105)"
				+ " as creation_date,se.name as eng_name,se.mobile_no as eng_mobile_no,se.email_id as eng_email_id"
				+ ",sm.status_mst_id,sm.status_code,sm.status_name,se.id as eng_id, convert(varchar, s.tentative_date, 105) "
				+ " from site_survey_mst s left join customer_sapmst cs on" + " s.customer_id=cs.customer_sapmst_id"
				// + " inner join user_to_region_mst ur" + " on
				// cs.region_code=ur.region_code"

				+ " inner join user_to_franchisee_mst u_f on s.franchisee_id=u_f.franchisee_id and u_f.user_mst_id=:user_id"
				+ " inner join status_mst sm on s.status=sm.status_mst_id"
				+ " left outer join franchise_mst f on s.franchisee_id=f.franchise_mst_id"
				+ " left outer join (select site_survey_id,id,franchisee_id,name,mobile_no,email_id,creation_date from"
				+" (SELECT site_survey_id,id,franchisee_id,name,mobile_no,email_id,creation_date"
				+" ,ROW_NUMBER() over(partition by site_survey_id order by creation_date desc) as cnt"
				+" FROM site_survey_eng_mst  group by site_survey_id,id,franchisee_id,name,mobile_no,email_id,creation_date)tbl"
				+" where cnt=1)se on s.id=se.site_survey_id"
				+ " where s.creation_date between :start_date and :end_date " + " " + " ";
		SiteSurveyListDTO bean = null;
		query = em.createNativeQuery(lQuery);
		query.setParameter("user_id", request.getParameter("user_id"));
		query.setParameter("start_date", DateUtil.convertDateToSqlDate(request.getParameter("start_date")));
		query.setParameter("end_date",
				DateUtil.convertDateToSqlDate(request.getParameter("end_date")) + " 23:59:59.999");*/
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			bean = new SiteSurveyListDTO();
			bean.setSite_survey_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setSite_survey_uniq_id(SDCommonUtil.convertNullToBlank((String) o[1], false));
			bean.setFranchisee_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
			bean.setFranchisee_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
			bean.setCreation_date(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
			bean.setEngineer_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[5]), false));
			bean.setEngineer_mobile_no(SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false));
			bean.setEngineer_email_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false));
			bean.setStatus_mst_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[8]), false));
			bean.setStatus_mst_code((SDCommonUtil.convertNullToBlank(String.valueOf(o[9]), false)));
			bean.setStatus_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[10]), false));
			bean.setEngineer_id(SDCommonUtil.convertNullToBlank(String.valueOf(o[11]), false));
			bean.setCustomer_name(SDCommonUtil.convertNullToBlank(String.valueOf(o[12]),false));
			bean.setSub_customer(SDCommonUtil.convertNullToBlank(String.valueOf(o[13]),false));
			bean.setCity(SDCommonUtil.convertNullToBlank(String.valueOf(o[14]),false));
			bean.setState_code(SDCommonUtil.convertNullToBlank(String.valueOf(o[15]),false));
			bean.setState_val(SDCommonUtil.convertNullToBlank(String.valueOf(o[16]),false));
			bean.setTentative_date(SDCommonUtil.convertNullToBlank(String.valueOf(o[17]), false));
			lst.add(bean);
		}
		return lst;

	}

	@SuppressWarnings("unchecked")
	@Override
	public SiteSurveyEngineerMst saveSiteSurveyEngineer(SiteSurveyEngineerDTO siteSurveyEngineerDTO) {
		SiteSurveyEngineerMst siteSurveyEngineerMt = new SiteSurveyEngineerMst();
		siteSurveyEngineerMt.setCreation_date(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		siteSurveyEngineerMt.setEmail_id(siteSurveyEngineerDTO.getEmail_id());
		siteSurveyEngineerMt.setFranchisee_id(siteSurveyEngineerDTO.getFranchisee_id());
		siteSurveyEngineerMt.setId(siteSurveyEngineerDTO.getId());
		siteSurveyEngineerMt.setMobile_no(siteSurveyEngineerDTO.getMobile_no());
		siteSurveyEngineerMt.setName(siteSurveyEngineerDTO.getName());
		siteSurveyEngineerMt.setSite_survey_id(siteSurveyEngineerDTO.getSite_survey_id());
		String currTime = DateUtil.convertDateToSqlDate(siteSurveyEngineerDTO.getEngVisitDate());
		siteSurveyEngineerMt.setEngVisitDate(currTime);
		siteSurveyEngineerMt.setEngVisitTiming(siteSurveyEngineerDTO.getEngVisitTiming());
		siteSurveyEngineerMt = em.merge(siteSurveyEngineerMt);
		Query query = em.createNamedQuery("SiteSurveyMaster.updateEngineerAllocatedStatus");
		query.setParameter(1, 37);
		query.setParameter(2, siteSurveyEngineerDTO.getSite_survey_id());
		int i = query.executeUpdate();
		
		//added entry for entry in tracker for engineer allocated status change begins 26-11-2019 16:36pm
		this.updateTracker(siteSurveyEngineerDTO.getSite_survey_id(), 37, siteSurveyEngineerDTO.getUserMstId());
		//added entry for entry in tracker for engineer allocated status change ends 26-11-2019 16:36pm

		query = em.createNamedQuery("SiteSurveyMaster.findById");
		query.setParameter(1, siteSurveyEngineerDTO.getSite_survey_id());
		SiteSurveyMaster siteSurveyMaster = (SiteSurveyMaster) query.getSingleResult();

		// email sending to site survey request begins
		query = em.createNativeQuery("select user_id,user_name,user_email,fzm.franchise_zone_email from user_to_region_mst ur inner join user_mst u on ur.user_id = u.user_mst_id left join cs_user_franchise_zone_mapping_mst cuzm on u.user_mst_id = cuzm.user_mst_id left join franchise_zone_mst fzm on cuzm.franchise_zone_mst_id = fzm.franchise_zone_mst_id where region_code ="+siteSurveyMaster.getState_id());
		List<Object[]> result = (List<Object[]>) query.getResultList();
		String csUserName = null;
		String csEmail = null;
		Integer userId = null;
		String zoneEmail = null;
		for (Object[] objects : result) {
			userId = (Integer)objects[0];
			csUserName = (String)objects[1];
			csEmail = (String)objects[2];
			zoneEmail = (String)objects[3];
		}
		
		query = em.createNativeQuery("select u.user_mst_id,u.user_name,u.user_email from site_survey_mst ssm inner join user_mst u on ssm.user_id = u.user_mst_id where ssm.id ="+siteSurveyMaster.getId());
		List<Object[]> resultsPm = (List<Object[]>) query.getResultList();
		String pmUserName = null;
		String pmEmail = null;
		Integer pmuserId = null;
		for (Object[] objects : resultsPm) {
			pmuserId = (Integer)objects[0];
			pmUserName = (String)objects[1];
			pmEmail = (String)objects[2];
			
		}
		
		
		EmailBean emailBean = new EmailBean();
		emailBean.setToMail((csEmail!=null?csEmail+";":null)+(zoneEmail!=null?zoneEmail:""));
		if(pmEmail!=null)
			emailBean.setCopyRecepients(pmEmail);
		emailBean.setSubject("Engineer has been allocated for site survey " + siteSurveyMaster.getUniq_id() + ".");
		emailBean.setEmailBody("Dear User,"// +finance.getUserName()+","
				+ "<br>Engineer has been allocated for Site Survey." + "<br>Site Survey ID:"
				+ siteSurveyMaster.getUniq_id() + "<br>Engineer Name : " + siteSurveyEngineerDTO.getName()
				+ "<br>Engineer Mobile Number : " + siteSurveyEngineerDTO.getMobile_no() + "<br>Engineer Email : "
				+ siteSurveyEngineerDTO.getEmail_id() 
				+ "<br> Customer Name - "
				+ (siteSurveyMaster.getCustomerName() != null && siteSurveyMaster.getCustomerName() != "" ? siteSurveyMaster.getCustomerName() : "")
				+ "<br> Sub Customer Name - "
				+ (siteSurveyMaster.getSub_customer() != null && siteSurveyMaster.getSub_customer() != "" ? siteSurveyMaster.getSub_customer() : "")
				+ "<br> Site Address - " + (siteSurveyMaster.getStreet_1() != null && siteSurveyMaster.getStreet_1() != "" ? siteSurveyMaster.getStreet_1() : "")
				+ " "+ (siteSurveyMaster.getStreet_2() != null && siteSurveyMaster.getStreet_2() != "" ? siteSurveyMaster.getStreet_2() : "")
				+ " "+ (siteSurveyMaster.getStreet_3() != null && siteSurveyMaster.getStreet_3() != "" ? siteSurveyMaster.getStreet_3() : "")
				+ " "+ (siteSurveyMaster.getStreet_4() != null && siteSurveyMaster.getStreet_4() != "" ? siteSurveyMaster.getStreet_4() : "")
				+ " "+ (siteSurveyMaster.getStreet_5() != null && siteSurveyMaster.getStreet_5() != "" ? siteSurveyMaster.getStreet_5() : "")
				+ "<br> City - "
				+ (siteSurveyMaster.getCity() != null && siteSurveyMaster.getCity() != "" ? siteSurveyMaster.getCity() : "")
				+ "<br> Pin - "
				+ (siteSurveyMaster.getPin() != null && siteSurveyMaster.getPin() != "" ? siteSurveyMaster.getPin() : "")
				+ "<br> Site Contact Person Name - "
				+ (siteSurveyMaster.getSite_person_contact_name() != null && siteSurveyMaster.getSite_person_contact_name() != "" ? siteSurveyMaster.getSite_person_contact_name() : "")	
				+ "<br> Contact person Number - "
				+ (siteSurveyMaster.getContact_person_no() != null && siteSurveyMaster.getContact_person_no() != "" ? siteSurveyMaster.getContact_person_no() : "")
				+ "<br> Alternative Number - "
				+ (siteSurveyMaster.getAlternative_mobile_no() != null && siteSurveyMaster.getAlternative_mobile_no() != "" ? siteSurveyMaster.getAlternative_mobile_no() : "")
				+ "<br> Tentative Date - "
				+ (siteSurveyMaster.getTentative_date() != null && siteSurveyMaster.getTentative_date() != "" ? siteSurveyMaster.getTentative_date() : "")
				+ "<br> Tentative Time - "
				+ (siteSurveyMaster.getTentative_timing() != null && siteSurveyMaster.getTentative_timing() != "" ? siteSurveyMaster.getTentative_timing() : "")
				+ "<br> Billable / Non-Billable - "
				+ (siteSurveyMaster.getBillable() != null && siteSurveyMaster.getBillable() != "" ? siteSurveyMaster.getBillable() : "")
				+ "<br> Remark - "
				+ (siteSurveyMaster.getRemarks() != null && siteSurveyMaster.getRemarks() != "" ? siteSurveyMaster.getRemarks() : "")
				+ "<br> Click here to login :  <a href=" + env.getProperty("emaillink") + ">O2C portal link</a>  "
				+ "<br><br>Sincerely,");
		callSpDao.sendEmail(emailBean);
		// email sending to site survey request ends
		// email sending to site survey request begins
		emailBean = new EmailBean();
		emailBean.setToMail(siteSurveyEngineerDTO.getEmail_id());
		emailBean.setSubject("Site Survey assigned : " + siteSurveyMaster.getUniq_id());
		emailBean.setEmailBody("Dear User,"// +finance.getUserName()+","
				+ "<br>Site Survey task has been assigned." + "<br>Site Survey ID:" + siteSurveyMaster.getUniq_id()
				+ "<br> Customer Name - "
				+ (siteSurveyMaster.getCustomerName() != null && siteSurveyMaster.getCustomerName() != "" ? siteSurveyMaster.getCustomerName() : "")
				+ "<br> Sub Customer Name - "
				+ (siteSurveyMaster.getSub_customer() != null && siteSurveyMaster.getSub_customer() != "" ? siteSurveyMaster.getSub_customer() : "")
				+ "<br> Site Address - " + (siteSurveyMaster.getStreet_1() != null && siteSurveyMaster.getStreet_1() != "" ? siteSurveyMaster.getStreet_1() : "")
				+ " "+ (siteSurveyMaster.getStreet_2() != null && siteSurveyMaster.getStreet_2() != "" ? siteSurveyMaster.getStreet_2() : "")
				+ " "+ (siteSurveyMaster.getStreet_3() != null && siteSurveyMaster.getStreet_3() != "" ? siteSurveyMaster.getStreet_3() : "")
				+ " "+ (siteSurveyMaster.getStreet_4() != null && siteSurveyMaster.getStreet_4() != "" ? siteSurveyMaster.getStreet_4() : "")
				+ " "+ (siteSurveyMaster.getStreet_5() != null && siteSurveyMaster.getStreet_5() != "" ? siteSurveyMaster.getStreet_5() : "")
				+ "<br> City - "
				+ (siteSurveyMaster.getCity() != null && siteSurveyMaster.getCity() != "" ? siteSurveyMaster.getCity() : "")
				+ "<br> Pin - "
				+ (siteSurveyMaster.getPin() != null && siteSurveyMaster.getPin() != "" ? siteSurveyMaster.getPin() : "")
				+ "<br> Site Contact Person Name - "
				+ (siteSurveyMaster.getSite_person_contact_name() != null && siteSurveyMaster.getSite_person_contact_name() != "" ? siteSurveyMaster.getSite_person_contact_name() : "")	
				+ "<br> Contact person Number - "
				+ (siteSurveyMaster.getContact_person_no() != null && siteSurveyMaster.getContact_person_no() != "" ? siteSurveyMaster.getContact_person_no() : "")
				+ "<br> Alternative Number - "
				+ (siteSurveyMaster.getAlternative_mobile_no() != null && siteSurveyMaster.getAlternative_mobile_no() != "" ? siteSurveyMaster.getAlternative_mobile_no() : "")
				+ "<br> Tentative Date - "
				+ (siteSurveyMaster.getTentative_date() != null && siteSurveyMaster.getTentative_date() != "" ? siteSurveyMaster.getTentative_date() : "")
				+ "<br> Tentative Time - "
				+ (siteSurveyMaster.getTentative_timing() != null && siteSurveyMaster.getTentative_timing() != "" ? siteSurveyMaster.getTentative_timing() : "")
				+ "<br> Billable / Non-Billable - "
				+ (siteSurveyMaster.getBillable() != null && siteSurveyMaster.getBillable() != "" ? siteSurveyMaster.getBillable() : "")
				+ "<br> Remark - "
				+ (siteSurveyMaster.getRemarks() != null && siteSurveyMaster.getRemarks() != "" ? siteSurveyMaster.getRemarks() : "")
				+ "<br> Click here to login :  <a href=" + env.getProperty("emaillink") + ">O2C portal link</a>  "
				+ "<br><br>Sincerely,");
		
		/*
		     emailBean.setEmailBody("Dear User,"// +finance.getUserName()+","
				+ "<br>Site Survey task has been assigned." + "<br>Site Survey ID:" + siteSurveyMaster.getUniq_id()
				+ "<br>Site Person Contact Name : " + siteSurveyMaster.getSite_person_contact_name() + "<br>City : "
				+ siteSurveyMaster.getCity() + "<br>Street 1 : " + siteSurveyMaster.getStreet_1() + "<br>Street 2 : "
				+ siteSurveyMaster.getStreet_2() + "<br>Street 3 : " + siteSurveyMaster.getStreet_3()
				+ "<br>Street 4 : " + siteSurveyMaster.getStreet_4() + "<br>Street 5 : "
				+ siteSurveyMaster.getStreet_5() + "<br>Pin : " + siteSurveyMaster.getPin()
				+ "<br>Please login to know more." + "<br> Click here to login :  <a href="
				+ env.getProperty("emaillink") + ">O2C portal link</a>  " + "<br><br>Sincerely");
		callSpDao.sendEmail(emailBean);
		*/
		callSpDao.sendEmail(emailBean);
		// email sending to site survey request ends

		return siteSurveyEngineerMt;
	}

	@Override
	public SiteSurveyEngineerMst getEngineerById(HttpServletRequest request) {
		Integer franchisee_id = Integer.parseInt(request.getParameter("engineer_id"));
		try {
			query = em.createNamedQuery("SiteSurveyEngineerMst.findById");
			query.setParameter(1, Integer.parseInt(request.getParameter("engineer_id")));
			return (SiteSurveyEngineerMst) query.getSingleResult();

		} catch (Exception e) {
			return new SiteSurveyEngineerMst();
		} finally {
			em.close();
		}
	}

	@Override
	public void uploadFile(MultipartFile file, String userId) throws Exception {
		HSSFWorkbook workbook = new HSSFWorkbook(file.getInputStream());
		HSSFRow row = null;
		int i = 1;
		BigDecimal alternateMobNo = null;
		BigDecimal contact_person_no = null;

		String uniq_id = "";
		HSSFSheet worksheet = workbook.getSheetAt(0);
		CustomerSapmst customerSapmst=null;
		while (i <= worksheet.getLastRowNum()) {
			row = worksheet.getRow(i++);
			synchronized (this) {
				Integer maxProposalNumber = getCurrentDayCountSiteSurveyMaster();
				uniq_id = "SIT_SUR_" + (DateUtil.getCurrentISTDateAsString(DateUtil.SIMPLE_DATE_FORMAT)
						.replace("-", "_").concat("_").concat(maxProposalNumber.toString()));
			}
			SiteSurveyMaster siteSurveyMaster = new SiteSurveyMaster();
			TechnologyMaster technologyMaster = this.getTechnologyObject(String.valueOf(row.getCell(11)));
			StateMst stateMst = null;
			HubMst hubMst = this.getHubObject(String.valueOf(row.getCell(12)));
			AntennaSizeMaster antennaSizeMaster = this.getAntennaObject(String.valueOf(row.getCell(13)));
			if (!(String.valueOf(row.getCell(0)).equals("") || String.valueOf(row.getCell(0)).equals("null"))) {
				if(SDCommonUtil.IsNumericDouble(String.valueOf(row.getCell(0)))){
					Double customeNum = Double.parseDouble(String.valueOf(row.getCell(0)));
					customerSapmst = this.getCustomerObject(String.valueOf(customeNum.intValue()));
				}else{//its non numeric					
					customerSapmst = this.getCustomerObject(String.valueOf(row.getCell(0)));
				}
				siteSurveyMaster.setCity(customerSapmst.getCityName());
				siteSurveyMaster.setStreet_1(customerSapmst.getStreet1());
				siteSurveyMaster.setStreet_2(customerSapmst.getStreet2());
				siteSurveyMaster.setStreet_3(customerSapmst.getStreet3());
				siteSurveyMaster.setStreet_4(customerSapmst.getStreet4());
				siteSurveyMaster.setStreet_5(customerSapmst.getStreet5());
				siteSurveyMaster.setPin(customerSapmst.getPin());
				siteSurveyMaster.setCustomer_id(customerSapmst.getCustomerSapmstId());
				stateMst = customerSapmst.getStateMst(); //this.getStateObject(customerSapmst.getStateMst());
			} else {
				siteSurveyMaster.setStreet_1(String.valueOf(row.getCell(2)));
				siteSurveyMaster.setStreet_2(String.valueOf(row.getCell(3)));
				siteSurveyMaster.setStreet_3(String.valueOf(row.getCell(4)));
				siteSurveyMaster.setStreet_4(String.valueOf(row.getCell(5)));
				siteSurveyMaster.setStreet_5(String.valueOf(row.getCell(6)));
				siteSurveyMaster.setCity(String.valueOf(row.getCell(7)));
				siteSurveyMaster.setPin(String.valueOf(row.getCell(8)));
				siteSurveyMaster.setCustomer_id(null);
				siteSurveyMaster.setCustomerName(String.valueOf(row.getCell(1)));
				stateMst = this.getStateObject((String.valueOf(row.getCell(15))));
			}
			siteSurveyMaster.setAntenna_size_id(antennaSizeMaster.getId());
			
			siteSurveyMaster.setBillable(String.valueOf(row.getCell(14)));
			if(!String.valueOf(row.getCell(10)).isEmpty()) {
				contact_person_no = new BigDecimal(String.valueOf(row.getCell(10)));
				siteSurveyMaster.setContact_person_no(String.valueOf(contact_person_no));
			}
			
			siteSurveyMaster.setCountry_id(1);
			siteSurveyMaster.setHub_id(hubMst.getHubMstId());
			siteSurveyMaster.setSite_person_contact_name(String.valueOf(row.getCell(9)));
			siteSurveyMaster.setUniq_id(uniq_id);
			siteSurveyMaster.setStatus(35);
			if(stateMst!=null)
				siteSurveyMaster.setState_id(stateMst.getStateMstId());
			siteSurveyMaster.setUser_id(Integer.parseInt(userId));
			siteSurveyMaster.setTechnology_id(technologyMaster.getId());
			siteSurveyMaster.setCreation_date(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
			siteSurveyMaster.setSub_customer(String.valueOf(row.getCell(16)));
			if(!String.valueOf(row.getCell(17)).isEmpty())
			{
				alternateMobNo = new BigDecimal(String.valueOf(row.getCell(17)));
				siteSurveyMaster.setAlternative_mobile_no(String.valueOf(alternateMobNo));
			}
			// siteSurveyMaster.setTentative_date(String.valueOf(row.getCell(18)));
			if(!String.valueOf(row.getCell(18)).isEmpty())
				siteSurveyMaster.setTentative_date(DateUtil.convertDateToSqlDate(String.valueOf(row.getCell(18))));
			siteSurveyMaster.setTentative_timing(String.valueOf(row.getCell(19)));
			siteSurveyMaster.setRemarks(String.valueOf(row.getCell(20)));
			SiteSurveyMaster savedSiteSurveyMst = em.merge(siteSurveyMaster);
			
			//added entry for entry in tracker for engineer allocated status change begins 26-11-2019 16:36pm
			this.updateTracker(savedSiteSurveyMst.getId(), 35, savedSiteSurveyMst.getUser_id());
			//added entry for entry in tracker for engineer allocated status change ends 26-11-2019 16:36pm
		}
	}

	public CustomerSapmst getCustomerObject(String customerNum) {
		try {

			query = em.createNamedQuery("CustomerSapmst.getCustomerdetailsByCustomerNum");
			query.setParameter(1, String.valueOf(customerNum));
			query.setMaxResults(1);
			CustomerSapmst customerSapmst = (CustomerSapmst) query.getSingleResult();
			return customerSapmst != null ? customerSapmst : new CustomerSapmst();
		} finally {
			em.close();
		}
	}

	public TechnologyMaster getTechnologyObject(String value) {
		try {

			query = em.createNamedQuery("TechnologyMaster.findByName");
			query.setParameter(1, value);
			TechnologyMaster technologyMaster = (TechnologyMaster) query.getSingleResult();
			return technologyMaster != null ? technologyMaster : new TechnologyMaster();
		} finally {
			em.close();
		}
	}

	public HubMst getHubObject(String value) {
		try {
			query = em.createNamedQuery("HubMst.findByCode");
			query.setParameter(1, value);
			HubMst hubMst = (HubMst) query.getSingleResult();
			return hubMst != null ? hubMst : new HubMst();
		} finally {
			em.close();
		}
	}

	public AntennaSizeMaster getAntennaObject(String value) {
		try {
			query = em.createNamedQuery("AntennaSizeMaster.findByName");
			query.setParameter(1, value);
			AntennaSizeMaster antennaSizeMaster = (AntennaSizeMaster) query.getSingleResult();
			return antennaSizeMaster != null ? antennaSizeMaster : new AntennaSizeMaster();
		} finally {
			em.close();
		}
	}

	public StateMst getStateObject(String value) {
		try {
			query = em.createNamedQuery("StateMst.findByName");
			query.setParameter(1, value);
			StateMst stateMst = (StateMst) query.getSingleResult();
			return stateMst != null ? stateMst : new StateMst();
		} finally {
			em.close();
		}
	}

	public int getCount(String table, String column, String value) {
		String lQuery = "select count(*) from " + table + " where " + column + "=?1";
		query = em.createNativeQuery(lQuery);
		query.setParameter(1, value);
		int num = (int) query.getSingleResult();
		return num;
	}

	@Override
	public List<SiteSurveyEngineerMst> getEngineerListBySiteIdFrachiseeId(HttpServletRequest request) {
		//Integer franchisee_id = Integer.parseInt(request.getParameter("engineer_id"));
		try {
			query = em.createNamedQuery("SiteSurveyEngineerMst.findBySiteSurveyId");
			query.setParameter(1, Integer.parseInt(request.getParameter("site_survey_id")));			
			List<SiteSurveyEngineerMst> siteSurveyEngineerMst = query.getResultList();			
			return siteSurveyEngineerMst != null ? siteSurveyEngineerMst : new ArrayList<SiteSurveyEngineerMst>();
		} catch (Exception e) {
			return new ArrayList<SiteSurveyEngineerMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public void updateTracker(Integer site_survey_id, Integer status, Integer user_id)  {
		SiteSurveyTrackerMaster siteSurveyTrackerMaster=new SiteSurveyTrackerMaster();
		siteSurveyTrackerMaster.setSite_survey_id(site_survey_id);
		siteSurveyTrackerMaster.setStatus(status);
		siteSurveyTrackerMaster.setUser_id((user_id));
		siteSurveyTrackerMaster.setComm_date((DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS)));
		em.merge(siteSurveyTrackerMaster);
	}

	@Override
	public SiteSurveyMaster getSiteSurveyByUniqId(SiteSurveyDTO siteSurveyDTO) {
		try {
			query = em.createNamedQuery("SiteSurveyMaster.ByUniqId");
			query.setParameter(1, siteSurveyDTO.getUniq_id());
			SiteSurveyMaster siteSurveyMaster = (SiteSurveyMaster) query.getSingleResult();
			return siteSurveyMaster;
		} catch (Exception e) {
			return new SiteSurveyMaster();
		} finally {
			em.close();
		}

	}

}
