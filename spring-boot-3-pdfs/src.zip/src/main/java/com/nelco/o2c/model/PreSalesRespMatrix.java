/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.dto.UserDTO;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Amol.l
 *
 */

@Entity
@Table(name = "pre_sales_resp_matrix")
@NamedQueries({ @NamedQuery(name = "PreSalesRespMatrix.findAll", query = "SELECT prm FROM PreSalesRespMatrix prm"),
		@NamedQuery(name = "PreSalesRespMatrix.getPSRespMatrixByUserMstIdAndOpId", query = "SELECT prm FROM PreSalesRespMatrix prm where prm.createdBy =?1 and prm.opportunityId=?2 and prm.respMatrixDetailsId=?3 "),
		@NamedQuery(name = "PreSalesRespMatrix.findByOppId", query = "SELECT prm from PreSalesRespMatrix prm where prm.respPerId=?1")
})
public class PreSalesRespMatrix implements Serializable {
	private static final long serialVersionUID = 37L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pre_sales_resp_matrix_id")
	private Integer preSalesRespMatrixId;
	
	
	@Column(name = "resp_matrix_details_id")
	private Integer respMatrixDetailsId;

	@Column(name = "topics_del")
	private String topicsDel;

	@Column(name = "status_flag")
	private String statusFlag;

	@Column(name = "created_by")
	private Integer createdBy;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "dept_mst_id")
	private Integer deptMstId;

	@Column(name = "opportunity_id")
	private Integer opportunityId;

	@Column(name = "resp_per_id")
	private Integer respPerId;

	@Column(name = "target_date")
	private String targetDate;
	
	@Column(name = "pending_date")
	private String pendingDate;
	
	@Column(name = "compl_date")
	private String complDate;
	
	@Column(name = "email_sent_flag")
	private String emailSentFlag="N";

	@Transient
	private DeptMst deptMst;

	@Transient
	private UserDTO respPerson;

	public String getEmailSentFlag() {
		return emailSentFlag;
	}

	public void setEmailSentFlag(String emailSentFlag) {
		this.emailSentFlag = emailSentFlag;
	}

	public Integer getPreSalesRespMatrixId() {
		return preSalesRespMatrixId;
	}

	public void setPreSalesRespMatrixId(Integer preSalesRespMatrixId) {
		this.preSalesRespMatrixId = preSalesRespMatrixId;
	}

	public Integer getRespMatrixDetailsId() {
		return respMatrixDetailsId;
	}

	public void setRespMatrixDetailsId(Integer respMatrixDetailsId) {
		this.respMatrixDetailsId = respMatrixDetailsId;
	}

	public String getTopicsDel() {
		return topicsDel;
	}

	public void setTopicsDel(String topicsDel) {
		this.topicsDel = topicsDel;
	}

	public String getStatusFlag() {
		return statusFlag;
	}

	public void setStatusFlag(String statusFlag) {
		this.statusFlag = statusFlag;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getDeptMstId() {
		return deptMstId;
	}

	public void setDeptMstId(Integer deptMstId) {
		this.deptMstId = deptMstId;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public Integer getRespPerId() {
		return respPerId;
	}

	public void setRespPerId(Integer respPerId) {
		this.respPerId = respPerId;
	}

	public String getTargetDate() {
		return DateUtil.convertDateTimeToString(targetDate);
		//return targetDate;
	}

	public void setTargetDate(String targetDate) {
		this.targetDate = DateUtil.convertDateToSqlDate(targetDate);
	}

	public String getPendingDate() {
		return pendingDate;
	}

	public void setPendingDate(String pendingDate) {
		this.pendingDate = pendingDate;
	}

	public String getComplDate() {
		return complDate;
	}

	public void setComplDate(String complDate) {
		this.complDate = complDate;
	}

	public DeptMst getDeptMst() {
		return deptMst;
	}

	public void setDeptMst(DeptMst deptMst) {
		this.deptMst = deptMst;
	}

	public UserDTO getRespPerson() {
		return respPerson;
	}

	public void setRespPerson(UserDTO respPerson) {
		this.respPerson = respPerson;
	}
	
}
