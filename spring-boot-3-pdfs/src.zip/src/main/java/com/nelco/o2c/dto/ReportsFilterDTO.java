package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.StateMst;
import com.nelco.o2c.model.StatusMst;

public class ReportsFilterDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	List<StatusMst> statusMstList;
	List<String> custList;
	List<String> franchiseNamesList;
	List<UserDTO> progmanagersList;
	List<String>  soTypeList;
	List<StateMst> stateMstList;
	
	public List<UserDTO> getProgmanagersList() {
		return progmanagersList;
	}


	public void setProgmanagersList(List<UserDTO> progmanagersList) {
		this.progmanagersList = progmanagersList;
	}


	public List<String> getFranchiseNamesList() {
		return franchiseNamesList;
	}


	public void setFranchiseNamesList(List<String> franchiseNamesList) {
		this.franchiseNamesList = franchiseNamesList;
	}


	public List<String> getCustList() {
		return custList;
	}


	public void setCustList(List<String> custList) {
		this.custList = custList;
	}


	public List<StatusMst> getStatusMstList() {
		return statusMstList;
	}


	public void setStatusMstList(List<StatusMst> statusMstList) {
		this.statusMstList = statusMstList;
	}


	public List<String> getSoTypeList() {
		return soTypeList;
	}


	public void setSoTypeList(List<String> soTypeList) {
		this.soTypeList = soTypeList;
	}


	public List<StateMst> getStateMstList() {
		return stateMstList;
	}


	public void setStateMstList(List<StateMst> stateMstList) {
		this.stateMstList = stateMstList;
	}
	
	
}
