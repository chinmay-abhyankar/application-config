/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.SoOrders;

/**
 * @author Amol.l
 *
 */
public class SoOrdersListDTO implements Serializable  {

	private static final long serialVersionUID = 39L;
	
	private String contractNum;
	private List<SoOrders> soOrders = new ArrayList<SoOrders>();
	private String uniqId;
	private Integer drfDetailsId;
	

	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}

	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}

	public String getUniqId() {
		return uniqId;
	}

	public void setUniqId(String uniqId) {
		this.uniqId = uniqId;
	}

	public String getContractNum() {
		return contractNum;
	}

	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}

	public List<SoOrders> getSoOrders() {
		return soOrders;
	}

	public void setSoOrders(List<SoOrders> soOrders) {
		this.soOrders = soOrders;
	}
	
}
