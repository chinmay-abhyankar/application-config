/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.OppUploadDetail;

/**
 * @author Jayshankar.r
 *
 */
public class SparesSoPodUploadDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private List<OppUploadDetail> oppUploadDetails = new ArrayList<OppUploadDetail>();
	private Integer sparesSoDeliveryId;
	private Integer userMstId;
	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}
	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}
	public Integer getSparesSoDeliveryId() {
		return sparesSoDeliveryId;
	}
	public void setSparesSoDeliveryId(Integer sparesSoDeliveryId) {
		this.sparesSoDeliveryId = sparesSoDeliveryId;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	
	
	
	
	
	
}
