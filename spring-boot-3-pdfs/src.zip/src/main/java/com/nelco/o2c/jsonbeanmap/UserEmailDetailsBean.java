/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

/**
 * @author Jayashankar.r
 *
 */
public class UserEmailDetailsBean {
	private String userId;
	private String userName;
	private String userMail;
	private String oppId;
	private String smOwnerId;
	private String zoneMail;
	private Integer userMstId;
	private Integer roleMstId;
	private String roleCode;
	private String loginId;
	
	
	

	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public Integer getRoleMstId() {
		return roleMstId;
	}
	public void setRoleMstId(Integer roleMstId) {
		this.roleMstId = roleMstId;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getZoneMail() {
		return zoneMail;
	}
	public void setZoneMail(String zoneMail) {
		this.zoneMail = zoneMail;
	}
	public String getSmOwnerId() {
		return smOwnerId;
	}
	public void setSmOwnerId(String smOwnerId) {
		this.smOwnerId = smOwnerId;
	}
	public String getOppId() {
		return oppId;
	}
	public void setOppId(String oppId) {
		this.oppId = oppId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserMail() {
		return userMail;
	}
	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}
	
}
