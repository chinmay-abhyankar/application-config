package com.nelco.o2c.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nelco.o2c.dto.ReportsDTO;
import com.nelco.o2c.service.RecurringInvoiceService;

@RestController
public class RecurringInvoiceController {
	@Autowired
	RecurringInvoiceService service;
	
//	@RequestMapping(value = "/getCustomerAutoComplete.do", method = RequestMethod.GET)
//	public List<CustomerSapmst> getCustomerAutoComplete(HttpServletRequest request) {
//		return service.getListCustomerAutoComplete(request);
//	}
	
	@RequestMapping(value = "/getRecurringInvoiceReport.do", method = RequestMethod.GET)
	public void getCustomerAutoComplete(HttpServletRequest request,HttpServletResponse response,@RequestParam("inputJson") String ipJson) throws SQLException, JsonParseException, JsonMappingException, IOException {
		ReportsDTO reportsDTO = utility(ipJson);
		service.getRecurringInvoiceReport(request, response, reportsDTO);
	}
	
	
	
	public ReportsDTO utility(@RequestParam("inputJson") String ipJson) throws SQLException, JsonParseException, JsonMappingException, IOException {
		
		 ObjectMapper mapper = new ObjectMapper();
		 ReportsDTO reportsDTO = mapper.readValue(ipJson, ReportsDTO.class);
	     return reportsDTO;
	}
	

//	@RequestMapping(value = "/getSalesOrderReport.do", method = RequestMethod.GET)
//	public List<SalesOrderReportDTO> getSalesOrderReport(HttpServletRequest request) {
//		return service.getSalesOrderReport(request);
//	}
}
