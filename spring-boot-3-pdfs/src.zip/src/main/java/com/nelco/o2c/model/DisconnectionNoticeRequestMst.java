package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the disconnectionrequest_mst database table.
 * 
 */
@Entity
@Table(name="disconnection_notice_request_mst")
@NamedQueries({
@NamedQuery(name="DisconnectionNoticeRequestMst.findAll", query="SELECT d FROM DisconnectionNoticeRequestMst d"),
@NamedQuery(name="DisconnectionNoticeRequestMst.updateSalesHeadAppStatus",query="UPDATE DisconnectionNoticeRequestMst d SET d.salesheadAppStatus=:requestStatus WHERE d.requestId=:requestId"),
@NamedQuery(name="DisconnectionNoticeRequestMst.updateFinanceHeadAppStatus",query="UPDATE DisconnectionNoticeRequestMst d SET d.financeheadAppStatus=:requestStatus WHERE d.requestId=:requestId")
})
@NamedNativeQueries({
	@NamedNativeQuery(name = "DisconnectionNoticeRequestMst.getRequestId", query = "SELECT 'DISN_'+FORMAT(GETDATE(),'dd')+'_'+FORMAT(GETDATE(),'MM')+'_'+FORMAT(GETDATE(),'yyyy')+'_'+CAST(COALESCE(MAX(typeid),0)+1 AS VARCHAR)FROM disconnection_notice_request_mst"),
	@NamedNativeQuery(name="DisconnectionNoticeRequestMst.getLatestRequestIdFromInvoiceNo", query="SELECT TOP 1 d.request_id,d.userid FROM disconnection_notice_request_mst d  WHERE d.invoice_no=:invoiceNo ORDER BY d.typeid DESC"),
	})

public class DisconnectionNoticeRequestMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int typeid;
	@Column(name="actflag",insertable=false,updatable=false)
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String actflag;

	@Column(name="change_date",insertable=false,updatable=false)
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Timestamp changeDate;

	@Column(name="financehead_app_status")
	private String financeheadAppStatus;

	@Column(name="invoice_no")
	private String invoiceNo;

	@Column(name="request_date")
	private String requestDate;

	@Column(name="request_id")
	private String requestId;

	@Column(name="saleshead_app_status")
	private String salesheadAppStatus;

	@Column(name="user_id")
	private String userId;
	
	@Column(name="disconnectionnotice_status")
	private String disconnectionnoticeStatus;
	
	@Column(name="disconnectionnotice_id")
	private String disconnectionnoticeId;
	
	@Column(name="disconnection_flag",insertable=false)
	private String disconnectionFlag;
	
	@Column(name="severity")
	private String severity;
	
	
	@Transient
	private String userRole="";
	
	@Transient
	private String requestStatus="";

	@Transient
	private String appRemark="";
	
	@Transient
	private OppUploadDetail oppUploadDetails;
	
	public DisconnectionNoticeRequestMst() {
	}
	
	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public OppUploadDetail getOppUploadDetails() {
		return oppUploadDetails;
	}

	public void setOppUploadDetails(OppUploadDetail oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}

	public String getAppRemark() {
		return appRemark;
	}

	public void setAppRemark(String appRemark) {
		this.appRemark = appRemark;
	}		
	
	public String getRequestStatus() {
		return requestStatus;
	}


	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}


	public String getUserRole() {
		return userRole;
	}


	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}


	public String getDisconnectionFlag() {
		return disconnectionFlag;
	}


	public void setDisconnectionFlag(String disconnectionFlag) {
		this.disconnectionFlag = disconnectionFlag;
	}


	public String getDisconnectionnoticeStatus() {
		return disconnectionnoticeStatus;
	}

	public void setDisconnectionnoticeStatus(String disconnectionnoticeStatus) {
		this.disconnectionnoticeStatus = disconnectionnoticeStatus;
	}

	public String getDisconnectionnoticeId() {
		return disconnectionnoticeId;
	}

	public void setDisconnectionnoticeId(String disconnectionnoticeId) {
		this.disconnectionnoticeId = disconnectionnoticeId;
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public Timestamp getChangeDate() {
		return this.changeDate;
	}

	public void setChangeDate(Timestamp changeDate) {
		this.changeDate = changeDate;
	}

	public String getFinanceheadAppStatus() {
		return this.financeheadAppStatus;
	}

	public void setFinanceheadAppStatus(String financeheadAppStatus) {
		this.financeheadAppStatus = financeheadAppStatus;
	}

	public String getInvoiceNo() {
		return this.invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	

	public String getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getRequestId() {
		return this.requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getSalesheadAppStatus() {
		return this.salesheadAppStatus;
	}

	public void setSalesheadAppStatus(String salesheadAppStatus) {
		this.salesheadAppStatus = salesheadAppStatus;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}