/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.PreSalesRespMatrix;

/**
 * @author Amol.l
 *
 */
public class PreSalesRespMatrixDTO  implements Serializable {
	private static final long serialVersionUID = 24L;
	
	private Integer opportunityId;
	private Integer userMstId;
	private Integer respMatrixDetailsId;
	private String commonStatus;
	private List<PreSalesRespMatrix> preSalesRespMatrixList = new ArrayList<PreSalesRespMatrix>();
	public Integer getOpportunityId() {
		return opportunityId;
	}
	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}
	
	public String getCommonStatus() {
		return commonStatus;
	}
	public void setCommonStatus(String commonStatus) {
		this.commonStatus = commonStatus;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	
	public Integer getRespMatrixDetailsId() {
		return respMatrixDetailsId;
	}
	public void setRespMatrixDetailsId(Integer respMatrixDetailsId) {
		this.respMatrixDetailsId = respMatrixDetailsId;
	}
	public List<PreSalesRespMatrix> getPreSalesRespMatrixList() {
		return preSalesRespMatrixList;
	}
	public void setPreSalesRespMatrixList(List<PreSalesRespMatrix> preSalesRespMatrixList) {
		this.preSalesRespMatrixList = preSalesRespMatrixList;
	}
	

}
