/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.jsonbeanmap.EmailBean;
import com.nelco.o2c.jsonbeanmap.TafApprovalBean;
import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.EmdRequestDetails;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.Taf;
import com.nelco.o2c.model.TafStatusTracker;
import com.nelco.o2c.model.TenderFeeRequestDetails;
import com.nelco.o2c.model.TenderTypeMst;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class EmdTenderFeeDaoImpl implements EmdTenderFeeDao {

	@PersistenceContext
	private EntityManager em;

	Query query;

	@Autowired
	CallSpDao callSpDao;

	@Autowired
	DrfApprovalDao drfApprovalDao;
	
	@Autowired
	TenderTafDao tenderTafDao;
	
	@Autowired
	CommonPotentialsDao commonPotentialsDao;
	
	@Autowired
	private Environment env;
	
	@Override
	public void saveTafCeoStatus(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		List<TafApprovalBean> tafApprBeans = commonDTO.getTafApprBeans();
		for (TafApprovalBean tafApprovalBean : tafApprBeans) {
			if(tafApprovalBean.getTafStatusCode().equalsIgnoreCase("A")) {
				TafStatusTracker tafStatusTracker = new TafStatusTracker();
				tafStatusTracker.setTafId(tafApprovalBean.getTafId());
				tafStatusTracker.setStatusMstId(9);
				tafStatusTracker.setReqBy(commonDTO.getUserMstId());
				String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
				tafStatusTracker.setStatusReqDate(currTime);
				em.merge(tafStatusTracker);
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserEmailDetailsBean> getFinanceList() {
		try {
			// TODO Auto-generated method stub
			query = em.createQuery(
					"select um.userMstId,um.userName,userEmail from UserMst um where um.roleId = 21 and um.isActive = 'Y' ");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<Object[]> userRes = (List<Object[]>) query.getResultList();
			List<UserEmailDetailsBean> financeList = new ArrayList<UserEmailDetailsBean>();
			for (Object[] objects : userRes) {
				UserEmailDetailsBean userEmailDetailsBean = new UserEmailDetailsBean();
				userEmailDetailsBean.setUserId(((Integer) objects[0]).toString());
				userEmailDetailsBean.setUserName((String) objects[1]);
				userEmailDetailsBean.setUserMail((String) objects[2]);
				financeList.add(userEmailDetailsBean);
			}
			return financeList;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TenderTypeMst> getTenderTypeList() {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("TenderTypeMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			return query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FileTypeMst> getFileTypes(Integer processId) {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("FileProcValMst.getFileTypesByTenderProcess");
			query.setParameter(1, processId);
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			return query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public EmdRequestDetails getEmdRequestData(CommonDTO commonDTO) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("EmdRequestDetails.findByOppId");
			query.setParameter(1, commonDTO.getOppId());
			List<EmdRequestDetails> emdResult = query.getResultList();
			return emdResult != null && emdResult.size() > 0 ? emdResult.get(0) : new EmdRequestDetails();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppUploadDetail> getOppUploadsByOppId(CommonDTO commonDTO) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("OppUploadDetail.findByOppId");
			query.setParameter(1, commonDTO.getOppId());
			return query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unused")
	@Override
	public void saveEmdDetails(EmdRequestDetails emdRequestDetails, HttpServletRequest request) {
		try {
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			// TODO Auto-generated method stub
			if (emdRequestDetails.getRequestStatus().equalsIgnoreCase("P")) {
				emdRequestDetails.setRequestDate(currTime);
			} else if(emdRequestDetails.getRequestStatus().equalsIgnoreCase("R")) {
				emdRequestDetails.setRejectionDate(currTime);
			} else {
				emdRequestDetails.setCompletionDate(currTime);
			}
			EmdRequestDetails savedEmdRequestDetails = em.merge(emdRequestDetails);
			
			//code for email sending begins
						UserEmailDetailsBean bean = new UserEmailDetailsBean();
						bean.setOppId(savedEmdRequestDetails.getOpportunityId().toString());
						bean.setUserId(savedEmdRequestDetails.getRequestBy().toString());
						UserEmailDetailsBean bidManager = drfApprovalDao.getUserEmailDetails(bean);
						bean.setUserId(savedEmdRequestDetails.getRequestTo().toString());
						UserEmailDetailsBean finance = drfApprovalDao.getUserEmailDetails(bean);
						CommonDTO commonDTO = new CommonDTO();
						commonDTO.setOppId(savedEmdRequestDetails.getOpportunityId());
						Taf currTaf = tenderTafDao.getTafHeaderByOppId(commonDTO);
						commonDTO.setOpportunityName(commonPotentialsDao.getPotentialNameByOppId(savedEmdRequestDetails.getOpportunityId()));
						//bean for email sending
						EmailBean emailBean = new EmailBean();
						
						if(emdRequestDetails.getRequestStatus().equalsIgnoreCase("P")) {
							emailBean.setToMail(finance.getUserMail());
							emailBean.setSubject("EMD Request");
							emailBean.setEmailBody("Dear User,"//+finance.getUserName()+","
							+"<br>This is Regarding " + commonDTO.getOpportunityName()+","+currTaf.getTenderNo()+" for "+currTaf.getScopeProj()+","
							+"Mr. "+bidManager.getUserName()
							+" has submitted request for preparation of EMD/DD."
							+ "<br> Comment - " + (savedEmdRequestDetails.getComments() != null && savedEmdRequestDetails.getComments() != "" ? savedEmdRequestDetails.getComments() : "")
							+ "<br> Click here to login :  <a href=" + request.getRequestURL().toString()
							.replace(request.getRequestURI(), "").concat(request.getContextPath()).concat("/")
							+ ">O2C portal link</a>  "+
							"<br><br>Sincerely");
						} else if(emdRequestDetails.getRequestStatus().equalsIgnoreCase("R")){
							emailBean.setToMail(bidManager.getUserMail());
							emailBean.setSubject("EMD Response");
							emailBean.setEmailBody("Dear User,"//+bidManager.getUserName()+","
							+"<br>This is Regarding " + commonDTO.getOpportunityName()+","+currTaf.getTenderNo()+" for "+currTaf.getScopeProj()+","
							+"Mr. "+finance.getUserName()
							+" has responded to your request for preparation of EMD/DD, please login to know more."
							+ "<br> Click here to login :  <a href=" + request.getRequestURL().toString()
							.replace(request.getRequestURI(), "").concat(request.getContextPath()).concat("/")
							+ ">O2C portal link</a>  "+
							"<br><br>Sincerely");
						} else {
							emailBean.setToMail(bidManager.getUserMail());
							emailBean.setSubject("EMD Response");
							emailBean.setEmailBody("Dear User,"//+bidManager.getUserName()+","
							+"<br>This is Regarding " + commonDTO.getOpportunityName()+","+currTaf.getTenderNo()+" for "+currTaf.getScopeProj()+","
							+"Mr. "+finance.getUserName()
							+" has responded to your request for preparation of EMD/DD, please login to know more."
							+ "<br> Click here to login :  <a href=" + env.getProperty("emaillink")/*request.getRequestURL().toString()
							.replace(request.getRequestURI(), "").concat(request.getContextPath()).concat("/")*/
							+ ">O2C portal link</a>  "+
							"<br><br>Sincerely");
						}
						callSpDao.sendEmail(emailBean);
			//code for email sending ends
						
			
			/*if (emdRequestDetails.getEmdRequestDetailsId() == null)
				em.refresh(emdRequestDetails);*/
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmdRequestDetails> getEmdRequestDataByRequestTo(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("EmdRequestDetails.findByRequestTo");
			query.setParameter(1, commonDTO.getUserMstId());

			return query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppDetails> getOppDetailsByOppId(Integer opportunityId) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("OppDetails.getOppDetbyOppId");
			query.setParameter(1, opportunityId);
			return query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public TenderFeeRequestDetails getTenderFeeData(CommonDTO commonDTO) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("TenderFeeRequestDetails.findByOppId");
			query.setParameter(1, commonDTO.getOppId());
			List<TenderFeeRequestDetails> resultList = query.getResultList();
			return resultList != null && resultList.size() > 0 ? resultList.get(0) : new TenderFeeRequestDetails();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unused")
	@Override
	public void saveTenderFeeDetails(TenderFeeRequestDetails tenderFeeRequestDetails, HttpServletRequest request) {
		try {
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			// TODO Auto-generated method stub
			if (tenderFeeRequestDetails.getRequestStatus().equalsIgnoreCase("P")) {
				tenderFeeRequestDetails.setRequestDate(currTime);
			} else if(tenderFeeRequestDetails.getRequestStatus().equalsIgnoreCase("R")) {
				tenderFeeRequestDetails.setRejectionDate(currTime);
			} else {
				tenderFeeRequestDetails.setCompletionDate(currTime);
			}
			TenderFeeRequestDetails savedTenderfeeRequestDetails = em.merge(tenderFeeRequestDetails);
			
			
			//code for email sending begins
			UserEmailDetailsBean bean = new UserEmailDetailsBean();
			bean.setOppId(savedTenderfeeRequestDetails.getOpportunityId().toString());
			bean.setUserId(savedTenderfeeRequestDetails.getRequestBy().toString());
			UserEmailDetailsBean bidManager = drfApprovalDao.getUserEmailDetails(bean);
			bean.setUserId(savedTenderfeeRequestDetails.getRequestTo().toString());
			UserEmailDetailsBean finance = drfApprovalDao.getUserEmailDetails(bean);
			CommonDTO commonDTO = new CommonDTO();
			commonDTO.setOppId(savedTenderfeeRequestDetails.getOpportunityId());
			Taf currTaf = tenderTafDao.getTafHeaderByOppId(commonDTO);
			commonDTO.setOpportunityName(commonPotentialsDao.getPotentialNameByOppId(savedTenderfeeRequestDetails.getOpportunityId()));
			//bean for email sending
			EmailBean emailBean = new EmailBean();
			
			if(savedTenderfeeRequestDetails.getRequestStatus().equalsIgnoreCase("P")) {
				emailBean.setToMail(finance.getUserMail());
				emailBean.setSubject("Tender Fees Request");
				emailBean.setEmailBody("Dear User,"//+finance.getUserName()+","
				+"<br>This is Regarding " + commonDTO.getOpportunityName()+","+currTaf.getTenderNo()+" for "+currTaf.getScopeProj()+","
				+"Mr. "+bidManager.getUserName()
				+" has submitted request for preparation of Tender fees, please login to know more."
				+ "<br> Click here to login :  <a href=" + request.getRequestURL().toString()
				.replace(request.getRequestURI(), "").concat(request.getContextPath()).concat("/")
				+ ">O2C portal link</a>  "+
				"<br><br>Sincerely");
			} else if(savedTenderfeeRequestDetails.getRequestStatus().equalsIgnoreCase("R")){
				emailBean.setToMail(bidManager.getUserMail());
				emailBean.setSubject("Tender Fees Response");
				emailBean.setEmailBody("Dear User,"//+bidManager.getUserName()+","
				+"<br>This is Regarding " + commonDTO.getOpportunityName()+","+currTaf.getTenderNo()+" for "+currTaf.getScopeProj()+","
				+"Mr. "+finance.getUserName()
				+" has responded to your request for preparation of Tender Fees, please login to know more."
				+ "<br> Click here to login :  <a href=" + request.getRequestURL().toString()
				.replace(request.getRequestURI(), "").concat(request.getContextPath()).concat("/")
				+ ">O2C portal link</a>  "+
				"<br><br>Sincerely");
			} else {
				emailBean.setToMail(bidManager.getUserMail());
				emailBean.setSubject("Tender Fees Response");
				emailBean.setEmailBody("Dear User,"//+bidManager.getUserName()+","
				+"<br>This is Regarding " + commonDTO.getOpportunityName()+","+currTaf.getTenderNo()+" for "+currTaf.getScopeProj()+","
				+"Mr. "+finance.getUserName()
				+" has responded to your request for preparation of Tender Fees, please login to know more."
				+ "<br> Click here to login :  <a href=" + env.getProperty("emaillink")/*request.getRequestURL().toString()
				.replace(request.getRequestURI(), "").concat(request.getContextPath()).concat("/")*/
				+ ">O2C portal link</a>  "+
				"<br><br>Sincerely");
			}
			callSpDao.sendEmail(emailBean);
//code for email sending ends
			
			/*if (tenderFeeRequestDetails.getTenderFeeRequestDetailsId() == null)
				em.refresh(tenderFeeRequestDetails);*/
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TenderFeeRequestDetails> getTenderFeeDataByRequestTo(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("TenderFeeRequestDetails.findByRequestTo");
			query.setParameter(1, commonDTO.getUserMstId());

			return query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public OppUploadDetail saveOppUploadDetails(OppUploadDetail oppUploadDetail) {
		try {
			// TODO Auto-generated method stub
			String currTime2 = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			oppUploadDetail.setUploadTime(currTime2);
			oppUploadDetail.setCreatedDate(new Date());
			OppUploadDetail oppUploadDetailTemp = em.merge(oppUploadDetail);
			if(oppUploadDetail.getOppUploadDetailsId()==null)
				em.refresh(oppUploadDetailTemp);
			return oppUploadDetailTemp;
		} finally {
			// TODO: handle finally clause
			//em.close();
		}
	}
}
