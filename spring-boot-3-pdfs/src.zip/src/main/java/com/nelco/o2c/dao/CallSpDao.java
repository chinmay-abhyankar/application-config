/**
 * 
 */
package com.nelco.o2c.dao;

import com.nelco.o2c.jsonbeanmap.EmailBean;
import com.nelco.o2c.model.ChildContract;

/**
 * @author Jayashankar.r
 *
 */
public interface CallSpDao {
	public void sendEmail(EmailBean emailBean);
	public void callContractGenSp();
	public void callContGenProcBychildConId(ChildContract childContract);
	public void callIspEmailToFinanceFirBillCreation(Integer firId,String firUniqId);
	
}
