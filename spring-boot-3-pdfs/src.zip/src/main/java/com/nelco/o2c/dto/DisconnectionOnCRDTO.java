package com.nelco.o2c.dto;

import java.math.BigDecimal;

public class DisconnectionOnCRDTO {

	private String soNo="";
	private String customerName="";
	private String ip="";
	private String disconnectionRequestDate="";
	private int noticePeriod;
	private String billingEndDate="";
	private String requestId="";
	private String status="";
	private String statusCode="";
	private String overallStatus="";
	private String hubName="";
	private String vsatId="";
	private String commonId="";
	
	private String bankName="";
	private String pmName="";
	private String slaTerm="";
	private String siteAddress="";
	private String state="";
	private String technology="";
	private String hub="";
	private String soType="";
	private String poNo="";
	private String reasonForDisconnection="";
	private String creditNoteNo="";
	private String creditAmt="";
	
	private String invoiceNo="";
	private String invoiceSubmissionDate="";
	private String paymentDueDate="";
	private String message="";
	private String error="";
	
	
	//For Disconnection Report On Customer Request
	public DisconnectionOnCRDTO(String customerName, String bankName,String pmName,String disconnectionRequestDate
			,String slaTerm,String billingEndDate,String siteAddress,String state,String ip,String vsatId,String technology,String hub
			,String soNo,String soType,String poNo,String reasonForDisconnection,String creditNoteNo,String creditAmt,String overallStatus) {
		this.customerName=customerName;
		this.bankName=bankName;
		this.pmName=pmName;
		this.disconnectionRequestDate=disconnectionRequestDate;
		this.slaTerm=slaTerm;
		this.billingEndDate=billingEndDate;
		this.siteAddress=siteAddress;
		this.state=state;
		this.ip=ip;
		this.vsatId=vsatId;
		this.technology=technology;
		this.hub=hub;
		this.soNo=soNo;
		this.soType=soType;
		this.poNo=poNo;
		this.reasonForDisconnection=reasonForDisconnection;
		this.creditNoteNo=creditNoteNo;
		this.creditAmt=creditAmt;
		this.overallStatus=overallStatus;
	}
	
	//For Disconnection Report On Non Payment
		public DisconnectionOnCRDTO(String customerName, String bankName,String pmName,String invoiceSubmissionDate,String slaTerm
				,String paymentDueDate
				,String billingEndDate,String siteAddress,String state,String ip,String vsatId,String technology,String hub
				,String invoiceNo,String soNo,String soType,String poNo,String reasonForDisconnection,String creditNoteNo,String creditAmt,String overallStatus) {
			this.customerName=customerName;
			this.bankName=bankName;
			this.pmName=pmName;
			this.invoiceSubmissionDate=invoiceSubmissionDate;
			this.slaTerm=slaTerm;
			this.paymentDueDate=paymentDueDate;
			this.billingEndDate=billingEndDate;
			this.siteAddress=siteAddress;
			this.state=state;
			this.ip=ip;
			this.vsatId=vsatId;
			this.technology=technology;
			this.hub=hub;
			this.invoiceNo=invoiceNo;
			this.soNo=soNo;
			this.soType=soType;
			this.poNo=poNo;
			this.reasonForDisconnection=reasonForDisconnection;
			this.creditNoteNo=creditNoteNo;
			this.creditAmt=creditAmt;
			this.overallStatus=overallStatus;
		}
	
		
	public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}

		public String getError() {
			return error;
		}

		public void setError(String error) {
			this.error = error;
		}

	public String getInvoiceNo() {
		return invoiceNo;
	}


	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}


	public String getInvoiceSubmissionDate() {
		return invoiceSubmissionDate;
	}


	public void setInvoiceSubmissionDate(String invoiceSubmissionDate) {
		this.invoiceSubmissionDate = invoiceSubmissionDate;
	}


	public String getPaymentDueDate() {
		return paymentDueDate;
	}


	public void setPaymentDueDate(String paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}


	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getPmName() {
		return pmName;
	}

	public void setPmName(String pmName) {
		this.pmName = pmName;
	}

	public String getSlaTerm() {
		return slaTerm;
	}

	public void setSlaTerm(String slaTerm) {
		this.slaTerm = slaTerm;
	}

	public String getSiteAddress() {
		return siteAddress;
	}

	public void setSiteAddress(String siteAddress) {
		this.siteAddress = siteAddress;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getHub() {
		return hub;
	}

	public void setHub(String hub) {
		this.hub = hub;
	}

	public String getSoType() {
		return soType;
	}

	public void setSoType(String soType) {
		this.soType = soType;
	}

	public String getPoNo() {
		return poNo;
	}

	public void setPoNo(String poNo) {
		this.poNo = poNo;
	}

	public String getReasonForDisconnection() {
		return reasonForDisconnection;
	}

	public void setReasonForDisconnection(String reasonForDisconnection) {
		this.reasonForDisconnection = reasonForDisconnection;
	}

	public String getCreditNoteNo() {
		return creditNoteNo;
	}

	public void setCreditNoteNo(String creditNoteNo) {
		this.creditNoteNo = creditNoteNo;
	}

	public String getCreditAmt() {
		return creditAmt;
	}

	public void setCreditAmt(String creditAmt) {
		this.creditAmt = creditAmt;
	}

	public String getCommonId() {
		return commonId;
	}

	public void setCommonId(String commonId) {
		this.commonId = commonId;
	}

	public String getHubName() {
		return hubName;
	}

	public void setHubName(String hubName) {
		this.hubName = hubName;
	}

	public String getVsatId() {
		return vsatId;
	}

	public void setVsatId(String vsatId) {
		this.vsatId = vsatId;
	}

	public String getOverallStatus() {
		return overallStatus;
	}

	public void setOverallStatus(String overallStatus) {
		this.overallStatus = overallStatus;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getDisconnectionRequestDate() {
		return disconnectionRequestDate;
	}

	public void setDisconnectionRequestDate(String disconnectionRequestDate) {
		this.disconnectionRequestDate = disconnectionRequestDate;
	}

	public int getNoticePeriod() {
		return noticePeriod;
	}

	public void setNoticePeriod(int noticePeriod) {
		this.noticePeriod = noticePeriod;
	}

	public String getBillingEndDate() {
		return billingEndDate;
	}

	public void setBillingEndDate(String billingEndDate) {
		this.billingEndDate = billingEndDate;
	}

	public String getSoNo() {
		return soNo;
	}

	public void setSoNo(String soNo) {
		this.soNo = soNo;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public DisconnectionOnCRDTO(String soNo, String customerName, String ip,String requestId,String disconnectionRequestDate
			,int noticePeriod,String billingEndDate,String status,String statusCode,String overallStatus,String hubName,String vsatId,String commonId) {
		this.soNo=soNo;
		this.customerName=customerName;
		this.ip=ip;
		this.requestId=requestId;
		this.disconnectionRequestDate=disconnectionRequestDate;
		this.noticePeriod=noticePeriod;
		this.billingEndDate=billingEndDate;
		this.status=status;
		this.statusCode=statusCode;
		this.overallStatus=overallStatus;
		this.hubName=hubName;
		this.vsatId=vsatId;
		this.commonId=commonId;
	}
	
	public DisconnectionOnCRDTO(String soNo, String customerName, String ip,String requestId,String disconnectionRequestDate
			,int noticePeriod,String billingEndDate,String status,String overallStatus) {
		this.soNo=soNo;
		this.customerName=customerName;
		this.ip=ip;
		this.requestId=requestId;
		this.disconnectionRequestDate=disconnectionRequestDate;
		this.noticePeriod=noticePeriod;
		this.billingEndDate=billingEndDate;
		this.status=status;
		this.overallStatus=overallStatus;
	}

	public DisconnectionOnCRDTO(String soNo, String customerName, String ip, String vsatId, String hubName,
			String disconnectionRequestDate, int noticePeriod, String billingEndDate,String message,String error) {
		this.soNo=soNo;
		this.customerName=customerName;
		this.ip=ip;
		this.vsatId=vsatId;
		this.hubName=hubName;
		this.disconnectionRequestDate=disconnectionRequestDate;
		this.noticePeriod=noticePeriod;
		this.billingEndDate=billingEndDate;
		this.message=message;
		this.status=error;
	}

}
