/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

/**
 * @author Amol.l
 *
 */
public class MaterialDTO implements Serializable {

	private static final long serialVersionUID = 105L;
	
	private Integer materialSapmstId;
	private String accAssignGroup;
	private String baseUnit;
	private String controlGroup;
	private String createdDate;
	private String deliveryPlant;
	private String distChannel;
	private String division;
	private String itemCategory;
	private String materialDesc;
	private String materialGroup;
	private String materialNo;
	private String materialType;
	private String plant;
	private String salesOrg;
	public Integer getMaterialSapmstId() {
		return materialSapmstId;
	}
	public void setMaterialSapmstId(Integer materialSapmstId) {
		this.materialSapmstId = materialSapmstId;
	}
	public String getAccAssignGroup() {
		return accAssignGroup;
	}
	public void setAccAssignGroup(String accAssignGroup) {
		this.accAssignGroup = accAssignGroup;
	}
	public String getBaseUnit() {
		return baseUnit;
	}
	public void setBaseUnit(String baseUnit) {
		this.baseUnit = baseUnit;
	}
	public String getControlGroup() {
		return controlGroup;
	}
	public void setControlGroup(String controlGroup) {
		this.controlGroup = controlGroup;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getDeliveryPlant() {
		return deliveryPlant;
	}
	public void setDeliveryPlant(String deliveryPlant) {
		this.deliveryPlant = deliveryPlant;
	}
	public String getDistChannel() {
		return distChannel;
	}
	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getItemCategory() {
		return itemCategory;
	}
	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}
	public String getMaterialDesc() {
		return materialDesc;
	}
	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}
	public String getMaterialGroup() {
		return materialGroup;
	}
	public void setMaterialGroup(String materialGroup) {
		this.materialGroup = materialGroup;
	}
	public String getMaterialNo() {
		return materialNo;
	}
	public void setMaterialNo(String materialNo) {
		this.materialNo = materialNo;
	}
	public String getMaterialType() {
		return materialType;
	}
	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getSalesOrg() {
		return salesOrg;
	}
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

}
