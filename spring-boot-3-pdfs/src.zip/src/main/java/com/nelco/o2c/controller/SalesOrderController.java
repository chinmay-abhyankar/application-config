/**
 * 
 */
package com.nelco.o2c.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.SoOrderDTO;
import com.nelco.o2c.dto.SoOrdersListDTO;
import com.nelco.o2c.model.SoOrders;
import com.nelco.o2c.service.SalesOrderService;

/**
 * @author Amol.l
 *
 */
@RestController
public class SalesOrderController {
	
	@Autowired
	SalesOrderService salesOrderService;
	
	@RequestMapping(value = "/getSoDetailsBySoNumber.do", method = RequestMethod.POST)
	public SoOrdersListDTO getSoDetailsBySoNumber(@RequestBody SoOrderDTO soOrderDTO) {
		SoOrdersListDTO soOrdersListDTONew = new SoOrdersListDTO();
		List<SoOrders> soOrders = new ArrayList<SoOrders>();
		soOrders = salesOrderService.getSoDetailsBySoNumber(soOrderDTO);
		//soOrderDTONew.setSoorderSapmst(soorder);
		soOrdersListDTONew.setSoOrders(soOrders);
		//soOrdersListDTONew.setSoNumber(soOrderDTO.getSoNumber());
		return soOrdersListDTONew;
	}
	
	@RequestMapping(value = "/getSOListByContractNum.do", method = RequestMethod.POST)
	public SoOrdersListDTO getSOListByContractNum(@RequestBody SoOrdersListDTO soOrdersListDTO) {
		SoOrdersListDTO soOrdersListDTONew = new SoOrdersListDTO();
		List<SoOrders> soOrders = salesOrderService.getSOListByContractNum(soOrdersListDTO.getContractNum());
		soOrdersListDTONew.setContractNum(soOrdersListDTO.getContractNum());
		soOrdersListDTONew.setSoOrders(soOrders);
		return soOrdersListDTONew;
	}
	
	@RequestMapping(value = "/getSOListBySparesSoUniqId.do", method = RequestMethod.POST)
	public SoOrdersListDTO getSOListBySparesSoUniqId(@RequestBody SoOrdersListDTO soOrdersListDTO) {
		SoOrdersListDTO soOrdersListDTONew = new SoOrdersListDTO();
		List<SoOrders> soOrders = salesOrderService.getSOListBySparesSoUniqId(soOrdersListDTO);
		//soOrdersListDTONew.setContractNum(soOrdersListDTO.getContractNum());
		soOrdersListDTONew.setSoOrders(soOrders);
		return soOrdersListDTONew;
	}
	
	
	@RequestMapping(value = "/getSOListByRelocationSoUniqId.do", method = RequestMethod.POST)
	public SoOrdersListDTO getSOListByRelocationSoUniqId(@RequestBody SoOrdersListDTO soOrdersListDTO) {
		SoOrdersListDTO soOrdersListDTONew = new SoOrdersListDTO();
		List<SoOrders> soOrders = salesOrderService.getSOListByRelocationSoUniqId(soOrdersListDTO);
		//soOrdersListDTONew.setContractNum(soOrdersListDTO.getContractNum());
		soOrdersListDTONew.setSoOrders(soOrders);
		return soOrdersListDTONew;
	}
	
	@RequestMapping(value = "/getSOListByDemoId.do", method = RequestMethod.POST)
	public SoOrdersListDTO getSOListByDemoId(@RequestBody SoOrdersListDTO soOrdersListDTO) {
		SoOrdersListDTO soOrdersListDTONew = new SoOrdersListDTO();
		List<SoOrders> soOrders = salesOrderService.getSOListByDemoId(soOrdersListDTO);
		//soOrdersListDTONew.setContractNum(soOrdersListDTO.getContractNum());
		soOrdersListDTONew.setSoOrders(soOrders);
		return soOrdersListDTONew;
	}

}
