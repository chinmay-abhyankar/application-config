/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Amol.l
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Approval {
	
	@JsonProperty("delegate")
	private String delegate;
	
	@JsonProperty("approve")
	private String approve;
	
	@JsonProperty("reject")
	private String reject;
	
	@JsonProperty("resubmit")
	private String resubmit;

	public String getDelegate() {
		return delegate;
	}

	public void setDelegate(String delegate) {
		this.delegate = delegate;
	}

	public String getApprove() {
		return approve;
	}

	public void setApprove(String approve) {
		this.approve = approve;
	}

	public String getReject() {
		return reject;
	}

	public void setReject(String reject) {
		this.reject = reject;
	}

	public String getResubmit() {
		return resubmit;
	}

	public void setResubmit(String resubmit) {
		this.resubmit = resubmit;
	}

	@Override
	public String toString() {
		return "Approval [delegate=" + delegate + ", approve=" + approve + ", reject=" + reject + ", resubmit="
				+ resubmit + "]";
	}
	
	
	
}
