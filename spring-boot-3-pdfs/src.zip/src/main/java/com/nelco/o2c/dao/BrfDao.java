/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.nelco.o2c.dto.BrfDTO;
import com.nelco.o2c.dto.BrfDetailsDTO;
import com.nelco.o2c.dto.BrfDetailsListDTO;
import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.OldSoDTO;
import com.nelco.o2c.dto.UserToHubDTO;
import com.nelco.o2c.model.Brf;
import com.nelco.o2c.model.BrfApproverDetail;
import com.nelco.o2c.model.BrfSoDetails;
import com.nelco.o2c.model.BrfStatusTracker;
import com.nelco.o2c.model.MaterialChildContract;
import com.nelco.o2c.model.OppUploadDetail;

/**
 * @author Amol.l
 *
 */
public interface BrfDao {

	public List<BrfDetailsDTO> getBrfListByDate(BrfDetailsListDTO brfDetailsListDTO);

	public Brf getBrfByBrfId(Integer brfId);

	public Brf saveBrf(Brf brf);

	public BrfApproverDetail saveSingleBrfApprovals(BrfApproverDetail brfApproverDetail);

	public boolean checkAllApproved(BrfApproverDetail brfApproverDetail);

	public BrfStatusTracker saveBrfStatusTracker(BrfStatusTracker brfStatusTracker);

	public boolean checkBrfRejectStatus(BrfStatusTracker brfStatusTracker);

	public BrfStatusTracker getBrfStatusTracker(CommonDTO commonDTO);

	public List<OldSoDTO> getOldSoList(CommonDTO commonDTO);

	public List<BrfDetailsDTO> getBrfListByContNumAndDate(BrfDetailsListDTO brfDetailsListDTO);

	public Integer getBrfCountByContractNum(String contractNum);

	public Integer getRemainNumSiteByContractNum(String contractNum);

	public MaterialChildContract getMaterialChildContractById(Integer childContractId);

	public BrfSoDetails saveBrfSoDetails(BrfSoDetails brfSoDetails);

	public List<OppUploadDetail> getUploadDetailsByBrfId(Integer brfId);

	public void deleteBrfSoDetByBrfId(Integer brfId);

	public List<BrfStatusTracker> getBrfStatusTrack(BrfDTO brfDTO);

	public int getCount(String table, String column, String value);

	public void uploadFile(MultipartFile file, String userMstId, String brfId) throws Exception;

	public void softDeleteByOpUpDetId(Integer oppUploadDetailsId);

	public UserToHubDTO getUserAndHubDetByHubMstId(Integer hubMstId);
	
	public List<MaterialChildContract> materialListByChildContId(Integer childContractId);
	
	public Integer sumOfOrderQtyByChildContId(Integer childContractId);

	public List<BrfSoDetails> brfSoDetListByBrfId(BrfDTO brfDTO);

	public List<BrfDetailsDTO> brfListToFillGeoTemplate(BrfDetailsListDTO brfDetailsListDTO);
	
}
