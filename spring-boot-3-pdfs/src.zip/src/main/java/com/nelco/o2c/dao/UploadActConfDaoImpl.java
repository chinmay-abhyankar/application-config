/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.HsoUploadDTO;
import com.nelco.o2c.model.HsoDetail;
import com.nelco.o2c.model.HsoStatusChangeTracker;
import com.nelco.o2c.model.HsoTransactionDetail;
import com.nelco.o2c.model.HsoTransactionDetailsTracker;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Jayshankar.r
 *
 */
@Repository
public class UploadActConfDaoImpl implements UploadActConfDao {

	@PersistenceContext
	private EntityManager em;

	Query query;

	@SuppressWarnings("unchecked")
	@Override
	public HsoUploadDTO updateHsoTransactionDetails(List<HsoTransactionDetail> transactionDetailsList,List<HsoDetail> hsoDetails) {
		// TODO Auto-generated method stub
		
		for (HsoDetail hsoDetail : hsoDetails) {
			query = em.createNamedQuery("HsoDetail.updateHsoDetails");
			query.setParameter("iflCableLength", hsoDetail.getIflCableLength());
			query.setParameter("hsoDetailsId", hsoDetail.getHsoDetailsId());
			
			query.executeUpdate();
		}
		
		for (HsoTransactionDetail hsoTransactionDetail : transactionDetailsList) {
			query = em.createNativeQuery(
					" select case when hso_transaction_status_mst_id is not null and hso_transaction_status_mst_id = 1 "
							+ " then 'Y' else 'N' end as val_flag  "
							+ " from hso_transaction_details where hso_transaction_details_id = :hsoTransactionDetailsId ");
			query.setParameter("hsoTransactionDetailsId", hsoTransactionDetail.getHsoTransactionDetailsId());

			String flag = "N";

			List<Object> flagValList = (List<Object>) query.getResultList();
			if (flagValList != null && flagValList.size() > 0) {
				flag = (String) flagValList.get(0);
			}

			if (flag.equalsIgnoreCase("Y")) {
				// saving the hsoTransactionDetails
				
				//code for file Name Generation begins 
				String dateString = "ACTC"+DateUtil.getCurrentISTDateAsString(DateUtil.CONTRACTCSVDATE)
				.replace("-", "").replace(":","");
				int totalLength = dateString.length();
				int remLength = 0;
				if(totalLength<19) {
					remLength = 19-totalLength;
					for(int i = 0;i<remLength;i++) {
						dateString = dateString.concat("0");
					}
				} else if(totalLength>19) {
					dateString = dateString.substring(0, 19);
				}
				String fileNameFinal = dateString+".csv";
				//code for file Name Generation ends
				
				hsoTransactionDetail.setFileName(fileNameFinal);
				
				em.merge(hsoTransactionDetail);

				// inserting into tracker
				
				HsoStatusChangeTracker hsoStatusChangeTracker = new HsoStatusChangeTracker();
				hsoStatusChangeTracker.setHsoTransactionDetailsId(hsoTransactionDetail.getHsoTransactionDetailsId());
				hsoStatusChangeTracker.setHsoTransactionStatusMstId(hsoTransactionDetail.getHsoTransactionStatusMstId());
				hsoStatusChangeTracker.setReqBy(hsoTransactionDetail.getModifiedBy());
				hsoStatusChangeTracker.setReqDate(hsoTransactionDetail.getModifiedDate());
				
				em.merge(hsoStatusChangeTracker);
			}
		}
		HsoUploadDTO hsoUploadDTO = new HsoUploadDTO();

		hsoUploadDTO.setIsUploaded(true);
		
		hsoUploadDTO.setMessage("Hso Template Uploaded Successfully");

		return hsoUploadDTO;
	}

}
