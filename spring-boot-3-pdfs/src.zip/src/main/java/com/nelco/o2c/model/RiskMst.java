package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the risk_mst database table.
 * 
 */
@Entity
@Table(name="risk_mst")
@NamedQuery(name="RiskMst.findAll", query="SELECT r FROM RiskMst r")
public class RiskMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="risk_mst_id")
	private Integer riskMstId;

	@Column(name="risk_code")
	private String riskCode;

	@Column(name="risk_val")
	private String riskVal;

	public Integer getRiskMstId() {
		return riskMstId;
	}

	public void setRiskMstId(Integer riskMstId) {
		this.riskMstId = riskMstId;
	}

	public String getRiskCode() {
		return riskCode;
	}

	public void setRiskCode(String riskCode) {
		this.riskCode = riskCode;
	}

	public String getRiskVal() {
		return riskVal;
	}

	public void setRiskVal(String riskVal) {
		this.riskVal = riskVal;
	}

	

}