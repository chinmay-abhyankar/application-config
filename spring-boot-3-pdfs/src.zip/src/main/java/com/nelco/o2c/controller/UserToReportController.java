package com.nelco.o2c.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.ReportContractDTO;
import com.nelco.o2c.dto.UserDTO;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.ReportMst;
import com.nelco.o2c.model.StatusMst;
import com.nelco.o2c.service.UserToReportService;

@RestController
public class UserToReportController {

	@Autowired
	private UserToReportService reportService;

	@GetMapping("/userToReport.do/{userID}")
	public List<ReportMst> getAsssignedReportsName(@PathVariable("userID") int userId) {
		return reportService.getAsssignedReportsName(userId);
	}

	@GetMapping("/searchByStatusCode.do")
	public List<StatusMst> searchByStatusCode() {
		return reportService.searchStatusByCode();
	}

	@GetMapping("/searchContractNumber.do")
	public ReportContractDTO searchSapContractNum(@RequestParam String sapContractNumber) {
		System.out.println(sapContractNumber);
		return reportService.searchSapContractNum(sapContractNumber);
	}

	@GetMapping("/allActiveHubs.do")
	public List<HubMst> getAllHubList() {
		return reportService.getAllHubList();
	}

	@GetMapping("/allProgramMangers.do")
	public List<UserDTO> getallProgramMangers() {
		return reportService.getALlProgramMangers();
	}
}
