package com.nelco.o2c.dto;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class FranchiseeDTO {
	
	private Integer id;
	private Integer activityType;	
	private Integer site_survey_id;	
	private String contactPersonNumber;	
	private String creationDate;	
	private String deliveryNum;	
	private Integer deliveryId;	
	private String installationAddress;	
	private String siteContactPerson;	
	private String siteSurveyDone;	
	private String siteSurveyUniqId;	
	private String soNumber;
	private Integer status;	
	private String uniq_id;	
	private String vsatId;	
	private String vsatIp;	
	private Integer user_id;	
	private Integer installationTypeMstId;
	private String item;
	private String tentativeDate;
	private Integer hubMstId;
	private String additionalRemarks;
	private Integer technologyMstId;
	private String subCustomer;
	
	
	
	
	
	public String getSubCustomer() {
		return subCustomer;
	}
	public void setSubCustomer(String subCustomer) {
		this.subCustomer = subCustomer;
	}
	public String getTentativeDate() {
		return tentativeDate;
	}
	public void setTentativeDate(String tentativeDate) {
		this.tentativeDate = tentativeDate;
	}
	public Integer getHubMstId() {
		return hubMstId;
	}
	public void setHubMstId(Integer hubMstId) {
		this.hubMstId = hubMstId;
	}
	public String getAdditionalRemarks() {
		return additionalRemarks;
	}
	public void setAdditionalRemarks(String additionalRemarks) {
		this.additionalRemarks = additionalRemarks;
	}
	public Integer getTechnologyMstId() {
		return technologyMstId;
	}
	public void setTechnologyMstId(Integer technologyMstId) {
		this.technologyMstId = technologyMstId;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public Integer getInstallationTypeMstId() {
		return installationTypeMstId;
	}
	public void setInstallationTypeMstId(Integer installationTypeMstId) {
		this.installationTypeMstId = installationTypeMstId;
	}
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	public String getUniq_id() {
		return uniq_id;
	}
	public void setUniq_id(String uniq_id) {
		this.uniq_id = uniq_id;
	}
	public Integer getSite_survey_id() {
		return site_survey_id;
	}
	public void setSite_survey_id(Integer site_survey_id) {
		this.site_survey_id = site_survey_id;
	}
	public Integer getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(Integer deliveryId) {
		this.deliveryId = deliveryId;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getActivityType() {
		return activityType;
	}
	public void setActivityType(Integer activityType) {
		this.activityType = activityType;
	}
	public String getContactPersonNumber() {
		return contactPersonNumber;
	}
	public void setContactPersonNumber(String contactPersonNumber) {
		this.contactPersonNumber = contactPersonNumber;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getDeliveryNum() {
		return deliveryNum;
	}
	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}
	public String getInstallationAddress() {
		return installationAddress;
	}
	public void setInstallationAddress(String installationAddress) {
		this.installationAddress = installationAddress;
	}
	public String getSiteContactPerson() {
		return siteContactPerson;
	}
	public void setSiteContactPerson(String siteContactPerson) {
		this.siteContactPerson = siteContactPerson;
	}
	public String getSiteSurveyDone() {
		return siteSurveyDone;
	}
	public void setSiteSurveyDone(String siteSurveyDone) {
		this.siteSurveyDone = siteSurveyDone;
	}
	public String getSiteSurveyUniqId() {
		return siteSurveyUniqId;
	}
	public void setSiteSurveyUniqId(String siteSurveyUniqId) {
		this.siteSurveyUniqId = siteSurveyUniqId;
	}
	public String getSoNumber() {
		return soNumber;
	}
	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	
	public String getVsatId() {
		return vsatId;
	}
	public void setVsatId(String vsatId) {
		this.vsatId = vsatId;
	}
	public String getVsatIp() {
		return vsatIp;
	}
	public void setVsatIp(String vsatIp) {
		this.vsatIp = vsatIp;
	}	
	
	
}
