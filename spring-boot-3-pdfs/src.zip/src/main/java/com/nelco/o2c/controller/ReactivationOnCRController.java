package com.nelco.o2c.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.nelco.o2c.dto.DisconnectionOnCRFormDTO;
import com.nelco.o2c.dto.ReactivationFormDTO;
import com.nelco.o2c.dto.ReactivationOnCRFormDTO;
import com.nelco.o2c.dto.ResponseDTO;
import com.nelco.o2c.service.ReactivationOnCRService;

@RestController
public class ReactivationOnCRController {
	@Autowired
	ReactivationOnCRService reactivationService;
	@RequestMapping(value = "/getReactivationOnCRRequestList.do", method = RequestMethod.GET)
		public ReactivationOnCRFormDTO getReactivationRequestList(ReactivationOnCRFormDTO reactivationformDTO, HttpServletRequest request) {	
		return reactivationService.getReactivationRequestsList(reactivationformDTO, request);
	}
	
	@RequestMapping(value = "/initiateReactivationRequestOnCR.do", method = RequestMethod.POST)
	public ReactivationOnCRFormDTO initiateReactivationRequest(@RequestBody ReactivationOnCRFormDTO reactivationFormDTO, HttpServletRequest request) {
		return reactivationService.initiateReactivationRequest(reactivationFormDTO,request);
	}
	
	@RequestMapping(value = "/reactivateSiteOnCR.do", method = RequestMethod.POST)
	public ReactivationOnCRFormDTO reactivateSite(@RequestBody ReactivationOnCRFormDTO reactivationFormDTO, HttpServletRequest request) {
		return reactivationService.reactivateSite(reactivationFormDTO,request);
	}

	@RequestMapping(value = "/reconnectionOnCRDetails.do", method = RequestMethod.GET)
	public ReactivationOnCRFormDTO getReconnectionRequestDetails(ReactivationOnCRFormDTO reactivationFormDTO, HttpServletRequest request) {
		return reactivationService.getReconnectionRequestDetails(reactivationFormDTO,request);
	}
	
	@RequestMapping(value = "/uploadReactivationRequestOnCR.do", method = RequestMethod.POST)
	public ReactivationOnCRFormDTO uploadDisconnectionRequestOnCR(ReactivationOnCRFormDTO reactivationOnCRFormDTO,MultipartHttpServletRequest request, @RequestParam String userId)
			throws IOException {
		ResponseDTO responseDTO = new ResponseDTO();
		MultipartFile file = request.getFile("theFile");
		try{
		responseDTO= reactivationService.validateFile(file, userId, responseDTO);
		reactivationOnCRFormDTO=reactivationService.uploadFile(file, userId,reactivationOnCRFormDTO,responseDTO.getResultMap());
		}catch(Exception e){e.printStackTrace();}
		return reactivationOnCRFormDTO;
	}
}
