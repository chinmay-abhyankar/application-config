package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class DisconnectionDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	
private List<CustomerwiseOutstandingDTO> OutstandingList=null;
private List<InvoiceListDTO> InvoiceList=null;
private List<OutstandingInvoicesDTO> OutstandingInvoiceList=null;
List<DisconnectionOnCRDTO> soList=new ArrayList<DisconnectionOnCRDTO>();

public List<DisconnectionOnCRDTO> getSoList() {
	return soList;
}

public void setSoList(List<DisconnectionOnCRDTO> soList) {
	this.soList = soList;
}

public List<OutstandingInvoicesDTO> getOutstandingInvoiceList() {
	return OutstandingInvoiceList;
}

public void setOutstandingInvoiceList(List<OutstandingInvoicesDTO> outstandingInvoiceList) {
	OutstandingInvoiceList = outstandingInvoiceList;
}

public List<CustomerwiseOutstandingDTO> getOutstandingList() {
	return OutstandingList;
}

public void setOutstandingList(List<CustomerwiseOutstandingDTO> outstandingList) {
	OutstandingList = outstandingList;
}

public List<InvoiceListDTO> getInvoiceList() {
	return InvoiceList;
}

public void setInvoiceList(List<InvoiceListDTO> invoiceList) {
	InvoiceList = invoiceList;
}

	
}
