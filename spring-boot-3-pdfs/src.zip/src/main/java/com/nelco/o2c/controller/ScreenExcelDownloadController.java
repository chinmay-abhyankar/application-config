/**
 * 
 */
package com.nelco.o2c.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nelco.o2c.dto.ScreenExcelDownloadDTO;
import com.nelco.o2c.service.ScreenExcelDownloadService;

/**
 * @author Jayshankar.r
 *
 */
@RestController
public class ScreenExcelDownloadController {
	
	@Autowired
	ScreenExcelDownloadService screenExcelDownloadService;
	
	public ScreenExcelDownloadDTO excelDownloadUtility(String ipJson) throws SQLException, JsonParseException, JsonMappingException, IOException {
		
		 ObjectMapper mapper = new ObjectMapper();
		 ScreenExcelDownloadDTO returnDTO = mapper.readValue(ipJson, ScreenExcelDownloadDTO.class);
	     return returnDTO;
	}
	
	@RequestMapping(value="/getRelocationSoExcel.do",method = {RequestMethod.GET,RequestMethod.POST})
	public void getRelocationSoExcel(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) {
		try {
			ScreenExcelDownloadDTO screenExcelDownloadDTO = excelDownloadUtility(ipJson);
			screenExcelDownloadService.getRelocationSoExcel(request, response, screenExcelDownloadDTO);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value="/getSparesSoExcel.do",method = {RequestMethod.GET,RequestMethod.POST})
	public void getSparesSoExcel(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) {
		try {
			ScreenExcelDownloadDTO screenExcelDownloadDTO = excelDownloadUtility(ipJson);
			screenExcelDownloadService.getSparesSoExcel(request, response, screenExcelDownloadDTO);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value="/getMasterContractExcel.do",method = {RequestMethod.GET,RequestMethod.POST})
	public void getMasterContractExcel(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) {
		try {
			ScreenExcelDownloadDTO screenExcelDownloadDTO = excelDownloadUtility(ipJson);
			screenExcelDownloadService.getMasterContractExcel(request, response, screenExcelDownloadDTO);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value="/getProposalExcel.do",method = {RequestMethod.GET,RequestMethod.POST})
	public void getProposalExcel(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) {
		try {
			ScreenExcelDownloadDTO screenExcelDownloadDTO = excelDownloadUtility(ipJson);
			screenExcelDownloadService.getProposalExcel(request, response, screenExcelDownloadDTO);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value="/getSiteSurveyFranchiseCostListExcel.do",method = {RequestMethod.GET,RequestMethod.POST})
	public void getSiteSurveyFranchiseCostListExcel(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) {
		try {
			ScreenExcelDownloadDTO screenExcelDownloadDTO = excelDownloadUtility(ipJson);
			screenExcelDownloadService.getSiteSurveyFranchiseCostListExcel(request, response, screenExcelDownloadDTO);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value="/getPaymentRequestListExcel.do",method = {RequestMethod.GET,RequestMethod.POST})
	public void getPaymentRequestListExcel(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) {
		try {
			ScreenExcelDownloadDTO screenExcelDownloadDTO = excelDownloadUtility(ipJson);
			screenExcelDownloadService.getPaymentRequestListExcel(request, response, screenExcelDownloadDTO);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value="/getPotentialsAMListExcel.do",method = {RequestMethod.GET,RequestMethod.POST})
	public void getPotentialsAMListExcel(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) {
		try {
			ScreenExcelDownloadDTO screenExcelDownloadDTO = excelDownloadUtility(ipJson);
			screenExcelDownloadService.getPotentialsAMListExcel(request, response, screenExcelDownloadDTO);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
