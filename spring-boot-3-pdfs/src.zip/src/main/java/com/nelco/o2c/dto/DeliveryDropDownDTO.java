/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.DeliveryStatusMst;
import com.nelco.o2c.model.PodStatusMst;

/**
 * @author Amol.l
 *
 */
public class DeliveryDropDownDTO  implements Serializable {

	private static final long serialVersionUID = 77L;
	
	
	private List<DeliveryStatusMst> deliveryStatusList = new ArrayList<DeliveryStatusMst>();
	private List<PodStatusMst> PodStatusList = new ArrayList<PodStatusMst>();
	public List<DeliveryStatusMst> getDeliveryStatusList() {
		return deliveryStatusList;
	}
	public void setDeliveryStatusList(List<DeliveryStatusMst> deliveryStatusList) {
		this.deliveryStatusList = deliveryStatusList;
	}
	public List<PodStatusMst> getPodStatusList() {
		return PodStatusList;
	}
	public void setPodStatusList(List<PodStatusMst> podStatusList) {
		PodStatusList = podStatusList;
	}
	
}
