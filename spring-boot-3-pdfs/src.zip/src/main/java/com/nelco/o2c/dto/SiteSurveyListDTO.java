package com.nelco.o2c.dto;

public class SiteSurveyListDTO {
	public String site_survey_id;
	public String site_survey_uniq_id;
	public String franchisee_id;
	public String franchisee_name;
	public String creation_date;
	public String engineer_name;
	public String engineer_mobile_no;
	public String engineer_email_id;
	public String engineer_id;
	public String status_mst_id;
	public String status_mst_code;
	public String status_name;
	public String tentative_date;
	private String customer_name;
	private String ship_to_party;
	private String sub_customer;
	private String street_1;
	private String street_2;
	private String street_3;
	private String street_4;
	private String street_5;
	private String city;
	private String state_code;
	private String state_val;
	private String pin;
	private String country_val;
	
	
	

	public String getCountry_val() {
		return country_val;
	}

	public void setCountry_val(String country_val) {
		this.country_val = country_val;
	}

	public String getSub_customer() {
		return sub_customer;
	}

	public void setSub_customer(String sub_customer) {
		this.sub_customer = sub_customer;
	}

	public String getStreet_1() {
		return street_1;
	}

	public void setStreet_1(String street_1) {
		this.street_1 = street_1;
	}

	public String getStreet_2() {
		return street_2;
	}

	public void setStreet_2(String street_2) {
		this.street_2 = street_2;
	}

	public String getStreet_3() {
		return street_3;
	}

	public void setStreet_3(String street_3) {
		this.street_3 = street_3;
	}

	public String getStreet_4() {
		return street_4;
	}

	public void setStreet_4(String street_4) {
		this.street_4 = street_4;
	}

	public String getStreet_5() {
		return street_5;
	}

	public void setStreet_5(String street_5) {
		this.street_5 = street_5;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState_val() {
		return state_val;
	}

	public void setState_val(String state_val) {
		this.state_val = state_val;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getShip_to_party() {
		return ship_to_party;
	}

	public void setShip_to_party(String ship_to_party) {
		this.ship_to_party = ship_to_party;
	}

	public String getTentative_date() {
		return tentative_date;
	}

	public void setTentative_date(String tentative_date) {
		this.tentative_date = tentative_date;
	}

	public String getEngineer_id() {
		return engineer_id;
	}

	public void setEngineer_id(String engineer_id) {
		this.engineer_id = engineer_id;
	}

	public String getStatus_mst_id() {
		return status_mst_id;
	}

	public void setStatus_mst_id(String status_mst_id) {
		this.status_mst_id = status_mst_id;
	}

	public String getStatus_mst_code() {
		return status_mst_code;
	}

	public void setStatus_mst_code(String status_mst_code) {
		this.status_mst_code = status_mst_code;
	}

	public String getStatus_name() {
		return status_name;
	}

	public void setStatus_name(String status_name) {
		this.status_name = status_name;
	}

	public String getSite_survey_id() {
		return site_survey_id;
	}

	public void setSite_survey_id(String site_survey_id) {
		this.site_survey_id = site_survey_id;
	}

	public String getSite_survey_uniq_id() {
		return site_survey_uniq_id;
	}

	public void setSite_survey_uniq_id(String site_survey_uniq_id) {
		this.site_survey_uniq_id = site_survey_uniq_id;
	}

	public String getFranchisee_id() {
		return franchisee_id;
	}

	public void setFranchisee_id(String franchisee_id) {
		this.franchisee_id = franchisee_id;
	}

	public String getFranchisee_name() {
		return franchisee_name;
	}

	public void setFranchisee_name(String franchisee_name) {
		this.franchisee_name = franchisee_name;
	}

	public String getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(String creation_date) {
		this.creation_date = creation_date;
	}

	public String getEngineer_name() {
		return engineer_name;
	}

	public void setEngineer_name(String engineer_name) {
		this.engineer_name = engineer_name;
	}

	public String getEngineer_mobile_no() {
		return engineer_mobile_no;
	}

	public void setEngineer_mobile_no(String engineer_mobile_no) {
		this.engineer_mobile_no = engineer_mobile_no;
	}

	public String getEngineer_email_id() {
		return engineer_email_id;
	}

	public void setEngineer_email_id(String engineer_email_id) {
		this.engineer_email_id = engineer_email_id;
	}

	public String getState_code() {
		return state_code;
	}

	public void setState_code(String state_code) {
		this.state_code = state_code;
	}

}
