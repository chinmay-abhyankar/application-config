/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.HubMst;

/**
 * @author Amol.l
 *
 */
public class HubMstDTO implements Serializable {
	private static final long serialVersionUID = 89L;
	private List<HubMst> hubList = new ArrayList<HubMst>();

	public List<HubMst> getHubList() {
		return hubList;
	}

	public void setHubList(List<HubMst> hubList) {
		this.hubList = hubList;
	}

}
