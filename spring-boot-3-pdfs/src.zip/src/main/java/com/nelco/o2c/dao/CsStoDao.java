/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.AllDeliveryListDTO;
import com.nelco.o2c.dto.CsStoDTO;
import com.nelco.o2c.model.CsStoPodUploadDetail;
import com.nelco.o2c.model.StoC;
import com.nelco.o2c.model.StoCsDelivery;
import com.nelco.o2c.model.StoCsDeliveryTracker;
import com.nelco.o2c.model.StoCsPodTracker;

/**
 * @author Jayashankar.r
 *
 */
public interface CsStoDao {

	List<StoC> getCsStoList(CsStoDTO ipCsStoDTO);

	StoC getStoCsById(CsStoDTO ipCsStoDTO);

	StoC saveCsSto(StoC stoCsToSave, Integer userMstId, String roleCode);

	Integer getCurrentDayCountStoCs();

	void saveStoCsMaterials(StoC stoCs, String roleCode);

	void submitByCs(CsStoDTO ipCsStoDTO);

	void submitByTrc(CsStoDTO ipCsStoDTO);

	List<StoCsDelivery> getDeliveryTrackCsSto(CsStoDTO ipCsStoDTO);

	StoCsDelivery saveDeliveryCsSto(StoCsDelivery delivery);

	StoCsDeliveryTracker saveDeliveryStatusTrackerCsSto(StoCsDeliveryTracker stoPmgtDeliveryStatusTracker);

	StoCsPodTracker savePodStatusTrackerCsSto(StoCsPodTracker stoPmgtPodStatusTracker);

	CsStoPodUploadDetail saveCsStoUpPodFile(CsStoPodUploadDetail pmgtStoPodUploadDetails);

	void updateCsStoPodStatusByDelId(Integer stoCsDeliveryId);

	CsStoPodUploadDetail getUpPodFileDetCsSto(Integer stoCsDeliveryId);

	List<StoCsDelivery> getStoCsDelListByDateAndDelStatusCode(AllDeliveryListDTO allDeliveryListDTO);

	StoC getCsStoByReqId(CsStoDTO ipCsStoDTO);

	List<StoCsDelivery> stoCsDelBydeliveryNum(CsStoDTO ipCsStoDTO);

	

}
