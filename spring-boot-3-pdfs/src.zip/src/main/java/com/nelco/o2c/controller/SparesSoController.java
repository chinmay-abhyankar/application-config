/**
 * 
 */
package com.nelco.o2c.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.nelco.o2c.dto.INCUploadDTO;
import com.nelco.o2c.dto.SparesDTO;
import com.nelco.o2c.dto.SparesSoDTO;
import com.nelco.o2c.dto.SparesSoUpDTO;
import com.nelco.o2c.service.SparesSoService;

/**
 * @author Jayshankar.r
 *
 */
@RestController
public class SparesSoController {
	
	@Autowired
	SparesSoService sparesSoService;
	
	@RequestMapping(value = "/getSparesSoList.do",method = RequestMethod.POST)
	public SparesDTO getSparesSoList(@RequestBody SparesDTO sparesInputDTO) {
		return sparesSoService.getSparesSoList(sparesInputDTO);
	}
	
	@RequestMapping(value = "/getSparesSoById.do",method = RequestMethod.POST)
	public SparesDTO getSparesSoById(@RequestBody SparesDTO sparesInputDTO) {
		return sparesSoService.getSparesSoById(sparesInputDTO);
	}
	
	@RequestMapping(value = "/saveSparesSoById.do",method = RequestMethod.POST)
	public SparesDTO saveSparesSoById(@RequestBody SparesDTO sparesInputDTO) {
		return sparesSoService.saveSparesSoById(sparesInputDTO);
	}
	
	@RequestMapping(value = "/deleteSparesSoMaterial.do",method = RequestMethod.POST)
	public SparesDTO deleteSparesSoMaterial(@RequestBody SparesDTO sparesInputDTO) {
		return sparesSoService.deleteSparesSoMaterial(sparesInputDTO);
	}
	
	@RequestMapping(value = "/updateSparesSoByPmgt.do", method = RequestMethod.POST)
	public SparesSoDTO updateSparesSoByPmgt(@RequestBody SparesSoDTO ipsparesSoDTO) {
		return sparesSoService.updateSparesSoByPmgt(ipsparesSoDTO);
	}
	
	@RequestMapping(value = "/chkDuplIncidentId.do",method = RequestMethod.POST)
	public SparesDTO chkDuplIncidentId(@RequestBody SparesDTO sparesInputDTO) {
		return sparesSoService.chkDuplIncidentId(sparesInputDTO);
	}
	
	@RequestMapping(value = "/getSparesSoByIncidentId.do",method = RequestMethod.POST)
	public SparesDTO getSparesSoByIncidentId(@RequestBody SparesDTO sparesInputDTO) {
		return sparesSoService.getSparesSoByIncidentId(sparesInputDTO);
	}

	//This is for bulk upload for Spares SO request for PMGT login
		@RequestMapping(value = "/uploadSparesSoReq.do", method = RequestMethod.POST)
		public SparesSoUpDTO uploadSparesSoReq(MultipartHttpServletRequest request,@RequestParam String userMstId,@RequestParam String roleCode) throws Exception {
			SparesSoUpDTO sparesSoUpDTO=new SparesSoUpDTO();		
			MultipartFile file = request.getFile("sparesSoReqFile");
			sparesSoUpDTO.setRoleCode(roleCode);
			sparesSoUpDTO.setUserMstId(Integer.parseInt(userMstId));
			if(sparesSoService.validateSparesSoReq(file, userMstId,sparesSoUpDTO)){
				sparesSoUpDTO = sparesSoService.uploadSparesSoReq(file, userMstId,roleCode);
				
			}else{
				sparesSoUpDTO.setUserMstId(Integer.parseInt(userMstId));
				return sparesSoUpDTO;
			}
			return sparesSoUpDTO;
			
		}
}
