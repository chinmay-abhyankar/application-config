/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.ChildContractDropDownDTO;
import com.nelco.o2c.dto.ContractDropDownDTO;
import com.nelco.o2c.dto.HubMstDTO;
import com.nelco.o2c.model.ConditionTypeMst;
import com.nelco.o2c.model.ContractDocTypeSapmst;
import com.nelco.o2c.model.DeliveryStatusMst;
import com.nelco.o2c.model.DistChannelMst;
import com.nelco.o2c.model.DivisionMst;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.InstallationTypeMst;
import com.nelco.o2c.model.PayTermsMst;
import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.PodStatusMst;
import com.nelco.o2c.model.PricingGroupMst;
import com.nelco.o2c.model.QuarterMst;
import com.nelco.o2c.model.SalesOfficeMst;
import com.nelco.o2c.model.SalesOrgMst;
import com.nelco.o2c.model.SegmentMst;
import com.nelco.o2c.model.TechnologyMaster;

/**
 * @author Amol.l
 *
 */
public interface CommonMasterDao {

	List<ContractDocTypeSapmst> getContractDocTypeList(ContractDropDownDTO contractDropDownDTO);

	public List<DivisionMst> getDivisionList(ContractDropDownDTO contractDropDownDTO);

	public List<DistChannelMst> getDistChannelList(ContractDropDownDTO contractDropDownDTO);

	public List<SalesOfficeMst> getSalesOfficeList(ContractDropDownDTO contractDropDownDTO);

	public List<SalesOrgMst> getSalesOrgList(ContractDropDownDTO contractDropDownDTO);

	public List<SegmentMst> getSegmentList(ChildContractDropDownDTO childContractDropDownDTO);

	public List<QuarterMst> getQuarterList(ChildContractDropDownDTO childContractDropDownDTO);

	public List<DeliveryStatusMst> getDeliveryStatusMstList();

	public List<PodStatusMst> getPodStatusMstList();

	public List<HubMst> getHubList(HubMstDTO hubMstDTO);

	public List<ConditionTypeMst> getConditionTypeList(ChildContractDropDownDTO childContractDropDownDTO);

	public List<PricingGroupMst> getPricingGroupList(ChildContractDropDownDTO childContractDropDownDTO);

	public List<PayTermsMst> getPayTermsList(ChildContractDropDownDTO childContractDropDownDTO);

	public int getCount(String table, String column, String value);

	public TechnologyMaster getTechnologyByDesc(String value);

	public HubMst getHubByDesc(String hubDesc);

	public InstallationTypeMst getInstallTypeMstByDesc(String installationTypeVal);

	public int getIncMaterialCount(String table, String column1, String value1, String column2, String value2);

	public int getCount(String table, String column1, String value1, String column2, String value2);

	public PlantSapmst getPlantByPlantCode(String plantCode);
}
