/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.StorageSapmst;
import com.nelco.o2c.model.UserMst;

/**
 * @author Jayashankar.r
 *
 */
public class PmgtStoDropDownDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private List<UserMst> storesList;
	private List<UserMst> financeList;
	private List<UserMst> pmgtCoordList;
	private List<UserMst> trcList;
	private List<UserMst> suppCoordList;
	private List<PlantSapmst> recPlantList;
	private List<StorageSapmst> storageList;
	private String index;
	
	public String getIndex() {
		return index;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	public List<StorageSapmst> getStorageList() {
		return storageList;
	}

	public void setStorageList(List<StorageSapmst> storageList) {
		this.storageList = storageList;
	}

	public List<PlantSapmst> getRecPlantList() {
		return recPlantList;
	}

	public void setRecPlantList(List<PlantSapmst> recPlantList) {
		this.recPlantList = recPlantList;
	}

	public List<UserMst> getSuppCoordList() {
		return suppCoordList;
	}

	public void setSuppCoordList(List<UserMst> suppCoordList) {
		this.suppCoordList = suppCoordList;
	}

	public List<UserMst> getTrcList() {
		return trcList;
	}

	public void setTrcList(List<UserMst> trcList) {
		this.trcList = trcList;
	}

	public List<UserMst> getStoresList() {
		return storesList;
	}

	public void setStoresList(List<UserMst> storesList) {
		this.storesList = storesList;
	}

	public List<UserMst> getFinanceList() {
		return financeList;
	}

	public void setFinanceList(List<UserMst> financeList) {
		this.financeList = financeList;
	}

	public List<UserMst> getPmgtCoordList() {
		return pmgtCoordList;
	}

	public void setPmgtCoordList(List<UserMst> pmgtCoordList) {
		this.pmgtCoordList = pmgtCoordList;
	}

}
