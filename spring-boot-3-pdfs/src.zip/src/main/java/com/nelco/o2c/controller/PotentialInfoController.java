package com.nelco.o2c.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.DrfDetailsDTO;
import com.nelco.o2c.dto.DrfInfoDTO;
import com.nelco.o2c.dto.FileUploadDTO;
import com.nelco.o2c.dto.PotentialInfoDTO;
import com.nelco.o2c.dto.PotentialInfoListDTO;
import com.nelco.o2c.dto.UpdateStatusDTO;
import com.nelco.o2c.dto.UploadTempFileDTO;
import com.nelco.o2c.model.DrfDetails;
import com.nelco.o2c.model.DrfUploadDetail;
import com.nelco.o2c.service.CommonPotentialsService;
import com.nelco.o2c.service.PotentialInfoService;
import com.nelco.o2c.utility.GenJasperReportUtility;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;

@RestController
public class PotentialInfoController {

	public static final String uploadingDir = "D:/NelcoDoc/";

	@Autowired
	DataSource ds;
	
	@Autowired
	PotentialInfoService potentialInfoService;
	
	@Autowired
	CommonPotentialsService commonPotentialsService;
	
	@RequestMapping(value = "/accountManagerPotentialInfo.do", method = RequestMethod.POST)
	public PotentialInfoListDTO accountManagerPotentialInfo(@RequestBody PotentialInfoDTO potentialInfoDTO) {
		return potentialInfoService.amPotentialInfoService(potentialInfoDTO);
	}
	
	@RequestMapping(value = "/preBidResponsibilityMatrix.do", method = RequestMethod.POST)
	public PotentialInfoListDTO preBidResponsibilityMatrix(@RequestBody CommonDTO commonDTO) {
		return potentialInfoService.preBidResponsibilityMatrix(commonDTO);
	}

	@RequestMapping(value = "/accountManagerDRFInfo.do", method = RequestMethod.POST)
	public DrfInfoDTO accountManagerDRFInfo(@RequestBody DrfInfoDTO drfInfoDTO) {
		return potentialInfoService.amDrfInfoService(drfInfoDTO);
	}

	@RequestMapping(value = "/saveDrfDetails.do", method = RequestMethod.POST)
	public DrfDetailsDTO saveDrfDetails(@RequestBody DrfDetailsDTO drfDetailsDTO) {

		return potentialInfoService.saveDrfDetailsServise(drfDetailsDTO);
	}

	@RequestMapping(value = "/getDrfDetailsByDrfId.do", method = RequestMethod.POST)
	public DrfDetails getDrfDetailsByDrfId(@RequestBody DrfDetails drfDetails) {
		return potentialInfoService.getDrfDetailsByDrfId(drfDetails);
	}

	@RequestMapping(value = "/getFileProcessUploadDetails.do", method = RequestMethod.POST)
	public FileUploadDTO getFileProcessUploadDetails(@RequestBody FileUploadDTO fileUploadDTO) {
		return potentialInfoService.getFileProcessUploadDetails(fileUploadDTO);
	}

	@RequestMapping(value = "/uploadfile.do", method = RequestMethod.POST)
	public UploadTempFileDTO uploadfile(MultipartHttpServletRequest request, /*@RequestBody MultipartFile uploadFile*/@RequestParam String fileTypeMstId,@RequestParam String isCutomerApproved) {
		Iterator<String> fileNames = request.getFileNames();
		UploadTempFileDTO uploadTempFileDTO = null;
		if(fileNames.hasNext()) {
			MultipartFile file = request.getFile(fileNames.next());
			uploadTempFileDTO = potentialInfoService.saveTempFileDetails(file, fileTypeMstId,isCutomerApproved);
		}
		
		return uploadTempFileDTO;

	}
	
	@RequestMapping(value = "/getUploadFileDetails.do", method = RequestMethod.POST)
	public DrfUploadDetail getUploadFileDetails(@RequestBody DrfUploadDetail drfUploadDetail) {
		
		return potentialInfoService.getDrfUploadDetailsBydrfUpDetailsId(drfUploadDetail.getDrfUpDetailsId());

	}
	

	@RequestMapping(value = "/downloadDocuments.do", method = {RequestMethod.POST,RequestMethod.GET})
	@CrossOrigin
	public void downloadDocuments(HttpServletResponse response, @RequestParam String drfUpDetailsId) {

		DrfUploadDetail drfUploadDetail = new DrfUploadDetail();
		drfUploadDetail = potentialInfoService.getDrfUploadDetailsBydrfUpDetailsId(Integer.parseInt(drfUpDetailsId));

		potentialInfoService.downloadDocuments(response, drfUploadDetail);
	}
	
	@RequestMapping(value = "/submitDrfDetailsStatus.do", method = RequestMethod.POST)
	public UpdateStatusDTO updateDrfDetailsStatus(@RequestBody UpdateStatusDTO updateStatusDTO,HttpServletRequest request) {
		return potentialInfoService.updateDrfDetailsStatus(updateStatusDTO,request);
	}
	
/*	@RequestMapping(value = "/sendMailByDemoEndDate.do", method = RequestMethod.POST)
	public CommonDTO sendMailByDemoEndDate(@RequestBody CommonDTO commonDTO,HttpServletRequest request) {
		return potentialInfoService.sendMailByDemoEndDate(commonDTO,request);
	}*/
	
	@RequestMapping(value = "/saveDrfUploadDetails.do", method = RequestMethod.POST)
	public DrfDetailsDTO saveDrfUploadDetails(@RequestBody DrfDetailsDTO drfDetailsDTO) throws Exception {
		return potentialInfoService.saveDrfUploadDetails(drfDetailsDTO);
	}

	/*public ReportsDTO utility(@RequestParam("oppo_id") String ipJson) throws SQLException, JsonParseException, JsonMappingException, IOException {
		
		 ObjectMapper mapper = new ObjectMapper();
		 ReportsDTO reportsDTO = mapper.readValue(ipJson, ReportsDTO.class);
	     return reportsDTO;
	}*/
	
	@RequestMapping(value = "/dwnRepByDrfDetId.do", method = RequestMethod.GET)
	public String generateDRFReport(HttpServletRequest request, HttpServletResponse response,@RequestParam String drfId) //@RequestParam String oppId
	    throws ParseException, SQLException, JRException, NamingException, IOException {

	String reportFileName = "DRF_Report";
	
	Connection conn = ds.getConnection();
	 
	// Parameters as Map to be passed to Jasper reports
	Map<String, Object> parameter = new HashMap<String, Object>();	
	parameter.put("drf_id", drfId);
	
	JasperReport jasperReport = GenJasperReportUtility.getCompiledFile(reportFileName, request);
	GenJasperReportUtility.generateReportPDF(response, parameter, jasperReport, conn); 
		
	conn.close();
	return null;

	}
}
