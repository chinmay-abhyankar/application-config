package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;


/**
 * The persistent class for the contract database table.
 * 
 */
@Entity
@Table(name="contract")
@NamedQueries({
	@NamedQuery(name="Contract.findAll", query="SELECT c FROM Contract c"),
	@NamedQuery(name = "Contract.getContractByProposalId", query = "SELECT c from Contract c where c.proposalId =?1 "),
	@NamedQuery(name = "Contract.getContractByContractId", query = "SELECT c from Contract c where c.contractId =?1 "),
	@NamedQuery(name="Contract.findByDateFilterAll", query=" SELECT c FROM Contract c inner join c.proposal p where c.isSubmit = 'Y' and c.createdDate between ?1 and ?2 "),
	@NamedQuery(name="Contract.findByDateFilterAndProposalIdAll", query=" SELECT c FROM Contract"
			+ " c inner join c.proposal p where c.isSubmit = 'Y' and c.createdDate between ?1 and ?2 and p.proposalId = ?3")
})
public class Contract implements Serializable {
	private static final long serialVersionUID = 71L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="contract_id")
	private Integer contractId;

	private String billable;

	@Column(name="cont_sales_doc_type")
	private String contSalesDocType;

	@Column(name="created_date", updatable = false)
	private String createdDate;

	@Column(name="dist_channel")
	private String distChannel;

	private String division;

	private String migration;

	@Column(name="po_number")
	private String poNumber;

	@Column(name="sales_office")
	private String salesOffice;

	@Column(name="sales_org")
	private String salesOrg;

	@Column(name="sold_to_party")
	private String soldToParty;

	@Column(name="total_value")
	private String totalValue;

	@Column(name="validity_date")
	private String validityDate;
	
	@Column(name="proposal_id")
	private String proposalId;
	
	@Column(name = "is_submit")
	private String isSubmit="N";
	
	@Column(name = "clause_contract_mst_id")
	private Integer clauseContractMstId;
	
	@Column(name = "notice_period")
	private Integer noticePeriod;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "proposal_id", referencedColumnName = "proposal_id", insertable = false, updatable = false)
	private Proposal proposal;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "contract_id", referencedColumnName = "contract_id", insertable = false, updatable = false)
	@OrderBy("item_no")
	private List<MaterialContract> materialContractList;
	
	@ManyToOne
	@JoinColumns({@JoinColumn(name = "sold_to_party", referencedColumnName = "customer_num", insertable = false, updatable = false),
			@JoinColumn(name = "dist_channel", referencedColumnName = "dist_channel", insertable = false, updatable = false),
			@JoinColumn(name = "division", referencedColumnName = "division", insertable = false, updatable = false),
			@JoinColumn(name = "sales_org", referencedColumnName = "sales_org", insertable = false, updatable = false)})
	private CustomerSapmst customerSapmst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "clause_contract_mst_id", referencedColumnName = "id", insertable = false, updatable = false)
	private ClauseContractMst clauseContractMst;
	
	@Column(name = "service_order_det_id")
	private Integer serviceOrderDetId;
	
	@Column(name = "created_by_id")
	private Integer createdbyId;
		
	public Integer getCreatedbyId() {
		return createdbyId;
	}

	public void setCreatedbyId(Integer createdbyId) {
		this.createdbyId = createdbyId;
	}

	public Integer getServiceOrderDetId() {
		return serviceOrderDetId;
	}

	public void setServiceOrderDetId(Integer serviceOrderDetId) {
		this.serviceOrderDetId = serviceOrderDetId;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "service_order_det_id", referencedColumnName = "service_order_det_id", insertable = false, updatable = false)
	private ServiceOrderMst serviceOrderMst;
	
	public ServiceOrderMst getServiceOrderMst() {
		return serviceOrderMst;
	}

	public void setServiceOrderMst(ServiceOrderMst serviceOrderMst) {
		this.serviceOrderMst = serviceOrderMst;
	}

	public Contract() {
	}
	
	public CustomerSapmst getCustomerSapmst() {
		return customerSapmst;
	}

	public void setCustomerSapmst(CustomerSapmst customerSapmst) {
		this.customerSapmst = customerSapmst;
	}

	public Proposal getProposal() {
		return proposal;
	}

	public void setProposal(Proposal proposal) {
		this.proposal = proposal;
	}

	public String getIsSubmit() {
		return isSubmit;
	}

	public void setIsSubmit(String isSubmit) {
		this.isSubmit = isSubmit;
	}


	public Integer getContractId() {
		return contractId;
	}

	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}

	public String getBillable() {
		return this.billable;
	}

	public void setBillable(String billable) {
		this.billable = billable;
	}

	public String getContSalesDocType() {
		return this.contSalesDocType;
	}

	public void setContSalesDocType(String contSalesDocType) {
		this.contSalesDocType = contSalesDocType;
	}

	public String getCreatedDate() {
		 return DateUtil.getSimpleUIDateFromSqlDate(this.createdDate);
		//return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getDistChannel() {
		return this.distChannel;
	}

	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}

	public String getDivision() {
		return this.division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getMigration() {
		return this.migration;
	}

	public void setMigration(String migration) {
		this.migration = migration;
	}

	public String getPoNumber() {
		return this.poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getSalesOffice() {
		return this.salesOffice;
	}

	public void setSalesOffice(String salesOffice) {
		this.salesOffice = salesOffice;
	}

	public String getSalesOrg() {
		return this.salesOrg;
	}

	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

	public String getSoldToParty() {
		return this.soldToParty;
	}

	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}

	public String getTotalValue() {
		return this.totalValue;
	}

	public void setTotalValue(String totalValue) {
		this.totalValue = totalValue;
	}
	public String getValidityDate() {
		return DateUtil.convertDateTimeToString(this.validityDate);
	}
	public void setValidityDate(String validityDate) {
		this.validityDate = validityDate;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public List<MaterialContract> getMaterialContractList() {
		return materialContractList;
	}
	public void setMaterialContractList(List<MaterialContract> materialContractList) {
		this.materialContractList = materialContractList;
	}
	
	public ClauseContractMst getClauseContractMst() {
		return clauseContractMst;
	}

	public void setClauseContractMst(ClauseContractMst clauseContractMst) {
		this.clauseContractMst = clauseContractMst;
	}

	public Integer getClauseContractMstId() {
		return clauseContractMstId;
	}

	public void setClauseContractMstId(Integer clauseContractMstId) {
		this.clauseContractMstId = clauseContractMstId;
	}

	public Integer getNoticePeriod() {
		return noticePeriod;
	}

	public void setNoticePeriod(Integer noticePeriod) {
		this.noticePeriod = noticePeriod;
	}
	
}