package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the drf_approver_details database table.
 * 
 */
@Entity
@Table(name="drf_approver_details")
@NamedQueries({@NamedQuery(name="DrfApproverDetail.findAll", query="SELECT d FROM DrfApproverDetail d where d.isActive = 'Y'"),
	@NamedQuery(name="DrfApproverDetail.findByDrfApprId", query="SELECT d FROM DrfApproverDetail d where d.drfDetailsId=?1 and d.apprById=?2 and d.isActive = 'Y' order by d.drfApproverDetailsId desc "),
	@NamedQuery(name="DrfApproverDetail.findByDrfId", query="SELECT d FROM DrfApproverDetail d where d.drfDetailsId=?1 and d.isActive = 'Y' "),
	@NamedQuery(name="DrfApproverDetail.getApprDetailsbyDrfIds", query="SELECT d FROM DrfApproverDetail d where d.drfDetailsId in ?1 and d.isActive = 'Y' ")})
public class DrfApproverDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="drf_approver_details_id")
	private Integer drfApproverDetailsId;

	@Column(name="drf_details_id")
	private Integer drfDetailsId;

	@Column(name="act_time")
	private String actTime;

	@Column(name="appr_by_id")
	private Integer apprById;

	@Column(name="appr_flg")
	private String apprFlg;

	@Column(name="appr_reason")
	private String apprReason;
	
	@Column(name = "is_active")
	private String isActive = "Y";

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public Integer getDrfApproverDetailsId() {
		return drfApproverDetailsId;
	}

	public void setDrfApproverDetailsId(Integer drfApproverDetailsId) {
		this.drfApproverDetailsId = drfApproverDetailsId;
	}

	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}

	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}

	public String getActTime() {
		return actTime;
	}

	public void setActTime(String actTime) {
		this.actTime = actTime;
	}

	public Integer getApprById() {
		return apprById;
	}

	public void setApprById(Integer apprById) {
		this.apprById = apprById;
	}

	public String getApprFlg() {
		return apprFlg;
	}

	public void setApprFlg(String apprFlg) {
		this.apprFlg = apprFlg;
	}

	public String getApprReason() {
		return apprReason;
	}

	public void setApprReason(String apprReason) {
		this.apprReason = apprReason;
	}
	
}