/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.BwSizingDTO;
import com.nelco.o2c.model.BWSizingDetails;
import com.nelco.o2c.model.CityMst;
import com.nelco.o2c.model.CountryMst;
import com.nelco.o2c.model.CustomerMst;
import com.nelco.o2c.model.ErrorJobLog;
import com.nelco.o2c.model.LocationMst;
import com.nelco.o2c.model.StateMst;

/**
 * @author Jayashankar.r
 *
 */
public interface BwSizingDao {
	public List<CustomerMst> getCustomerDetails(String custSearchStr);

	public BWSizingDetails getBwSizingbyDrf(Integer drfDetailsId);

	public List<LocationMst> getLocations();

	public List<CityMst> getCitys();

	public List<StateMst> getStates();

	public List<CountryMst> getCountrys();

	public BWSizingDetails saveBwSizingDetails(BWSizingDetails bWSizingDetails);

	public BWSizingDetails getBwSizingById(Integer bwSizingDetailsId);

	public void saveCustMaster(CustomerMst custMst);

	public List<ErrorJobLog> getErrorLogs(BwSizingDTO input);
}
