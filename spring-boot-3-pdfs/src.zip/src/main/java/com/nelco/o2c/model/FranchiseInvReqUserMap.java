package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the franchise_inv_req_user_map database table.
 * 
 */
@Entity
@Table(name="franchise_inv_req_user_map")
@NamedQueries({
	@NamedQuery(name="FranchiseInvReqUserMap.findAll", query="SELECT f FROM FranchiseInvReqUserMap f"),
	@NamedQuery(name="FranchiseInvReqUserMap.getUserInvIdCount", query="SELECT count(f) FROM FranchiseInvReqUserMap f "
			+ " where f.userMstId=:userMstId and f.franchiseInvReqId=:franchiseInvReqId and f.roleMstId=:roleMstId ")
})

public class FranchiseInvReqUserMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="franchise_inv_req_user_map_id")
	private Integer franchiseInvReqUserMapId;

	@Column(name="franchise_inv_req_id")
	private Integer franchiseInvReqId;

	@Column(name="role_mst_id")
	private Integer roleMstId;

	@Column(name="user_mst_id")
	private Integer userMstId;

	public FranchiseInvReqUserMap() {
	}

	public Integer getFranchiseInvReqUserMapId() {
		return this.franchiseInvReqUserMapId;
	}

	public void setFranchiseInvReqUserMapId(Integer franchiseInvReqUserMapId) {
		this.franchiseInvReqUserMapId = franchiseInvReqUserMapId;
	}

	public Integer getFranchiseInvReqId() {
		return this.franchiseInvReqId;
	}

	public void setFranchiseInvReqId(Integer franchiseInvReqId) {
		this.franchiseInvReqId = franchiseInvReqId;
	}

	public Integer getRoleMstId() {
		return this.roleMstId;
	}

	public void setRoleMstId(Integer roleMstId) {
		this.roleMstId = roleMstId;
	}

	public Integer getUserMstId() {
		return this.userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

}