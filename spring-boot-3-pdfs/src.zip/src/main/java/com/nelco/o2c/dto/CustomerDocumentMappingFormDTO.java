package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.CustomerMandatoryDocMapping;
import com.nelco.o2c.model.FileTypeMst;

public class CustomerDocumentMappingFormDTO {
private List<CustomerDocumentMappingListDTO> customerDocumentMappingList=new ArrayList<CustomerDocumentMappingListDTO>();
private List<CustomerMandatoryDocMapping> customerDocumentMapping=new ArrayList<CustomerMandatoryDocMapping>();
private List<FileTypeMst> documentTypes=new ArrayList<FileTypeMst>();

public List<FileTypeMst> getDocumentTypes() {
	return documentTypes;
}

public void setDocumentTypes(List<FileTypeMst> documentTypes) {
	this.documentTypes = documentTypes;
}

public List<CustomerMandatoryDocMapping> getCustomerDocumentMapping() {
	return customerDocumentMapping;
}

public void setCustomerDocumentMapping(List<CustomerMandatoryDocMapping> customerDocumentMapping) {
	this.customerDocumentMapping = customerDocumentMapping;
}

public List<CustomerDocumentMappingListDTO> getCustomerDocumentMappingList() {
	return customerDocumentMappingList;
}

public void setCustomerDocumentMappingList(List<CustomerDocumentMappingListDTO> customerDocumentMappingList) {
	this.customerDocumentMappingList = customerDocumentMappingList;
}



}
