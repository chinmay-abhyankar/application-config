/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

/**
 * @author Amol.l
 *
 */
public class UploadTempFileDTO implements Serializable {
	
	private static final long serialVersionUID = 13L;
	
	
	private Integer fileTypeMstId;
	private String upFileName;
	private String uploadUrl;
	private String isCutomerApproved;
	
	public String getIsCutomerApproved() {
		return isCutomerApproved;
	}
	public void setIsCutomerApproved(String isCutomerApproved) {
		this.isCutomerApproved = isCutomerApproved;
	}
	public Integer getFileTypeMstId() {
		return fileTypeMstId;
	}
	public void setFileTypeMstId(Integer fileTypeMstId) {
		this.fileTypeMstId = fileTypeMstId;
	}
	public String getUpFileName() {
		return upFileName;
	}
	public void setUpFileName(String upFileName) {
		this.upFileName = upFileName;
	}
	public String getUploadUrl() {
		return uploadUrl;
	}
	public void setUploadUrl(String uploadUrl) {
		this.uploadUrl = uploadUrl;
	}

}
