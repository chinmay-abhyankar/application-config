/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.ChildContract;

/**
 * @author Amol.l
 *
 */
public class ChildContractListDTO implements Serializable {

	private static final long serialVersionUID = 11L;
	
	
	private Integer contractId;
	private String fromDate;
	private String toDate;
	private List<ChildContract> childContractDTOList = new ArrayList<ChildContract>();
	private Integer userMstId;
	private String roleCode;
	private String finRemarks;
	private Integer childContractId;
	private Boolean isSaved = false;
	private Integer brfId;

	public Boolean getIsSaved() {
		return isSaved;
	}
	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}
	public String getFinRemarks() {
		return finRemarks;
	}
	public void setFinRemarks(String finRemarks) {
		this.finRemarks = finRemarks;
	}
	public Integer getChildContractId() {
		return childContractId;
	}
	public void setChildContractId(Integer childContractId) {
		this.childContractId = childContractId;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public Integer getContractId() {
		return contractId;
	}
	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public List<ChildContract> getChildContractDTOList() {
		return childContractDTOList;
	}
	public void setChildContractDTOList(List<ChildContract> childContractDTOList) {
		this.childContractDTOList = childContractDTOList;
	}
	public Integer getBrfId() {
		return brfId;
	}
	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}
	
}
