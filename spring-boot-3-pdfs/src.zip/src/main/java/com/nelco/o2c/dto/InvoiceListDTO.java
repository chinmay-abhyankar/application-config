package com.nelco.o2c.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import org.springframework.stereotype.Component;
@Component
public class InvoiceListDTO implements Serializable{
private String m_strInvoiceNo="";
private String m_strInvoiceDate="";
private BigDecimal m_strOutstandingAmt;
private String m_strInvoiceDueDate="";
public String getM_strInvoiceNo() {
	return m_strInvoiceNo;
}
public void setM_strInvoiceNo(String m_strInvoiceNo) {
	this.m_strInvoiceNo = m_strInvoiceNo;
}
public String getM_strInvoiceDate() {
	return m_strInvoiceDate;
}
public void setM_strInvoiceDate(String m_strInvoiceDate) {
	this.m_strInvoiceDate = m_strInvoiceDate;
}
public BigDecimal getM_strOutstandingAmt() {
	return m_strOutstandingAmt;
}
public void setM_strOutstandingAmt(BigDecimal m_strOutstandingAmt) {
	this.m_strOutstandingAmt = m_strOutstandingAmt;
}
public String getM_strInvoiceDueDate() {
	return m_strInvoiceDueDate;
}
public void setM_strInvoiceDueDate(String m_strInvoiceDueDate) {
	this.m_strInvoiceDueDate = m_strInvoiceDueDate;
}

}
