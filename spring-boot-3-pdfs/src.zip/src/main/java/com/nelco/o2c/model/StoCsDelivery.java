package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;

/**
 * The persistent class for the sto_cs_delivery database table.
 * 
 */
@Entity
@Table(name = "sto_cs_delivery")
@NamedQueries({ @NamedQuery(name = "StoCsDelivery.findAll", query = "SELECT s FROM StoCsDelivery s"),
	@NamedQuery(name = "StoCsDelivery.stoCsDelBydeliveryNum", query = "SELECT s FROM StoCsDelivery s where s.deliveryNum =?1 "),
		@NamedQuery(name = "StoCsDelivery.getStoCsDeliveryList", query = "SELECT s FROM StoCsDelivery s where s.sapDelDate between ?1 and ?2"),
		@NamedQuery(name = "StoCsDelivery.getStoCsDelListByDateAndDelStatusCode", query = " SELECT "
				+ " new StoCsDelivery(s.stoCsDeliveryId, "
				+ " s.addate, s.boxes, s.courierName, s.sapDelDate, " + 
				" s.deliveryNum, s.deliveryStatusMstId, s.dispatchDate, "
				+ " s.docketNum, s.eddate, " + 
				" s.grnNo, s.inboundInvoice, deldet.materialDesc, "
				+ " deldet.materialNum, s.podStatusMstId, " + 
				" s.prNo, deldet.quantity, deldet.recPlantCode, deldet.recPlantName, s.stoCsGenId," + 
				" s.taxInvoice, s.poNo, s.deliveryStatusMst, s.podStatusMst) "
				+ " FROM StoCsDelivery s inner join s.deliveryStatusMst dsm "
				+ " inner join s.stoCsDeliveryDetail deldet "
				+ " where s.sapDelDate between ?1 and ?2 and dsm.delStatusCode in :status"),
		@NamedQuery(name = "StoCsDelivery.getStoCsDeliveryListSE", query = "SELECT s FROM StoCsDelivery s inner join s.stoCs sc where  s.sapDelDate between ?1 and ?2 and sc.reqById = ?3 and sc.supplyPlantId = isnull(?4,sc.supplyPlantId)"),
		@NamedQuery(name = "StoCsDelivery.getStoCsDeliveryListStores", query = "SELECT s FROM StoCsDelivery s inner join s.stoCs sc where s.sapDelDate between ?1 and ?2 and sc.storeUserId = ?3 and sc.supplyPlantId = isnull(?4,sc.supplyPlantId)"),
		@NamedQuery(name = "StoCsDelivery.getStoCsDeliveryListSuppCoord", query = "SELECT s FROM StoCsDelivery s inner join s.stoCs sc where s.sapDelDate between ?1 and ?2 and sc.csCoordId = ?3 and sc.supplyPlantId = isnull(?4,sc.supplyPlantId)"),
		@NamedQuery(name = "StoCsDelivery.updateCsStoPodStatusByDelId", query = "update StoCsDelivery s set s.podStatusMstId=?1 where s.stoCsDeliveryId=?2") })
public class StoCsDelivery implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sto_cs_delivery_id")
	private Integer stoCsDeliveryId;

	private String addate;

	private String boxes;

	@Column(name = "courier_name")
	private String courierName;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "delivery_num")
	private String deliveryNum;

	@Column(name = "delivery_status_mst_id")
	private Integer deliveryStatusMstId;

	@Column(name = "dispatch_date")
	private String dispatchDate;

	@Column(name = "docket_num")
	private String docketNum;

	private String eddate;

	@Column(name = "grn_no")
	private String grnNo;

	@Column(name = "inbound_invoice")
	private String inboundInvoice;

	@Column(name = "material_desc")
	private String materialDesc;

	@Column(name = "material_num")
	private String materialNum;

	@Column(name = "pod_status_mst_id")
	private Integer podStatusMstId;

	@Column(name = "pr_no")
	private String prNo;

	private String quantity;

	@Column(name = "rec_plant_code")
	private String recPlantCode;

	@Column(name = "rec_plant_name")
	private String recPlantName;

	@Column(name = "sto_cs_gen_id")
	private String stoCsGenId;

	@Column(name = "tax_invoice")
	private String taxInvoice;

	@Column(name = "po_no")
	private String poNo;
	
	@Column(name = "sap_del_date",updatable = false)
	private String sapDelDate;

	public StoCsDelivery() {
	}

	
	
	public StoCsDelivery(Integer stoCsDeliveryId, String addate, String boxes, String courierName, String sapDelDate,
			String deliveryNum, Integer deliveryStatusMstId, String dispatchDate, String docketNum, String eddate,
			String grnNo, String inboundInvoice, String materialDesc, String materialNum, Integer podStatusMstId,
			String prNo, String quantity, String recPlantCode, String recPlantName, String stoCsGenId,
			String taxInvoice, String poNo, DeliveryStatusMst deliveryStatusMst, PodStatusMst podStatusMst) {
		super();
		this.stoCsDeliveryId = stoCsDeliveryId;
		this.addate = addate;
		this.boxes = boxes;
		this.courierName = courierName;
		this.sapDelDate = sapDelDate;
		this.deliveryNum = deliveryNum;
		this.deliveryStatusMstId = deliveryStatusMstId;
		this.dispatchDate = dispatchDate;
		this.docketNum = docketNum;
		this.eddate = eddate;
		this.grnNo = grnNo;
		this.inboundInvoice = inboundInvoice;
		this.materialDesc = materialDesc;
		this.materialNum = materialNum;
		this.podStatusMstId = podStatusMstId;
		this.prNo = prNo;
		this.quantity = quantity;
		this.recPlantCode = recPlantCode;
		this.recPlantName = recPlantName;
		this.stoCsGenId = stoCsGenId;
		this.taxInvoice = taxInvoice;
		this.poNo = poNo;
		this.deliveryStatusMst = deliveryStatusMst;
		this.podStatusMst = podStatusMst;
	}



	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "sto_cs_gen_id", referencedColumnName = "sto_cs_gen_id", insertable = false, updatable = false)
	private StoC stoCs;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "delivery_status_mst_id", referencedColumnName = "delivery_status_mst_id", insertable = false, updatable = false)
	private DeliveryStatusMst deliveryStatusMst;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "pod_status_mst_id", referencedColumnName = "pod_status_mst_id", insertable = false, updatable = false)
	private PodStatusMst podStatusMst;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "sto_cs_delivery_id", referencedColumnName = "sto_cs_delivery_id", insertable = false, updatable = false)
	private List<StoCsDeliveryDetail> stoCsDeliveryDetail;
	
	

	public List<StoCsDeliveryDetail> getStoCsDeliveryDetail() {
		return stoCsDeliveryDetail;
	}

	public void setStoCsDeliveryDetail(List<StoCsDeliveryDetail> stoCsDeliveryDetail) {
		this.stoCsDeliveryDetail = stoCsDeliveryDetail;
	}

	public String getPoNo() {
		return poNo;
	}

	public void setPoNo(String poNo) {
		this.poNo = poNo;
	}

	public StoC getStoCs() {
		return stoCs;
	}

	public void setStoCs(StoC stoCs) {
		this.stoCs = stoCs;
	}

	public DeliveryStatusMst getDeliveryStatusMst() {
		return deliveryStatusMst;
	}

	public void setDeliveryStatusMst(DeliveryStatusMst deliveryStatusMst) {
		this.deliveryStatusMst = deliveryStatusMst;
	}

	public PodStatusMst getPodStatusMst() {
		return podStatusMst;
	}

	public void setPodStatusMst(PodStatusMst podStatusMst) {
		this.podStatusMst = podStatusMst;
	}

	public Integer getStoCsDeliveryId() {
		return stoCsDeliveryId;
	}

	public void setStoCsDeliveryId(Integer stoCsDeliveryId) {
		this.stoCsDeliveryId = stoCsDeliveryId;
	}

	public String getAddate() {
		return DateUtil.convertDateTimeToString(this.addate);
		// return addate;
	}

	public void setAddate(String addate) {
		this.addate = addate;
	}

	public String getBoxes() {
		return boxes;
	}

	public void setBoxes(String boxes) {
		this.boxes = boxes;
	}

	public String getCourierName() {
		return courierName;
	}

	public void setCourierName(String courierName) {
		this.courierName = courierName;
	}

	public String getCreatedDate() {
		return DateUtil.convertDateTimeToString(this.createdDate);
		// return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getDeliveryNum() {
		return deliveryNum;
	}

	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}

	public Integer getDeliveryStatusMstId() {
		return deliveryStatusMstId;
	}

	public void setDeliveryStatusMstId(Integer deliveryStatusMstId) {
		this.deliveryStatusMstId = deliveryStatusMstId;
	}

	public String getDispatchDate() {
		return DateUtil.convertDateTimeToString(this.dispatchDate);
		// return dispatchDate;
	}

	public void setDispatchDate(String dispatchDate) {
		this.dispatchDate = dispatchDate;
	}

	public String getDocketNum() {
		return docketNum;
	}

	public void setDocketNum(String docketNum) {
		this.docketNum = docketNum;
	}

	public String getEddate() {
		return DateUtil.convertDateTimeToString(this.eddate);
		// return eddate;
	}

	public void setEddate(String eddate) {
		this.eddate = eddate;
	}

	public String getGrnNo() {
		return grnNo;
	}

	public void setGrnNo(String grnNo) {
		this.grnNo = grnNo;
	}

	public String getInboundInvoice() {
		return inboundInvoice;
	}

	public void setInboundInvoice(String inboundInvoice) {
		this.inboundInvoice = inboundInvoice;
	}

	public String getMaterialDesc() {
		return materialDesc;
	}

	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}

	public String getMaterialNum() {
		return materialNum;
	}

	public void setMaterialNum(String materialNum) {
		this.materialNum = materialNum;
	}

	public Integer getPodStatusMstId() {
		return podStatusMstId;
	}

	public void setPodStatusMstId(Integer podStatusMstId) {
		this.podStatusMstId = podStatusMstId;
	}

	public String getPrNo() {
		return prNo;
	}

	public void setPrNo(String prNo) {
		this.prNo = prNo;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getRecPlantCode() {
		return recPlantCode;
	}

	public void setRecPlantCode(String recPlantCode) {
		this.recPlantCode = recPlantCode;
	}

	public String getRecPlantName() {
		return recPlantName;
	}

	public void setRecPlantName(String recPlantName) {
		this.recPlantName = recPlantName;
	}

	public String getStoCsGenId() {
		return stoCsGenId;
	}

	public void setStoCsGenId(String stoCsGenId) {
		this.stoCsGenId = stoCsGenId;
	}

	public String getTaxInvoice() {
		return taxInvoice;
	}

	public void setTaxInvoice(String taxInvoice) {
		this.taxInvoice = taxInvoice;
	}

	public String getSapDelDate() {
//		return sapDelDate;
		return DateUtil.convertDateTimeToString(this.sapDelDate);
	}

	public void setSapDelDate(String sapDelDate) {
		this.sapDelDate = sapDelDate;
	}

}