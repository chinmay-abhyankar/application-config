/**
 * 
 */
package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nelco.o2c.model.StatusMst;
import com.nelco.o2c.model.Taf;
import com.nelco.o2c.model.TafMst;
import com.nelco.o2c.model.TendBidDet;

/**
 * @author Jayashankar.r
 *
 */
@Component
public class TafDetailsDTO {
	private List<TafMst> tafList = new ArrayList<TafMst>();
	private Taf tafHeader = new Taf();
	private StatusMst tafStatus;
	private TendBidDet tenderBidDet;

	public TendBidDet getTenderBidDet() {
		return tenderBidDet;
	}

	public void setTenderBidDet(TendBidDet tenderBidDet) {
		this.tenderBidDet = tenderBidDet;
	}

	public StatusMst getTafStatus() {
		return tafStatus;
	}

	public void setTafStatus(StatusMst tafStatus) {
		this.tafStatus = tafStatus;
	}

	public List<TafMst> getTafList() {
		return tafList;
	}

	public void setTafList(List<TafMst> tafList) {
		this.tafList = tafList;
	}

	public Taf getTafHeader() {
		return tafHeader;
	}

	public void setTafHeader(Taf tafHeader) {
		this.tafHeader = tafHeader;
	}
}
