package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "antenna_size_mst")

@NamedQueries({
	@NamedQuery(name = "AntennaSizeMaster.findAll", query = "select e from AntennaSizeMaster e"),
@NamedQuery(name="AntennaSizeMaster.findByName", query="SELECT h FROM AntennaSizeMaster h where h.value=?1")
})

public class AntennaSizeMaster implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	private Integer id;

	@Column(name = "value")
	private String value;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
