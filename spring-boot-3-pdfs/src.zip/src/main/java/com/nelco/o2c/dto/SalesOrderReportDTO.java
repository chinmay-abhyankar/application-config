package com.nelco.o2c.dto;

public class SalesOrderReportDTO {
	private String soNumber = "";
	private String contSalesDocTypeId = "";
	private String contSalesDocType = "";
	private String soDate = "";
	private String customerNo = "";
	private String customerName = "";
	private String iCConfirmationDate = "";
	private String warranty = "";
	private String clauseId = "";
	private String clause = "";
	private String dueDate = "";

	public String getClauseId() {
		return clauseId;
	}

	public void setClauseId(String clauseId) {
		this.clauseId = clauseId;
	}

	public String getSoNumber() {
		return soNumber;
	}

	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}

	public String getContSalesDocTypeId() {
		return contSalesDocTypeId;
	}

	public void setContSalesDocTypeId(String contSalesDocTypeId) {
		this.contSalesDocTypeId = contSalesDocTypeId;
	}

	public String getContSalesDocType() {
		return contSalesDocType;
	}

	public void setContSalesDocType(String contSalesDocType) {
		this.contSalesDocType = contSalesDocType;
	}

	public String getSoDate() {
		return soDate;
	}

	public void setSoDate(String soDate) {
		this.soDate = soDate;
	}

	public String getCustomerNo() {
		return customerNo;
	}

	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getiCConfirmationDate() {
		return iCConfirmationDate;
	}

	public void setiCConfirmationDate(String iCConfirmationDate) {
		this.iCConfirmationDate = iCConfirmationDate;
	}

	public String getWarranty() {
		return warranty;
	}

	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}

	public String getClause() {
		return clause;
	}

	public void setClause(String clause) {
		this.clause = clause;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

}
