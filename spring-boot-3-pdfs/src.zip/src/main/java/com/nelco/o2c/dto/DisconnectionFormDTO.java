package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.model.DisconnectionAlltypesMst;
import com.nelco.o2c.model.DisconnectionNoticeRequestMst;
import com.nelco.o2c.model.DisconnectionRequestAction;
import com.nelco.o2c.model.DisconnectionRequestMst;
import com.nelco.o2c.model.OppUploadDetail;
@Component
public class DisconnectionFormDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3523881036098901857L;
	private List<DisconnectionAlltypesMst> disconnectionStatus;
	private List<DisconnectionAlltypesMst> disconnectionActions;
	private List<DisconnectionAlltypesMst> disconnectionSeverities;
	private DisconnectionRequestAction disconnectionRequestActions;
	private List<DisconnectionRequestAction> actionDetails=	new ArrayList<DisconnectionRequestAction>();
	private List<CustomerSapmst> customer_list;
	private List<OppUploadDetail> oppUploadDetails = new ArrayList<OppUploadDetail>();
	private List<DisconnectionNoticeRequestMst> noticeRequestDetails=	new ArrayList<DisconnectionNoticeRequestMst>();
	private List<DisconnectionNoticeRequestMst> apprejList=	new ArrayList<DisconnectionNoticeRequestMst>();
	
	private CustomerInfoDTO customerInfo;
	private InvoiceInfoDTO invoiceDetails;
	private List<ReminderDetailsDTO> reminderDetails;
	private DisconnectionRequestDetailsDTO disconnectionRequestDetails;
	private List<DisconnectionRequestTrackerDTO> requestTracker;
	private SiteInfoDTO siteInfo;
	
	private List<DisconnectionRequestMst> disconnectionAppRejList=	new ArrayList<DisconnectionRequestMst>();
	
	public SiteInfoDTO getSiteInfo() {
		return siteInfo;
	}
	public void setSiteInfo(SiteInfoDTO siteInfo) {
		this.siteInfo = siteInfo;
	}
	public List<DisconnectionRequestTrackerDTO> getRequestTracker() {
		return requestTracker;
	}
	public void setRequestTracker(List<DisconnectionRequestTrackerDTO> requestTracker) {
		this.requestTracker = requestTracker;
	}
	public List<DisconnectionAlltypesMst> getDisconnectionSeverities() {
		return disconnectionSeverities;
	}
	public void setDisconnectionSeverities(List<DisconnectionAlltypesMst> disconnectionSeverities) {
		this.disconnectionSeverities = disconnectionSeverities;
	}
	public List<DisconnectionRequestMst> getDisconnectionAppRejList() {
		return disconnectionAppRejList;
	}
	public void setDisconnectionAppRejList(List<DisconnectionRequestMst> disconnectionAppRejList) {
		this.disconnectionAppRejList = disconnectionAppRejList;
	}
	public List<DisconnectionRequestAction> getActionDetails() {
		return actionDetails;
	}
	public void setActionDetails(List<DisconnectionRequestAction> actionDetails) {
		this.actionDetails = actionDetails;
	}
	public List<DisconnectionNoticeRequestMst> getNoticeRequestDetails() {
		return noticeRequestDetails;
	}
	public void setNoticeRequestDetails(List<DisconnectionNoticeRequestMst> noticeRequestDetails) {
		this.noticeRequestDetails = noticeRequestDetails;
	}
	public DisconnectionRequestAction getDisconnectionRequestActions() {
		return disconnectionRequestActions;
	}
	public DisconnectionRequestDetailsDTO getDisconnectionRequestDetails() {
		return disconnectionRequestDetails;
	}
	public void setDisconnectionRequestDetails(DisconnectionRequestDetailsDTO disconnectionRequestDetails) {
		this.disconnectionRequestDetails = disconnectionRequestDetails;
	}
	
	public List<DisconnectionNoticeRequestMst> getApprejList() {
		return apprejList;
	}
	public void setApprejList(List<DisconnectionNoticeRequestMst> apprejList) {
		this.apprejList = apprejList;
	}
	public void setDisconnectionRequestActions(DisconnectionRequestAction disconnectionRequestActions) {
		this.disconnectionRequestActions = disconnectionRequestActions;
	}
	
	public CustomerInfoDTO getCustomerInfo() {
		return customerInfo;
	}
	public void setCustomerInfo(CustomerInfoDTO customerInfo) {
		this.customerInfo = customerInfo;
	}
	public InvoiceInfoDTO getInvoiceDetails() {
		return invoiceDetails;
	}
	public void setInvoiceDetails(InvoiceInfoDTO invoiceDetails) {
		this.invoiceDetails = invoiceDetails;
	}
	public List<ReminderDetailsDTO> getReminderDetails() {
		return reminderDetails;
	}
	public void setReminderDetails(List<ReminderDetailsDTO> reminderDetails) {
		this.reminderDetails = reminderDetails;
	}
	
	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}
	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}
	public List<CustomerSapmst> getCustomer_list() {
		return customer_list;
	}
	public void setCustomer_list(List<CustomerSapmst> customer_list) {
		this.customer_list = customer_list;
	}
	
	public List<DisconnectionAlltypesMst> getDisconnectionStatus() {
		return disconnectionStatus;
	}
	public void setDisconnectionStatus(List<DisconnectionAlltypesMst> disconnectionStatus) {
		this.disconnectionStatus = disconnectionStatus;
	}
	public List<DisconnectionAlltypesMst> getDisconnectionActions() {
		return disconnectionActions;
	}
	public void setDisconnectionActions(List<DisconnectionAlltypesMst> disconnectionActions) {
		this.disconnectionActions = disconnectionActions;
	}

}
