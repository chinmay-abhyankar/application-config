package com.nelco.o2c.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.InvoiceSubmissionDTO;
import com.nelco.o2c.dto.PaymentCollectionBreakupDTO;
import com.nelco.o2c.dto.PaymentCollectionDTO;
import com.nelco.o2c.model.InvoiceSubmissionFeedbackMst;
import com.nelco.o2c.model.InvoiceSubmissionMst;
import com.nelco.o2c.model.PaymentCollectionCustomerwise;
import com.nelco.o2c.model.PaymentCollectionInvoicewise;
import com.nelco.o2c.utility.DateUtil;
@Repository
public class PaymentCollectionDaoImpl implements PaymentCollectionDao{
	@PersistenceContext
	private EntityManager em;
	Query query;	
	StoredProcedureQuery spQuery;
	
	@Override
	public List<PaymentCollectionDTO> getInvoiceListForSubmission(HttpServletRequest request) {
		spQuery = em.createStoredProcedureQuery("isp_getCustomerwisePaymentCollectionDetails")
				.registerStoredProcedureParameter("customer", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("startDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("endDate", String.class, ParameterMode.IN);
		spQuery.setParameter("customer", request.getParameter("customer"))
				.setParameter("startDate", DateUtil.convertDateToSqlDate(request.getParameter("startdate")))
				.setParameter("endDate", DateUtil.convertDateToSqlDate(request.getParameter("enddate")));
		List<Object[]> paymentList=spQuery.getResultList();
		
		return paymentList.stream().map(result -> new PaymentCollectionDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3]),String.valueOf(result[4]),String.valueOf(result[5]))
		   ).collect(Collectors.toList());
	}

	@Override
	public List<PaymentCollectionBreakupDTO> getPaymentCollectionBreakupList(HttpServletRequest request) {
		spQuery = em.createStoredProcedureQuery("isp_getInvoicewisePaymentCollectionDetails")
				.registerStoredProcedureParameter("paymentNo", String.class, ParameterMode.IN);
		spQuery.setParameter("paymentNo", request.getParameter("paymentNo"));
		List<Object[]> paymentList=spQuery.getResultList();
		
		return paymentList.stream().map(result -> new PaymentCollectionBreakupDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3]),String.valueOf(result[4]),String.valueOf(result[5]),String.valueOf(result[6]),String.valueOf(result[7]),String.valueOf(result[8]),String.valueOf(result[9]))
		   ).collect(Collectors.toList());
	}

	@Override
	public PaymentCollectionCustomerwise submitPaymentDetails(PaymentCollectionCustomerwise requestDetails) {
		query=em.createNamedQuery("PaymentCollectionCustomerwise.getRequestId");
		String reminderId=String.valueOf(query.getSingleResult());
		requestDetails.setPaymentNo(reminderId);	
		requestDetails.setPaymentDate(DateUtil.convertDateToSqlDate(requestDetails.getPaymentDate()));	
		requestDetails.setChequeDate(DateUtil.convertDateToSqlDate(requestDetails.getChequeDate()));
		requestDetails.setChequeNo(requestDetails.getChequeDate());
		PaymentCollectionCustomerwise savedRequest=em.merge(requestDetails);
		spQuery = em.createStoredProcedureQuery("isp_sendPaymentCollectionIntimations")
				.registerStoredProcedureParameter("paymentNo", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("paymentType", String.class, ParameterMode.IN);
		spQuery.setParameter("paymentNo", reminderId)
		.setParameter("paymentType", "customerwise");
		spQuery.execute();
		return savedRequest;
	}

	@Override
	public PaymentCollectionInvoicewise submitInvoicewisePaymentBreakup(PaymentCollectionInvoicewise breakupDetails) {
		
		breakupDetails.setPaymentDate(DateUtil.convertDateToSqlDate(breakupDetails.getPaymentDate()));
		PaymentCollectionInvoicewise savedBreakup=em.merge(breakupDetails);
		spQuery = em.createStoredProcedureQuery("isp_sendPaymentCollectionIntimations")
				.registerStoredProcedureParameter("paymentNo", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("paymentType", String.class, ParameterMode.IN);
		spQuery.setParameter("paymentNo", breakupDetails.getPaymentNo())
		.setParameter("paymentType", "invoicewise");
		spQuery.execute();
		return savedBreakup;
	}

}
