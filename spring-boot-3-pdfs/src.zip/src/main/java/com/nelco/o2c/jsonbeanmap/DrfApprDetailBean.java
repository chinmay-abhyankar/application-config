/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

/**
 * @author Jayashankar.r
 *
 */
public class DrfApprDetailBean {
	private String preSalesId;
	private String preSalesName;
	private String preSalesMail;
	private String accMgrId;
	private String accMgrName;
	private String accMgrMail;
	private String prgManagerId;
	private String prgManagerName;
	private String prgManagerMail;
	private String techApprId;
	private String techApprName;
	private String techApprMail;
	private String opHeadId;
	private String opHeadName;
	private String opHeadMail;
	private String pmgtHeadId;
	private String pmgtHeadName;
	private String pmgtHeadMail;
	private String preSalesHeadId;
	private String preSalesHeadName;
	private String preSalesHeadMail;
	private String custName;
	private String salesCordId;
	private String salesCordName;
	private String salesCordMail;
	private Integer eboSalesHeadId;
	private String eboSalesHeadName;
	private String eboSalesHeadMail;
	private Integer vpSalesId;
	private String vpSalesName;
	private String vpsSalesMail;
	private Integer ceoId;
	private String ceoName;
	private String ceoMail;
	
	
	public String getEboSalesHeadName() {
		return eboSalesHeadName;
	}

	public void setEboSalesHeadName(String eboSalesHeadName) {
		this.eboSalesHeadName = eboSalesHeadName;
	}

	public String getEboSalesHeadMail() {
		return eboSalesHeadMail;
	}

	public void setEboSalesHeadMail(String eboSalesHeadMail) {
		this.eboSalesHeadMail = eboSalesHeadMail;
	}

	public String getVpSalesName() {
		return vpSalesName;
	}

	public void setVpSalesName(String vpSalesName) {
		this.vpSalesName = vpSalesName;
	}

	public String getVpsSalesMail() {
		return vpsSalesMail;
	}

	public void setVpsSalesMail(String vpsSalesMail) {
		this.vpsSalesMail = vpsSalesMail;
	}

	public String getCeoName() {
		return ceoName;
	}

	public void setCeoName(String ceoName) {
		this.ceoName = ceoName;
	}

	public String getCeoMail() {
		return ceoMail;
	}

	public void setCeoMail(String ceoMail) {
		this.ceoMail = ceoMail;
	}

	public Integer getEboSalesHeadId() {
		return eboSalesHeadId;
	}

	public void setEboSalesHeadId(Integer eboSalesHeadId) {
		this.eboSalesHeadId = eboSalesHeadId;
	}

	public Integer getVpSalesId() {
		return vpSalesId;
	}

	public void setVpSalesId(Integer vpSalesId) {
		this.vpSalesId = vpSalesId;
	}

	public Integer getCeoId() {
		return ceoId;
	}

	public void setCeoId(Integer ceoId) {
		this.ceoId = ceoId;
	}

	public String getSalesCordId() {
		return salesCordId;
	}

	public void setSalesCordId(String salesCordId) {
		this.salesCordId = salesCordId;
	}

	public String getSalesCordName() {
		return salesCordName;
	}

	public void setSalesCordName(String salesCordName) {
		this.salesCordName = salesCordName;
	}

	public String getSalesCordMail() {
		return salesCordMail;
	}

	public void setSalesCordMail(String salesCordMail) {
		this.salesCordMail = salesCordMail;
	}

	public String getPreSalesId() {
		return preSalesId;
	}

	public void setPreSalesId(String preSalesId) {
		this.preSalesId = preSalesId;
	}

	public String getPreSalesName() {
		return preSalesName;
	}

	public void setPreSalesName(String preSalesName) {
		this.preSalesName = preSalesName;
	}

	public String getPreSalesMail() {
		return preSalesMail;
	}

	public void setPreSalesMail(String preSalesMail) {
		this.preSalesMail = preSalesMail;
	}

	public String getAccMgrId() {
		return accMgrId;
	}

	public void setAccMgrId(String accMgrId) {
		this.accMgrId = accMgrId;
	}

	public String getAccMgrName() {
		return accMgrName;
	}

	public void setAccMgrName(String accMgrName) {
		this.accMgrName = accMgrName;
	}

	public String getAccMgrMail() {
		return accMgrMail;
	}

	public void setAccMgrMail(String accMgrMail) {
		this.accMgrMail = accMgrMail;
	}

	public String getPrgManagerId() {
		return prgManagerId;
	}

	public void setPrgManagerId(String prgManagerId) {
		this.prgManagerId = prgManagerId;
	}

	public String getPrgManagerName() {
		return prgManagerName;
	}

	public void setPrgManagerName(String prgManagerName) {
		this.prgManagerName = prgManagerName;
	}

	public String getPrgManagerMail() {
		return prgManagerMail;
	}

	public void setPrgManagerMail(String prgManagerMail) {
		this.prgManagerMail = prgManagerMail;
	}

	public String getTechApprId() {
		return techApprId;
	}

	public void setTechApprId(String techApprId) {
		this.techApprId = techApprId;
	}

	public String getTechApprName() {
		return techApprName;
	}

	public void setTechApprName(String techApprName) {
		this.techApprName = techApprName;
	}

	public String getTechApprMail() {
		return techApprMail;
	}

	public void setTechApprMail(String techApprMail) {
		this.techApprMail = techApprMail;
	}

	public String getOpHeadId() {
		return opHeadId;
	}

	public void setOpHeadId(String opHeadId) {
		this.opHeadId = opHeadId;
	}

	public String getOpHeadName() {
		return opHeadName;
	}

	public void setOpHeadName(String opHeadName) {
		this.opHeadName = opHeadName;
	}

	public String getOpHeadMail() {
		return opHeadMail;
	}

	public void setOpHeadMail(String opHeadMail) {
		this.opHeadMail = opHeadMail;
	}

	public String getPmgtHeadId() {
		return pmgtHeadId;
	}

	public void setPmgtHeadId(String pmgtHeadId) {
		this.pmgtHeadId = pmgtHeadId;
	}

	public String getPmgtHeadName() {
		return pmgtHeadName;
	}

	public void setPmgtHeadName(String pmgtHeadName) {
		this.pmgtHeadName = pmgtHeadName;
	}

	public String getPmgtHeadMail() {
		return pmgtHeadMail;
	}

	public void setPmgtHeadMail(String pmgtHeadMail) {
		this.pmgtHeadMail = pmgtHeadMail;
	}

	public String getPreSalesHeadId() {
		return preSalesHeadId;
	}

	public void setPreSalesHeadId(String preSalesHeadId) {
		this.preSalesHeadId = preSalesHeadId;
	}

	public String getPreSalesHeadName() {
		return preSalesHeadName;
	}

	public void setPreSalesHeadName(String preSalesHeadName) {
		this.preSalesHeadName = preSalesHeadName;
	}

	public String getPreSalesHeadMail() {
		return preSalesHeadMail;
	}

	public void setPreSalesHeadMail(String preSalesHeadMail) {
		this.preSalesHeadMail = preSalesHeadMail;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	@Override
	public String toString() {
		return "DrfApprDetailBean [" + (preSalesId != null ? "preSalesId=" + preSalesId + ", " : "")
				+ (preSalesName != null ? "preSalesName=" + preSalesName + ", " : "")
				+ (preSalesMail != null ? "preSalesMail=" + preSalesMail + ", " : "")
				+ (accMgrId != null ? "accMgrId=" + accMgrId + ", " : "")
				+ (accMgrName != null ? "accMgrName=" + accMgrName + ", " : "")
				+ (accMgrMail != null ? "accMgrMail=" + accMgrMail + ", " : "")
				+ (prgManagerId != null ? "prgManagerId=" + prgManagerId + ", " : "")
				+ (prgManagerName != null ? "prgManagerName=" + prgManagerName + ", " : "")
				+ (prgManagerMail != null ? "prgManagerMail=" + prgManagerMail + ", " : "")
				+ (techApprId != null ? "techApprId=" + techApprId + ", " : "")
				+ (techApprName != null ? "techApprName=" + techApprName + ", " : "")
				+ (techApprMail != null ? "techApprMail=" + techApprMail + ", " : "")
				+ (opHeadId != null ? "opHeadId=" + opHeadId + ", " : "")
				+ (opHeadName != null ? "opHeadName=" + opHeadName + ", " : "")
				+ (opHeadMail != null ? "opHeadMail=" + opHeadMail + ", " : "")
				+ (pmgtHeadId != null ? "pmgtHeadId=" + pmgtHeadId + ", " : "")
				+ (pmgtHeadName != null ? "pmgtHeadName=" + pmgtHeadName + ", " : "")
				+ (pmgtHeadMail != null ? "pmgtHeadMail=" + pmgtHeadMail + ", " : "")
				+ (preSalesHeadId != null ? "preSalesHeadId=" + preSalesHeadId + ", " : "")
				+ (preSalesHeadName != null ? "preSalesHeadName=" + preSalesHeadName + ", " : "")
				+ (preSalesHeadMail != null ? "preSalesHeadMail=" + preSalesHeadMail + ", " : "")
				+ (custName != null ? "custName=" + custName : "") + "]";
	}

}
