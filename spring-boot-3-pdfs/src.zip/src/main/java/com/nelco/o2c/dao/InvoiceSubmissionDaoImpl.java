package com.nelco.o2c.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nelco.o2c.dto.InvoiceFeedbackDTO;
import com.nelco.o2c.dto.InvoiceSubmissionActionsTrackerDTO;
import com.nelco.o2c.dto.InvoiceSubmissionDTO;
import com.nelco.o2c.dto.InvoiceSubmissionFormDTO;
import com.nelco.o2c.dto.InvoiceSubmissionRequestDetailsDTO;
import com.nelco.o2c.dto.OppUploadDetailDTO;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.InvoiceSubmissionActionsTracker;
import com.nelco.o2c.model.InvoiceSubmissionAlltypesMst;
import com.nelco.o2c.model.InvoiceSubmissionFeedbackMst;
import com.nelco.o2c.model.InvoiceSubmissionMst;
import com.nelco.o2c.utility.DateUtil;
@Repository
public class InvoiceSubmissionDaoImpl implements InvoiceSubmissionDao {
	@PersistenceContext
	private EntityManager em;
	Query query;
	Query query1;
	StoredProcedureQuery spQuery;
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	DataSource dataSource;
	
	@Override
	public List<InvoiceSubmissionDTO> getOutstandingInvoicesList(HttpServletRequest request) {
		List<Map<String, Object>> rows = null;
		SimpleJdbcCall jdbcCall = null;
		jdbcCall = new SimpleJdbcCall(dataSource).withProcedureName("isp_getInvoicesForSubmissiontoCustomer_Paginate");
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("customer", request.getParameter("customer"));
		inParamMap.put("startDate", DateUtil.convertDateToSqlDate(request.getParameter("startDate")));
		inParamMap.put("endDate", DateUtil.convertDateToSqlDate(request.getParameter("endDate")));
		inParamMap.put("invoiceNo", request.getParameter("invoiceNo"));
		inParamMap.put("invoiceType", request.getParameter("invoiceType"));
		inParamMap.put("checkStatus",request.getParameter("checkStatus"));
		inParamMap.put("submissionStatus", request.getParameter("submissionStatus"));
		inParamMap.put("companyCode", request.getParameter("companyCode"));
		inParamMap.put("rowNumber", request.getParameter("rowNumber"));
		inParamMap.put("direction", request.getParameter("direction"));
		SqlParameterSource parameter = new MapSqlParameterSource(inParamMap);
		jdbcCall.execute(parameter);
		Map<String, Object> map = jdbcCall.execute(parameter);
		rows = (List<Map<String, Object>>) map.get("#result-set-1");
		InvoiceSubmissionDTO dto=null;
		List<InvoiceSubmissionDTO> resultList=new ArrayList<InvoiceSubmissionDTO>();
		for (Map<String, Object> newmap : rows) {
			dto=new InvoiceSubmissionDTO(String.valueOf(newmap.get("customerNo"))
					,String.valueOf(newmap.get("customer_name"))
					,String.valueOf(newmap.get("invoiceNo"))
					,String.valueOf(newmap.get("invoiceDate"))
					,String.valueOf(newmap.get("invoiceSubmissionDate"))
					,String.valueOf(newmap.get("outstandingAmt"))
					,String.valueOf(newmap.get("submissionDueDate"))
					,String.valueOf(newmap.get("invoiceType"))
					,String.valueOf(newmap.get("billingDate"))
					,String.valueOf(newmap.get("soNo"))
					,String.valueOf(newmap.get("checkStatus"))
					,String.valueOf(newmap.get("cancellationStatus"))
					,String.valueOf(newmap.get("cancellationStatusCode"))
					,String.valueOf(newmap.get("requestId"))
					,String.valueOf(newmap.get("submissionStatus"))
					,String.valueOf(newmap.get("companyCode"))					
					,Integer.parseInt(String.valueOf(newmap.get("rowNumber"))));
			resultList.add(dto);
		}
		return resultList;
		/*spQuery = em.createStoredProcedureQuery("isp_getInvoicesForSubmissiontoCustomer_Paginate")
				.registerStoredProcedureParameter("customer", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("startDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("endDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("invoiceType", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("checkStatus", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("submissionStatus", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("companyCode", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("rowNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("direction", String.class, ParameterMode.IN);
		spQuery.setParameter("customer", request.getParameter("customer"))
				.setParameter("startDate", DateUtil.convertDateToSqlDate(request.getParameter("startDate")))
				.setParameter("endDate", DateUtil.convertDateToSqlDate(request.getParameter("endDate")))
				.setParameter("invoiceNo", request.getParameter("invoiceNo"))
				.setParameter("invoiceType", request.getParameter("invoiceType"))
				.setParameter("checkStatus", request.getParameter("checkStatus"))
				.setParameter("submissionStatus", request.getParameter("submissionStatus"))
				.setParameter("companyCode", request.getParameter("companyCode"))
				.setParameter("rowNumber", request.getParameter("rowNumber"))
				.setParameter("direction", request.getParameter("direction"));
		spQuery.execute();*/
		
		/*query = em.createNamedQuery("InvoiceSubmissionInfoRetriver.findAll");
		query.setParameter("userId", "170");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		List<Object[]> invoiceList=query.getResultList();		
		return invoiceList.stream().map(result -> new InvoiceSubmissionDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3]),String.valueOf(result[4]),String.valueOf(result[5]),String.valueOf(result[6]),String.valueOf(result[7]),String.valueOf(result[8]),String.valueOf(result[9]),String.valueOf(result[10]),String.valueOf(result[11]),String.valueOf(result[12]),String.valueOf(result[13]),String.valueOf(result[14]),String.valueOf(result[15]),Integer.parseInt(String.valueOf(result[16]))
		   )).collect(Collectors.toList());*/
		
		
		
		/*spQuery = em.createStoredProcedureQuery("isp_getInvoicesForSubmissiontoCustomer_Paginate")
				.registerStoredProcedureParameter("customer", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("startDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("endDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("invoiceType", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("checkStatus", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("submissionStatus", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("companyCode", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("rowNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("direction", String.class, ParameterMode.IN);
		spQuery.setParameter("customer", request.getParameter("customer"))
				.setParameter("startDate", DateUtil.convertDateToSqlDate(request.getParameter("startDate")))
				.setParameter("endDate", DateUtil.convertDateToSqlDate(request.getParameter("endDate")))
				.setParameter("invoiceNo", request.getParameter("invoiceNo"))
				.setParameter("invoiceType", request.getParameter("invoiceType"))
				.setParameter("checkStatus", request.getParameter("checkStatus"))
				.setParameter("submissionStatus", request.getParameter("submissionStatus"))
				.setParameter("companyCode", request.getParameter("companyCode"))
				.setParameter("rowNumber", request.getParameter("rowNumber"))
				.setParameter("direction", request.getParameter("direction"));
		
		spQuery.setHint("org.hibernate.cacheable", Boolean.TRUE);
		@SuppressWarnings("unchecked")		
		List<Object[]> invoiceList=spQuery.getResultList();		
		return invoiceList.stream().map(result -> new InvoiceSubmissionDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3]),String.valueOf(result[4]),String.valueOf(result[5]),String.valueOf(result[6]),String.valueOf(result[7]),String.valueOf(result[8]),String.valueOf(result[9]),String.valueOf(result[10]),String.valueOf(result[11]),String.valueOf(result[12]),String.valueOf(result[13]),String.valueOf(result[14]),String.valueOf(result[15]),Integer.parseInt(String.valueOf(result[16]))
		   )).collect(Collectors.toList());*/		
		
		
	}
	
	/*@Override
	public List<InvoiceSubmissionDTO> getOutstandingInvoicesList(HttpServletRequest request) {
		query = em.createNativeQuery(" [dbo].[isp_getInvoicesForSubmissiontoCustomer_Paginate] "				
				+ "@customer = ?"
				+ ",@startDate = ?"
				+ ",@endDate = ?"
				+ ",@invoiceNo = ?"
				+ ",@invoiceType = ?"
				+ ",@checkStatus = ?"
				+ ",@submissionStatus = ?"
				+ ",@companyCode = ?"
				+ ",@rowNumber = ?"
				+ ",@direction = ?");
		query.setParameter(1, request.getParameter("customer"));
		query.setParameter(2, DateUtil.convertDateToSqlDate(request.getParameter("startDate")));
		query.setParameter(3, DateUtil.convertDateToSqlDate(request.getParameter("endDate")));
		query.setParameter(4, request.getParameter("invoiceNo"));
		query.setParameter(5, request.getParameter("invoiceType"));
		query.setParameter(6, request.getParameter("checkStatus"));
		query.setParameter(7, request.getParameter("submissionStatus"));
		query.setParameter(8, request.getParameter("companyCode"));
		query.setParameter(9, request.getParameter("rowNumber"));
		query.setParameter(10, request.getParameter("direction"));

		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		@SuppressWarnings("unchecked")		
		List<Object[]> invoiceList=query.getResultList();		
		return invoiceList.stream().map(result -> new InvoiceSubmissionDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3]),String.valueOf(result[4]),String.valueOf(result[5]),String.valueOf(result[6]),String.valueOf(result[7]),String.valueOf(result[8]),String.valueOf(result[9]),String.valueOf(result[10]),String.valueOf(result[11]),String.valueOf(result[12]),String.valueOf(result[13]),String.valueOf(result[14]),String.valueOf(result[15]),Integer.parseInt(String.valueOf(result[16]))
		   )).collect(Collectors.toList());				
	}*/

	@Override
	public List<InvoiceSubmissionRequestDetailsDTO> getSubmissionRequestDetailsFromInvoiceNo(String invoiceNo) {
		Object[] obj;
		List<InvoiceSubmissionRequestDetailsDTO> lst=new ArrayList<InvoiceSubmissionRequestDetailsDTO>();
		spQuery = em.createStoredProcedureQuery("isp_getInvoiceSubnussionRequestDetailsFromInvoiceNo")
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN);
		spQuery.setParameter("invoiceNo", invoiceNo);
		List<Object[]> invoiceList=spQuery.getResultList();
		InvoiceSubmissionRequestDetailsDTO dto=new InvoiceSubmissionRequestDetailsDTO();
		for(int i=0;i<invoiceList.size();i++){
			obj=invoiceList.get(i);
			dto=new InvoiceSubmissionRequestDetailsDTO();
			dto.setRequestId(String.valueOf(obj[0]));
			dto.setRequestDate(String.valueOf(obj[1]));
			dto.setRequestType(String.valueOf(obj[2]));
			dto.setUploadedDocuments(setUploadedDocuments(String.valueOf(obj[0])));
			lst.add(dto);
		}
		/*return invoiceList.stream().map(result -> new InvoiceInfoDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3]),String.valueOf(result[4]),String.valueOf(result[5])
		   )).collect(Collectors.toList()).get(0);*/
		return lst;
	}
	
	private List<OppUploadDetailDTO> setUploadedDocuments(String requestId) {
		List<OppUploadDetailDTO> docList=new ArrayList<OppUploadDetailDTO>();
		Object[] obj;
		query=em.createNamedQuery("OppUploadDetail.getUploadListForInvoiceSubmission");
		query.setParameter("requestId", requestId);			
		List lst=query.getResultList();
		for(int i=0;i<lst.size();i++){
			obj=(Object[])lst.get(i);
			OppUploadDetailDTO dto=new OppUploadDetailDTO();
			dto.setOppUploadDetailsId(String.valueOf(obj[0]));
			dto.setFileName(String.valueOf(obj[1]));
			dto.setUploadUrl(String.valueOf(obj[2]));
			docList.add(dto);
		}
		return docList;
	}

	@Override
	public List<InvoiceFeedbackDTO> getFeedbackDetailsFromInvoiceNo(String invoiceNo) {
		Object[] obj;
		List<InvoiceFeedbackDTO> lst=new ArrayList<InvoiceFeedbackDTO>();
		spQuery = em.createStoredProcedureQuery("isp_getFeedbackDetailsFromInvoiceNo")
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN);
		spQuery.setParameter("invoiceNo", invoiceNo);
		List<Object[]> invoiceList=spQuery.getResultList();
		InvoiceFeedbackDTO dto=new InvoiceFeedbackDTO();
		for(int i=0;i<invoiceList.size();i++){
			obj=invoiceList.get(i);
			dto=new InvoiceFeedbackDTO();
			dto.setFeedbackType(String.valueOf(obj[0]));
			dto.setFeedbackSubtype(String.valueOf(obj[1]));
			dto.setFeedback(String.valueOf(obj[2]));
			dto.setFeedbackDate(String.valueOf(obj[3]));
			dto.setUserId(String.valueOf(obj[4]));
			lst.add(dto);
		}
		
		return lst;
	}

	@Override
	public List<OppUploadDetailDTO> getInvoiceDocumentsDetails(String invoiceNo) {
		List<OppUploadDetailDTO> docList=new ArrayList<OppUploadDetailDTO>();
		Object[] obj;
		spQuery = em.createStoredProcedureQuery("isp_getDocumentAttachmentsForInvoice")
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN);
		spQuery.setParameter("invoiceNo", invoiceNo);			
		List lst=spQuery.getResultList();
		for(int i=0;i<lst.size();i++){
			obj=(Object[])lst.get(i);
			OppUploadDetailDTO dto=new OppUploadDetailDTO();
			dto.setOppUploadDetailsId(String.valueOf(obj[0]));
			dto.setFileName(String.valueOf(obj[1]));
			dto.setUploadUrl(String.valueOf(obj[2]));
			dto.setDocType(String.valueOf(obj[3]));
			dto.setUploadDate(String.valueOf(obj[4]));
			docList.add(dto);
		}
		return docList;
	}

	@Override
	public String getSubmissionDueStatus(String invoiceNo) {
		String status="1";
		Object obj;
		spQuery = em.createStoredProcedureQuery("isp_getInvoiceSubmissionDueStatus")
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN);
		spQuery.setParameter("invoiceNo", invoiceNo);	
		obj=spQuery.getSingleResult();
		status=String.valueOf(obj);
		return status;
	}

	@Override
	public InvoiceSubmissionMst submitInvoiceDetails(InvoiceSubmissionMst tobeSavedRequest) {
		String action="Submitted Invoice to Customer";
		if(tobeSavedRequest.getRequestId()==null || tobeSavedRequest.getRequestId().equals("")||tobeSavedRequest.getRequestId().equals("null")){
		query=em.createNamedQuery("InvoiceSubmissionMst.getRequestId");
		String reminderId=String.valueOf(query.getSingleResult());
		tobeSavedRequest.setRequestId(reminderId);	
		}
		tobeSavedRequest.setInvoiceNo(tobeSavedRequest.getInvoiceNo());
		tobeSavedRequest.setCheckStatus("Y");
		tobeSavedRequest.setSubmissionDate(DateUtil.convertDateToSqlDate(tobeSavedRequest.getSubmissionDate()));		
		InvoiceSubmissionMst savedRequest=em.merge(tobeSavedRequest);
		if(tobeSavedRequest.getRequestType().equals("3")){
			action="Rejected Invoice: "+tobeSavedRequest.getRejectionType();
			spQuery = em.createStoredProcedureQuery("isp_sendInvoiceSubmissionRejectionIntimations")
					.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("requestId", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("rejectionType", String.class, ParameterMode.IN);
			spQuery.setParameter("invoiceNo", tobeSavedRequest.getInvoiceNo())
				   .setParameter("requestId", tobeSavedRequest.getRequestId())
				   .setParameter("rejectionType", tobeSavedRequest.getRejectionType());
					spQuery.execute();
		}
		updateDisconnectionActionTracker(savedRequest.getInvoiceNo(), savedRequest.getRequestId(), savedRequest.getUpdatedby(), action,savedRequest.getRemark(), "");
		return savedRequest;
	}
	
	

	@Override
	public InvoiceSubmissionFeedbackMst submitFeedback(InvoiceSubmissionFeedbackMst tobeSavedFeedback) {
		query=em.createNamedQuery("InvoiceSubmissionMst.getRequestIdFromInvoiceNo");
		query.setParameter("invoiceNo", tobeSavedFeedback.getInvoiceNo());
		String requestId=String.valueOf(query.getSingleResult());
		tobeSavedFeedback.setRequestId(requestId);
		tobeSavedFeedback.setRequestDate(DateUtil.convertDateToSqlDate(tobeSavedFeedback.getRequestDate()));
		InvoiceSubmissionFeedbackMst savedFeedback=em.merge(tobeSavedFeedback);
		updateDisconnectionActionTracker(savedFeedback.getInvoiceNo(), savedFeedback.getRequestId(), savedFeedback.getUserId(), "Updated Customer Feedback", "", "");
		return savedFeedback;
	}

	@Override
	public InvoiceSubmissionFormDTO getInvoiceSubmissionMasters(InvoiceSubmissionFormDTO invoiceSubmissionFormDTO) {
		List<InvoiceSubmissionAlltypesMst> masters=null;
		query = em.createNamedQuery("InvoiceSubmissionAlltypesMst.getTypes");
		query.setParameter("type", "rej_type");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		masters=query.getResultList();
		invoiceSubmissionFormDTO.setRejectionTypes(masters != null ? masters : new ArrayList<InvoiceSubmissionAlltypesMst>());
		
		query = em.createNamedQuery("InvoiceSubmissionAlltypesMst.getTypes");
		query.setParameter("type", "feedback_type");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		masters=query.getResultList();
		invoiceSubmissionFormDTO.setFeedbackTypes(masters != null ? masters : new ArrayList<InvoiceSubmissionAlltypesMst>());
		
		query = em.createNamedQuery("InvoiceSubmissionAlltypesMst.getTypes");
		query.setParameter("type", "general");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		masters=query.getResultList();
		invoiceSubmissionFormDTO.setGeneralFeedbackTypes(masters != null ? masters : new ArrayList<InvoiceSubmissionAlltypesMst>());
		
		query = em.createNamedQuery("InvoiceSubmissionAlltypesMst.getTypes");
		query.setParameter("type", "dispute");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		masters=query.getResultList();
		invoiceSubmissionFormDTO.setDisputeFeedbackTypes(masters != null ? masters : new ArrayList<InvoiceSubmissionAlltypesMst>());
		
		List lst=new ArrayList();
		query = em.createNamedQuery("InvoiceTypeMst.findAll");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		lst=query.getResultList();
		invoiceSubmissionFormDTO.setInvoiceTypes(lst != null ? lst : new ArrayList());
		
		query = em.createNamedQuery("InvoiceSubmissionAlltypesMst.getTypes");
		query.setParameter("type", "check_types");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		masters=query.getResultList();
		invoiceSubmissionFormDTO.setCheckTypes(masters != null ? masters : new ArrayList<InvoiceSubmissionAlltypesMst>());
		
		List<FileTypeMst> fileTypes=null;
		query = em.createNamedQuery("FileTypeMst.findAll");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		fileTypes=query.getResultList();
		invoiceSubmissionFormDTO.setDocumentTypes(fileTypes != null ? fileTypes : new ArrayList<FileTypeMst>());		
		
		query = em.createNamedQuery("InvoiceSubmissionAlltypesMst.getTypes");
		query.setParameter("type", "submissionStatus");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		masters=query.getResultList();
		invoiceSubmissionFormDTO.setSubmissionStatusList(masters != null ? masters : new ArrayList<InvoiceSubmissionAlltypesMst>());
		
		query = em.createNamedQuery("InvoiceSubmissionAlltypesMst.getTypes");
		query.setParameter("type", "companyCode");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		masters=query.getResultList();
		invoiceSubmissionFormDTO.setCompanyCodeList(masters != null ? masters : new ArrayList<InvoiceSubmissionAlltypesMst>());					
		
		return invoiceSubmissionFormDTO;
	}

	@Override
	public InvoiceSubmissionMst updateDocumentCheckForInvoiceSubmission(InvoiceSubmissionMst tobeSavedRequest) {
		if(tobeSavedRequest.getRequestId()==null || tobeSavedRequest.getRequestId().equals("")||tobeSavedRequest.getRequestId().equals("null")){
			query=em.createNamedQuery("InvoiceSubmissionMst.getRequestId");
			String reminderId=String.valueOf(query.getSingleResult());
			tobeSavedRequest.setRequestId(reminderId);	
			}
		tobeSavedRequest.setInvoiceNo(tobeSavedRequest.getInvoiceNo());
		tobeSavedRequest.setCheckStatus("Y");
		tobeSavedRequest.setCheckedBy(tobeSavedRequest.getSubmittedBy());
		tobeSavedRequest.setSubmittedBy("");
		tobeSavedRequest.setSubmissionDate(null);		
		InvoiceSubmissionMst savedRequest=em.merge(tobeSavedRequest);
		updateDisconnectionActionTracker(savedRequest.getInvoiceNo(), savedRequest.getRequestId(), savedRequest.getUpdatedby(), "Checked documents for Submission", savedRequest.getRemark(), "");
		return savedRequest;
	}

	private void updateDisconnectionActionTracker(String identifierField,String requestId,String userId,String action,String remark,String attchmentId){
		InvoiceSubmissionActionsTracker invoiceSubmissionActionsTracker=new InvoiceSubmissionActionsTracker();
		invoiceSubmissionActionsTracker.setIdentifierField(identifierField);
		invoiceSubmissionActionsTracker.setRequestid(requestId);
		invoiceSubmissionActionsTracker.setUserid(userId);
		invoiceSubmissionActionsTracker.setAction(action);
		invoiceSubmissionActionsTracker.setRemark(remark);
		invoiceSubmissionActionsTracker.setAttachmentId(attchmentId);
		em.merge(invoiceSubmissionActionsTracker);
	}

	@Override
	public List<InvoiceSubmissionActionsTrackerDTO> getInvoiceSubmissionActionsTracker(String invoiceNo) {
		Object[] obj;
		spQuery = em.createStoredProcedureQuery("isp_getInvoiceSubmissionActionsTrackerFromInvoiceNo")
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN);
		spQuery.setParameter("invoiceNo", invoiceNo);
		List<Object[]> invoiceList=spQuery.getResultList();
		InvoiceSubmissionActionsTrackerDTO dto=new InvoiceSubmissionActionsTrackerDTO();
		List<InvoiceSubmissionActionsTrackerDTO> lst=new ArrayList<InvoiceSubmissionActionsTrackerDTO>();
		for(int i=0;i<invoiceList.size();i++){
			obj=invoiceList.get(i);
			dto=new InvoiceSubmissionActionsTrackerDTO();
			dto.setUser(String.valueOf(obj[0]));
			dto.setRequestId(String.valueOf(obj[1]));
			dto.setAction(String.valueOf(obj[2]));
			dto.setActionDate(String.valueOf(obj[3]));
			dto.setRemark(String.valueOf(obj[4]));
			lst.add(dto);
		}
		/*return invoiceList.stream().map(result -> new ReminderDetailsDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3])
		   )).collect(Collectors.toList());*/
		return lst;
	}
	@Override
	public List<InvoiceSubmissionDTO> getOutstandingInvoicesList_Paginated(HttpServletRequest request){
		spQuery = em.createStoredProcedureQuery("isp_getInvoicesForSubmissiontoCustomer_Paginate")
				.registerStoredProcedureParameter("invoiceNo", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("customer", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("startDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("endDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("invoiceType", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("checkStatus", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("submissionStatus", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("companyCode", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("rowNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("direction", String.class, ParameterMode.IN);
		
		
		 spQuery.setParameter("invoiceNo", request.getParameter("invoiceNo"))
				.setParameter("customer", request.getParameter("customer"))
				.setParameter("startDate", DateUtil.convertDateToSqlDate(request.getParameter("startDate")))
				.setParameter("endDate", DateUtil.convertDateToSqlDate(request.getParameter("endDate")))
				.setParameter("invoiceType", request.getParameter("invoiceType"))
				.setParameter("checkStatus", request.getParameter("checkStatus"))
				.setParameter("submissionStatus", request.getParameter("submissionStatus"))
				.setParameter("companyCode", request.getParameter("companyCode"))
				.setParameter("rowNumber", "0")
				.setParameter("direction", "F");
		spQuery.setHint("org.hibernate.cacheable", Boolean.TRUE);
		List<Object[]> invoiceList=spQuery.getResultList();
		return invoiceList.stream().map(result -> new InvoiceSubmissionDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3]),String.valueOf(result[4]),String.valueOf(result[5]),String.valueOf(result[6]),String.valueOf(result[7]),String.valueOf(result[8]),String.valueOf(result[9]),String.valueOf(result[10]),String.valueOf(result[11]),String.valueOf(result[12]),String.valueOf(result[13]),String.valueOf(result[14]),String.valueOf(result[15]),Integer.parseInt(String.valueOf(result[16]))
		   )).collect(Collectors.toList());		
	}
}
