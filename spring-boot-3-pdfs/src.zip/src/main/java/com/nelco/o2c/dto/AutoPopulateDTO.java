/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.model.HsoDetail;
import com.nelco.o2c.model.MaterialContract;
import com.nelco.o2c.model.MaterialSapmst;
import com.nelco.o2c.model.PayTermsMst;
import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.SoOrders;
import com.nelco.o2c.model.StorageSapmst;

/**
 * @author Jayashankar.r
 *
 */
public class AutoPopulateDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<MaterialSapmst> materialList;

	private List<CustomerSapmst> customerList;

	private List<PlantSapmst> plantList;

	private List<StorageSapmst> storageList;

	private List<MaterialContract> materialContractList;
	
	private List<PayTermsMst> paymentTermsList;
	
	private List<SoOrders> soOrdersList;
	
	private List<HsoDetail> ipList;
	
	private String billToParty;

	public String getBillToParty() {
		return billToParty;
	}

	public void setBillToParty(String billToParty) {
		this.billToParty = billToParty;
	}

	public List<HsoDetail> getIpList() {
		return ipList;
	}

	public void setIpList(List<HsoDetail> ipList) {
		this.ipList = ipList;
	}

	public List<PayTermsMst> getPaymentTermsList() {
		return paymentTermsList;
	}

	public void setPaymentTermsList(List<PayTermsMst> paymentTermsList) {
		this.paymentTermsList = paymentTermsList;
	}

	public List<MaterialContract> getMaterialContractList() {
		return materialContractList;
	}

	public void setMaterialContractList(List<MaterialContract> materialContractList) {
		this.materialContractList = materialContractList;
	}

	public List<StorageSapmst> getStorageList() {
		return storageList;
	}

	public void setStorageList(List<StorageSapmst> storageList) {
		this.storageList = storageList;
	}

	public List<PlantSapmst> getPlantList() {
		return plantList;
	}

	public void setPlantList(List<PlantSapmst> plantList) {
		this.plantList = plantList;
	}

	public List<CustomerSapmst> getCustomerList() {
		return customerList;
	}

	public void setCustomerList(List<CustomerSapmst> customerList) {
		this.customerList = customerList;
	}

	public List<MaterialSapmst> getMaterialList() {
		return materialList;
	}

	public void setMaterialList(List<MaterialSapmst> materialList) {
		this.materialList = materialList;
	}

	public List<SoOrders> getSoOrdersList() {
		return soOrdersList;
	}

	public void setSoOrdersList(List<SoOrders> soOrdersList) {
		this.soOrdersList = soOrdersList;
	}
	
}
