/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

import com.nelco.o2c.model.PodUploadDetails;

/**
 * @author Amol.l
 *
 */

public class PodUploadDetailsDTO implements Serializable {

	private static final long serialVersionUID = 79L;

	private Integer deliveryId;
	private PodUploadDetails podUploadDetails = new PodUploadDetails();

	public Integer getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(Integer deliveryId) {
		this.deliveryId = deliveryId;
	}

	public PodUploadDetails getPodUploadDetails() {
		return podUploadDetails;
	}

	public void setPodUploadDetails(PodUploadDetails podUploadDetails) {
		this.podUploadDetails = podUploadDetails;
	}

}
