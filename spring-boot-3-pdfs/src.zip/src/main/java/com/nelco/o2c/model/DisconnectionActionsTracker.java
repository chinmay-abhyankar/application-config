package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the disconnection_actions_tracker database table.
 * 
 */
@Entity
@Table(name="disconnection_actions_tracker")
@NamedQuery(name="DisconnectionActionsTracker.findAll", query="SELECT d FROM DisconnectionActionsTracker d")
public class DisconnectionActionsTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private int typeid;

	@Column(insertable=false, updatable=false, length=2)
	private String actflag;

	@Column(length=100)
	private String action;

	@Column(name="action_date", insertable=false, updatable=false)
	private Timestamp actionDate;

	@Column(name="identifier_field", length=50)
	private String identifierField;
	
	@Column(name="attachment_id", length=50)
	private String attachmentId;
	
	

	@Column(length=500)
	private String remark;

	@Column(length=50)
	private String requestid;

	@Column(length=50)
	private String userid;

	public DisconnectionActionsTracker() {
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Timestamp getActionDate() {
		return this.actionDate;
	}

	public void setActionDate(Timestamp actionDate) {
		this.actionDate = actionDate;
	}

	public String getIdentifierField() {
		return this.identifierField;
	}

	public void setIdentifierField(String identifierField) {
		this.identifierField = identifierField;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRequestid() {
		return this.requestid;
	}

	public void setRequestid(String requestid) {
		this.requestid = requestid;
	}

	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getAttachmentId() {
		return attachmentId;
	}

	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}

}