package com.nelco.o2c.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.nelco.o2c.dto.InvoiceDTO;
import com.nelco.o2c.dto.MaterialDetailsDTO;
import com.nelco.o2c.dto.MaterialStatusUpdateDTO;
import com.nelco.o2c.dto.SalesReturnDTO;
import com.nelco.o2c.dto.SalesReturnFormDTO;
import com.nelco.o2c.dto.SalesReturnListDTO;
import com.nelco.o2c.dto.SalesReturnSaveDTO;
import com.nelco.o2c.model.CreditNoteBwMst;
import com.nelco.o2c.model.CreditNoteEquipMst;
import com.nelco.o2c.model.SalesReturnMst;

public interface SalesReturnDao {
	public List<InvoiceDTO> getListInvoiceAutoComplete(HttpServletRequest request);
	
	public SalesReturnDTO getSalesReturnMasters(SalesReturnDTO salesReturnDTO);
	
	public List<InvoiceDTO> getListInvoiceBWAutoComplete(HttpServletRequest request);
	
	public List<MaterialDetailsDTO> getMaterialDetailsAutoComplete(HttpServletRequest request);
	
	public SalesReturnMst saveSalesReturn(SalesReturnFormDTO salesReturnFormDTO);
	
	public SalesReturnSaveDTO getSalesReturnRequestById(HttpServletRequest request);
	
	public SalesReturnMst submitSalesReturn(SalesReturnFormDTO salesReturnFormDTO);

	Integer getCurrentDayCountSiteSurveyMaster();
	
	public List<SalesReturnListDTO> getSalesReturnRequestForSalesTeam(HttpServletRequest request);
	
	public List<SalesReturnListDTO> getSalesReturnRequestForNOCTeam(HttpServletRequest request);
	
	public SalesReturnMst updateNOCRwmarks(SalesReturnFormDTO salesReturnFormDTO);
	
	public List<SalesReturnListDTO> getSalesReturnRequestForStoresTeam(HttpServletRequest request);
	
	public SalesReturnMst updateMaterialReturn(SalesReturnFormDTO salesReturnFormDTO);
	
	public String getToEmailId(int requestId,String level);
	
	public String getStoresToEmailId(int id, String level) ;
	
	public String setEmailBody(int requestId,String level);
	
	public void updateMultipleMaterialReturn(MaterialStatusUpdateDTO materialStatusUpdateDTO);
	
	public CreditNoteEquipMst getEquipmentCrNoById(HttpServletRequest request);
	
	public CreditNoteBwMst getBandWidthCrNoById(HttpServletRequest request);
}
