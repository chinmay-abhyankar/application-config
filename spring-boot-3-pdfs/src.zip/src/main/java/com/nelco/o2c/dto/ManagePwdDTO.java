package com.nelco.o2c.dto;

import java.io.Serializable;

import com.nelco.o2c.model.UserMst;

public class ManagePwdDTO implements Serializable {
	
	private static final long serialVersionUID = 55L;

	private String loginId;
	private Integer userMstId;
	private String oldPwd;
	private String newPwd;
	private Boolean authFailed = true;
	private Boolean pwdChangeFlag = false;
	private UserMst userMst;
	
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getOldPwd() {
		return oldPwd;
	}
	public void setOldPwd(String oldPwd) {
		this.oldPwd = oldPwd;
	}
	public String getNewPwd() {
		return newPwd;
	}
	public void setNewPwd(String newPwd) {
		this.newPwd = newPwd;
	}
	public Boolean getAuthFailed() {
		return authFailed;
	}
	public void setAuthFailed(Boolean authFailed) {
		this.authFailed = authFailed;
	}
	public UserMst getUserMst() {
		return userMst;
	}
	public void setUserMst(UserMst userMst) {
		this.userMst = userMst;
	}
	public Boolean getPwdChangeFlag() {
		return pwdChangeFlag;
	}
	public void setPwdChangeFlag(Boolean pwdChangeFlag) {
		this.pwdChangeFlag = pwdChangeFlag;
	}
	
	
}
