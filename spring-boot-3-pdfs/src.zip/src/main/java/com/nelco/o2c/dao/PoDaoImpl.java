/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.ConstantProperties;
import com.nelco.o2c.dto.PoDTO;
import com.nelco.o2c.dto.PoPendingDTO;
import com.nelco.o2c.dto.PoQueryResponseDTO;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.Opportunity;
import com.nelco.o2c.model.OrderTypeMst;
import com.nelco.o2c.model.PoApprovalDetail;
import com.nelco.o2c.model.PoQueryDetail;
import com.nelco.o2c.model.PoResponseDetail;
import com.nelco.o2c.model.PoStatusTracker;
import com.nelco.o2c.model.ProductTypeMst;
import com.nelco.o2c.model.Proposal;
import com.nelco.o2c.model.ServiceOrderMst;
import com.nelco.o2c.model.StatusMst;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

import sun.security.util.PendingException;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class PoDaoImpl implements PoDao {

	@PersistenceContext
	private EntityManager em;

	Query query;
	
	@Autowired
	SchedulerDao schedulerDao;
	
	@Autowired
	ConstantProperties properties;

	@SuppressWarnings("unchecked")
	@Override
	public List<OppDetails> getPoDetails(PoDTO poInputDTO) {
		// TODO Auto-generated method stub
		if (poInputDTO.getRoleCode().equals(Constants.PRESALESHEADCODE)) {
			query = em.createNamedQuery("OppDetails.getPoDetailsPreSalesHead");
		} else if (poInputDTO.getRoleCode().equals(Constants.EBOHEADCODE)) {
			query = em.createNamedQuery("OppDetails.getPoDetailsEboHead");
		} else if (poInputDTO.getRoleCode().equals(Constants.OPERATIONSHEADCODE)) {
			query = em.createNamedQuery("OppDetails.getPoDetailsNocHead");
		} else if (poInputDTO.getRoleCode().equals(Constants.PMGTHEADCODE)) {
			query = em.createNamedQuery("OppDetails.getPoDetailsPmgtHead");
		} else if (poInputDTO.getRoleCode().equals(Constants.FINANCEROLECODE)) {
			if(poInputDTO.getOrgCode()!=null && poInputDTO.getOrgCode().equals(Constants.ORGCODETNSL)) {
				query = em.createNamedQuery("OppDetails.getPoDetailsFinanceTnsl");
			} else {
				query = em.createNamedQuery("OppDetails.getPoDetailsFinance");
			}
		} else if (poInputDTO.getRoleCode().equals(Constants.ACCOUNTMANAGERCODE)) {
			query = em.createNamedQuery("OppDetails.getPoDetailsAM");
		} else {
			query = em.createNamedQuery("OppDetails.getPoDetails");
		}

		String fromDate = DateUtil.convertDateToSqlDate(poInputDTO.getFromDate());
		String toDate = DateUtil.convertDateToSqlDate(poInputDTO.getToDate());

		query.setParameter(1, fromDate);
		query.setParameter(2, toDate + " 23:59:59");
		if (poInputDTO.getRoleCode().equals(Constants.ACCOUNTMANAGERCODE)) {
			query.setParameter(3, poInputDTO.getSmOwnerId());
		} else {
			query.setParameter(3, poInputDTO.getUserMstId());
		}

		List<OppDetails> opportunityDetObjs = (List<OppDetails>) query.getResultList();
		return opportunityDetObjs;
	}
	


	@SuppressWarnings("unchecked")
	@Override
	public StatusMst getPoStatus(Integer proposalId) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("PoStatusTracker.findByProposalId");
			query.setParameter(1, proposalId);
			query.setMaxResults(1);
			List<PoStatusTracker> tafTrackerList = query.getResultList();
			StatusMst status = new StatusMst();
			if (tafTrackerList != null && tafTrackerList.size() > 0) {
				status = tafTrackerList.get(0).getStatusMst();
			}
			return status;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public Proposal getPo(PoDTO poInputDTO) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("Proposal.findByProposalId");
			query.setParameter(1, poInputDTO.getProposalId());
			Proposal prop = (Proposal) query.getSingleResult();
			/*if (prop.getPoDate() != null) {
				prop.setPoDate(DateUtil.getSimpleUIDateFromSqlDate(prop.getPoDate()));
			}*/
			return prop;
		}catch (Exception e) {
			e.printStackTrace();
			return new Proposal();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ServiceOrderMst> getserviceOrderList() {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("ServiceOrderMst.findAll");
			return (List<ServiceOrderMst>) query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ProductTypeMst> getproductTypeList() {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("ProductTypeMst.findAll");
			return (List<ProductTypeMst>) query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppUploadDetail> getOppUploadDetails(PoDTO poInputDTO) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("OppUploadDetail.findByProposalIdAndOppId", OppUploadDetail.class);
			query.setParameter(1, poInputDTO.getOpportunityId());
			query.setParameter(2, poInputDTO.getProposalId());
			List<OppUploadDetail> oppUploadDetailList = query.getResultList();
			return oppUploadDetailList != null ? oppUploadDetailList : new ArrayList<OppUploadDetail>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Proposal savePo(Proposal proposal) {
		try {
			// TODO Auto-generated method stub
			proposal.setExpDelDate(DateUtil.convertDateToSqlDate(proposal.getExpDelDate()));
			proposal.setPoDate(DateUtil.convertDateToSqlDate(proposal.getPoDate()));
			if(proposal.getProposalId()==null) {

				Integer maxProposalNumber = schedulerDao.getMaxProposalnumber();
				//existingProposal = new Proposal();
				
				query = em.createNamedQuery("Opportunity.getOpportunityByOpId");
				query.setParameter(1, proposal.getOpportunityId());
				List<Opportunity> opps = (List<Opportunity>) query.getResultList();
				if(opps.size()>0) {
				Opportunity exisOppObj = opps.get(0);
				String proposalGenId = "PROP_"
						+ (DateUtil.getCurrentISTDateAsString(DateUtil.SIMPLE_DATE_FORMAT).replace("-", "_")
								.concat("_").concat(maxProposalNumber.toString()));

				proposal.setProposalGenId(proposalGenId);

				proposal.setOpportunityId(exisOppObj.getOpportunityId());
				proposal.setZohoId(exisOppObj.getZohoId());
				proposal.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
				proposal.setCreatedBy("Portal");
				proposal.setZohoCreatedTime(exisOppObj.getZohoCreatedTime());
				proposal.setZohoModifiedTime(exisOppObj.getZohoModifiedTime());
				proposal.setSmownerId(exisOppObj.getSmownerId());
				proposal.setCurrentStatus(exisOppObj.getCurrentStatus());
				proposal.setStatusMstId(Constants.PONOTSUBMITTEDSTATUS);
				}
				
			}
			Proposal savedProposal = em.merge(proposal);
			if(proposal.getProposalId()==null) {
				PoStatusTracker poStatusTracker = new PoStatusTracker();

				// added this user id for scheduler
				poStatusTracker.setCreatedById(Constants.SALESCOORDINTID);

				poStatusTracker.setProposalId(savedProposal.getProposalId());

				// added this status id for not submitted
				poStatusTracker.setStatusMstId(Constants.PONOTSUBMITTEDSTATUS);

				String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
				poStatusTracker.setReqDate(currTime);
				
				em.merge(poStatusTracker);
			}
			
			return savedProposal;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserMst> getUserListByJobCodeAndOrg(String roleCd, String orgCode) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("UserMst.getUserListByJobCodeAndOrg");
			query.setParameter(1, roleCd);
			query.setParameter(2, orgCode);
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);

			List<UserMst> userMstList = (List<UserMst>) query.getResultList();
			return userMstList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<UserMst>();
		} finally {
			em.close();
		}
	}

	@Override
	public void savePoStatusTracker(PoStatusTracker poStatusTracker) {
		try {
			// TODO Auto-generated method stub
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			poStatusTracker.setReqDate(currTime);
			PoStatusTracker savedStatusTracker = em.merge(poStatusTracker);
			if (poStatusTracker.getPoStatusTrackerId() == null)
				em.refresh(savedStatusTracker);
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}
	
	@Override
	public void updateApproverFlag(Proposal submittedProposal) {
		query = em.createNamedQuery("PoApprovalDetail.updateIsActivebyProposalIdAndApprId");
		query.setParameter(1, "N");
		query.setParameter(2, submittedProposal.getProposalId());
		query.executeUpdate();
	}

	@Override
	public PoApprovalDetail saveApproverDetails(PoApprovalDetail poApprDetails) {
		try {
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			poApprDetails.setActTime(currTime);

			/*if (poApprDetails.getPoApprovalDetailsId() == null) {
				query = em.createNamedQuery("PoApprovalDetail.updateIsActivebyProposalIdAndApprId");
				query.setParameter(1, "N");
				query.setParameter(2, poApprDetails.getProposalId());
				query.setParameter(3, poApprDetails.getApprById());
				query.executeUpdate();
			}*/

			poApprDetails.setIsActive("Y");

			PoApprovalDetail savedPoApprDetails = em.merge(poApprDetails);

			// condition check for refresh
			if (poApprDetails.getPoApprovalDetailsId() == null) {
				em.refresh(savedPoApprDetails);
			}

			return savedPoApprDetails;

		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public PoApprovalDetail getApprovalDetByPropIdAndUserId(PoDTO poInputDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("PoApprovalDetail.getApprovalDetByPropIdAndUserId");
			query.setParameter(1, poInputDTO.getProposalId());
			query.setParameter(2, poInputDTO.getUserMstId());
			List<PoApprovalDetail> resultList = (List<PoApprovalDetail>) query.getResultList();
			return resultList != null && resultList.size() > 0 ? resultList.get(0) : new PoApprovalDetail();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new PoApprovalDetail();
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean checkIfAllApproved(PoDTO poInputDTO) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("PoApprovalDetail.findByProposalId", PoApprovalDetail.class);
			query.setParameter(1, poInputDTO.getProposal() != null ? poInputDTO.getProposal().getProposalId()
					: poInputDTO.getProposalId());
			List<PoApprovalDetail> poApprovalDetails = query.getResultList();
			boolean returnFlag = false;

			for (PoApprovalDetail poApprovalDetail : poApprovalDetails) {
				if (poApprovalDetail.getApprFlag().equals(Constants.POAPPRST))
					returnFlag = true;
				else {
					returnFlag = false;
					break;
				}
			}
			return returnFlag;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PoQueryDetail> getPoQueryDetails(PoQueryResponseDTO poQueryResponseDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("PoQueryDetail.findByPoId", PoQueryDetail.class);
			query.setParameter(1, poQueryResponseDTO.getProposalId());
			return query.getResultList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<PoQueryDetail>();
		} finally {
			em.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public PoQueryDetail getPoQueryDetailsById(Integer id) {
		// TODO Auto-generated method stub
		try {
			PoQueryDetail poQueryDetail = em.find(PoQueryDetail.class, id);
			return poQueryDetail;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new PoQueryDetail();
		} finally {
			em.close();
		}
	}

	@Override
	public PoQueryDetail postPoQuery(PoQueryDetail query) {
		// TODO Auto-generated method stub
		String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
		query.setCreatedDate(currTime);
		PoQueryDetail savedQuery = em.merge(query);
		if (query.getPoQueryDetailsId() == null)
			em.refresh(savedQuery);
		return savedQuery;
	}

	@Override
	public PoResponseDetail postPoResponse(PoResponseDetail response) {
		// TODO Auto-generated method stub
		String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
		response.setCreatedDate(currTime);
		PoResponseDetail savedResponse = em.merge(response);
		if (response.getPoResponseDetailsId() == null)
			em.refresh(savedResponse);
		return savedResponse;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserMst> getPmList(Integer roleId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("UserMst.getUserListByRoleId");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			query.setParameter(1, roleId);
			List<UserMst> userMstList = (List<UserMst>) query.getResultList();
			return userMstList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<UserMst>();
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<HubMst> getHubList() {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("HubMst.findAll");
			return (List<HubMst>) query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public void updateAccMgrPoRemarks(PoDTO poDTO) {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("Proposal.updateAccMgrRemarksByProposalId");
			query.setParameter(1, poDTO.getRemarks());
			query.setParameter(2, poDTO.getProposalId());
			query.executeUpdate();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public UserMst getUserDetailEmailById(Integer id) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("UserMst.getUserEmailById");
			query.setParameter(1, id);
			UserMst userMst = (UserMst)query.getSingleResult();
			return userMst;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} finally {
			em.close();
		}
	}

	@Override
	public UserMst getUserDetailEmailBySmOwnerId(String smowner) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("UserMst.getUserEmailBySmownerId");
			query.setParameter(1, smowner);
			UserMst userMst = (UserMst) query.getSingleResult();
			return userMst;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PoApprovalDetail> getPoApprovalData(PoDTO inputPoDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("PoApprovalDetail.getActiveApproverByProposalId");
			query.setParameter(1, inputPoDTO.getProposalId());
			return (List<PoApprovalDetail>) query.getResultList();
		} finally {
			em.close();
		}		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OrderTypeMst> getOrderTypeList() {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("OrderTypeMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<OrderTypeMst> ordertypeList = query.getResultList();
			return ordertypeList != null ? ordertypeList : new ArrayList<OrderTypeMst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}



	@Override
	public List<Proposal> getProposalByOppId(int oppid, PoDTO poInputDTO) {
		
			String fromDate = DateUtil.convertDateToSqlDate(poInputDTO.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(poInputDTO.getToDate());
			query = em.createNamedQuery("Proposal.findByOppIdAndProDate");
		
			query.setParameter(1, oppid);
			query.setParameter(2, fromDate);
			query.setParameter(3, toDate + " 23:59:59");
			List<Proposal> proposals =(List<Proposal>) query.getResultList();
			return proposals!=null?proposals:new ArrayList<Proposal>();	
	}



	@Override
	public String getReciveingPlantEmail(String plantSapMstId) {
		try {
		 query = em.createNativeQuery("select user_mst_email from plant_to_usermst where plant_sapmst_id =?1");
		 query.setParameter(1, plantSapMstId);
		 String recUser = (String) query.getSingleResult();
		 return recUser;
		}catch (Exception e) {
			return "";
		}
		
	}



	@Override
	public String getBusineesLine(Integer oppurtunityId) {
		try {
			query = em.createNativeQuery("select content from opp_details where opportunity_id =?1 and val=?2");
			query.setParameter(1, oppurtunityId);
			query.setParameter(2, Constants.PRODANDSERVICES);
			String busineesLine = (String) query.getSingleResult();
			return busineesLine;
		}
		catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}



	@Override
	public boolean checkProposalId(Integer proposalId) {
		// TODO Auto-generated method stub
		query = em.createQuery("select count(p) from Proposal p where p.proposalId = :proposalId ");
		query.setParameter("proposalId", proposalId);
		
		try {
			Long maxNumber = (Long) query.getSingleResult();
			return maxNumber.intValue()>0?true:false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} finally {
			em.close();
		}
	}



	@Override
	public boolean checkProposalIdAndUserMstId(Integer proposalId, Integer userMstId) {
		// TODO Auto-generated method stub
		query = em.createQuery("select count(p) from PoApprovalDetail p  where p.apprById = :userMstId "
				+ " and p.proposalId = :proposalId and p.isActive = 'Y' ");
		query.setParameter("userMstId", userMstId);
		query.setParameter("proposalId", proposalId);
		
		try {
			Long maxNumber = (Long) query.getSingleResult();
			return maxNumber.intValue()>0?true:false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} finally {
			em.close();
		}
	}



	@SuppressWarnings("unchecked")
	@Override
	public PoApprovalDetail getPoApprovalDetailByProposalIdAndUserId(Integer proposalId, Integer userMstId) {
		try {
			// TODO Auto-generated method stub
			query = em.createQuery("select p from PoApprovalDetail p  where p.apprById = :userMstId "
					+ " and p.proposalId = :proposalId and p.isActive = 'Y' ");
			query.setParameter("userMstId", userMstId);
			query.setParameter("proposalId", proposalId);
			List<PoApprovalDetail> result = (List<PoApprovalDetail>) query.getResultList();
			return (result != null && result.size() > 0) ? result.get(0) : null;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
		
	}



	@Override
	public boolean checkValidUuidKeyByPropIdAndUserId(String uuidKey, Integer proposalId, Integer userMstId) {
		// TODO Auto-generated method stub
		query = em.createQuery("select count(p) from PoApprovalDetail p  where p.apprById = :userMstId "
				+ " and p.proposalId = :proposalId and p.isActive = 'Y' and p.uuidKey = :uuidKey ");
		query.setParameter("userMstId", userMstId);
		query.setParameter("proposalId", proposalId);
		query.setParameter("uuidKey", uuidKey);
		
		try {
			Long maxNumber = (Long) query.getSingleResult();
			return maxNumber.intValue()>0?true:false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} finally {
			em.close();
		}
	}



	@SuppressWarnings("unchecked")
	@Override
	public List<PoPendingDTO> getPendingPoApprovals(PoDTO inputPoDTO) {
		// TODO Auto-generated method stub
		query = em.createNativeQuery("select * from "
				+ " (select p.proposal_id,p.zoho_id,p.proposal_gen_id,p.po_number,od.val as heading,"
				+ " od.content as content,sm.status_name, sm.status_code,"
				+ " convert(varchar, p.created_date, 105) as created_date,sm.status_mst_id, p.opportunity_id "
				+ " from proposal p inner join status_mst sm on p.status_mst_id = sm.status_mst_id "
				+ " inner join po_approval_details pa "
				+ " on (p.proposal_id = pa.proposal_id and pa.appr_flag = 'P' and pa.is_active = 'Y') "
				+ " inner join opp_details od on (p.opportunity_id = od.opportunity_id) "
				+ " where pa.appr_by_id = :apprById and p.status_mst_id != 16 "
				+ " and od.val in ('"+properties.getOpDetAccountName()+"',"
						+ " '"+properties.getOpDetPotentialName()+"',"
								+ "'"+properties.getOpDetBusinessLine()+"',"
										+ "'"+properties.getPoDetPotentialOwner()+"','"+properties.getOpDetCurrentStatus()+"')) as tbl "
				+ " pivot (min(content) for heading in "
				+ " (["+properties.getOpDetAccountName()+"],"
						+ "["+properties.getOpDetPotentialName()+"],"
								+ "["+properties.getOpDetBusinessLine()+"],"
										+ "["+properties.getPoDetPotentialOwner()+"],"
												+ "["+properties.getOpDetCurrentStatus()+"])) as pvttbl ");
		query.setParameter("apprById", inputPoDTO.getUserMstId());
		
		List<Object[]> res = (List<Object[]>) query.getResultList();
		List<PoPendingDTO> returnList = new ArrayList<PoPendingDTO>();
		PoPendingDTO pendingDto = null;
		for (Object[] objects : res) {
			pendingDto = new PoPendingDTO();
			
			pendingDto.setProposalId(objects[0]!=null?(Integer)objects[0]:null);
			pendingDto.setZohoId(objects[1]!=null?(String)objects[1]:null);
			pendingDto.setProposalGenId(objects[2]!=null?(String)objects[2]:null);
			pendingDto.setPoNumber(objects[3]!=null?(String)objects[3]:null);
			pendingDto.setStatusName(objects[4]!=null?(String)objects[4]:null);
			pendingDto.setStatusCode(objects[5]!=null?(String)objects[5]:null);
			pendingDto.setCreatedDate(objects[6]!=null?(String)objects[6]:null);
			pendingDto.setStatusMstId(objects[7]!=null?(Integer)objects[7]:null);
			pendingDto.setOppId(objects[8]!=null?(Integer)objects[8]:null);
			pendingDto.setCustomerName(objects[9]!=null?(String)objects[9]:null);
			pendingDto.setPotentialName(objects[10]!=null?(String)objects[10]:null);
			pendingDto.setBusinessLine(objects[11]!=null?(String)objects[11]:null);
			pendingDto.setPotentialOwner(objects[12]!=null?(String)objects[12]:null);
			pendingDto.setZohoStatus(objects[13]!=null?(String)objects[13]:null);
			
			returnList.add(pendingDto);
		}
		
		return returnList;
	}

}
