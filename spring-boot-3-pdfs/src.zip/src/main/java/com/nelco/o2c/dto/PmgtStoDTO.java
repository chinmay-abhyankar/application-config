/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.StoPmgt;
import com.nelco.o2c.model.StoPmgtDelivery;

/**
 * @author Jayashankar.r
 *
 */
public class PmgtStoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer userMstId;
	private String fromDate;
	private String toDate;
	private String roleCode;
	private List<StoPmgt> stoPmgtList;
	private StoPmgt stoPmgt;
	private Integer stoPmgtId;
	private Boolean isSaved = false;
	private List<StoPmgtDelivery> stoPmgtDeliveryList;
	private String selectedStatus;
	private String plantCode;
	private String companyCode;
	private String index;
	private String stoPmgtGenId;
	private String deliveryNum;
	private String plant;
	
	
	public String getDeliveryNum() {
		return deliveryNum;
	}

	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}

	public String getStoPmgtGenId() {
		return stoPmgtGenId;
	}

	public void setStoPmgtGenId(String stoPmgtGenId) {
		this.stoPmgtGenId = stoPmgtGenId;
	}

	public String getIndex() {
		return index;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getSelectedStatus() {
		return selectedStatus;
	}

	public void setSelectedStatus(String selectedStatus) {
		this.selectedStatus = selectedStatus;
	}

	public List<StoPmgtDelivery> getStoPmgtDeliveryList() {
		return stoPmgtDeliveryList;
	}

	public void setStoPmgtDeliveryList(List<StoPmgtDelivery> stoPmgtDeliveryList) {
		this.stoPmgtDeliveryList = stoPmgtDeliveryList;
	}

	public Boolean getIsSaved() {
		return isSaved;
	}

	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}

	public Integer getStoPmgtId() {
		return stoPmgtId;
	}

	public void setStoPmgtId(Integer stoPmgtId) {
		this.stoPmgtId = stoPmgtId;
	}

	public Integer getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public List<StoPmgt> getStoPmgtList() {
		return stoPmgtList;
	}

	public void setStoPmgtList(List<StoPmgt> stoPmgtList) {
		this.stoPmgtList = stoPmgtList;
	}

	public StoPmgt getStoPmgt() {
		return stoPmgt;
	}

	public void setStoPmgt(StoPmgt stoPmgt) {
		this.stoPmgt = stoPmgt;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	@Override
	public String toString() {
		return "PmgtStoDTO [userMstId=" + userMstId + ", fromDate=" + fromDate + ", toDate=" + toDate + ", roleCode="
				+ roleCode + ", stoPmgtList=" + stoPmgtList + ", stoPmgt=" + stoPmgt + ", stoPmgtId=" + stoPmgtId
				+ ", isSaved=" + isSaved + ", stoPmgtDeliveryList=" + stoPmgtDeliveryList + ", selectedStatus="
				+ selectedStatus + ", plantCode=" + plantCode + ", companyCode=" + companyCode + ", index=" + index
				+ ", stoPmgtGenId=" + stoPmgtGenId + ", deliveryNum=" + deliveryNum + ", plant=" + plant + "]";
	}

}
