/**
 * 
 */
package com.nelco.o2c.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dao.UserManagementRepository;
import com.nelco.o2c.dto.UserDTO;
import com.nelco.o2c.dto.UserDetails;
import com.nelco.o2c.dto.UserManagementDTO;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.service.UserManagementService;
import com.nelco.o2c.utility.RecordNotFoundException;

/**
 * @author Chinmay A
 *
 */
@RestController
public class UserManagementController {

	@Autowired
	UserManagementService umService;

	@Autowired
	UserManagementRepository umRepository;
	
	@RequestMapping(value="/getUMDropDowns.do", method = RequestMethod.GET)
	public UserManagementDTO getUMDropDowns() {
		return umService.getAllDropDowns();
	}
	
	@RequestMapping(value="/getUMDetails.do", method = RequestMethod.GET)
	public UserDetails getUMDetails() {
		return umService.getUserDetails();
	}

	@RequestMapping(value="/getUMDetailsById.do",method = RequestMethod.POST)
	public ResponseEntity<UserDTO> getUMDetailsById(@Valid @RequestBody UserDTO userDTO) throws Exception{
		Optional<UserMst> userObj = umRepository.findById(userDTO.getUserMstId());
		if(userObj.isPresent()) {
			UserDTO userDTONew = umService.getUMDetailsById(userObj.get());
			return ResponseEntity.ok(userDTONew);
		}
		else {
			throw new RecordNotFoundException("No Record exist with the given Id "+userDTO.getUserMstId());
		}
	}
	
	@RequestMapping(value = "/createUser.do",method = RequestMethod.POST)
	public ResponseEntity  createUser(@Valid @RequestBody UserDTO userDTO) throws Exception {
		return ResponseEntity.ok(umService.createUser(userDTO));
	}

	@RequestMapping(value = "/updateUser.do",method = RequestMethod.POST)
	public ResponseEntity  updateUser(@Valid @RequestBody UserDTO userDTO) throws Exception {
		Optional<UserMst> userObj = umRepository.findById(userDTO.getUserMstId());
		if(userObj.isPresent()) {
			return ResponseEntity.ok(umService.updateUser(userDTO,userObj));
		}
		else {
			throw new RecordNotFoundException("No Record exist with the given Id "+userDTO.getUserMstId());
		}
	}
	
	@RequestMapping(value = "/deActivateUser.do",method = RequestMethod.POST)
	public ResponseEntity deActivateUser(@Valid @RequestBody UserDTO userDTO) throws Exception{
		Optional<UserMst> userObj = umRepository.findById(userDTO.getUserMstId());
		if(userObj.isPresent()) {
			return ResponseEntity.ok(umService.deActivateUser(userDTO,userObj));
		}
		else {
			throw new RecordNotFoundException("No Record exist with the given Id "+userDTO.getUserMstId());
		}
	}
	
}
