/**
 * 
 */
package com.nelco.o2c.controller;

import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.nelco.o2c.dto.PoDTO;
import com.nelco.o2c.dto.PoQueryResponseDTO;
import com.nelco.o2c.model.PoApprovalDetail;
import com.nelco.o2c.model.Proposal;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.service.CommonPotentialsService;
import com.nelco.o2c.service.PoService;



/**
 * @author Jayashankar.r
 *
 */
@RestController
public class PoController {

	@Autowired
	PoService poService;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	CommonPotentialsService commonPotentialsService;

	@RequestMapping(value = "/getPoDetails.do", method = RequestMethod.POST)
	public PoDTO getPoDetails(@RequestBody PoDTO poDTO) {
		return poService.getPoDetails(poDTO);
	}

	@RequestMapping(value = "/getPoDropDowns.do", method = RequestMethod.GET)
	public PoDTO getPoDropDowns() {
		return poService.getPoDropDowns();
	}

	@RequestMapping(value = "/getPo.do", method = RequestMethod.POST)
	public PoDTO getPo(@RequestBody PoDTO poInputDTO) {
		return poService.getPo(poInputDTO);
	}

	@RequestMapping(value = "/savePo.do", method = RequestMethod.POST)
	public PoDTO savePo(@RequestBody PoDTO poInputDTO) {
		return poService.savePo(poInputDTO);
	}

	@RequestMapping(value = "/submitPoNs.do", method = RequestMethod.POST)
	public PoDTO submitPo(@RequestBody PoDTO poInputDTO, HttpServletRequest request) throws Exception {
		return poService.submitPoNs(poInputDTO, request);
	}

	@RequestMapping(value = "/apprRejPo.do", method = RequestMethod.POST)
	public PoDTO apprRejPo(@RequestBody PoDTO poInputDTO, HttpServletRequest request) {

		return poService.apprRejPoDetails(poInputDTO, request);
	}

	@RequestMapping(value = "/getPoQueryDetails.do", method = RequestMethod.POST)
	public PoQueryResponseDTO getPoQueryDetails(@RequestBody PoQueryResponseDTO poQueryResponseDTO) {

		return poService.getPoQueryDetails(poQueryResponseDTO);
	}

	@RequestMapping(value = "/postPoQuery.do", method = RequestMethod.POST)
	public PoQueryResponseDTO postPoQuery(@RequestBody PoQueryResponseDTO poQueryResponseDTO,
			HttpServletRequest request) {

		return poService.postPoQuery(poQueryResponseDTO, request);
	}

	@RequestMapping(value = "/postPoResponse.do", method = RequestMethod.POST)
	public PoQueryResponseDTO postPoResponse(@RequestBody PoQueryResponseDTO poQueryResponseDTO,
			HttpServletRequest request) {

		return poService.postPoResponse(poQueryResponseDTO, request);
	}
	
	@RequestMapping(value = "/accMgrPoRemarks.do", method = RequestMethod.POST)
	public PoDTO accMgrPoRemarks(@RequestBody PoDTO poDTO) {
		return poService.accMgrPoRemarks(poDTO);
	}
	
	@RequestMapping(value = "/getPoApprovalData.do", method = RequestMethod.POST)
	public PoDTO getPoApprovalData(@RequestBody PoDTO inputPoDTO) {
		return poService.getPoApprovalData(inputPoDTO);
	}
	
	@RequestMapping(value = "/getPendingPoApprovals.do", method = RequestMethod.POST)
	public PoDTO getPendingPoApprovals(@RequestBody PoDTO inputPoDTO) {
		return poService.getPendingPoApprovals(inputPoDTO);
	}
	
	@CrossOrigin
	@RequestMapping(value = "/apprRejProposal.do", method = {RequestMethod.POST,RequestMethod.GET})
	public ModelAndView apprRejProposal(HttpServletRequest request,@RequestParam(name="uuidKey", required = true) String uuidKey, 
			@RequestParam(name="proposalId",required = true) String propId,
			@RequestParam(name="userMstId",required = true) String userId, 
			@RequestParam(name = "apprRejFlag", required = true) String apprRejFlag) {
		ModelAndView mv = new ModelAndView("poApproval");
		Integer proposalId = null;
		Integer userMstId = null;
		Boolean valid = true;
		// Check for Valid FLag or not
		if (!Stream.of("A", "R").anyMatch(apprRejFlag::equalsIgnoreCase)) {
			mv.addObject("MSG", "Invalid Approve/Reject Flag");
			valid = false;
		}
		// check for proposal id numeric or not
		if (valid) {
			try {
				proposalId = Integer.parseInt(propId);
				if (poService.checkProposalId(proposalId)) {

					valid = true;
				} else {
					mv.addObject("MSG", "Invalid PO ID");
					valid = false;
				}
			} catch (NumberFormatException nue) {
				mv.addObject("MSG", "Invalid PO ID");
				valid = false;
			}
		}

		// check for usermst id numeric or not.
		if (valid) {
			try {
				userMstId = Integer.parseInt(userId);
				if (poService.checkProposalIdAndUserMstId(proposalId, userMstId)) {
					valid = true;
				} else {
					mv.addObject("MSG", "Invalid User ID");
					valid = false;
				}
			} catch (NumberFormatException nue) {
				mv.addObject("MSG", "Invalid User ID");
				valid = false;
			}
		}

		// check whether uuid valid or not
		if (valid) {
			if (poService.checkValidUuidKeyByPropIdAndUserId(uuidKey, proposalId, userMstId)) {
				valid = true;
			} else {
				mv.addObject("MSG", "Invalid Key");
				valid = false;
			}
		}

		if (valid) {
			PoDTO poInputDTO = new PoDTO();

			PoApprovalDetail poApprovalDetail = poService.getPoApprovalDetailByProposalIdAndUserId(proposalId,
					userMstId);

			if (poApprovalDetail != null) {
				if (poApprovalDetail.getApprFlag().equalsIgnoreCase("A")) {
					mv.addObject("MSG", "PO already approved");
				} else if (poApprovalDetail.getApprFlag().equalsIgnoreCase("R")) {
					mv.addObject("MSG", "PO already Rejected");
				} else {

					// updating the approval detail flag as per the input coming from the link
					poApprovalDetail.setApprFlag(apprRejFlag);
					// setting poApprval detail object
					poInputDTO.setPoApprovalDetail(poApprovalDetail);

					// setting proposal Id
					poInputDTO.setProposalId(proposalId);

					Proposal proposal = poService.getProposalById(poInputDTO);

					UserMst userMst = commonPotentialsService.getUserDetailsById(userMstId);
					// setting user mst id
					poInputDTO.setUserMstId(userMstId);
					if (proposal != null) {
						if (userMst.getRoleMst() != null) {
							poInputDTO.setRoleCode(userMst.getRoleMst().getRoleCd());
							// setting status in outside object
							poInputDTO.setStatusMst(proposal.getStatusMst());
							// setting the proposal object
							poInputDTO.setProposal(proposal);

							// calling service method of po approval
							PoDTO poOutputDTO = poService.apprRejPoDetails(poInputDTO, request);
							if (poOutputDTO.getIsSaved()) {
								if (apprRejFlag.equalsIgnoreCase("A")) {
									mv.addObject("MSG", "PO : " + proposal.getProposalGenId() + " has been approved.");
								} else {
									mv.addObject("MSG", "PO : " + proposal.getProposalGenId() + " has been rejected.");
								}

							} else {
								mv.addObject("MSG", "Could not approve PO : " + proposal.getProposalGenId()
										+ " successfully. Please contact the support.");
							}
						} else {
							mv.addObject("MSG", "No user Details found ");
							valid = false;
						}
					} else {
						mv.addObject("MSG", "Invalid PO Id.");
						valid = false;
					}

				}

			} else {
				mv.addObject("MSG", "Invalid User ID And Proposal ID");
				valid = false;
			}

		}

		return mv;
	}
}
