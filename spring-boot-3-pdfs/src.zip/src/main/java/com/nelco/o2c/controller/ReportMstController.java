package com.nelco.o2c.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.ReportsFilterDTO;
import com.nelco.o2c.model.ReportMst;
import com.nelco.o2c.service.ReportMstService;
import com.nelco.o2c.service.SiteSurveyReportService;

@RestController
public class ReportMstController {
	
	@Autowired
	private ReportMstService reportMstService;
	
	@Autowired
	private SiteSurveyReportService siteSurveyReportService;
	
	@RequestMapping(value = "/getAllReportMst.do", method = RequestMethod.GET)
	public List<ReportMst> getAllReports(){
		return reportMstService.getAllReports();
	}
	
	@GetMapping(value="/getAllReportMst.do/{reportId}")
	public ReportMst findById(@PathVariable("reportId") int theId) {
		
		ReportMst reportMst = reportMstService.findById(theId);
		if(reportMst==null) {
			throw new RuntimeException("No Reports found with the Id:"+theId);
		}
		return reportMst;
	}
	
	
	@RequestMapping(value="/reportFilters.do",method = RequestMethod.GET)
	public ReportsFilterDTO siteSurveyFilters() {
		return siteSurveyReportService.getReportsFilterDropDown();
	}
	
}
