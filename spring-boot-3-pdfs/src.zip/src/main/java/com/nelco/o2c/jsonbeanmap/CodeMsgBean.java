/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Jayashankar.r
 *
 */
public class CodeMsgBean {

	@JsonProperty("code")
	private String code;
	
	@JsonProperty("message")
	private String message;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
