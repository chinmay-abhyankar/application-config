package com.nelco.o2c.dto;

import java.math.BigDecimal;

public class ReactivationListDTO {
private String customerNo;
private String customerName;
private String requestId;
private String disconnectionDate;
private String invoiceNo;
private String outstandingAmt;
private String disconnectionType;
private String disconnectionTypeCode;
private String requestStatus="";
private String requestStatusCode="";

private String soNo="";
private String ip="";
private String commonId="";

public String getCommonId() {
	return commonId;
}
public void setCommonId(String commonId) {
	this.commonId = commonId;
}
public String getSoNo() {
	return soNo;
}
public void setSoNo(String soNo) {
	this.soNo = soNo;
}
public String getIp() {
	return ip;
}
public void setIp(String ip) {
	this.ip = ip;
}
public String getRequestStatus() {
	return requestStatus;
}
public void setRequestStatus(String requestStatus) {
	this.requestStatus = requestStatus;
}
public String getRequestStatusCode() {
	return requestStatusCode;
}
public void setRequestStatusCode(String requestStatusCode) {
	this.requestStatusCode = requestStatusCode;
}
public ReactivationListDTO(String customerNo, String customerName, String requestId, String disconnectionDate, String invoiceNo,
		String outstandingAmt, String disconnectionType, String disconnectionTypeCode,String requestStatus,String requestStatusCode) {
		this.customerNo=customerNo;
		this.customerName=customerName;
		this.requestId=requestId;
		this.disconnectionDate=disconnectionDate;
		this.invoiceNo=invoiceNo;
		this.outstandingAmt=outstandingAmt;
		this.disconnectionTypeCode=disconnectionTypeCode;
		this.requestStatus=requestStatus;
		this.requestStatusCode=requestStatusCode;
}
public ReactivationListDTO(String customerNo, String customerName, String requestId, String disconnectionDate,String soNo,String ip,String requestStatus,String requestStatusCode,String invoiceNo,String commonId,String dummy) {
	this.customerNo=customerNo;
	this.customerName=customerName;
	this.requestId=requestId;
	this.disconnectionDate=disconnectionDate;
	this.soNo=soNo;
	this.ip=ip;
	this.requestStatus=requestStatus;
	this.requestStatusCode=requestStatusCode;
	this.invoiceNo=invoiceNo;
	this.commonId=commonId;
}
public String getCustomerNo() {
	return customerNo;
}
public void setCustomerNo(String customerNo) {
	this.customerNo = customerNo;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getRequestId() {
	return requestId;
}
public void setRequestId(String requestId) {
	this.requestId = requestId;
}
public String getDisconnectionDate() {
	return disconnectionDate;
}
public void setDisconnectionDate(String disconnectionDate) {
	this.disconnectionDate = disconnectionDate;
}
public String getInvoiceNo() {
	return invoiceNo;
}
public void setInvoiceNo(String invoiceNo) {
	this.invoiceNo = invoiceNo;
}
public String getOutstandingAmt() {
	return outstandingAmt;
}
public void setOutstandingAmt(String outstandingAmt) {
	this.outstandingAmt = outstandingAmt;
}
public String getDisconnectionType() {
	return disconnectionType;
}
public void setDisconnectionType(String disconnectionType) {
	this.disconnectionType = disconnectionType;
}
public String getDisconnectionTypeCode() {
	return disconnectionTypeCode;
}
public void setDisconnectionTypeCode(String disconnectionTypeCode) {
	this.disconnectionTypeCode = disconnectionTypeCode;
}

}
