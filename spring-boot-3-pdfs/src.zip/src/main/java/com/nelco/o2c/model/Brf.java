package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.utility.DateUtil;

/**
 * The persistent class for the brf database table.
 * 
 */
@Entity
@Table(name = "brf")
@NamedQueries({ @NamedQuery(name = "Brf.findAll", query = "SELECT b FROM Brf b")})
@NamedNativeQuery(name = "Brf.getBrfByBrfId", query = "SELECT "
		+ "b.brf_id,b.acco_mgr,b.bandwidth,b.brf_plan,b.bw_allocation,b.contract_num,b.created_date,b.existing_site,b.product,b.old_so_num,b.po_num,b.prog_mgr,"
		+ "b.finance_remark,b.site_name,b.sold_to_party,csm.customer_name,b.status_mst_id,sm.status_name,b.technology,b.tent_act_date,b.child_contract_id,sm.status_code,"
		+ "b.finance_id,b.noc_mgr_id,b.noc_remark from brf b inner join customer_sapmst csm on b.sold_to_party = csm.customer_num inner join status_mst sm"
		+ " on b.status_mst_id = sm.status_mst_id where b.brf_id = :brfIdParam ")
public class Brf implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "brf_id")
	private Integer brfId;

	@Column(name = "acco_mgr")
	private Integer accoMgr;

	private String bandwidth;

	@Column(name = "brf_plan")
	private String brfPlan;

	@Column(name = "bw_allocation")
	private String bwAllocation;

	@Column(name = "contract_num")
	private String contractNum;

	@Column(name = "created_date", updatable= false)
	private String createdDate;

	@Column(name = "existing_site")
	private String existingSite;

	@Column(name = "product")
	private String product;

	@Column(name = "old_so_num")
	private String oldSoNum;

	@Column(name = "po_num")
	private String poNum;

	@Column(name = "prog_mgr")
	private Integer progMgr;

	@Column(name = "site_name")
	private String siteName;  //Number of Site

	@Column(name = "sold_to_party")
	private String soldToParty;

	@Column(name = "status_mst_id")
	private Integer statusMstId;

	private String technology;

	@Column(name = "tent_act_date")
	private String tentActDate;

	@Column(name = "child_contract_id")
	private Integer childContractId;

	@Column(name = "finance_id")
	private Integer financeId;

	@Column(name = "noc_mgr_id")
	private Integer nocMgrId;

	@Transient
	private String customerName;
	
	@Transient
	private String progMgrName;

	@Transient
	private String statusName;

	@Transient
	private String statusCode;

	@Column(name = "finance_remark")
	private String financeRemark;

	@Column(name = "noc_remark")
	private String nocRemark;
	
	@Column(name="sales_org")
	private String salesOrg;
	
	@Column(name="dist_channel")
	private String distChannel;

	@Column(name="division")
	private String division;
	
	@Column(name = "regulatory_id")
	private Integer regulatoryId;
	
	@Column(name = "item")
	private String item;
	
	@Column(name = "billing_end_date")
	private String billingEndDate;
	
	@Column(name = "modified_date")
	private String modifiedDate;
	
	@Column(name = "so_orders_id")
	private Integer soOrdersId;
	
	@Column(name = "material_num")
	private String materialNum;
	
	@Column(name = "pm_remark")
	private String pmRemark;
	
	@Column(name = "hub_mst_id")
	private Integer hubMstId;
	
	@Column(name = "updated_date")
	private String updatedDate;
	
	@Transient
	private Integer brfNumOfSiteCreated;
	
	@Transient
	private String accoMgrName;
	
	@Transient
	private String hubDesc;
	
	@Column(name = "drf_details_id")
	private Integer drfDetailsId;

	@Column(name = "so_number")
	private  String soNumber;
	
	public Brf() {
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_mst_id", referencedColumnName = "status_mst_id", insertable = false, updatable = false)
	private StatusMst statusMst;
	
//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "brf_id", referencedColumnName = "brf_id", insertable = false, updatable = false)
//	private GeoTemplate geoTemplate;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "brf_id", referencedColumnName = "brf_id", insertable = false, updatable = false)
	private List<GeoTemplate> geoTemplateList;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "brf_id", referencedColumnName = "brf_id", insertable = false, updatable = false)
	private List<BrfSoDetails> brfSoDetailsList;
	
	public StatusMst getStatusMst() {
		return statusMst;
	}

	public void setStatusMst(StatusMst statusMst) {
		this.statusMst = statusMst;
	}

	public Integer getBrfId() {
		return brfId;
	}

	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}

	public String getBandwidth() {
		return bandwidth;
	}

	public void setBandwidth(String bandwidth) {
		this.bandwidth = bandwidth;
	}

	public String getBrfPlan() {
		return brfPlan;
	}

	public void setBrfPlan(String brfPlan) {
		this.brfPlan = brfPlan;
	}

	public String getBwAllocation() {
		return bwAllocation;
	}

	public void setBwAllocation(String bwAllocation) {
		this.bwAllocation = bwAllocation;
	}

	public String getContractNum() {
		return contractNum;
	}

	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}

	public String getCreatedDate() {
//		return createdDate;
		return DateUtil.convertDateTimeToString(this.createdDate);
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getExistingSite() {
		return existingSite;
	}

	public void setExistingSite(String existingSite) {
		this.existingSite = existingSite;
	}

	public String getOldSoNum() {
		return oldSoNum;
	}

	public void setOldSoNum(String oldSoNum) {
		this.oldSoNum = oldSoNum;
	}

	public String getPoNum() {
		return poNum;
	}

	public void setPoNum(String poNum) {
		this.poNum = poNum;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getSoldToParty() {
		return soldToParty;
	}

	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}

	public Integer getStatusMstId() {
		return statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getTentActDate() {
//		return tentActDate;
		return DateUtil.convertDateTimeToString(this.tentActDate);
	}

	public void setTentActDate(String tentActDate) {
		this.tentActDate = tentActDate;
	}

	public Integer getChildContractId() {
		return childContractId;
	}

	public void setChildContractId(Integer childContractId) {
		this.childContractId = childContractId;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getProgMgrName() {
		return progMgrName;
	}

	public void setProgMgrName(String progMgrName) {
		this.progMgrName = progMgrName;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public Integer getFinanceId() {
		return financeId;
	}

	public void setFinanceId(Integer financeId) {
		this.financeId = financeId;
	}

	public Integer getNocMgrId() {
		return nocMgrId;
	}

	public void setNocMgrId(Integer nocMgrId) {
		this.nocMgrId = nocMgrId;
	}

	public String getFinanceRemark() {
		return financeRemark;
	}

	public void setFinanceRemark(String financeRemark) {
		this.financeRemark = financeRemark;
	}

	public String getNocRemark() {
		return nocRemark;
	}

	public void setNocRemark(String nocRemark) {
		this.nocRemark = nocRemark;
	}

	public String getSalesOrg() {
		return salesOrg;
	}

	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

	public String getDistChannel() {
		return distChannel;
	}

	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public Integer getRegulatoryId() {
		return regulatoryId;
	}

	public void setRegulatoryId(Integer regulatoryId) {
		this.regulatoryId = regulatoryId;
	}

	public Integer getAccoMgr() {
		return accoMgr;
	}

	public void setAccoMgr(Integer accoMgr) {
		this.accoMgr = accoMgr;
	}

	public Integer getProgMgr() {
		return progMgr;
	}

	public void setProgMgr(Integer progMgr) {
		this.progMgr = progMgr;
	}

	public List<GeoTemplate> getGeoTemplateList() {
		return geoTemplateList;
	}

	public void setGeoTemplateList(List<GeoTemplate> geoTemplateList) {
		this.geoTemplateList = geoTemplateList;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getBillingEndDate() {
//		return billingEndDate;
		return DateUtil.convertDateTimeToString(this.billingEndDate);
	}

	public void setBillingEndDate(String billingEndDate) {
		this.billingEndDate = billingEndDate;
	}

	public String getModifiedDate() {
//		return modifiedDate;
		return DateUtil.convertDateTimeToString(this.modifiedDate);
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getSoOrdersId() {
		return soOrdersId;
	}

	public void setSoOrdersId(Integer soOrdersId) {
		this.soOrdersId = soOrdersId;
	}

	public String getMaterialNum() {
		return materialNum;
	}

	public void setMaterialNum(String materialNum) {
		this.materialNum = materialNum;
	}

	public List<BrfSoDetails> getBrfSoDetailsList() {
		return brfSoDetailsList;
	}

	public void setBrfSoDetailsList(List<BrfSoDetails> brfSoDetailsList) {
		this.brfSoDetailsList = brfSoDetailsList;
	}

	public String getAccoMgrName() {
		return accoMgrName;
	}

	public void setAccoMgrName(String accoMgrName) {
		this.accoMgrName = accoMgrName;
	}

	public Integer getBrfNumOfSiteCreated() {
		return brfNumOfSiteCreated;
	}

	public void setBrfNumOfSiteCreated(Integer brfNumOfSiteCreated) {
		this.brfNumOfSiteCreated = brfNumOfSiteCreated;
	}

	public String getPmRemark() {
		return pmRemark;
	}

	public void setPmRemark(String pmRemark) {
		this.pmRemark = pmRemark;
	}

	public Integer getHubMstId() {
		return hubMstId;
	}

	public void setHubMstId(Integer hubMstId) {
		this.hubMstId = hubMstId;
	}

	public String getHubDesc() {
		return hubDesc;
	}

	public void setHubDesc(String hubDesc) {
		this.hubDesc = hubDesc;
	}

	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}

	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}

	public String getSoNumber() {
		return soNumber;
	}

	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}
		
}