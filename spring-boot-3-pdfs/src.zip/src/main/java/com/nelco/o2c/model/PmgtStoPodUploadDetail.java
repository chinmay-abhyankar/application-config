package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the pmgt_sto_pod_upload_details database table.
 * 
 */
@Entity
@Table(name = "pmgt_sto_pod_upload_details")
@NamedQueries({
		@NamedQuery(name = "PmgtStoPodUploadDetail.getPodByStoPmgtDeliveryId", query = "SELECT p FROM PmgtStoPodUploadDetail p where p.stoPmgtDeliveryId=?1"),
		@NamedQuery(name = "PmgtStoPodUploadDetail.findAll", query = "SELECT p FROM PmgtStoPodUploadDetail p") })
public class PmgtStoPodUploadDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pmgt_sto_pod_upload_details_id")
	private Integer pmgtStoPodUploadDetailsId;

	@Column(name = "created_by")
	private Integer createdBy;

	@Column(name = "file_type_mst_id")
	private Integer fileTypeMstId;

	@Column(name = "sto_pmgt_delivery_id")
	private Integer stoPmgtDeliveryId;

	@Column(name = "up_file_name")
	private String upFileName;

	@Column(name = "upload_time")
	private String uploadTime;

	@Column(name = "upload_url")
	private String uploadUrl;

	public PmgtStoPodUploadDetail() {
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "file_type_mst_id", referencedColumnName = "file_type_mst_id", insertable = false, updatable = false)
	private FileTypeMst fileTypeMst;

	public FileTypeMst getFileTypeMst() {
		return fileTypeMst;
	}

	public void setFileTypeMst(FileTypeMst fileTypeMst) {
		this.fileTypeMst = fileTypeMst;
	}

	public Integer getPmgtStoPodUploadDetailsId() {
		return pmgtStoPodUploadDetailsId;
	}

	public void setPmgtStoPodUploadDetailsId(Integer pmgtStoPodUploadDetailsId) {
		this.pmgtStoPodUploadDetailsId = pmgtStoPodUploadDetailsId;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getFileTypeMstId() {
		return fileTypeMstId;
	}

	public void setFileTypeMstId(Integer fileTypeMstId) {
		this.fileTypeMstId = fileTypeMstId;
	}

	public Integer getStoPmgtDeliveryId() {
		return stoPmgtDeliveryId;
	}

	public void setStoPmgtDeliveryId(Integer stoPmgtDeliveryId) {
		this.stoPmgtDeliveryId = stoPmgtDeliveryId;
	}

	public String getUpFileName() {
		return upFileName;
	}

	public void setUpFileName(String upFileName) {
		this.upFileName = upFileName;
	}

	public String getUploadTime() {
		return uploadTime;
	}

	public void setUploadTime(String uploadTime) {
		this.uploadTime = uploadTime;
	}

	public String getUploadUrl() {
		return uploadUrl;
	}

	public void setUploadUrl(String uploadUrl) {
		this.uploadUrl = uploadUrl;
	}

}