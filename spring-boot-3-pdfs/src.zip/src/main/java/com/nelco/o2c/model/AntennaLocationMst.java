package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the antenna_location_mst database table.
 * 
 */
@Entity
@Table(name="antenna_location_mst")
@NamedQuery(name="AntennaLocationMst.findAll", query="SELECT a FROM AntennaLocationMst a where a.isActive = 'Y' ")
public class AntennaLocationMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="antenna_location_mst_id")
	private Integer antennaLocationMstId;

	@Column(name="antenna_location_code")
	private String antennaLocationCode;

	@Column(name="antenna_location_val")
	private String antennaLocationVal;

	@Column(name="is_active")
	private String isActive;

	public AntennaLocationMst() {
	}

	public Integer getAntennaLocationMstId() {
		return this.antennaLocationMstId;
	}

	public void setAntennaLocationMstId(Integer antennaLocationMstId) {
		this.antennaLocationMstId = antennaLocationMstId;
	}

	public String getAntennaLocationCode() {
		return this.antennaLocationCode;
	}

	public void setAntennaLocationCode(String antennaLocationCode) {
		this.antennaLocationCode = antennaLocationCode;
	}

	public String getAntennaLocationVal() {
		return this.antennaLocationVal;
	}

	public void setAntennaLocationVal(String antennaLocationVal) {
		this.antennaLocationVal = antennaLocationVal;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

}