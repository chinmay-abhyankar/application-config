/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.InstallationStatusMst;
import com.nelco.o2c.model.StateMst;
import com.nelco.o2c.model.StatusMst;

/**
 * @author Jayshankar.r
 *
 */
public class FranchiseDropDownDTO implements Serializable  {

	private static final long serialVersionUID = 1L;
	
	private Integer userMstId;
	private String roleCode;
	private Integer status;
	private Integer stateMstId;
	private List<StateMst> stateList;
	private List<StatusMst> statusList;
	private List<InstallationStatusMst> installationStatusList;
	
	
	
	public List<InstallationStatusMst> getInstallationStatusList() {
		return installationStatusList;
	}
	public void setInstallationStatusList(List<InstallationStatusMst> installationStatusList) {
		this.installationStatusList = installationStatusList;
	}
	public List<StateMst> getStateList() {
		return stateList;
	}
	public void setStateList(List<StateMst> stateList) {
		this.stateList = stateList;
	}
	public List<StatusMst> getStatusList() {
		return statusList;
	}
	public void setStatusList(List<StatusMst> statusList) {
		this.statusList = statusList;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getStateMstId() {
		return stateMstId;
	}
	public void setStateMstId(Integer stateMstId) {
		this.stateMstId = stateMstId;
	}
	
	
	
}
