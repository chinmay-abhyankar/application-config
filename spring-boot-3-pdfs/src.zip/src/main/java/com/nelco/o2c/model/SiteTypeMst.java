package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the site_type_mst database table.
 * 
 */
@Entity
@Table(name="site_type_mst")
@NamedQuery(name="SiteTypeMst.findAll", query="SELECT s FROM SiteTypeMst s where s.isActive = 'Y' ")
public class SiteTypeMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="site_type_mst_id")
	private Integer siteTypeMstId;

	@Column(name="is_active")
	private String isActive;

	@Column(name="site_type_code")
	private String siteTypeCode;

	@Column(name="site_type_val")
	private String siteTypeVal;

	public SiteTypeMst() {
	}

	public Integer getSiteTypeMstId() {
		return this.siteTypeMstId;
	}

	public void setSiteTypeMstId(Integer siteTypeMstId) {
		this.siteTypeMstId = siteTypeMstId;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getSiteTypeCode() {
		return this.siteTypeCode;
	}

	public void setSiteTypeCode(String siteTypeCode) {
		this.siteTypeCode = siteTypeCode;
	}

	public String getSiteTypeVal() {
		return this.siteTypeVal;
	}

	public void setSiteTypeVal(String siteTypeVal) {
		this.siteTypeVal = siteTypeVal;
	}

}