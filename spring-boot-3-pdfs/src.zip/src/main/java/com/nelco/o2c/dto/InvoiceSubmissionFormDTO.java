package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.CustomerAgeingDetails;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.InvoiceSubmissionAlltypesMst;
import com.nelco.o2c.model.InvoiceSubmissionFeedbackMst;
import com.nelco.o2c.model.InvoiceSubmissionMst;
import com.nelco.o2c.model.InvoiceTypeMst;
import com.nelco.o2c.model.OppUploadDetail;

public class InvoiceSubmissionFormDTO {
	private List<InvoiceSubmissionDTO> InvoiceList=new ArrayList<InvoiceSubmissionDTO>();
	private CustomerInfoDTO customerInfo;
	private InvoiceInfoDTO invoiceDetails;
	private List<InvoiceSubmissionRequestDetailsDTO> submissionRequestDetails=new ArrayList<InvoiceSubmissionRequestDetailsDTO>();
	private List<InvoiceFeedbackDTO> feedbackInfo=new ArrayList<InvoiceFeedbackDTO>();
	private List<OppUploadDetailDTO> invoiceDocuments=new ArrayList<OppUploadDetailDTO>();
	private String isSumbissionDue="";
	private String isChecked="";
	private List<InvoiceSubmissionMst> requestDetails=new ArrayList<InvoiceSubmissionMst>();
	private List<InvoiceSubmissionFeedbackMst> feedbackDetails=new ArrayList<InvoiceSubmissionFeedbackMst>();
	private List<OppUploadDetail> oppUploadDetails = new ArrayList<OppUploadDetail>();								  
	private List<InvoiceSubmissionAlltypesMst> rejectionTypes=new ArrayList<InvoiceSubmissionAlltypesMst>();
	private List<InvoiceSubmissionAlltypesMst> feedbackTypes=new ArrayList<InvoiceSubmissionAlltypesMst>();
	private List<InvoiceSubmissionAlltypesMst> disputeFeedbackTypes=new ArrayList<InvoiceSubmissionAlltypesMst>();
	private List<InvoiceSubmissionAlltypesMst> generalFeedbackTypes=new ArrayList<InvoiceSubmissionAlltypesMst>();
	private List<InvoiceTypeMst> invoiceTypes=new ArrayList<InvoiceTypeMst>();
	private List<InvoiceSubmissionAlltypesMst> checkTypes=new ArrayList<InvoiceSubmissionAlltypesMst>();
	private List<FileTypeMst> documentTypes=new ArrayList<FileTypeMst>();
	private List<InvoiceSubmissionActionsTrackerDTO> requestTracker;
	private List<InvoiceSubmissionAlltypesMst> submissionStatusList=new ArrayList<InvoiceSubmissionAlltypesMst>();
	private List<InvoiceSubmissionAlltypesMst> CompanyCodeList=new ArrayList<InvoiceSubmissionAlltypesMst>();
	

	public List<InvoiceSubmissionAlltypesMst> getCompanyCodeList() {
		return CompanyCodeList;
	}

	public void setCompanyCodeList(List<InvoiceSubmissionAlltypesMst> companyCodeList) {
		CompanyCodeList = companyCodeList;
	}


	public List<InvoiceSubmissionAlltypesMst> getSubmissionStatusList() {
		return submissionStatusList;
	}

	public void setSubmissionStatusList(List<InvoiceSubmissionAlltypesMst> submissionStatusList) {
		this.submissionStatusList = submissionStatusList;
	}

	public List<InvoiceSubmissionActionsTrackerDTO> getRequestTracker() {
		return requestTracker;
	}

	public void setRequestTracker(List<InvoiceSubmissionActionsTrackerDTO> requestTracker) {
		this.requestTracker = requestTracker;
	}

	public String getIsChecked() {
		return isChecked;
	}

	public void setIsChecked(String isChecked) {
		this.isChecked = isChecked;
	}

	public List<FileTypeMst> getDocumentTypes() {
		return documentTypes;
	}

	public void setDocumentTypes(List<FileTypeMst> documentTypes) {
		this.documentTypes = documentTypes;
	}

	public List<InvoiceSubmissionAlltypesMst> getCheckTypes() {
		return checkTypes;
	}

	public void setCheckTypes(List<InvoiceSubmissionAlltypesMst> checkTypes) {
		this.checkTypes = checkTypes;
	}

	public List<InvoiceTypeMst> getInvoiceTypes() {
		return invoiceTypes;
	}

	public void setInvoiceTypes(List<InvoiceTypeMst> invoiceTypes) {
		this.invoiceTypes = invoiceTypes;
	}

	public List<InvoiceSubmissionAlltypesMst> getFeedbackTypes() {
		return feedbackTypes;
	}

	public void setFeedbackTypes(List<InvoiceSubmissionAlltypesMst> feedbackTypes) {
		this.feedbackTypes = feedbackTypes;
	}

	public List<InvoiceSubmissionAlltypesMst> getRejectionTypes() {
		return rejectionTypes;
	}

	public void setRejectionTypes(List<InvoiceSubmissionAlltypesMst> rejectionTypes) {
		this.rejectionTypes = rejectionTypes;
	}

	public List<InvoiceSubmissionAlltypesMst> getDisputeFeedbackTypes() {
		return disputeFeedbackTypes;
	}

	public void setDisputeFeedbackTypes(List<InvoiceSubmissionAlltypesMst> disputeFeedbackTypes) {
		this.disputeFeedbackTypes = disputeFeedbackTypes;
	}

	public List<InvoiceSubmissionAlltypesMst> getGeneralFeedbackTypes() {
		return generalFeedbackTypes;
	}

	public void setGeneralFeedbackTypes(List<InvoiceSubmissionAlltypesMst> generalFeedbackTypes) {
		this.generalFeedbackTypes = generalFeedbackTypes;
	}

	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}

	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}

	public List<InvoiceSubmissionMst> getRequestDetails() {
		return requestDetails;
	}

	public List<InvoiceFeedbackDTO> getFeedbackInfo() {
		return feedbackInfo;
	}

	public void setFeedbackInfo(List<InvoiceFeedbackDTO> feedbackInfo) {
		this.feedbackInfo = feedbackInfo;
	}

	public void setRequestDetails(List<InvoiceSubmissionMst> requestDetails) {
		this.requestDetails = requestDetails;
	}

	public void setFeedbackDetails(List<InvoiceSubmissionFeedbackMst> feedbackDetails) {
		this.feedbackDetails = feedbackDetails;
	}

	public List<OppUploadDetailDTO> getInvoiceDocuments() {
		return invoiceDocuments;
	}

	public void setInvoiceDocuments(List<OppUploadDetailDTO> invoiceDocuments) {
		this.invoiceDocuments = invoiceDocuments;
	}

	public String getIsSumbissionDue() {
		return isSumbissionDue;
	}

	public void setIsSumbissionDue(String isSumbissionDue) {
		this.isSumbissionDue = isSumbissionDue;
	}



	public List<InvoiceSubmissionFeedbackMst> getFeedbackDetails() {
		return feedbackDetails;
	}

	public List<InvoiceSubmissionRequestDetailsDTO> getSubmissionRequestDetails() {
		return submissionRequestDetails;
	}

	public void setSubmissionRequestDetails(List<InvoiceSubmissionRequestDetailsDTO> submissionRequestDetails) {
		this.submissionRequestDetails = submissionRequestDetails;
	}

	public CustomerInfoDTO getCustomerInfo() {
		return customerInfo;
	}

	public void setCustomerInfo(CustomerInfoDTO customerInfo) {
		this.customerInfo = customerInfo;
	}

	public InvoiceInfoDTO getInvoiceDetails() {
		return invoiceDetails;
	}

	public void setInvoiceDetails(InvoiceInfoDTO invoiceDetails) {
		this.invoiceDetails = invoiceDetails;
	}

	public List<InvoiceSubmissionDTO> getInvoiceList() {
		return InvoiceList;
	}

	public void setInvoiceList(List<InvoiceSubmissionDTO> invoiceList) {
		InvoiceList = invoiceList;
	}

	
}
