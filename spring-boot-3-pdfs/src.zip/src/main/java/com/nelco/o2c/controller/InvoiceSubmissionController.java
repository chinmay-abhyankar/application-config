package com.nelco.o2c.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.DisconnectionDTO;
import com.nelco.o2c.dto.DisconnectionFormDTO;
import com.nelco.o2c.dto.InvoiceSubmissionFormDTO;
import com.nelco.o2c.service.InvoiceSubmissionService;

@RestController
public class InvoiceSubmissionController {
@Autowired
InvoiceSubmissionService invoiceSubmissionService;

@RequestMapping(value = "/getInvoiceListForSubmission.do", method = RequestMethod.GET)
public InvoiceSubmissionFormDTO getListForInvoiceSubmission(InvoiceSubmissionFormDTO invoiceSubmissionFormDTO, HttpServletRequest request) {
	return invoiceSubmissionService.getInvoiceListForSubmission(invoiceSubmissionFormDTO, request);
}

@RequestMapping(value = "/invoiceSubmissionRequestDetails.do", method = RequestMethod.GET)
public InvoiceSubmissionFormDTO getInvoiceSubmissionRequestDetails(InvoiceSubmissionFormDTO invoiceSubmissionFormDTO, HttpServletRequest request) {
	return invoiceSubmissionService.getInvoiceSubmissionRequestDetails(invoiceSubmissionFormDTO,request);
}

@RequestMapping(value = "/submitInvoiceDetails.do", method = RequestMethod.POST)
public InvoiceSubmissionFormDTO submitInvoiceDetails(@RequestBody InvoiceSubmissionFormDTO invoiceSubmissionFormDTO, HttpServletRequest request) {
	return invoiceSubmissionService.submitInvoiceDetails(invoiceSubmissionFormDTO,request);
}

@RequestMapping(value = "/updateDocumentCheckForInvoiceSubmission.do", method = RequestMethod.POST)
public InvoiceSubmissionFormDTO updateDocumentCheckForInvoiceSubmission(@RequestBody InvoiceSubmissionFormDTO invoiceSubmissionFormDTO, HttpServletRequest request) {
	return invoiceSubmissionService.updateDocumentCheckForInvoiceSubmission(invoiceSubmissionFormDTO,request);
}

@RequestMapping(value = "/submitFeedback.do", method = RequestMethod.POST)
public InvoiceSubmissionFormDTO submitFeedback(@RequestBody InvoiceSubmissionFormDTO invoiceSubmissionFormDTO, HttpServletRequest request) {
	return invoiceSubmissionService.submitFeedback(invoiceSubmissionFormDTO,request);
}

@RequestMapping(value = "/getInvoiceSubmissionMasters.do", method = RequestMethod.GET)
public InvoiceSubmissionFormDTO getDisconnectionMasters(InvoiceSubmissionFormDTO invoiceSubmissionFormDTO) {
	return invoiceSubmissionService.getInvoiceSubmissionMasters(invoiceSubmissionFormDTO);
}
}
