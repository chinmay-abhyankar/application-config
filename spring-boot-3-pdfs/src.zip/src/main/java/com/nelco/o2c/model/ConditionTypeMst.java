package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the condition_type_mst database table.
 * 
 */
@Entity
@Table(name="condition_type_mst")
@NamedQuery(name="ConditionTypeMst.findAll", query="SELECT c FROM ConditionTypeMst c where c.isActive = 'Y'")
public class ConditionTypeMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="condition_type_mst_id")
	private Integer conditionTypeMstId;

	@Column(name="condition_type_code")
	private String conditionTypeCode;

	@Column(name="condition_type_val")
	private String conditionTypeVal;

	@Column(name="is_active")
	private String isActive;

	public ConditionTypeMst() {
	}

	public Integer getConditionTypeMstId() {
		return this.conditionTypeMstId;
	}

	public void setConditionTypeMstId(Integer conditionTypeMstId) {
		this.conditionTypeMstId = conditionTypeMstId;
	}

	public String getConditionTypeCode() {
		return this.conditionTypeCode;
	}

	public void setConditionTypeCode(String conditionTypeCode) {
		this.conditionTypeCode = conditionTypeCode;
	}

	public String getConditionTypeVal() {
		return this.conditionTypeVal;
	}

	public void setConditionTypeVal(String conditionTypeVal) {
		this.conditionTypeVal = conditionTypeVal;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

}