package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the non_feasible_option_mst database table.
 * 
 */
@Entity
@Table(name="non_feasible_option_mst")
@NamedQuery(name="NonFeasibleOptionMst.findAll", query="SELECT n FROM NonFeasibleOptionMst n")
public class NonFeasibleOptionMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="non_feasible_option_mst_id")
	private Integer nonFeasibleOptionMstId;

	@Column(name="non_feasible_option_code")
	private String nonFeasibleOptionCode;

	@Column(name="non_feasible_option_value")
	private String nonFeasibleOptionValue;

	public NonFeasibleOptionMst() {
	}

	public Integer getNonFeasibleOptionMstId() {
		return this.nonFeasibleOptionMstId;
	}

	public void setNonFeasibleOptionMstId(Integer nonFeasibleOptionMstId) {
		this.nonFeasibleOptionMstId = nonFeasibleOptionMstId;
	}

	public String getNonFeasibleOptionCode() {
		return this.nonFeasibleOptionCode;
	}

	public void setNonFeasibleOptionCode(String nonFeasibleOptionCode) {
		this.nonFeasibleOptionCode = nonFeasibleOptionCode;
	}

	public String getNonFeasibleOptionValue() {
		return this.nonFeasibleOptionValue;
	}

	public void setNonFeasibleOptionValue(String nonFeasibleOptionValue) {
		this.nonFeasibleOptionValue = nonFeasibleOptionValue;
	}

}