package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the division_mst database table.
 * 
 */
@Entity
@Table(name="division_mst")
@NamedQuery(name="DivisionMst.findAll", query="SELECT d FROM DivisionMst d")
public class DivisionMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="division_mst_id")
	private int divisionMstId;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="division_code")
	private String divisionCode;

	@Column(name="division_desc")
	private String divisionDesc;

	@Column(name="is_active")
	private String isActive;

	private String sequence;

	public DivisionMst() {
	}

	public int getDivisionMstId() {
		return this.divisionMstId;
	}

	public void setDivisionMstId(int divisionMstId) {
		this.divisionMstId = divisionMstId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDivisionCode() {
		return this.divisionCode;
	}

	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}

	public String getDivisionDesc() {
		return this.divisionDesc;
	}

	public void setDivisionDesc(String divisionDesc) {
		this.divisionDesc = divisionDesc;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getSequence() {
		return this.sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

}