/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.SoOrderDTO;
import com.nelco.o2c.dto.SoOrdersListDTO;
import com.nelco.o2c.model.SoOrders;

/**
 * @author Amol.l
 *
 */

@Repository
public class SalesOrderDaoImpl implements SalesOrderDao {

	@PersistenceContext
	private EntityManager em;

	Query query;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<SoOrders> getSoDetailsBySoNumber(SoOrderDTO soOrderDTO) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("SoOrders.getSoDetailsBySoNumber");
			query.setParameter(1, soOrderDTO.getSoNumber());
			/*query.setParameter(2, soOrderDTO.getContractNum());
			query.setParameter(3, soOrderDTO.getMaterialNum());
			query.setParameter(4, soOrderDTO.getSalesOrg());*/
			List<SoOrders> soorders = (List<SoOrders>) query.getResultList();
			return soorders;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<SoOrders>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<SoOrders> getSOListByContractNum(String contractNum) {
		// TODO Auto-generated method stub
				try {

					if(contractNum!=null) {
						query = em.createNamedQuery("SoOrders.getSOListByContractNum");
						query.setParameter(1, contractNum);
					} else {
						query = em.createNamedQuery("SoOrders.getSOListWithoutContractNum");
					}
					query.setHint("org.hibernate.cacheable", Boolean.TRUE);
					@SuppressWarnings("unchecked")
					List<SoOrders> soOrders = (List<SoOrders>) query.getResultList();
					return soOrders;
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
					return new ArrayList<SoOrders>();
				} finally {
					em.close();
				}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SoOrders> getSOListBySparesSoUniqId(SoOrdersListDTO soOrdersListDTO) {
		// TODO Auto-generated method stub
		try {
				query = em.createNamedQuery("SoOrders.getSOListBySparesSoUniqId");
				query.setParameter(1, soOrdersListDTO.getUniqId());
				query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			
				List<SoOrders> soOrders = (List<SoOrders>) query.getResultList();
				return soOrders;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<SoOrders>();
		} finally {
			em.close();
		}
}

	@Override
	public List<SoOrders> getSOListByRelocationSoUniqId(SoOrdersListDTO soOrdersListDTO) {
		// TODO Auto-generated method stub
		try {
				query = em.createNamedQuery("SoOrders.getSOListByRelocationSoUniqId");
				query.setParameter(1, soOrdersListDTO.getUniqId());
				query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			
				List<SoOrders> soOrders = (List<SoOrders>) query.getResultList();
				return soOrders;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<SoOrders>();
		} finally {
			em.close();
		}
}

	@SuppressWarnings("unchecked")
	@Override
	public List<SoOrders> getSOListByDemoId(SoOrdersListDTO soOrdersListDTO) {
		// TODO Auto-generated method stub
		try {
				query = em.createNamedQuery("SoOrders.getSOListByDemoSoUniqId");
				query.setParameter(1, soOrdersListDTO.getDrfDetailsId());
				query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			
				List<SoOrders> soOrders = (List<SoOrders>) query.getResultList();
				return soOrders;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<SoOrders>();
		} finally {
			em.close();
		}
}
}
