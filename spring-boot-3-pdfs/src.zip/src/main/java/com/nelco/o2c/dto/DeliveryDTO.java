/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.Delivery;

/**
 * @author Amol.l
 *
 */
public class DeliveryDTO implements Serializable {
	
	private static final long serialVersionUID = 27L;
	private Integer deliveryId;
	private Delivery Delivery = new Delivery();
	private String isSave;
	private Integer userMstId;
	private List<Delivery> deliveryList = new ArrayList<Delivery>();
	private String deliveryNum;
	private String deliveryIdList;
	private List<CommonMailDTO> commonMailDTOList = new ArrayList<CommonMailDTO>();
	private String isSRMailSent;	
	
	public Integer getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(Integer deliveryId) {
		this.deliveryId = deliveryId;
	}
	
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public Delivery getDelivery() {
		return Delivery;
	}
	public void setDelivery(Delivery delivery) {
		Delivery = delivery;
	}
	public String getIsSave() {
		return isSave;
	}
	public void setIsSave(String isSave) {
		this.isSave = isSave;
	}
	public List<Delivery> getDeliveryList() {
		return deliveryList;
	}
	public void setDeliveryList(List<Delivery> deliveryList) {
		this.deliveryList = deliveryList;
	}
	public String getDeliveryNum() {
		return deliveryNum;
	}
	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}
	public String getDeliveryIdList() {
		return deliveryIdList;
	}
	public void setDeliveryIdList(String deliveryIdList) {
		this.deliveryIdList = deliveryIdList;
	}
	public List<CommonMailDTO> getCommonMailDTOList() {
		return commonMailDTOList;
	}
	public void setCommonMailDTOList(List<CommonMailDTO> commonMailDTOList) {
		this.commonMailDTOList = commonMailDTOList;
	}
	public String getIsSRMailSent() {
		return isSRMailSent;
	}
	public void setIsSRMailSent(String isSRMailSent) {
		this.isSRMailSent = isSRMailSent;
	}
	
}
