package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the disconnection_request_on_cr_mst database table.
 * 
 */
@Entity
@Table(name="disconnection_request_on_cr_mst")
@NamedQueries({
	@NamedQuery(name="DisconnectionRequestOnCrMst.findAll", query="SELECT d FROM DisconnectionRequestOnCrMst d"),
	@NamedQuery(name="DisconnectionRequestOnCrMst.updateDisconnectionStatus",query="UPDATE DisconnectionRequestOnCrMst d SET d.disconnectionStatus=:requestStatus WHERE d.requestId=:requestId")
})


@NamedNativeQueries({
	@NamedNativeQuery(name = "DisconnectionRequestOnCrMst.getRequestId", query = "SELECT 'DIS_CR_'+FORMAT(GETDATE(),'dd')+'_'+FORMAT(GETDATE(),'MM')+'_'+FORMAT(GETDATE(),'yyyy')+'_'+CAST(COALESCE(MAX(typeid),0)+1 AS VARCHAR)FROM disconnection_request_on_cr_mst")
	})
public class DisconnectionRequestOnCrMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false,insertable=false, updatable=false)
	private int typeid;

	@Column(insertable=false, updatable=false)
	private String actflag;

	@Column(name="billing_end_date")
	private String billingEndDate;

	@Column(name="disconnection_date")
	private String disconnectionDate;

	@Column(name="disconnection_request_date")
	private String disconnectionRequestDate;

	@Column(name="disconnection_status")
	private String disconnectionStatus;
	
	@Column(name="notice_period")
	private Integer noticePeriod;

	private String ip;

	@Column(name="request_date", insertable=false, updatable=false)
	private Timestamp requestDate;

	@Column(name="request_id")
	private String requestId;
	
	@Column(name="common_id")
	private String common_id;
	

	@Column(name="request_type", insertable=false, updatable=false)
	private String requestType;

	@Column(name="so_no")
	private String soNo;

	@Column(name="user_id")
	private String userId;

	public DisconnectionRequestOnCrMst() {
	}


	public Integer getNoticePeriod() {
		return noticePeriod;
	}

	public void setNoticePeriod(Integer noticePeriod) {
		this.noticePeriod = noticePeriod;
	}
	
	public String getCommon_id() {
		return common_id;
	}

	public void setCommon_id(String common_id) {
		this.common_id = common_id;
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public String getBillingEndDate() {
		return this.billingEndDate;
	}

	public void setBillingEndDate(String billingEndDate) {
		this.billingEndDate = billingEndDate;
	}

	public String getDisconnectionDate() {
		return this.disconnectionDate;
	}

	public void setDisconnectionDate(String disconnectionDate) {
		this.disconnectionDate = disconnectionDate;
	}

	public String getDisconnectionRequestDate() {
		return this.disconnectionRequestDate;
	}

	public void setDisconnectionRequestDate(String disconnectionRequestDate) {
		this.disconnectionRequestDate = disconnectionRequestDate;
	}
	

	public String getDisconnectionStatus() {
		return disconnectionStatus;
	}

	public void setDisconnectionStatus(String disconnectionStatus) {
		this.disconnectionStatus = disconnectionStatus;
	}

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Timestamp getRequestDate() {
		return this.requestDate;
	}

	public void setRequestDate(Timestamp requestDate) {
		this.requestDate = requestDate;
	}

	public String getRequestId() {
		return this.requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getRequestType() {
		return this.requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getSoNo() {
		return this.soNo;
	}

	public void setSoNo(String soNo) {
		this.soNo = soNo;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}