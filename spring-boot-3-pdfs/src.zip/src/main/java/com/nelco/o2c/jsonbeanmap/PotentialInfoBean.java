/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Amol.l
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PotentialInfoBean {
	
	@JsonProperty("per_page")
	private String perPage;
	
	@JsonProperty("count")
	private String count;
	
	@JsonProperty("page")
	private String page;
	
	@JsonProperty("moreRecords")
	private String moreRecords;

	public String getPerPage() {
		return perPage;
	}

	public void setPerPage(String perPage) {
		this.perPage = perPage;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getMoreRecords() {
		return moreRecords;
	}

	public void setMoreRecords(String moreRecords) {
		this.moreRecords = moreRecords;
	}

	@Override
	public String toString() {
		return "PotentialInfoBean [perPage=" + perPage + ", count=" + count + ", page=" + page + ", moreRecords="
				+ moreRecords + "]";
	}
	
	
}
