package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the payment_collection_invoicewise database table.
 * 
 */
@Entity
@Table(name="payment_collection_invoicewise")
@NamedQuery(name="PaymentCollectionInvoicewise.findAll", query="SELECT p FROM PaymentCollectionInvoicewise p")
public class PaymentCollectionInvoicewise implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private int typeid;

	@Column(insertable=false, updatable=false, length=2)
	private String actflag;

	@Column(name="collected_amt", precision=18, scale=2)
	private BigDecimal collectedAmt;

	@Column(name="invoice_no", length=50)
	private String invoiceNo;

	@Column(name="payment_date")
	private String paymentDate;

	@Column(name="payment_no", length=50)
	private String paymentNo;

	@Column(name="updated_on", insertable=false, updatable=false)
	private Timestamp updatedOn;

	private String updatedby;
	
	@Column(name="tds", precision=18, scale=2)
	private BigDecimal tds;

	public PaymentCollectionInvoicewise() {
	}



	public BigDecimal getTds() {
		return tds;
	}



	public void setTds(BigDecimal tds) {
		this.tds = tds;
	}



	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public BigDecimal getCollectedAmt() {
		return this.collectedAmt;
	}

	public void setCollectedAmt(BigDecimal collectedAmt) {
		this.collectedAmt = collectedAmt;
	}


	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getPaymentDate() {
		return this.paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getPaymentNo() {
		return this.paymentNo;
	}

	public void setPaymentNo(String paymentNo) {
		this.paymentNo = paymentNo;
	}

	public Timestamp getUpdatedOn() {
		return this.updatedOn;
	}

	public void setUpdatedOn(Timestamp updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getUpdatedby() {
		return this.updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

}