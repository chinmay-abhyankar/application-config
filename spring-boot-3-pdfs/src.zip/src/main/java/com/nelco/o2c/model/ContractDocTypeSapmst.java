package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the contract_doc_type_sapmst database table.
 * 
 */
@Entity
@Table(name="contract_doc_type_sapmst")
@NamedQuery(name="ContractDocTypeSapmst.findAll", query="SELECT c FROM ContractDocTypeSapmst c")
public class ContractDocTypeSapmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="cont_desc")
	private String contDesc;

	@Column(name="cont_sales_doc_type")
	private String contSalesDocType;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="contract_doc_type_sapmst_id")
	private int contractDocTypeSapmstId;

	@Column(name="created_date")
	private Timestamp createdDate;

	public ContractDocTypeSapmst() {
	}

	public String getContDesc() {
		return this.contDesc;
	}

	public void setContDesc(String contDesc) {
		this.contDesc = contDesc;
	}

	public String getContSalesDocType() {
		return this.contSalesDocType;
	}

	public void setContSalesDocType(String contSalesDocType) {
		this.contSalesDocType = contSalesDocType;
	}

	public int getContractDocTypeSapmstId() {
		return this.contractDocTypeSapmstId;
	}

	public void setContractDocTypeSapmstId(int contractDocTypeSapmstId) {
		this.contractDocTypeSapmstId = contractDocTypeSapmstId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

}