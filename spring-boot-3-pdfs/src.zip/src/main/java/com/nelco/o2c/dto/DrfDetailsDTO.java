/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.DrfDetails;
import com.nelco.o2c.model.DrfUploadDetail;

/**
 * @author Amol.l
 *
 */
public class DrfDetailsDTO implements Serializable {
	private static final long serialVersionUID = 21L;
	
	private String username;
	private Integer statusMstId;
	private DrfDetails drfDetails = new DrfDetails();
	private List<UploadTempFileDTO> uploadTempFileDTOList = new ArrayList<UploadTempFileDTO>();
	private List<DrfUploadDetail> drfUploadDetailList = new ArrayList<DrfUploadDetail>();
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Integer getStatusMstId() {
		return statusMstId;
	}
	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}
	public DrfDetails getDrfDetails() {
		return drfDetails;
	}
	public void setDrfDetails(DrfDetails drfDetails) {
		this.drfDetails = drfDetails;
	}
	public List<UploadTempFileDTO> getUploadTempFileDTOList() {
		return uploadTempFileDTOList;
	}
	public void setUploadTempFileDTOList(List<UploadTempFileDTO> uploadTempFileDTOList) {
		this.uploadTempFileDTOList = uploadTempFileDTOList;
	}
	public List<DrfUploadDetail> getDrfUploadDetailList() {
		return drfUploadDetailList;
	}
	public void setDrfUploadDetailList(List<DrfUploadDetail> drfUploadDetailList) {
		this.drfUploadDetailList = drfUploadDetailList;
	}
	

	
}
