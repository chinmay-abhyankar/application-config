package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.utility.DateUtil;


/**
 * The persistent class for the relocation_so database table.
 * 
 */
@Entity
@Table(name="relocation_so")
@NamedQueries({@NamedQuery(name="RelocationSo.findAll", query="SELECT r FROM RelocationSo r"),
	/*@NamedQuery(name="RelocationSo.findByCreatorIdAndDateRange", query="SELECT r FROM RelocationSo r "
			+ " inner join fetch r.relocationSoUserMapList ruser where r.createdDate "
			+ " between :fromDate and :toDate and ruser.userMstId = :userMstId order by r.relocationSoId desc"),*/
	@NamedQuery(name = "RelocationSo.getCurrentDayMaxCount",query = " select (count(r)+1) from RelocationSo "
			+ " r where r.createdDate between ?1 and ?2 ")})
@NamedNativeQueries({
	@NamedNativeQuery(name = "RelocationSo.findByCreatorIdAndDateRange",query = " SELECT distinct rs.relocation_so_id,"
			+ " rs.uniq_id,"
			+ " rs.old_equipment_so,"
			+ " rs.old_ship_to_party,rs.old_shtp_address,rs.new_shtp_address ,rs.relocation_type_mst_id ,"
			+ " rs.relocation_charges ,rs.is_submit ,convert(varchar, rs.created_date, 105) ,rs.modified_date ,rs.created_by ,"
			+ " rs.site_type_mst_id ,rs.po_number, case when so.so_number is null then 'N' else 'Y' end as so_number_flag,"
			+ " rtm.relocation_type_val "
			+ " FROM relocation_so rs inner join relocation_so_user_map rum on rs.relocation_so_id = rum.relocation_so_id "
			+ " left outer join so_orders so on rs.uniq_id = so.reloc_so_req_id "
			+ " left outer join  relocation_type_mst rtm on rs.relocation_type_mst_id = rtm.relocation_type_mst_id "
			+ " where rs.created_date between :fromDate and :toDate and rum.user_mst_id = :userMstId "
			+ " order by rs.relocation_so_id desc ")
})
public class RelocationSo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="relocation_so_id")
	private Integer relocationSoId;

	@Column(name="created_date",updatable=false)
	private String createdDate;

	@Column(name="is_submit")
	private String isSubmit;

	@Column(name="modified_date")
	private String modifiedDate;

	@Column(name="new_shtp_address")
	private String newShtpAddress;

	@Column(name="old_equipment_so")
	private String oldEquipmentSo;

	@Column(name="old_ship_to_party")
	private String oldShipToParty;

	@Column(name="old_shtp_address")
	private String oldShtpAddress;

	@Column(name="relocation_charges")
	private String relocationCharges;

	@Column(name="relocation_type_mst_id")
	private Integer relocationTypeMstId;

	@Column(name="uniq_id",updatable = false)
	private String uniqId;
	
	@Column(name = "created_by",updatable = false)
	private Integer createdBy;
	
	@Column(name = "site_type_mst_id")
	private Integer siteTypeMstId;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "relocation_so_id", referencedColumnName = "relocation_so_id", insertable = false, updatable = false)
	private Set<RelocationSoUserMap> relocationSoUserMapList;
	
	@Transient
	private String soFlag = "N";
	
	@Transient
	private String relocationTypeVal="";
	
	
	
	
	
	public String getRelocationTypeVal() {
		return relocationTypeVal;
	}

	public void setRelocationTypeVal(String relocationTypeVal) {
		this.relocationTypeVal = relocationTypeVal;
	}

	public String getSoFlag() {
		return soFlag;
	}

	public void setSoFlag(String soFlag) {
		this.soFlag = soFlag;
	}

	@Column(name = "po_number")
	private String poNumber;

	
	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public Integer getSiteTypeMstId() {
		return siteTypeMstId;
	}

	public void setSiteTypeMstId(Integer siteTypeMstId) {
		this.siteTypeMstId = siteTypeMstId;
	}

	public Set<RelocationSoUserMap> getRelocationSoUserMapList() {
		return relocationSoUserMapList;
	}

	public void setRelocationSoUserMapList(Set<RelocationSoUserMap> relocationSoUserMapList) {
		this.relocationSoUserMapList = relocationSoUserMapList;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public RelocationSo() {
	}

	public Integer getRelocationSoId() {
		return this.relocationSoId;
	}

	public void setRelocationSoId(Integer relocationSoId) {
		this.relocationSoId = relocationSoId;
	}

	public String getCreatedDate() {
		//return DateUtil.convertDateTimeToString(this.createdDate);
		return this.createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getIsSubmit() {
		return this.isSubmit;
	}

	public void setIsSubmit(String isSubmit) {
		this.isSubmit = isSubmit;
	}

	public String getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getNewShtpAddress() {
		return this.newShtpAddress;
	}

	public void setNewShtpAddress(String newShtpAddress) {
		this.newShtpAddress = newShtpAddress;
	}

	public String getOldEquipmentSo() {
		return this.oldEquipmentSo;
	}

	public void setOldEquipmentSo(String oldEquipmentSo) {
		this.oldEquipmentSo = oldEquipmentSo;
	}

	public String getOldShipToParty() {
		return this.oldShipToParty;
	}

	public void setOldShipToParty(String oldShipToParty) {
		this.oldShipToParty = oldShipToParty;
	}

	public String getOldShtpAddress() {
		return this.oldShtpAddress;
	}

	public void setOldShtpAddress(String oldShtpAddress) {
		this.oldShtpAddress = oldShtpAddress;
	}

	public String getRelocationCharges() {
		return this.relocationCharges;
	}

	public void setRelocationCharges(String relocationCharges) {
		this.relocationCharges = relocationCharges;
	}

	public Integer getRelocationTypeMstId() {
		return this.relocationTypeMstId;
	}

	public void setRelocationTypeMstId(Integer relocationTypeMstId) {
		this.relocationTypeMstId = relocationTypeMstId;
	}

	public String getUniqId() {
		return this.uniqId;
	}

	public void setUniqId(String uniqId) {
		this.uniqId = uniqId;
	}

}