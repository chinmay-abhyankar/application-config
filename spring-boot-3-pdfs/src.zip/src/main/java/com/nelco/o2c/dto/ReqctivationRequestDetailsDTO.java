package com.nelco.o2c.dto;

public class ReqctivationRequestDetailsDTO {
private String requestId="";
private String requestDate="";
private String businessHeadAppStatus="";
private String userId="";
private String disconnectionDate="";
private String businessHeadAppStatusCode="";
private String reactivationStatus="";
private String reactivationStatusCode="";
public String getRequestId() {
	return requestId;
}
public void setRequestId(String requestId) {
	this.requestId = requestId;
}
public String getRequestDate() {
	return requestDate;
}
public void setRequestDate(String requestDate) {
	this.requestDate = requestDate;
}
public String getBusinessHeadAppStatus() {
	return businessHeadAppStatus;
}
public void setBusinessHeadAppStatus(String businessHeadAppStatus) {
	this.businessHeadAppStatus = businessHeadAppStatus;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getDisconnectionDate() {
	return disconnectionDate;
}
public void setDisconnectionDate(String disconnectionDate) {
	this.disconnectionDate = disconnectionDate;
}
public String getBusinessHeadAppStatusCode() {
	return businessHeadAppStatusCode;
}
public void setBusinessHeadAppStatusCode(String businessHeadAppStatusCode) {
	this.businessHeadAppStatusCode = businessHeadAppStatusCode;
}
public String getReactivationStatus() {
	return reactivationStatus;
}
public void setReactivationStatus(String reactivationStatus) {
	this.reactivationStatus = reactivationStatus;
}
public String getReactivationStatusCode() {
	return reactivationStatusCode;
}
public void setReactivationStatusCode(String reactivationStatusCode) {
	this.reactivationStatusCode = reactivationStatusCode;
}

}
