package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the franchise_allocation_tracker database table.
 * 
 */
@Entity
@Table(name="franchise_allocation_tracker")
@NamedQuery(name="FranchiseAllocationTracker.findAll", query="SELECT f FROM FranchiseAllocationTracker f")
public class FranchiseAllocationTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="franchise_allocation_tracker_id")
	private Integer franchiseAllocationTrackerId;

	@Column(name="franchise_mst_id")
	private Integer franchiseMstId;

	@Column(name="franchisee_allocation_mst_id")
	private Integer franchiseeAllocationMstId;

	@Column(name="req_time")
	private String reqTime;

	public FranchiseAllocationTracker() {
	}

	public Integer getFranchiseAllocationTrackerId() {
		return franchiseAllocationTrackerId;
	}

	public void setFranchiseAllocationTrackerId(Integer franchiseAllocationTrackerId) {
		this.franchiseAllocationTrackerId = franchiseAllocationTrackerId;
	}

	public Integer getFranchiseMstId() {
		return franchiseMstId;
	}

	public void setFranchiseMstId(Integer franchiseMstId) {
		this.franchiseMstId = franchiseMstId;
	}

	public Integer getFranchiseeAllocationMstId() {
		return franchiseeAllocationMstId;
	}

	public void setFranchiseeAllocationMstId(Integer franchiseeAllocationMstId) {
		this.franchiseeAllocationMstId = franchiseeAllocationMstId;
	}

	public String getReqTime() {
		return reqTime;
	}

	public void setReqTime(String reqTime) {
		this.reqTime = reqTime;
	}

	

	

}