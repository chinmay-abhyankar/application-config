/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.DrfStatusTracker;

/**
 * @author Amol.l
 *
 */
public class DrfInfoDTO implements Serializable {

	private static final long serialVersionUID = 14L;

	private Integer drfDetailsId;
	private String zohoId;
	private String potentialName;
	private String businessLine;
	private String createdDate;
	private String closingDate;
	private Integer opportunityId;
	private String roleCode;
	private String userMstId;
	private String custName;
	private String marketSegment;
	private List<DrfStatusTracker> drfStatusTrackers = new ArrayList<DrfStatusTracker>();
	private String opHead;
	private String opHeadApprFlg;
	private String pmgtHead;
	private String pmgtHeadApprFlg;
	private String preSalesHead;
	private String preSalesHeadApprFlg;
	
	public String getOpHead() {
		return opHead;
	}

	public void setOpHead(String opHead) {
		this.opHead = opHead;
	}

	public String getOpHeadApprFlg() {
		return opHeadApprFlg;
	}

	public void setOpHeadApprFlg(String opHeadApprFlg) {
		this.opHeadApprFlg = opHeadApprFlg;
	}

	public String getPmgtHead() {
		return pmgtHead;
	}

	public void setPmgtHead(String pmgtHead) {
		this.pmgtHead = pmgtHead;
	}

	public String getPmgtHeadApprFlg() {
		return pmgtHeadApprFlg;
	}

	public void setPmgtHeadApprFlg(String pmgtHeadApprFlg) {
		this.pmgtHeadApprFlg = pmgtHeadApprFlg;
	}

	public String getPreSalesHead() {
		return preSalesHead;
	}

	public void setPreSalesHead(String preSalesHead) {
		this.preSalesHead = preSalesHead;
	}

	public String getPreSalesHeadApprFlg() {
		return preSalesHeadApprFlg;
	}

	public void setPreSalesHeadApprFlg(String preSalesHeadApprFlg) {
		this.preSalesHeadApprFlg = preSalesHeadApprFlg;
	}

	public String getMarketSegment() {
		return marketSegment;
	}

	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}

	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getZohoId() {
		return zohoId;
	}

	public void setZohoId(String zohoId) {
		this.zohoId = zohoId;
	}

	public String getPotentialName() {
		return potentialName;
	}

	public void setPotentialName(String potentialName) {
		this.potentialName = potentialName;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getClosingDate() {
		return closingDate;
	}

	public void setClosingDate(String closingDate) {
		this.closingDate = closingDate;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public List<DrfStatusTracker> getDrfStatusTrackers() {
		return drfStatusTrackers;
	}

	public void setDrfStatusTrackers(List<DrfStatusTracker> drfStatusTrackers) {
		this.drfStatusTrackers = drfStatusTrackers;
	}

	public String getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(String userMstId) {
		this.userMstId = userMstId;
	}

}
