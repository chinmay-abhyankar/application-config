package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the eval_type_mst database table.
 * 
 */
@Entity
@Table(name="eval_type_mst")
@NamedQuery(name="EvalTypeMst.findAll", query="SELECT e FROM EvalTypeMst e")
public class EvalTypeMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="eval_type_mst_id")
	private Integer evalTypeMstId;

	@Column(name="eval_code")
	private String evalCode;

	@Column(name="eval_val")
	private String evalVal;

	public Integer getEvalTypeMstId() {
		return evalTypeMstId;
	}

	public void setEvalTypeMstId(Integer evalTypeMstId) {
		this.evalTypeMstId = evalTypeMstId;
	}

	public String getEvalCode() {
		return evalCode;
	}

	public void setEvalCode(String evalCode) {
		this.evalCode = evalCode;
	}

	public String getEvalVal() {
		return evalVal;
	}

	public void setEvalVal(String evalVal) {
		this.evalVal = evalVal;
	}

	

}