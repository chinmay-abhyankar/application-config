package com.nelco.o2c.dto;

public class SalesReturnListDTO {
	private String id;
	private String uniqId;
	private String invoiceNoEquipment;	
	private String invoiceNoBW;
	private String customerNum;
	private String customerName;
	private String salesOrderNoBW;
	private String salesOrderNoEquipment;
	private String materialNum;
	private String materialDesc;
	private String mdApproved;
	private String returnType;
	private String creditNoteNoEquipment;
	private String creditNoteNoBW;
	private String disconnectionDate;
	private String status;
	private String statusName;
	
	private String equipmentCreditNoteAmount;
	private String equipmentCreditNoteDate;
	private String bwCreditNoteDate;
	private String bwCreditPostingDate;
	private String bwCreditAmount;
	private String consumtionNo;
	
	public String getConsumtionNo() {
		return consumtionNo;
	}
	public void setConsumtionNo(String consumtionNo) {
		this.consumtionNo = consumtionNo;
	}
	public String getBwCreditNoteDate() {
		return bwCreditNoteDate;
	}
	public void setBwCreditNoteDate(String bwCreditNoteDate) {
		this.bwCreditNoteDate = bwCreditNoteDate;
	}
	public String getBwCreditPostingDate() {
		return bwCreditPostingDate;
	}
	public void setBwCreditPostingDate(String bwCreditPostingDate) {
		this.bwCreditPostingDate = bwCreditPostingDate;
	}
	public String getBwCreditAmount() {
		return bwCreditAmount;
	}
	public void setBwCreditAmount(String bwCreditAmount) {
		this.bwCreditAmount = bwCreditAmount;
	}
	public String getUniqId() {
		return uniqId;
	}
	public void setUniqId(String uniqId) {
		this.uniqId = uniqId;
	}
	public String getEquipmentCreditNoteAmount() {
		return equipmentCreditNoteAmount;
	}
	public void setEquipmentCreditNoteAmount(String equipmentCreditNoteAmount) {
		this.equipmentCreditNoteAmount = equipmentCreditNoteAmount;
	}
	public String getEquipmentCreditNoteDate() {
		return equipmentCreditNoteDate;
	}
	public void setEquipmentCreditNoteDate(String equipmentCreditNoteDate) {
		this.equipmentCreditNoteDate = equipmentCreditNoteDate;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getInvoiceNoEquipment() {
		return invoiceNoEquipment;
	}
	public void setInvoiceNoEquipment(String invoiceNoEquipment) {
		this.invoiceNoEquipment = invoiceNoEquipment;
	}
	public String getInvoiceNoBW() {
		return invoiceNoBW;
	}
	public void setInvoiceNoBW(String invoiceNoBW) {
		this.invoiceNoBW = invoiceNoBW;
	}
	public String getCustomerNum() {
		return customerNum;
	}
	public void setCustomerNum(String customerNum) {
		this.customerNum = customerNum;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getSalesOrderNoBW() {
		return salesOrderNoBW;
	}
	public void setSalesOrderNoBW(String salesOrderNoBW) {
		this.salesOrderNoBW = salesOrderNoBW;
	}
	public String getSalesOrderNoEquipment() {
		return salesOrderNoEquipment;
	}
	public void setSalesOrderNoEquipment(String salesOrderNoEquipment) {
		this.salesOrderNoEquipment = salesOrderNoEquipment;
	}
	public String getMaterialNum() {
		return materialNum;
	}
	public void setMaterialNum(String materialNum) {
		this.materialNum = materialNum;
	}
	public String getMaterialDesc() {
		return materialDesc;
	}
	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}
	public String getMdApproved() {
		return mdApproved;
	}
	public void setMdApproved(String mdApproved) {
		this.mdApproved = mdApproved;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	public String getCreditNoteNoEquipment() {
		return creditNoteNoEquipment;
	}
	public void setCreditNoteNoEquipment(String creditNoteNoEquipment) {
		this.creditNoteNoEquipment = creditNoteNoEquipment;
	}
	public String getCreditNoteNoBW() {
		return creditNoteNoBW;
	}
	public void setCreditNoteNoBW(String creditNoteNoBW) {
		this.creditNoteNoBW = creditNoteNoBW;
	}
	public String getDisconnectionDate() {
		return disconnectionDate;
	}
	public void setDisconnectionDate(String disconnectionDate) {
		this.disconnectionDate = disconnectionDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	
	
}
