/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.nelco.o2c.utility.Constants;

/**
 * @author Jayashankar.r
 *
 */
public class LeadsBean {

	private List<RowBean> rowList;

	@JsonProperty("row")
	private Object rowObj;

	public Object getRowObj() {
		return rowObj;
	}

	// setter logic required due to capture dynamic behaviour of response i.e,
	// incase of single recored json object returned and incase of multiple record
	// array of json objects returned
	@SuppressWarnings("unchecked")
	public void setRowObj(Object rowObj) {
		rowList = new ArrayList<RowBean>();
		if (rowObj instanceof Map) {
			LinkedHashMap<String, Object> rowMap = (LinkedHashMap<String, Object>) rowObj;
			RowBean rowBean = new RowBean();
			rowBean.setNo(rowMap.get(Constants.NO).toString());
			List<LinkedHashMap<String, Object>> flMapList = (List<LinkedHashMap<String, Object>>) rowMap
					.get(Constants.FL);
			List<ValContentBean> flList = new ArrayList<ValContentBean>();
			for (LinkedHashMap<String, Object> linkedHashMap : flMapList) {
				ValContentBean valBean = new ValContentBean();
				valBean.setVal(linkedHashMap.get(Constants.VAL).toString());
				valBean.setContent(linkedHashMap.get(Constants.CONTENT).toString());
				flList.add(valBean);
			}

			rowBean.setFlList(flList);
			this.rowList.add(rowBean);
		} else {

			List<LinkedHashMap<String, Object>> rowMapList = (List<LinkedHashMap<String, Object>>) rowObj;

			for (LinkedHashMap<String, Object> linkedHashMapRow : rowMapList) {
				RowBean rowBean = new RowBean();
				rowBean.setNo(linkedHashMapRow.get(Constants.NO).toString());
				List<LinkedHashMap<String, Object>> flMapList = (List<LinkedHashMap<String, Object>>) linkedHashMapRow
						.get(Constants.FL);
				List<ValContentBean> flList = new ArrayList<ValContentBean>();
				for (LinkedHashMap<String, Object> linkedHashMapVal : flMapList) {
					ValContentBean valBean = new ValContentBean();
					valBean.setVal(linkedHashMapVal.get(Constants.VAL).toString());
					valBean.setContent(linkedHashMapVal.get(Constants.CONTENT).toString());
					flList.add(valBean);
				}

				rowBean.setFlList(flList);
				this.rowList.add(rowBean);
			}
		}
		this.rowObj = rowObj;
	}

	public List<RowBean> getRowList() {
		return rowList;
	}

	public void setRowList(List<RowBean> rowList) {
		this.rowList = rowList;
	}

}
