package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the order_type_mst database table.
 * 
 */
@Entity
@Table(name="order_type_mst")
@NamedQuery(name="OrderTypeMst.findAll", query="SELECT o FROM OrderTypeMst o where o.isActive = 'Y'")
public class OrderTypeMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="order_type_mst_id")
	private Integer orderTypeMstId;

	@Column(name="is_active")
	private String isActive;

	@Column(name="order_type_code")
	private String orderTypeCode;

	@Column(name="order_type_val")
	private String orderTypeVal;

	public OrderTypeMst() {
	}

	public Integer getOrderTypeMstId() {
		return this.orderTypeMstId;
	}

	public void setOrderTypeMstId(Integer orderTypeMstId) {
		this.orderTypeMstId = orderTypeMstId;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getOrderTypeCode() {
		return this.orderTypeCode;
	}

	public void setOrderTypeCode(String orderTypeCode) {
		this.orderTypeCode = orderTypeCode;
	}

	public String getOrderTypeVal() {
		return this.orderTypeVal;
	}

	public void setOrderTypeVal(String orderTypeVal) {
		this.orderTypeVal = orderTypeVal;
	}

}