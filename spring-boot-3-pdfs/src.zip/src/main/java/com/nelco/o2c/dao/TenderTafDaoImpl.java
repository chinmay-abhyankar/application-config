/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.EmailDocDTO;
import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.BidTypeMst;
import com.nelco.o2c.model.ClauseMst;
import com.nelco.o2c.model.EvalTypeMst;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.LeadBidderMst;
import com.nelco.o2c.model.LeaseMst;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.PreCriteria;
import com.nelco.o2c.model.RiskMst;
import com.nelco.o2c.model.StatusMst;
import com.nelco.o2c.model.Taf;
import com.nelco.o2c.model.TafDetails;
import com.nelco.o2c.model.TafMst;
import com.nelco.o2c.model.TafStatusTracker;
import com.nelco.o2c.model.TendBidDet;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class TenderTafDaoImpl implements TenderTafDao {

	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	CommonPotentialsDao commonPotentialsDao;

	Query query;

	@SuppressWarnings("unchecked")
	@Override
	public List<OppDetails> getOppDetailsByOppId(Integer oppId) {
		try {
			// TODO Auto-generated method stub
			query = em.createQuery(
					" select od.oppDetailsId,od.opportunityId,od.val,od.content from OppDetails od where od.opportunityId = ?1 ");
			query.setParameter(1, oppId);
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			List<OppDetails> oppDetailList = new ArrayList<OppDetails>();
			for (Object[] objects : resultList) {
				OppDetails oppDetails = new OppDetails();
				oppDetails.setOppDetailsId((Integer) objects[0]);
				oppDetails.setOpportunityId((Integer) objects[1]);
				oppDetails.setVal((String) objects[2]);
				oppDetails.setContent((String) objects[3]);

				oppDetailList.add(oppDetails);
			}
			return oppDetailList;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public TendBidDet getTenderBidDetailsByOppId(Integer oppId) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("TendBidDet.findByOppId", TendBidDet.class);
			query.setParameter(1, oppId);
			List<TendBidDet> tendBidList = query.getResultList();
			TendBidDet tendBidDet = tendBidList != null && tendBidList.size() > 0 ? tendBidList.get(0)
					: new TendBidDet();
			tendBidDet.setOpportunityId(oppId);
			return tendBidDet;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PreCriteria> getPreCriteriaByOppId(Integer oppId) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("PreCriteria.findByOppId", PreCriteria.class);
			query.setParameter(1, oppId);
			List<PreCriteria> preCriteriaList = query.getResultList();
			return preCriteriaList != null ? preCriteriaList : new ArrayList<PreCriteria>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppUploadDetail> getOppUploadDetailsByOppId(Integer oppId) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("OppUploadDetail.findByOppId", OppUploadDetail.class);
			query.setParameter(1, oppId);
			List<OppUploadDetail> oppUploadDetailList = query.getResultList();
			return oppUploadDetailList != null ? oppUploadDetailList : new ArrayList<OppUploadDetail>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FileTypeMst> getFileTypeList() {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("FileProcValMst.getFileTypesByProcess");
			// query.setParameter(1, tAFPROCESSID);
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<FileTypeMst> filetypeList = query.getResultList();
			return filetypeList != null ? filetypeList : new ArrayList<FileTypeMst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserEmailDetailsBean> getVerticalHeads() {
		try {
			// TODO Auto-generated method stub
			query = em.createQuery(
					"select um.userMstId,um.userName,userEmail from UserMst um where um.subDepMstId in (1,2,5) and um.headFlag = 'Y' and um.isActive = 'Y' ");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<Object[]> userRes = (List<Object[]>) query.getResultList();
			List<UserEmailDetailsBean> verticalHeads = new ArrayList<UserEmailDetailsBean>();
			for (Object[] objects : userRes) {
				UserEmailDetailsBean userEmailDetailsBean = new UserEmailDetailsBean();
				userEmailDetailsBean.setUserId(((Integer) objects[0]).toString());
				userEmailDetailsBean.setUserName((String) objects[1]);
				userEmailDetailsBean.setUserMail((String) objects[2]);
				verticalHeads.add(userEmailDetailsBean);
			}
			return verticalHeads;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserEmailDetailsBean> getSalesHeads() {
		try {
			// TODO Auto-generated method stub
			query = em.createQuery(
					"select um.userMstId,um.userName,userEmail from UserMst um where um.deptMstId =1 and um.headFlag = 'Y' and um.isActive = 'Y' ");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<Object[]> userRes = (List<Object[]>) query.getResultList();
			List<UserEmailDetailsBean> salesHeads = new ArrayList<UserEmailDetailsBean>();
			for (Object[] objects : userRes) {
				UserEmailDetailsBean userEmailDetailsBean = new UserEmailDetailsBean();
				userEmailDetailsBean.setUserId(((Integer) objects[0]).toString());
				userEmailDetailsBean.setUserName((String) objects[1]);
				userEmailDetailsBean.setUserMail((String) objects[2]);
				salesHeads.add(userEmailDetailsBean);
			}
			return salesHeads;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<LeadBidderMst> getLeadBidderList() {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("LeadBidderMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<LeadBidderMst> leadBidders = query.getResultList();
			return leadBidders != null ? leadBidders : new ArrayList<LeadBidderMst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<LeaseMst> getLeaseList() {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("LeaseMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<LeaseMst> leaseList = query.getResultList();
			return leaseList != null ? leaseList : new ArrayList<LeaseMst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ClauseMst> getClauseList() {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("ClauseMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<ClauseMst> clauseList = query.getResultList();
			return clauseList != null ? clauseList : new ArrayList<ClauseMst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public void saveTenderBidDetails(TendBidDet tenderBidDetails, String sbu) {
		try {
			// TODO Auto-generated method stub
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			tenderBidDetails.setCreatedDate(currTime);
			TendBidDet tenderBidDetailsTemp = em.merge(tenderBidDetails);
			if(tenderBidDetails.getTendBidDetId()==null)
				em.refresh(tenderBidDetailsTemp);
			CommonDTO commonDTO = new CommonDTO();
			commonDTO.setOppId(tenderBidDetails.getOpportunityId());
			Taf existingTaf = getTafHeaderByOppId(commonDTO);
			Taf savedTaf = null;
			if (existingTaf == null) {
				// creating taf
				Taf taf = new Taf();
				taf.setOpportunityId(tenderBidDetailsTemp.getOpportunityId());
				taf.setLeadBidderMstId(tenderBidDetailsTemp.getLeadBidderMstId());
				taf.setTendFees(tenderBidDetailsTemp.getTendAmt());
				taf.setPrebidMeetDate(DateUtil.convertDateToSqlDate(tenderBidDetailsTemp.getPrebidMeetDate()));
				taf.setScopeProj(tenderBidDetailsTemp.getProjScope());
				taf.setSbu(sbu);
				taf.setTenderNo(tenderBidDetailsTemp.getTenderNo());
				String currDate = DateUtil.getCurrentISTDateOnlyAsString(DateUtil.DATE_ONLY_FORMAT_MSSQL);
				taf.setCreatedDate(currDate);
				taf.setBidSubDate(currDate);
				taf.setProjType(commonPotentialsDao.getNatureByOppId(tenderBidDetailsTemp.getOpportunityId()));
				// status tracker
				savedTaf = em.merge(taf);
				TafStatusTracker tafStatusTracker = new TafStatusTracker();
				tafStatusTracker.setTafId(savedTaf.getTafId());
				tafStatusTracker.setStatusMstId(7);
				tafStatusTracker.setStatusReqDate(currTime);
				tafStatusTracker.setReqBy(tenderBidDetails.getCreatedBy());
				em.merge(tafStatusTracker);
			} else {
				existingTaf.setOpportunityId(tenderBidDetailsTemp.getOpportunityId());
				existingTaf.setLeadBidderMstId(tenderBidDetailsTemp.getLeadBidderMstId());
				existingTaf.setTendFees(tenderBidDetailsTemp.getTendAmt());
				existingTaf.setPrebidMeetDate(DateUtil.convertDateToSqlDate(tenderBidDetailsTemp.getPrebidMeetDate()));
				existingTaf.setScopeProj(tenderBidDetailsTemp.getProjScope());
				existingTaf.setTenderNo(tenderBidDetailsTemp.getTenderNo());
				existingTaf.setProjType(commonPotentialsDao.getNatureByOppId(tenderBidDetailsTemp.getOpportunityId()));
				savedTaf = em.merge(existingTaf);
			}

		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public List<PreCriteria> savePreCriteriaDetails(List<PreCriteria> preCriterias) {
		try {
			// TODO Auto-generated method stub
			List<PreCriteria> preCriteriasReturn = new ArrayList<PreCriteria>();
			for (PreCriteria preCriteria : preCriterias) {
				String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
				preCriteria.setCreatedDate(currTime);
				PreCriteria preCriteriaTemp = em.merge(preCriteria);
				if(preCriteria.getPreCriteriaId()==null)
					em.refresh(preCriteriaTemp);
				preCriteriasReturn.add(preCriteriaTemp);
			}
			return preCriteriasReturn;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public OppUploadDetail saveOppUploadDetails(OppUploadDetail oppUploadDetail) {
		try {
			// TODO Auto-generated method stub
			String currTime2 = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			oppUploadDetail.setUploadTime(currTime2);
			oppUploadDetail.setCreatedDate(new Date());
			OppUploadDetail oppUploadDetailTemp = em.merge(oppUploadDetail);
			if(oppUploadDetail.getOppUploadDetailsId()==null)
				em.refresh(oppUploadDetailTemp);
			return oppUploadDetailTemp;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BidTypeMst> getBidTypeList() {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("BidTypeMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<BidTypeMst> bidTypes = query.getResultList();
			return bidTypes != null ? bidTypes : new ArrayList<BidTypeMst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EvalTypeMst> getEvalTypeList() {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("EvalTypeMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<EvalTypeMst> evalTypes = query.getResultList();
			return evalTypes != null ? evalTypes : new ArrayList<EvalTypeMst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RiskMst> getRiskList() {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("RiskMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<RiskMst> risks = query.getResultList();
			return risks != null ? risks : new ArrayList<RiskMst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public Taf getTafHeaderByOppId(CommonDTO commonDTO) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("Taf.findByOppId");
			query.setParameter(1, commonDTO.getOppId());
			return (Taf) query.getSingleResult();
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TafMst> getTafList() {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("TafMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			return query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TafDetails> getTafDetails(Integer tafId) {
		try {
			query = em.createNamedQuery("TafDetails.getTafMstByTafId");
			query.setParameter(1, tafId);
			List<TafDetails> detailsList = query.getResultList();
			return detailsList != null ? detailsList : new ArrayList<TafDetails>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public StatusMst getTafStatus(Integer tafId) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("TafStatusTracker.findByTafId");
			query.setParameter(1, tafId);
			query.setMaxResults(1);
			List<TafStatusTracker> tafTrackerList = query.getResultList();
			StatusMst status = new StatusMst();
			if (tafTrackerList != null && tafTrackerList.size() > 0) {
				status = tafTrackerList.get(0).getStatusMst();
			}
			return status;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public Taf saveTafHeader(Taf tafHeader) {
		// TODO Auto-generated method stub
		String currDate = DateUtil.getCurrentISTDateOnlyAsString(DateUtil.DATE_ONLY_FORMAT_MSSQL);
		tafHeader.setCreatedDate(currDate);
		Taf savedTempTaf = em.merge(tafHeader);
		/*if(tafHeader.getTafId()==null)
			em.refresh(savedTempTaf);*/
		return savedTempTaf;
	}

	@Override
	public List<TafMst> saveTafList(List<TafMst> tafList, Taf taf) {
		try {
			// TODO Auto-generated method stub
			for (TafMst tafMst : tafList) {
				TafDetails tafDetails = tafMst.getTafDetails();
				tafDetails.setTafId(taf.getTafId());
				tafDetails.setTafMstId(tafMst.getTafMstId());
				String currDate = DateUtil.getCurrentISTDateOnlyAsString(DateUtil.DATE_ONLY_FORMAT_MSSQL);
				tafDetails.setCreatedDate(currDate);
				TafDetails savedTafDetails = em.merge(tafDetails);
				if (tafDetails.getTafDetailsId() == null)
					em.refresh(savedTafDetails);
				tafMst.setTafDetails(savedTafDetails);
			}
			return tafList;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<UserEmailDetailsBean> getPreBidResource() {
		try {
			// TODO Auto-generated method stub
			query = em.createQuery(
					"select um.userMstId,um.userName,userEmail from UserMst um where um.roleId = 7 and um.isActive = 'Y' ");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<Object[]> userRes = (List<Object[]>) query.getResultList();
			List<UserEmailDetailsBean> prebids = new ArrayList<UserEmailDetailsBean>();
			for (Object[] objects : userRes) {
				UserEmailDetailsBean userEmailDetailsBean = new UserEmailDetailsBean();
				userEmailDetailsBean.setUserId(((Integer) objects[0]).toString());
				userEmailDetailsBean.setUserName((String) objects[1]);
				userEmailDetailsBean.setUserMail((String) objects[2]);
				prebids.add(userEmailDetailsBean);
			}
			return prebids;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public TafStatusTracker saveTafStatusTracker(TafStatusTracker tafStatusTracker) {
		try {
			// TODO Auto-generated method stub
			TafStatusTracker savedTracker = em.merge(tafStatusTracker);
			if (tafStatusTracker.getTafStatusTrackerId() != null)
				em.refresh(tafStatusTracker);
			return savedTracker;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public Taf getTafById(Integer tafId) {
		// TODO Auto-generated method stub
		return em.find(Taf.class, tafId);
	}

	@Transactional
	@Override
	public void updateEmailSentFlag(EmailDocDTO emailDocDTO) {
		try {
			// TODO Auto-generated method stub
			if (emailDocDTO.getRespMatrixDetailsId() != null) {
				query = em.createQuery("update RespMatrixDetails rm set rm.emailSentFlag='Y' where rm.respMatrixDetailsId=?1");
				query.setParameter(1, emailDocDTO.getRespMatrixDetailsId());
			}
			else {
				query = em.createQuery("update PreSalesRespMatrix pre set pre.emailSentFlag='Y' where pre.preSalesRespMatrixId=?1");
				query.setParameter(1, emailDocDTO.getPreSalesRespMatrixId());
			}
			query.executeUpdate();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}
}
