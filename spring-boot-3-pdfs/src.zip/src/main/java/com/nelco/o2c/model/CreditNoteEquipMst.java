package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the credit_note_equip_mst database table.
 * 
 */
@Entity
@Table(name="credit_note_equip_mst")
@NamedQueries({@NamedQuery(name="CreditNoteEquipMst.findAll", query="SELECT h FROM CreditNoteEquipMst h ")
,@NamedQuery(name="CreditNoteEquipMst.findByCrNo",query="select h from CreditNoteEquipMst h where h.creditNoteNo=?1")		
})
public class CreditNoteEquipMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String amount;

	@Column(name="cancelled_invoice_no")
	private String cancelledInvoiceNo;

	@Column(name="creation_date")
	private String creationDate;

	@Column(name="credit_note_no")
	private String creditNoteNo;

	public CreditNoteEquipMst() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}	

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCancelledInvoiceNo() {
		return this.cancelledInvoiceNo;
	}

	public void setCancelledInvoiceNo(String cancelledInvoiceNo) {
		this.cancelledInvoiceNo = cancelledInvoiceNo;
	}

	public String getCreationDate() {
		return this.creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getCreditNoteNo() {
		return this.creditNoteNo;
	}

	public void setCreditNoteNo(String creditNoteNo) {
		this.creditNoteNo = creditNoteNo;
	}

}