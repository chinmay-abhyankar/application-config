package com.nelco.o2c.controller;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.FranchiseDropDownDTO;
import com.nelco.o2c.dto.FranchiseeAllocDTO;
import com.nelco.o2c.dto.FranchiseeAllocEngineerDTO;
import com.nelco.o2c.dto.FranchiseeAllocFormDTO;
import com.nelco.o2c.dto.FranchiseeDTO;
import com.nelco.o2c.dto.FranchiseeListFormDTO;
import com.nelco.o2c.dto.HsoUploadDTO;
import com.nelco.o2c.dto.INCUploadDTO;
import com.nelco.o2c.dto.UpdateFranchiseDTO;
import com.nelco.o2c.model.Delivery;
import com.nelco.o2c.model.FranchiseeAllocEngMst;
import com.nelco.o2c.model.FranchiseeAllocationMst;
import com.nelco.o2c.service.FranshiseeAllocService;
import com.nelco.o2c.service.UploadActConfService;

@RestController
public class FranchiseeAllocController {
	@Autowired
	FranshiseeAllocService franshiseeAllocService;
	
	@Autowired
	UploadActConfService uploadActConfService;

	@RequestMapping(value = "/getSiteSurveyAutoComplete.do", method = RequestMethod.GET)
	public FranchiseeAllocDTO getListCustomerAutoComplete(HttpServletRequest request) {
		FranchiseeAllocDTO franchiseeAllocDTO = new FranchiseeAllocDTO();
		franchiseeAllocDTO.setSiteSurveyList(franshiseeAllocService.getListSiteSurveyMaster(request));
		return franchiseeAllocDTO;
	}

	@RequestMapping(value = "/getFranchiseeFormJson.do", method = RequestMethod.GET)
	public FranchiseeAllocFormDTO getFranchiseeFormJson() {
		FranchiseeAllocFormDTO siteSurveyFormDTO = new FranchiseeAllocFormDTO();
		franshiseeAllocService.getFranchiseeFormMasters(siteSurveyFormDTO);
		return siteSurveyFormDTO;
	}

	// This is for PMGT for creation of franchisee allocation
	@RequestMapping(value = "/getDeliveryListForPMGT.do", method = RequestMethod.GET)
	public List<FranchiseeListFormDTO> getDeliveryListForPMGT(HttpServletRequest request) {
		FranchiseeAllocFormDTO siteSurveyFormDTO = new FranchiseeAllocFormDTO();
		return franshiseeAllocService.getDeliveryListForPMGT(siteSurveyFormDTO, request);
		// return siteSurveyFormDTO;
	}

	// This is for CS for creation of franchisee allocation
	@RequestMapping(value = "/getFranchiseeAllocListForCS.do", method = RequestMethod.GET)
	public List<FranchiseeListFormDTO> getFranchiseeAllocListForCS(HttpServletRequest request) {
		FranchiseeAllocFormDTO siteSurveyFormDTO = new FranchiseeAllocFormDTO();
		return franshiseeAllocService.getFranchiseeAllocListForCS(request);
		// return siteSurveyFormDTO;
	}

	// This is for CS for creation of franchisee co-ordinator
	@RequestMapping(value = "/getFranchiseeAllocListForFC.do", method = RequestMethod.GET)
	public List<FranchiseeListFormDTO> getFranchiseeAllocListForFC(HttpServletRequest request) {
		FranchiseeAllocFormDTO siteSurveyFormDTO = new FranchiseeAllocFormDTO();
		return franshiseeAllocService.getFranchiseeAllocListForFranhisee(request);
		// return siteSurveyFormDTO;
	}

	// This is for Saving Engineer For Franchisee Co-ordinator
	@RequestMapping(value = "/saveFranchiseeEngineer.do", method = RequestMethod.POST)
	public FranchiseeAllocEngMst saveFranchiseeAllocSurveyEngineer(@RequestBody FranchiseeAllocEngineerDTO franchiseeAllocEngineerDTO) {
		return franshiseeAllocService.saveFranchiseeAllocSurveyEngineer(franchiseeAllocEngineerDTO);
	}

	// This is for getting engineer by site survey id and franchisee
	@RequestMapping(value = "/getFranchiseeEngineerById.do", method = RequestMethod.GET)
	public FranchiseeAllocEngMst getFranchiseeEngineerById(HttpServletRequest request) {
		return franshiseeAllocService.getEngineerById(request);
	}
	// This is for getting engineer list by site survey id and franchisee
	@RequestMapping(value = "/getEngineerListByFranchiseeAllocIdFrachiseeId.do", method = RequestMethod.GET)
	public List<FranchiseeAllocEngMst> getEngineerListBySiteIdFrachiseeId(HttpServletRequest request) {
		return franshiseeAllocService.getEngineerListBySiteIdFrachiseeId(request);
	}

	@RequestMapping(value = "/updateFranchiseeAllocFranchisee.do", method = RequestMethod.POST)
	public FranchiseeAllocationMst updateFranchiseeAllocFranchisee(@RequestBody UpdateFranchiseDTO input) {
		return franshiseeAllocService.updateFranchiseeAllocFranchisee(input);
	}

	@RequestMapping(value = "/getFranchiseeById.do", method = RequestMethod.GET)
	public List<FranchiseeListFormDTO> getDeliveryById(HttpServletRequest request) {
		return franshiseeAllocService.getDeliveryById(request);
	}

	@RequestMapping(value = "/saveFranchiseeAllocation.do", method = RequestMethod.POST)
	public FranchiseeAllocationMst saveFranchiseeAllocation(@RequestBody FranchiseeDTO franchiseeDTO) {		
		System.out.println("Hiii");
		return franshiseeAllocService.saveFranchiseeAllocation(franchiseeDTO);		
	}
	
	@RequestMapping(value = "/getDeliveryList.do", method = RequestMethod.GET)
	public List<Delivery> getDeliveryList() {		
		System.out.println("Hiii");
		return franshiseeAllocService.getDeliveryList();		
	}

	@RequestMapping(value = "/submitFranchiseeAllocation.do", method = RequestMethod.POST)
	public FranchiseeAllocationMst submitFranchiseeAllocation(@RequestBody FranchiseeDTO franchiseeDTO) {		
//		System.out.println("Hiii");
		return franshiseeAllocService.submitFranchiseeAllocation(franchiseeDTO);		
	}
	
	@RequestMapping(value = "/acceptFranchiseEngineer.do",method = RequestMethod.POST)
	public CommonDTO acceptFranchiseEngineer(@RequestBody CommonDTO commonDTOInput) {
		return franshiseeAllocService.acceptFranchiseEngineer(commonDTOInput);
	}
	
	@RequestMapping(value = "/uploadActConf.do",method = RequestMethod.POST)
	public HsoUploadDTO uploadActConf(MultipartHttpServletRequest request,@RequestParam String userMstId) throws Exception  {
		HsoUploadDTO hsoUploadDTO = new HsoUploadDTO();
		hsoUploadDTO.setUserMstId(Integer.valueOf(userMstId));
		
		Iterator<String> fileNames = request.getFileNames();
		
		if(fileNames.hasNext()) {
			MultipartFile file = request.getFile(fileNames.next());
			hsoUploadDTO =uploadActConfService.uploadActConf(hsoUploadDTO,file);
		}
		
		return hsoUploadDTO;
	}
	
	@RequestMapping(value = "/getInCDropDowns.do",method = RequestMethod.POST)
	public FranchiseDropDownDTO getInCDropDowns(@RequestBody FranchiseDropDownDTO inputFranchiseDropDownDTO) {
		return franshiseeAllocService.getInCDropDowns(inputFranchiseDropDownDTO);
	}
	
	//This is for bulk upload for Installation and Commissioning request for PMGT login
	@RequestMapping(value = "/uploadINCRequest.do", method = RequestMethod.POST)
	public INCUploadDTO uploadINCRequest(MultipartHttpServletRequest request,@RequestParam String userMstId) throws Exception {
		INCUploadDTO iNCUploadDTO=new INCUploadDTO();		
		MultipartFile file = request.getFile("incRequestFile");
		if(franshiseeAllocService.validateINCRequest(file, userMstId,iNCUploadDTO)){
			iNCUploadDTO = franshiseeAllocService.uploadINCRequest(file, userMstId);
			
		}else{
			iNCUploadDTO.setUserMstId(Integer.parseInt(userMstId));
			return iNCUploadDTO;
		}
		return iNCUploadDTO;
		
	}
}
