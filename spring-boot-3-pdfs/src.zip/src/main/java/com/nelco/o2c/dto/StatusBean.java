package com.nelco.o2c.dto;

public class StatusBean {
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public StatusBean(String status) {
		super();
		this.status = status;
	}

}
