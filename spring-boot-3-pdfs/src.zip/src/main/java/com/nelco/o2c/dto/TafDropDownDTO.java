/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.BidTypeMst;
import com.nelco.o2c.model.EvalTypeMst;
import com.nelco.o2c.model.LeadBidderMst;
import com.nelco.o2c.model.RiskMst;

/**
 * @author Jayashankar.r
 *
 */
@Component
public class TafDropDownDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private List<BidTypeMst> bidTypeList = new ArrayList<BidTypeMst>();
	private List<EvalTypeMst> evaltypeList = new ArrayList<EvalTypeMst>();
	private List<LeadBidderMst> leadBidderList = new ArrayList<LeadBidderMst>();
	private List<RiskMst> riskList = new ArrayList<RiskMst>();
	private List<UserEmailDetailsBean> preBidResources = new ArrayList<UserEmailDetailsBean>();
	
	
	public List<UserEmailDetailsBean> getPreBidResources() {
		return preBidResources;
	}
	public void setPreBidResources(List<UserEmailDetailsBean> preBidResources) {
		this.preBidResources = preBidResources;
	}
	public List<BidTypeMst> getBidTypeList() {
		return bidTypeList;
	}
	public void setBidTypeList(List<BidTypeMst> bidTypeList) {
		this.bidTypeList = bidTypeList;
	}
	public List<EvalTypeMst> getEvaltypeList() {
		return evaltypeList;
	}
	public void setEvaltypeList(List<EvalTypeMst> evaltypeList) {
		this.evaltypeList = evaltypeList;
	}
	public List<LeadBidderMst> getLeadBidderList() {
		return leadBidderList;
	}
	public void setLeadBidderList(List<LeadBidderMst> leadBidderList) {
		this.leadBidderList = leadBidderList;
	}
	public List<RiskMst> getRiskList() {
		return riskList;
	}
	public void setRiskList(List<RiskMst> riskList) {
		this.riskList = riskList;
	}
}
