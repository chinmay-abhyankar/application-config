/**
 * 
 */
package com.nelco.o2c.dto;

/**
 * @author Amol.l
 *
 */
public class SoCsvDTO {
	private String soNum;
	private String tentActDate;
	private String newSoActDate;
	
	public SoCsvDTO(String soNum, String tentActDate, String newSoActDate) {
		super();
		this.soNum = soNum;
		this.tentActDate = tentActDate;
		this.newSoActDate = newSoActDate;
	}
	
	public SoCsvDTO() {
		// TODO Auto-generated constructor stub
	}

	public String getSoNum() {
		return soNum;
	}
	public void setSoNum(String soNum) {
		this.soNum = soNum;
	}
	public String getTentActDate() {
		return tentActDate;
	}
	public void setTentActDate(String tentActDate) {
		this.tentActDate = tentActDate;
	}
	public String getNewSoActDate() {
		return newSoActDate;
	}
	public void setNewSoActDate(String newSoActDate) {
		this.newSoActDate = newSoActDate;
	}

}
