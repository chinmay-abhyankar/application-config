/**
 * 
 */
package com.nelco.o2c.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.GeoTempDTO;
import com.nelco.o2c.dto.GeoTemplateDTO;
import com.nelco.o2c.dto.HubMstDTO;
import com.nelco.o2c.model.GeoTemplate;
import com.nelco.o2c.service.GeoTemplateService;

/**
 * @author Amol.l
 *
 */
@RestController
public class GeoTemplateController {

	@Autowired
	GeoTemplateService geoTemplateService;

	@RequestMapping(value = "/getGeoTemplateListByBrfId.do", method = RequestMethod.POST)
	public GeoTemplateDTO getGeoTemplateListByDate(@RequestBody GeoTemplateDTO geoTemplateDTO) {
		GeoTemplateDTO geoTemplateDTONew = new GeoTemplateDTO();
		List<GeoTempDTO> geoTempDTOList = new ArrayList<GeoTempDTO>();
		geoTempDTOList = geoTemplateService.getGeoTemplateListByBrfId(geoTemplateDTO);
		geoTemplateDTONew.setToDate(geoTemplateDTO.getToDate());
		geoTemplateDTONew.setFromDate(geoTemplateDTO.getFromDate());
		geoTemplateDTONew.setGeoTempDTOList(geoTempDTOList);
		geoTemplateDTONew.setContractId(geoTemplateDTO.getContractId());
		geoTemplateDTONew.setBrfId(geoTemplateDTO.getBrfId());
		return geoTemplateDTONew;
	}
	
	@RequestMapping(value = "/getGeoTempByGeoTempId.do", method = RequestMethod.POST)
	public GeoTemplateDTO getGeoTempByGeoTempId(@RequestBody GeoTemplateDTO geoTemplateDTO) {
		GeoTemplateDTO geoTemplateDTONew = new GeoTemplateDTO();
		GeoTemplate geoTemplate = new GeoTemplate();
		geoTemplate = geoTemplateService.getGeoTempByGeoTempId(geoTemplateDTO.getGeoTemplateId());
		geoTemplateDTONew.setGeoTemplateId(geoTemplateDTO.getGeoTemplateId());
		geoTemplateDTONew.setGeoTemplate(geoTemplate);
		return geoTemplateDTONew;
	}
	
	@RequestMapping(value = "/saveGeoTemplate.do", method = RequestMethod.POST)
	public GeoTemplateDTO saveBrf(@RequestBody GeoTemplateDTO geoTemplateDTO) {
		GeoTemplateDTO geoTemplateDTONew = new GeoTemplateDTO();
		GeoTemplate geoTemplate = new GeoTemplate();
		geoTemplate = geoTemplateService.saveGeoTemplate(geoTemplateDTO);
		geoTemplateDTONew.setGeoTemplate(geoTemplate);
		geoTemplateDTONew.setIsSaved(true);
		return geoTemplateDTONew;
	}
	
	@RequestMapping(value = "/getHubList.do", method = RequestMethod.POST)
	public HubMstDTO getNocMgrAndFinanceUsers(@RequestBody HubMstDTO hubMstDTO) {
		
		return geoTemplateService.getHubList(hubMstDTO);
	}
}
