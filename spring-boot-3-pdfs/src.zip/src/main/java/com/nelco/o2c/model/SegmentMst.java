package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the segment_mst database table.
 * 
 */
@Entity
@Table(name="segment_mst")
@NamedQuery(name="SegmentMst.findAll", query="SELECT s FROM SegmentMst s")
public class SegmentMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="segment_mst_id")
	private int segmentMstId;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="is_active")
	private String isActive;

	@Column(name="segment_code")
	private String segmentCode;

	@Column(name="segment_desc")
	private String segmentDesc;

	private String sequence;

	public SegmentMst() {
	}

	public int getSegmentMstId() {
		return this.segmentMstId;
	}

	public void setSegmentMstId(int segmentMstId) {
		this.segmentMstId = segmentMstId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getSegmentCode() {
		return this.segmentCode;
	}

	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

	public String getSegmentDesc() {
		return this.segmentDesc;
	}

	public void setSegmentDesc(String segmentDesc) {
		this.segmentDesc = segmentDesc;
	}

	public String getSequence() {
		return this.sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

}