package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.CustomerDocumentMappingFormDTO;
import com.nelco.o2c.dto.CustomerDocumentMappingListDTO;
import com.nelco.o2c.model.CustomerMandatoryDocMapping;
import com.nelco.o2c.model.DisconnectionAlltypesMst;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.InvoiceSubmissionMst;

@Repository
public class CustomerDocumentMappingDaoImpl implements CustomerDocumentMappingDao{
	@PersistenceContext
	private EntityManager em;
	Query query;	
	StoredProcedureQuery spQuery;
	
	@Override
	public List<CustomerDocumentMappingListDTO> getCustomerDocumentMappingList(HttpServletRequest request) {
		spQuery = em.createStoredProcedureQuery("isp_getCustomerDocumentMapping")
				.registerStoredProcedureParameter("customer", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("doucument", String.class, ParameterMode.IN);
		spQuery.setParameter("customer", request.getParameter("customer"))
				.setParameter("doucument", request.getParameter("documentCode"));
		List<Object[]> requestList=spQuery.getResultList();
		return requestList.stream().map(result -> new CustomerDocumentMappingListDTO(
		         String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2]),String.valueOf(result[3]),String.valueOf(result[4]))
		   ).collect(Collectors.toList());
	}

	@Override
	public CustomerMandatoryDocMapping addDocumentsForCustomer(CustomerMandatoryDocMapping tobeSavedRequest) {
		CustomerMandatoryDocMapping savedRequest=em.merge(tobeSavedRequest);
		return savedRequest;
	}

	@Override
	public void removeDocumentsForCustomer(CustomerMandatoryDocMapping tobeDeletedRequest) {
		query=em.createNamedQuery("CustomerMandatoryDocMapping.deleteDocument");
		query.setParameter("customer", tobeDeletedRequest.getCustomer());
		query.setParameter("documentCode", tobeDeletedRequest.getDocumentCode());
		query.executeUpdate();
	}

	@Override
	public CustomerDocumentMappingFormDTO getDisconnectionMasters(
			CustomerDocumentMappingFormDTO customerDocumentMappingFormDTO) {
		List<FileTypeMst> masters=null;
		query = em.createNamedQuery("FileTypeMst.findAll");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		masters=query.getResultList();
		customerDocumentMappingFormDTO.setDocumentTypes(masters != null ? masters : new ArrayList<FileTypeMst>());
		return customerDocumentMappingFormDTO;
	}

}
