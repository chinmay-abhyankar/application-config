package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the invoice_submission_mst database table.
 * 
 */
@Entity
@Table(name="invoice_submission_mst")
@NamedQuery(name="InvoiceSubmissionMst.findAll", query="SELECT i FROM InvoiceSubmissionMst i")
@NamedNativeQueries({
	@NamedNativeQuery(name = "InvoiceSubmissionMst.getRequestId", query = "SELECT 'INS_'+FORMAT(GETDATE(),'dd')+'_'+FORMAT(GETDATE(),'MM')+'_'+FORMAT(GETDATE(),'yyyy')+'_'+CAST(COALESCE(MAX(id),0)+1 AS VARCHAR)FROM invoice_submission_mst"),
	@NamedNativeQuery(name = "InvoiceSubmissionMst.getRequestIdFromInvoiceNo", query = "SELECT TOP 1 i.request_id FROM invoice_submission_mst i WHERE invoice_no=:invoiceNo ORDER BY id desc"),
	@NamedNativeQuery(name = "InvoiceSubmissionMst.getRequestInformationFromInvoiceNo", query = "SELECT TOP 1 i.request_id,submitted_by FROM invoice_submission_mst i WHERE invoice_no=:invoiceNo ORDER BY id desc"),
	})

public class InvoiceSubmissionMst implements Serializable {
	private static final long serialVersionUID = 1L;

	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private int id;

	@Column(length=2)
	private String actflag;

	@Column(name="invoice_no", length=20)
	private String invoiceNo;

	@Column(name="rejection_type", length=50)
	private String rejectionType;

	@Column(length=50)
	private String remark;

	@Id
	@Column(name="request_id", length=20)
	private String requestId;

	@Column(name="request_type", length=20)
	private String requestType;

	@Column(name="submission_date")
	private String submissionDate;

	@Column(name="submitted_by", length=20)
	private String submittedBy;
	
	@Column(name="checked_by", length=20)
	private String checkedBy;	
	
	@Column(name="check_status", length=20)
	private String checkStatus;

	@Column(name="check_date",insertable=false, updatable=false)
	private String checkDate;
	
	@Column(length=20)
	private String updatedby;

	@Column(insertable=false, updatable=false)
	private Timestamp updatedon;

	public InvoiceSubmissionMst() {
	}

	public String getCheckedBy() {
		return checkedBy;
	}

	public void setCheckedBy(String checkedBy) {
		this.checkedBy = checkedBy;
	}

	public String getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public String getInvoiceNo() {
		return this.invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getRejectionType() {
		return this.rejectionType;
	}

	public void setRejectionType(String rejectionType) {
		this.rejectionType = rejectionType;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRequestId() {
		return this.requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getRequestType() {
		return this.requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getSubmissionDate() {
		return this.submissionDate;
	}

	public void setSubmissionDate(String submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getSubmittedBy() {
		return this.submittedBy;
	}

	public void setSubmittedBy(String submittedBy) {
		this.submittedBy = submittedBy;
	}

	public String getUpdatedby() {
		return this.updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

	public Timestamp getUpdatedon() {
		return this.updatedon;
	}

	public void setUpdatedon(Timestamp updatedon) {
		this.updatedon = updatedon;
	}

	public String getCheckDate() {
		return checkDate;
	}

	public void setCheckDate(String checkDate) {
		this.checkDate = checkDate;
	}

}