package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 * The persistent class for the drf_upload_details database table.
 * 
 */
@Entity
@Table(name = "drf_upload_details")
@NamedQueries({
@NamedQuery(name = "DrfUploadDetail.findAll", query = "SELECT d FROM DrfUploadDetail d"),@NamedQuery(name = "DrfUploadDetail.getDrfUploadDetailsBydrfUpDetailsId", query = "SELECT dud FROM DrfUploadDetail dud where dud.drfUpDetailsId=?1")})
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "drfUpDetailsId")
public class DrfUploadDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "drf_up_details_id")
	private Integer drfUpDetailsId;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "drf_details_id")
	private Integer drfDetailsId;

	@Column(name = "file_type_mst_id")
	private Integer fileTypeMstId;

	@Column(name = "up_file_name")
	private String upFileName;

	@Column(name = "upload_url")
	private String uploadUrl;
	
	@Column(name = "is_customer_approved")
	private String isCutomerApproved;
	
	
	
	public String getIsCutomerApproved() {
		return isCutomerApproved;
	}

	public void setIsCutomerApproved(String isCutomerApproved) {
		this.isCutomerApproved = isCutomerApproved;
	}

	public Integer getDrfUpDetailsId() {
		return drfUpDetailsId;
	}

	public void setDrfUpDetailsId(Integer drfUpDetailsId) {
		this.drfUpDetailsId = drfUpDetailsId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}

	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}

	public Integer getFileTypeMstId() {
		return fileTypeMstId;
	}

	public void setFileTypeMstId(Integer fileTypeMstId) {
		this.fileTypeMstId = fileTypeMstId;
	}

	public String getUpFileName() {
		return upFileName;
	}

	public void setUpFileName(String upFileName) {
		this.upFileName = upFileName;
	}

	public String getUploadUrl() {
		return uploadUrl;
	}

	public void setUploadUrl(String uploadUrl) {
		this.uploadUrl = uploadUrl;
	}

	@Override
	public String toString() {
		return "DrfUploadDetail [drfUpDetailsId=" + drfUpDetailsId + ", createdBy=" + createdBy + ", createdDate="
				+ createdDate + ", drfDetailsId=" + drfDetailsId + ", fileTypeMstId=" + fileTypeMstId + ", upFileName="
				+ upFileName + ", uploadUrl=" + uploadUrl + "]";
	}

	

}