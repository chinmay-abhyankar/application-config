/**
 * 
 */
package com.nelco.o2c.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.ContractDTO;
import com.nelco.o2c.dto.ContractDropDownDTO;
import com.nelco.o2c.model.Contract;
import com.nelco.o2c.service.ContractService;

/**
 * @author Amol.l
 *
 */
@RestController
public class ContractController {

	@Autowired
	ContractService contractService;

	@RequestMapping(value = "/getContractByProposalId.do", method = RequestMethod.POST)
	public ContractDTO getContractByProposalId(@RequestBody ContractDTO contractDTO) {
		ContractDTO contractDTONew = new ContractDTO();
		Contract contract = new Contract();
		contract = contractService.getContractByProposalId(contractDTO.getProposalId());
		contractDTONew.setProposalId(contractDTO.getProposalId());
		contractDTONew.setContract(contract);
		return contractDTONew;
	}

	@RequestMapping(value = "/getContractByContractId.do", method = RequestMethod.POST)
	public ContractDTO getContractByContractId(@RequestBody ContractDTO contractDTO) {
		ContractDTO contractDTONew = new ContractDTO();
		Contract contract = new Contract();
		contract = contractService.getContractByContractId(contractDTO.getContractId());
		contractDTONew.setContractId(contractDTO.getContractId());
		contractDTONew.setContract(contract);
		return contractDTONew;
	}

	@RequestMapping(value = "/getContractDropDowns.do", method = RequestMethod.POST)
	public ContractDropDownDTO getContractDropDowns(@RequestBody ContractDropDownDTO contractDropDownDTO) {
		return contractService.getContractDropDowns(contractDropDownDTO);
	}

	@RequestMapping(value = "/saveContract.do", method = RequestMethod.POST)
	public ContractDTO saveContract(@RequestBody ContractDTO contractDTO) {
		ContractDTO contractDTONew = new ContractDTO();
//		Contract contract = new Contract();
		ContractDTO contractDTOObj = contractService.saveContract(contractDTO);
//		contract = contractService.getContractByContractId(contractDTOObj.getContract().getContractId());
//		contractDTONew.setContract(contract);
		if(contractDTOObj.getContract().getContractId() != null)
		{
			contractDTONew.setIsSave("Y");
			contractDTONew.setContractId(contractDTOObj.getContract().getContractId());
			contractDTONew.setContract(contractDTOObj.getContract());
		}else {
			contractDTONew.setIsSave("N");
		}
		
		return contractDTONew;
	}
	
	@RequestMapping(value = "/getMasterContractList.do", method = RequestMethod.POST)
	public ContractDTO getMasterContractList(@RequestBody CommonDTO commonDTO) {
		return contractService.getMasterContractList(commonDTO);
	}
}
