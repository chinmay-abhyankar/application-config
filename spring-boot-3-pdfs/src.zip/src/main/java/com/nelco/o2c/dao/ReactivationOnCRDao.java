package com.nelco.o2c.dao;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.nelco.o2c.dto.DisconnectionReconnectionDatesToCSVDTO;
import com.nelco.o2c.dto.ReactivationListDTO;
import com.nelco.o2c.model.ReactivationRequestMst;
import com.nelco.o2c.dto.ReactivationOnCRDTO;

public interface ReactivationOnCRDao {

	List<ReactivationListDTO> getReactivationRequestsList(HttpServletRequest request);

	ReactivationRequestMst initiateReactivationRequest(ReactivationRequestMst reactivationRequest);

	ReactivationRequestMst reactivateSite(ReactivationRequestMst toBeStatuses);

	List<DisconnectionReconnectionDatesToCSVDTO> getBillingStartDate(String requestId);

	int getCount(String string, String string2, String valueOf);

	Object validateIpforDisconnection(String valueOf);

	List<ReactivationOnCRDTO> uploadFile(MultipartFile file, String userId, HashMap<String, String> resultMap);

	void sendReactivationOnCRIntimation(String commonId);
	
}
