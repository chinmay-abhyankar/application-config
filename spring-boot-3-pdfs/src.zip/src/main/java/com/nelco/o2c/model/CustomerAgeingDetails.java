package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the customer_ageing_report database table.
 * 
 */
@Entity
@Table(name="customer_ageing_report")
@NamedQueries({
@NamedQuery(name="CustomerAgeingDetails.findAll", query="SELECT cad FROM CustomerAgeingDetails cad"),
@NamedQuery(name="CustomerAgeingDetails.getCustomerwiseOutstanding", query="SELECT new CustomerAgeingDetails(cad.customer,cm.customerName,SUM(cad.outstandingAmt))"
		+ " FROM CustomerAgeingDetails cad"
		+ " INNER JOIN cad.customerMst cm"
		+ " GROUP BY cad.customer,cm.customerName"),
@NamedQuery(name="CustomerAgeingDetails.getOutstandingforCustomer", query="SELECT cad.invoiceNo,cad.invoiceDate,cad.outstandingAmt,cad.dueDate"
		+ " FROM CustomerAgeingDetails cad"
		+ " INNER JOIN cad.customerMst cm"
		+ " WHERE cad.customer=:customerParam AND (cad.invoiceDate>=:startDateParam AND cad.invoiceDate=:endDateParam)"),
@NamedQuery(name="CustomerAgeingDetails.getCompanyCodeList", query="SELECT DISTINCT cad.companyCode as label,cad.companyCode as value FROM CustomerAgeingDetails cad")

})
public class CustomerAgeingDetails implements Serializable {
	

	private static final long serialVersionUID = 1L;
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="customer",referencedColumnName="customer_num", insertable = false, updatable = false)
	private CustomerSapmst customerMst;
	
	public CustomerAgeingDetails(String CustomerCode,String CustomerName,BigDecimal amt){
		this.customer=CustomerCode;
		this.customerMst.setCustomerName(CustomerName);
		this.totalAmt=amt;
	}
	
	public CustomerSapmst getCustomerMst() {
		return customerMst;
	}

	public void setCustomerMst(CustomerSapmst customerMst) {
		this.customerMst = customerMst;
	}

	
	public BigDecimal getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(BigDecimal totalAmt) {
		this.totalAmt = totalAmt;
	}


	@Transient
	private BigDecimal totalAmt;
	
	@Id
	private int typeid;

	private String actflag;

	@Column(name="company_code")
	private String companyCode;

	private String customer;

	@Column(name="invoice_date")
	private String invoiceDate;

	@Column(name="invoice_no")
	private String invoiceNo;

	@Column(name="outstanding_amt")
	private BigDecimal outstandingAmt;

	@Column(name="payment_terms")
	private String paymentTerms;

	@Column(name="so_no")
	private String soNo;
	
	@Column(name="due_date")
	private String dueDate;

	private Timestamp updateedon;

	
	public CustomerAgeingDetails() {
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCustomer() {
		return this.customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceNo() {
		return this.invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public BigDecimal getOutstandingAmt() {
		return this.outstandingAmt;
	}

	public void setOutstandingAmt(BigDecimal outstandingAmt) {
		this.outstandingAmt = outstandingAmt;
	}

	public String getPaymentTerms() {
		return this.paymentTerms;
	}

	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public String getSoNo() {
		return this.soNo;
	}

	public void setSoNo(String soNo) {
		this.soNo = soNo;
	}	

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public Timestamp getUpdateedon() {
		return this.updateedon;
	}

	public void setUpdateedon(Timestamp updateedon) {
		this.updateedon = updateedon;
	}

}