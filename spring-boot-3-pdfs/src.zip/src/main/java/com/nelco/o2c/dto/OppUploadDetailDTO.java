package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.OppUploadDetail;

public class OppUploadDetailDTO implements Serializable {
	
	private static final long serialVersionUID = 13L;
	private String oppUploadDetailsId="";
	private String fileName="";
	private String uploadUrl="";
	private String docType="";
	private String uploadDate="";
	private OppUploadDetail oppUploadDetail = new OppUploadDetail();
		
	public String getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(String uploadDate) {
		this.uploadDate = uploadDate;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getUploadUrl() {
		return uploadUrl;
	}

	public void setUploadUrl(String uploadUrl) {
		this.uploadUrl = uploadUrl;
	}

	public String getOppUploadDetailsId() {
		return oppUploadDetailsId;
	}

	public void setOppUploadDetailsId(String oppUploadDetailsId) {
		this.oppUploadDetailsId = oppUploadDetailsId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public OppUploadDetail getOppUploadDetail() {
		return oppUploadDetail;
	}

	public void setOppUploadDetail(OppUploadDetail oppUploadDetail) {
		this.oppUploadDetail = oppUploadDetail;
	}

	private List<OppUploadDetail> oppUploadDetailList = new ArrayList<OppUploadDetail>();

	public List<OppUploadDetail> getOppUploadDetailList() {
		return oppUploadDetailList;
	}

	public void setOppUploadDetailList(List<OppUploadDetail> oppUploadDetailList) {
		this.oppUploadDetailList = oppUploadDetailList;
	}

	
}
