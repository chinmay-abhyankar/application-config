/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.model.Contract;
import com.nelco.o2c.model.MaterialContract;

/**
 * @author Amol.l
 *
 */
public interface ContractDao {

	public Contract getContractByProposalId(String proposalId);
	
	public Contract getContractByContractId(Integer contractId);

	public Contract saveContract(Contract contract);

	public MaterialContract saveMaterialContract(MaterialContract materialContract);

	public List<Contract> getMasterContractList(CommonDTO commonDTO);
}
