package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the hub_mst database table.
 * 
 */
@Entity
@Table(name="hub_mst")
@NamedQueries({@NamedQuery(name="HubMst.findAll", query="SELECT h FROM HubMst h where h.isActive='Y'"),
@NamedQuery(name="HubMst.findByCode", query="SELECT h FROM HubMst h where h.hubCode=?1 and h.isActive='Y'"),
@NamedQuery(name="HubMst.allActiveHubs",query="SELECT h from HubMst h where h.isActive=?1"),
@NamedQuery(name="HubMst.hubByDesc", query="SELECT h FROM HubMst h where h.hubDesc=?1 and h.isActive='Y'")
})

public class HubMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="hub_mst_id")
	private Integer hubMstId;

	@Column(name="hub_code")
	private String hubCode;

	@Column(name="hub_desc")
	private String hubDesc;

	@Column(name="is_active")
	private String isActive;
	
	@Column(name="noc_insta_email")
	private String nocInstaEmail;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "hub_mst_id", referencedColumnName = "hub_mst_id", insertable = false, updatable = false)
	private List<UserToHub> userToHub;
	

	public List<UserToHub> getUserToHub() {
		return userToHub;
	}

	public void setUserToHub(List<UserToHub> userToHub) {
		this.userToHub = userToHub;
	}

	public HubMst() {
	}

	public Integer getHubMstId() {
		return hubMstId;
	}

	public void setHubMstId(Integer hubMstId) {
		this.hubMstId = hubMstId;
	}

	public String getHubCode() {
		return hubCode;
	}

	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}

	public String getHubDesc() {
		return hubDesc;
	}

	public void setHubDesc(String hubDesc) {
		this.hubDesc = hubDesc;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getNocInstaEmail() {
		return nocInstaEmail;
	}

	public void setNocInstaEmail(String nocInstaEmail) {
		this.nocInstaEmail = nocInstaEmail;
	}

}