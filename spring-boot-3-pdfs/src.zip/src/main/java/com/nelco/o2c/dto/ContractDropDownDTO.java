package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.ConditionTypeMst;
import com.nelco.o2c.model.ContractDocTypeSapmst;
import com.nelco.o2c.model.DistChannelMst;
import com.nelco.o2c.model.DivisionMst;
import com.nelco.o2c.model.PricingGroupMst;
import com.nelco.o2c.model.SalesOfficeMst;
import com.nelco.o2c.model.SalesOrgMst;
import com.nelco.o2c.model.ServiceOrderMst;

public class ContractDropDownDTO  implements Serializable {
	private static final long serialVersionUID = 72L;
	
	private List<ContractDocTypeSapmst> contractDocTypeSapmstList = new ArrayList<ContractDocTypeSapmst>();
	private List<DivisionMst> divisionMstList = new ArrayList<DivisionMst>();
	private List<DistChannelMst> distChannelMsttList = new ArrayList<DistChannelMst>();
	private List<SalesOfficeMst> salesOfficeMstList = new ArrayList<SalesOfficeMst>();
	private List<SalesOrgMst> salesOrgMstList = new ArrayList<SalesOrgMst>();
	private List<ConditionTypeMst> conditionTypeList = new ArrayList<ConditionTypeMst>();
	private List<PricingGroupMst> pricingGroupList = new ArrayList<PricingGroupMst>();
	private List<ServiceOrderMst> serviceOrderList = new ArrayList<ServiceOrderMst>();
	
	public List<ServiceOrderMst> getServiceOrderList() {
		return serviceOrderList;
	}
	public void setServiceOrderList(List<ServiceOrderMst> serviceOrderList) {
		this.serviceOrderList = serviceOrderList;
	}
	public List<ConditionTypeMst> getConditionTypeList() {
		return conditionTypeList;
	}
	public void setConditionTypeList(List<ConditionTypeMst> conditionTypeList) {
		this.conditionTypeList = conditionTypeList;
	}
	public List<PricingGroupMst> getPricingGroupList() {
		return pricingGroupList;
	}
	public void setPricingGroupList(List<PricingGroupMst> pricingGroupList) {
		this.pricingGroupList = pricingGroupList;
	}
	public List<ContractDocTypeSapmst> getContractDocTypeSapmstList() {
		return contractDocTypeSapmstList;
	}
	public void setContractDocTypeSapmstList(List<ContractDocTypeSapmst> contractDocTypeSapmstList) {
		this.contractDocTypeSapmstList = contractDocTypeSapmstList;
	}
	public List<DivisionMst> getDivisionMstList() {
		return divisionMstList;
	}
	public void setDivisionMstList(List<DivisionMst> divisionMstList) {
		this.divisionMstList = divisionMstList;
	}
	public List<DistChannelMst> getDistChannelMsttList() {
		return distChannelMsttList;
	}
	public void setDistChannelMsttList(List<DistChannelMst> distChannelMsttList) {
		this.distChannelMsttList = distChannelMsttList;
	}
	public List<SalesOfficeMst> getSalesOfficeMstList() {
		return salesOfficeMstList;
	}
	public void setSalesOfficeMstList(List<SalesOfficeMst> salesOfficeMstList) {
		this.salesOfficeMstList = salesOfficeMstList;
	}
	public List<SalesOrgMst> getSalesOrgMstList() {
		return salesOrgMstList;
	}
	public void setSalesOrgMstList(List<SalesOrgMst> salesOrgMstList) {
		this.salesOrgMstList = salesOrgMstList;
	}
	
}
