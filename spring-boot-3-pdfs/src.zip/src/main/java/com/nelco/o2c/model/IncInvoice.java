package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;

import com.nelco.o2c.utility.DateUtil;

import java.sql.Timestamp;


/**
 * The persistent class for the inc_invoice database table.
 * 
 */
@Entity
@Table(name="inc_invoice")
@NamedQueries({@NamedQuery(name="IncInvoice.findAll", query="SELECT i FROM IncInvoice i"),
	@NamedQuery(name="IncInvoice.findAllByInvoiceDate", query="SELECT i FROM IncInvoice i where i.invDate between :fromDate and :toDate ")})
public class IncInvoice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="inc_invoice_id")
	private Integer incInvoiceId;

	@Column(name="inv_date")
	private String invDate;

	@Column(name="inv_no")
	private String invNo;

	@Column(name="inv_type")
	private String invType;

	@Column(name="item_no")
	private String itemNo;

	@Column(name="item_qty")
	private String itemQty;

	@Column(name="material_code")
	private String materialCode;

	@Column(name="total_amt")
	private String totalAmt;

	public IncInvoice() {
	}

	public Integer getIncInvoiceId() {
		return incInvoiceId;
	}

	public void setIncInvoiceId(Integer incInvoiceId) {
		this.incInvoiceId = incInvoiceId;
	}

	public String getInvDate() {
		return DateUtil.convertDateTimeToString(this.invDate);
		//return invDate;
	}

	public void setInvDate(String invDate) {
		this.invDate = invDate;
	}

	public String getInvNo() {
		return invNo;
	}

	public void setInvNo(String invNo) {
		this.invNo = invNo;
	}

	public String getInvType() {
		return invType;
	}

	public void setInvType(String invType) {
		this.invType = invType;
	}

	public String getItemNo() {
		return itemNo;
	}

	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public String getItemQty() {
		return itemQty;
	}

	public void setItemQty(String itemQty) {
		this.itemQty = itemQty;
	}

	public String getMaterialCode() {
		return materialCode;
	}

	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	public String getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(String totalAmt) {
		this.totalAmt = totalAmt;
	}

	

}