package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the sto_pmgt_delivery_details database table.
 * 
 */
@Entity
@Table(name="sto_pmgt_delivery_details")
@NamedQuery(name="StoPmgtDeliveryDetail.findAll", query="SELECT s FROM StoPmgtDeliveryDetail s")
public class StoPmgtDeliveryDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="sto_pmgt_delivery_details_id")
	private Integer stoPmgtDeliveryDetailsId;

	@Column(name="material_desc")
	private String materialDesc;

	@Column(name="material_num")
	private String materialNum;

	private String quantity;

	@Column(name="rec_plant_code")
	private String recPlantCode;

	@Column(name="rec_plant_name")
	private String recPlantName;

	@Column(name="sto_gen_id")
	private String stoGenId;

	@Column(name="sto_pmgt_delivery_id")
	private Integer stoPmgtDeliveryId;

	public StoPmgtDeliveryDetail() {
	}

	public Integer getStoPmgtDeliveryDetailsId() {
		return stoPmgtDeliveryDetailsId;
	}

	public void setStoPmgtDeliveryDetailsId(Integer stoPmgtDeliveryDetailsId) {
		this.stoPmgtDeliveryDetailsId = stoPmgtDeliveryDetailsId;
	}

	public String getMaterialDesc() {
		return materialDesc;
	}

	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}

	public String getMaterialNum() {
		return materialNum;
	}

	public void setMaterialNum(String materialNum) {
		this.materialNum = materialNum;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getRecPlantCode() {
		return recPlantCode;
	}

	public void setRecPlantCode(String recPlantCode) {
		this.recPlantCode = recPlantCode;
	}

	public String getRecPlantName() {
		return recPlantName;
	}

	public void setRecPlantName(String recPlantName) {
		this.recPlantName = recPlantName;
	}

	public String getStoGenId() {
		return stoGenId;
	}

	public void setStoGenId(String stoGenId) {
		this.stoGenId = stoGenId;
	}

	public Integer getStoPmgtDeliveryId() {
		return stoPmgtDeliveryId;
	}

	public void setStoPmgtDeliveryId(Integer stoPmgtDeliveryId) {
		this.stoPmgtDeliveryId = stoPmgtDeliveryId;
	}

	

}