/**
 * 
 */
package com.nelco.o2c.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.nelco.o2c.dto.LoginDTO;

/**
 * @author Jayashankar.r
 *
 */
@Component
public class SessionInterceptor extends HandlerInterceptorAdapter {

	@Autowired
	private HttpSession session;
	
	@Override
    public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler) throws Exception {
		/*LoginDTO workArea = (LoginDTO) session
				.getAttribute("workArea");
		System.out.println(request.getRequestURI()+"request uri");
		System.out.println(request.getContextPath()+"----Contextttttt");
		if (!request.getRequestURI().contains("login")
				&& !request.getRequestURI().endsWith(request.getContextPath()+"/")
				&&!request.getRequestURI().contains("authenticateUser") && !request.getRequestURI().contains("sessionExpiredUser")
				 && (workArea == null || workArea.getUserMst()==null)
				 && !request.getRequestURI().contains("css")
				 && !request.getRequestURI().contains("images")
				 && !request.getRequestURI().contains("js")
				 && !request.getRequestURI().contains("libs")
				 && !request.getRequestURI().contains("partials")
				 && !request.getRequestURI().contains("webfonts")
				 && !request.getRequestURI().contains("webjs") 
				 && !request.getRequestURI().contains("apprRejProposal")) {
			System.out.println("Invalid Session");
			System.out.println(request.getContextPath());
			response.sendError(999, "sessionTimeout");
		    response.sendRedirect(request.getContextPath()+"/sessionExpiredUser.do");
		}*/
		return true;

	}
}
