/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Jayashankar.r
 *
 */
public class ValContentBean {

	@JsonProperty("val")
	private String val;

	@JsonProperty("content")
	private String content;

	public String getVal() {
		return val;
	}

	public void setVal(String val) {
		this.val = val;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
