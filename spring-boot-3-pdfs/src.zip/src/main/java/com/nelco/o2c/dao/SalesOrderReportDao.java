package com.nelco.o2c.dao;

import java.util.List;

public interface SalesOrderReportDao {
	public List<String> getAllSoTypes();
}
