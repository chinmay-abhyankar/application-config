/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author Amol.l
 *
 */

@Entity
@Table(name = "clause_mst")
@NamedQuery(name="ClauseMst.findAll", query="SELECT c FROM ClauseMst c")
public class ClauseMst implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "clause_mst_id")
	private Integer clauseMstId;

	@Column(name = "clause_code", length = 10)
	private String clauseCode;
	
	@Column(name = "clause_val", length = 200)
	private String clauseVal;

	public Integer getClauseMstId() {
		return clauseMstId;
	}

	public void setClauseMstId(Integer clauseMstId) {
		this.clauseMstId = clauseMstId;
	}

	public String getClauseCode() {
		return clauseCode;
	}

	public void setClauseCode(String clauseCode) {
		this.clauseCode = clauseCode;
	}

	public String getClauseVal() {
		return clauseVal;
	}

	public void setClauseVal(String clauseVal) {
		this.clauseVal = clauseVal;
	}
	
	
}
