package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.model.ReportMst;

public interface ReportMstDao {
	public List<ReportMst> getAllReportNames();
	
	public ReportMst findById(int theId);
}
