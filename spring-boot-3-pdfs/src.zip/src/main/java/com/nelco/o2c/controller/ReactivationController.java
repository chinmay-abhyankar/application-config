package com.nelco.o2c.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.DisconnectionDTO;
import com.nelco.o2c.dto.DisconnectionFormDTO;
import com.nelco.o2c.dto.ReactivationFormDTO;
import com.nelco.o2c.service.ReactivationService;

@RestController
public class ReactivationController {
@Autowired 
ReactivationService reactivationService;

@RequestMapping(value = "/getReactivationRequestList.do", method = RequestMethod.GET)
public ReactivationFormDTO getReactivationRequestList(ReactivationFormDTO reactivationformDTO, HttpServletRequest request) {
	return reactivationService.getReactivationRequestsList(reactivationformDTO, request);
}

@RequestMapping(value = "/initiateReactivationRequest.do", method = RequestMethod.POST)
public ReactivationFormDTO initiateReactivationRequest(@RequestBody ReactivationFormDTO reactivationformDTO, HttpServletRequest request) {
	return reactivationService.initiateReactivationRequest(reactivationformDTO,request);
}

@RequestMapping(value = "/appRejReactivationRequest.do", method = RequestMethod.POST)
public ReactivationFormDTO appRejReactivationRequest(@RequestBody ReactivationFormDTO reactivationformDTO, HttpServletRequest request) {
	return reactivationService.appRejReactivationRequest(reactivationformDTO,request);
}

@RequestMapping(value = "/reactivateSite.do", method = RequestMethod.POST)
public ReactivationFormDTO reactivateSite(@RequestBody ReactivationFormDTO reactivationformDTO, HttpServletRequest request) {
	return reactivationService.reactivateSite(reactivationformDTO,request);
}

@RequestMapping(value = "/reconnectionRequestDetails.do", method = RequestMethod.GET)
public ReactivationFormDTO getReconnectionRequestDetails(ReactivationFormDTO reactivationformDTO, HttpServletRequest request) {
	return reactivationService.getReconnectionRequestDetails(reactivationformDTO,request);
}
}
