package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the status_process_mst database table.
 * 
 */
@Entity
@Table(name = "status_process_mst")
@NamedQuery(name = "StatusProcessMst.findAll", query = "SELECT s FROM StatusProcessMst s")
public class StatusProcessMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "status_process_mst_id")
	private Integer statusProcessMstId;

	@Column(name = "process_mst_id")
	private Integer processMstId;

	@Column(name = "status_mst_id")
	private Integer statusMstId;

	public Integer getStatusProcessMstId() {
		return statusProcessMstId;
	}

	public void setStatusProcessMstId(Integer statusProcessMstId) {
		this.statusProcessMstId = statusProcessMstId;
	}

	public Integer getProcessMstId() {
		return processMstId;
	}

	public void setProcessMstId(Integer processMstId) {
		this.processMstId = processMstId;
	}

	public Integer getStatusMstId() {
		return statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}

}