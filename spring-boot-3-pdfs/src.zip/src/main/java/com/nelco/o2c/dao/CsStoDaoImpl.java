/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.AllDeliveryListDTO;
import com.nelco.o2c.dto.CsStoDTO;
import com.nelco.o2c.model.CsStoPodUploadDetail;
import com.nelco.o2c.model.StoC;
import com.nelco.o2c.model.StoCsDelivery;
import com.nelco.o2c.model.StoCsDeliveryTracker;
import com.nelco.o2c.model.StoCsMaterial;
import com.nelco.o2c.model.StoCsPodTracker;
import com.nelco.o2c.model.StoCsStatusTracker;
import com.nelco.o2c.model.StoPmgtDelivery;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class CsStoDaoImpl implements CsStoDao {

	@PersistenceContext
	private EntityManager em;

	Query query;

	private String csStoGenId;

	@SuppressWarnings("unchecked")
	@Override
	public List<StoC> getCsStoList(CsStoDTO ipCsStoDTO) {
		// TODO Auto-generated method stub
		try {
			String fromDate = DateUtil.convertDateToSqlDate(ipCsStoDTO.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(ipCsStoDTO.getToDate());
			if (ipCsStoDTO.getRoleCode().equals(Constants.SUPPEXECROLECODE)) {
				query = em.createNamedQuery("StoC.getStoCSListSupexe");
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59.999");
				query.setParameter(3, ipCsStoDTO.getUserMstId());
			} else if (ipCsStoDTO.getRoleCode().equals(Constants.TRCROLECODE)) {
				query = em.createNamedQuery("StoC.getStoCsListTrc");
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59.999");
				query.setParameter(3, ipCsStoDTO.getUserMstId());
			} else if (ipCsStoDTO.getRoleCode().equals(Constants.SUPPCOORDROLECODE)) {
				query = em.createNamedQuery("StoC.getStoCsListCsCoord");
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59.999");
				query.setParameter(3, ipCsStoDTO.getUserMstId());
			} else {
				query = em.createNamedQuery("StoC.findByCreatedDate");
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59.999");
			}

			return (List<StoC>) query.getResultList();
		} finally {
			em.close();
		}
	}

	@Override
	public StoC getStoCsById(CsStoDTO ipCsStoDTO) {
		// TODO Auto-generated method stub
		try {
			return em.find(StoC.class, ipCsStoDTO.getStoCsId());
		} catch (Exception e) {
			return new StoC();
		} finally {
			em.close();
		}
	}

	@Override
	public StoC saveCsSto(StoC stoCsToSave, Integer userMstId,String roleCode) {
		// TODO Auto-generated method stub
		String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
		if (stoCsToSave.getStoCsId() == null) {
			stoCsToSave.setStatusMstId(Constants.CSSTONSID);
			synchronized (this) {
				Integer maxProposalNumber = getCurrentDayCountStoCs();
				this.csStoGenId = "CSSTO_" + (DateUtil.getCurrentISTDateAsString(DateUtil.SIMPLE_DATE_FORMAT)
						.replace("-", "_").concat("_").concat(maxProposalNumber.toString()));

			}
			stoCsToSave.setStoCsGenId(this.csStoGenId);
		}
		stoCsToSave.setCreatedDate(currTime);

		StoC savedStoCs = em.merge(stoCsToSave);
		stoCsToSave.setStoCsId(savedStoCs.getStoCsId());
		saveStoCsMaterials(stoCsToSave,roleCode);
		if (stoCsToSave.getStoCsId() == null) {
			//em.refresh(savedStoCs);
			StoCsStatusTracker stoCsStatusTracker = new StoCsStatusTracker();
			stoCsStatusTracker.setReqById(userMstId);
			stoCsStatusTracker.setReqDate(currTime);
			stoCsStatusTracker.setStatusMstId(Constants.CSSTONSID);
			stoCsStatusTracker.setStoCsId(savedStoCs.getStoCsId());
			em.merge(stoCsStatusTracker);
		}
		return savedStoCs;
	}

	@Override
	public void saveStoCsMaterials(StoC stoCs, String roleCode) {
		// TODO Auto-generated method stub
		List<StoCsMaterial> stoCsMaterialList = stoCs.getStoCsMaterialList();
		for (StoCsMaterial stoPmgtMaterial : stoCsMaterialList) {
			stoPmgtMaterial.setPlantSapmst(null);
			stoPmgtMaterial.setStorageSapmst(null);
			stoPmgtMaterial.setStoCsId(stoCs.getStoCsId());
			if(roleCode.equals(Constants.SUPPEXECROLECODE)) {
				stoPmgtMaterial.setAvailMaterialNum(stoPmgtMaterial.getReqMaterialNum());
				stoPmgtMaterial.setAvailQuantity(stoPmgtMaterial.getReqQuantity());
			}
			em.merge(stoPmgtMaterial);
		}
	}

	@Override
	public Integer getCurrentDayCountStoCs() {
		try {
			String currentDate = DateUtil.getCurrentISTDateOnlyAsString(DateUtil.DATE_ONLY_FORMAT_MSSQL);
			query = em.createNamedQuery("StoC.getCurrentDayCountStoCs");
			query.setParameter(1, currentDate);
			query.setParameter(2, currentDate + " 23:59:59.999");
			Long maxNumber = (Long) query.getSingleResult();
			return maxNumber.intValue();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public void submitByCs(CsStoDTO ipCsStoDTO) {
		try {
			// TODO Auto-generated method stub
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			query = em.createNamedQuery("StoC.updateCsSubmit");
			//query.setParameter(1, currTime);
			query.setParameter(1, Constants.CSSTOSTTID);
			query.setParameter(2, ipCsStoDTO.getStoCsId());
			query.executeUpdate();
			StoCsStatusTracker stoCsStatusTracker = new StoCsStatusTracker();
			stoCsStatusTracker.setReqById(ipCsStoDTO.getUserMstId());
			stoCsStatusTracker.setReqDate(currTime);
			stoCsStatusTracker.setStatusMstId(Constants.CSSTOSTTID);
			stoCsStatusTracker.setStoCsId(ipCsStoDTO.getStoCsId());
			em.merge(stoCsStatusTracker);
		} finally {
			// TODO: handle finally clause
			em.close();
		}

	}

	@Override
	public void submitByTrc(CsStoDTO ipCsStoDTO) {
		try {
			// TODO Auto-generated method stub
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			query = em.createNamedQuery("StoC.updateTrcSubmit");
			//query.setParameter(1, currTime);
			query.setParameter(1, Constants.CSSTOSBTID);
			query.setParameter(2, ipCsStoDTO.getStoCsId());
			query.executeUpdate();
			StoCsStatusTracker stoCsStatusTracker = new StoCsStatusTracker();
			stoCsStatusTracker.setReqById(ipCsStoDTO.getUserMstId());
			stoCsStatusTracker.setReqDate(currTime);
			stoCsStatusTracker.setStatusMstId(Constants.CSSTOSBTID);
			stoCsStatusTracker.setStoCsId(ipCsStoDTO.getStoCsId());
			em.merge(stoCsStatusTracker);
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StoCsDelivery> getDeliveryTrackCsSto(CsStoDTO ipCsStoDTO) {
		// TODO Auto-generated method stub
		String fromDate = DateUtil.convertDateToSqlDate(ipCsStoDTO.getFromDate());
		String toDate = DateUtil.convertDateToSqlDate(ipCsStoDTO.getToDate());

		if (ipCsStoDTO.getRoleCode().equals(Constants.SUPPEXECROLECODE)) {
			if((ipCsStoDTO.getPlant()==null) || (ipCsStoDTO.getPlant().isEmpty()) 
					|| ("".equalsIgnoreCase(ipCsStoDTO.getPlant())) || ("ALL".equalsIgnoreCase(ipCsStoDTO.getPlant()))) {
				query = em.createNamedQuery("StoCsDelivery.getStoCsDeliveryListSE");
				query.setParameter(1, fromDate + Constants.MINDAYTIME);
				query.setParameter(2, toDate + Constants.MAXDAYTIME);
				query.setParameter(3, ipCsStoDTO.getUserMstId());
				query.setParameter(4, null);
			}
			else {
				query = em.createNativeQuery("select plant_sapmst_id from plant_sapmst where plant_code = ?1");
				query.setParameter(1, ipCsStoDTO.getPlant());
				int plantId = (int) query.getSingleResult();
				
				query = em.createNamedQuery("StoCsDelivery.getStoCsDeliveryListSE");
				query.setParameter(1, fromDate + Constants.MINDAYTIME);
				query.setParameter(2, toDate + Constants.MAXDAYTIME);
				query.setParameter(3, ipCsStoDTO.getUserMstId());
				query.setParameter(4, plantId);
			}
		} else if (ipCsStoDTO.getRoleCode().equals(Constants.STOREEXECUTIVECODE)
				|| ipCsStoDTO.getRoleCode().equals(Constants.STOREASSOCIATECODE)) {
			if((ipCsStoDTO.getPlant()==null) || (ipCsStoDTO.getPlant().isEmpty()) 
					|| ("".equalsIgnoreCase(ipCsStoDTO.getPlant())) || ("ALL".equalsIgnoreCase(ipCsStoDTO.getPlant()))) {
				query = em.createNamedQuery("StoCsDelivery.getStoCsDeliveryListStores");
				query.setParameter(1, fromDate + Constants.MINDAYTIME);
				query.setParameter(2, toDate + Constants.MAXDAYTIME);
				query.setParameter(3, ipCsStoDTO.getUserMstId());
				query.setParameter(4, null);
			}
			else {
				query = em.createNativeQuery("select plant_sapmst_id from plant_sapmst where plant_code = ?1");
				query.setParameter(1, ipCsStoDTO.getPlant());
				int plantId = (int) query.getSingleResult();
				
				query = em.createNamedQuery("StoCsDelivery.getStoCsDeliveryListStores");
				query.setParameter(1, fromDate + Constants.MINDAYTIME);
				query.setParameter(2, toDate + Constants.MAXDAYTIME);
				query.setParameter(3, ipCsStoDTO.getUserMstId());
				query.setParameter(4, plantId);
			}
			
		} else if (ipCsStoDTO.getRoleCode().equals(Constants.SUPPCOORDROLECODE)) {
			if((ipCsStoDTO.getPlant()==null) || (ipCsStoDTO.getPlant().isEmpty())
					|| ("".equalsIgnoreCase(ipCsStoDTO.getPlant())) || ("ALL".equalsIgnoreCase(ipCsStoDTO.getPlant()))) {
				query = em.createNamedQuery("StoCsDelivery.getStoCsDeliveryListSuppCoord");
				query.setParameter(1, fromDate + Constants.MINDAYTIME);
				query.setParameter(2, toDate + Constants.MAXDAYTIME);
				query.setParameter(3, ipCsStoDTO.getUserMstId());
				query.setParameter(4, null);
			}else {
				query = em.createNativeQuery("select plant_sapmst_id from plant_sapmst where plant_code = ?1");
				query.setParameter(1, ipCsStoDTO.getPlant());
				int plantId = (int) query.getSingleResult();
				
				query = em.createNamedQuery("StoCsDelivery.getStoCsDeliveryListSuppCoord");
				query.setParameter(1, fromDate + Constants.MINDAYTIME);
				query.setParameter(2, toDate + Constants.MAXDAYTIME);
				query.setParameter(3, ipCsStoDTO.getUserMstId());
				query.setParameter(4, plantId);
			}
		} else {
			query = em.createNamedQuery("StoCsDelivery.getStoCsDeliveryList");
			query.setParameter(1, fromDate + Constants.MINDAYTIME);
			query.setParameter(2, toDate + Constants.MAXDAYTIME);
		}

		List<StoCsDelivery> delList = (List<StoCsDelivery>) query.getResultList();

		return delList;
	}

	@Override
	public StoCsDelivery saveDeliveryCsSto(StoCsDelivery delivery) {
		// TODO Auto-generated method stub

		delivery.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		String dispatchDate = DateUtil.convertDateToSqlDate(delivery.getDispatchDate());
		//String addate = DateUtil.convertDateToSqlDate(delivery.getAddate());
		String eddate = DateUtil.convertDateToSqlDate(delivery.getEddate());
		delivery.setDispatchDate(dispatchDate);
		//delivery.setAddate(addate);
		delivery.setEddate(eddate);

		StoCsDelivery deliveryNew = em.merge(delivery);

		if (delivery.getStoCsDeliveryId() == null) {
			em.refresh(deliveryNew);
		}
		return deliveryNew;
	}

	@Override
	public StoCsDeliveryTracker saveDeliveryStatusTrackerCsSto(StoCsDeliveryTracker stoPmgtDeliveryStatusTracker) {
		// TODO Auto-generated method stub

		stoPmgtDeliveryStatusTracker
				.setStatusReqDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));

		StoCsDeliveryTracker deliveryStatusTrackerNew = em.merge(stoPmgtDeliveryStatusTracker);
		if (stoPmgtDeliveryStatusTracker.getStoCsDeliveryTrackerId() == null) {
			em.refresh(deliveryStatusTrackerNew);
		}
		return deliveryStatusTrackerNew;

	}

	@Override
	public StoCsPodTracker savePodStatusTrackerCsSto(StoCsPodTracker stoPmgtPodStatusTracker) {
		// TODO Auto-generated method stub
		stoPmgtPodStatusTracker.setStatusReqDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));

		StoCsPodTracker podStatusTrackerNew = em.merge(stoPmgtPodStatusTracker);
		if (stoPmgtPodStatusTracker.getStoCsPodTrackerId() == null) {
			em.refresh(podStatusTrackerNew);
		}
		return podStatusTrackerNew;
	}

	@Override
	public CsStoPodUploadDetail saveCsStoUpPodFile(CsStoPodUploadDetail pmgtStoPodUploadDetails) {
		// TODO Auto-generated method stub
		return em.merge(pmgtStoPodUploadDetails);
	}

	@Override
	public void updateCsStoPodStatusByDelId(Integer stoCsDeliveryId) {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			if (stoCsDeliveryId != null) {
				query = em.createNamedQuery("StoCsDelivery.updateCsStoPodStatusByDelId");
				query.setParameter(1, Constants.PODUPLOADEDSTATUSID);
				query.setParameter(2, stoCsDeliveryId);
			}
			query.executeUpdate();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public CsStoPodUploadDetail getUpPodFileDetCsSto(Integer stoCsDeliveryId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("CsStoPodUploadDetail.getPodByStoCsDeliveryId");
			query.setParameter(1, stoCsDeliveryId);
			CsStoPodUploadDetail pmgtStoPodUploadDetail = (CsStoPodUploadDetail) query.getSingleResult();
			return pmgtStoPodUploadDetail;
		} catch(Exception e) {
			return new CsStoPodUploadDetail();
		}finally {
			em.close();
		}
		
	}

	@Override
	public List<StoCsDelivery> getStoCsDelListByDateAndDelStatusCode(AllDeliveryListDTO allDeliveryListDTO) {
		try {
			String fromDate = DateUtil.convertDateToSqlDate(allDeliveryListDTO.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(allDeliveryListDTO.getToDate());

			query = em.createNamedQuery("StoCsDelivery.getStoCsDelListByDateAndDelStatusCode");

			query.setParameter(1, fromDate + Constants.MINDAYTIME);
			query.setParameter(2, toDate + Constants.MAXDAYTIME);
			if("All".equalsIgnoreCase(allDeliveryListDTO.getDelStatusCode())) {
				List<String> status = Arrays.asList("ITR","NA","DLV","WDA");
				query.setParameter("status", status);
			}else {
				query.setParameter("status", allDeliveryListDTO.getDelStatusCode());
			}
			@SuppressWarnings("unchecked")
			List<StoCsDelivery> stoCsDeliveryList = (List<StoCsDelivery>) query.getResultList();

			return stoCsDeliveryList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<StoCsDelivery>();
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public StoC getCsStoByReqId(CsStoDTO ipCsStoDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("StoC.getCsStoByReqId");
			query.setParameter(1, ipCsStoDTO.getStoCsGenId());
			List<StoC> stoCsList = (List<StoC>) query.getResultList();
			
			return stoCsList!=null && stoCsList.size()>0?stoCsList.get(0):new StoC();
		} catch (Exception e) {
			return new StoC();
		} finally {
			em.close();
		}
	}

	@Override
	public List<StoCsDelivery> stoCsDelBydeliveryNum(CsStoDTO ipCsStoDTO) {
		try {
			query = em.createNamedQuery("StoCsDelivery.stoCsDelBydeliveryNum");
			query.setParameter(1, ipCsStoDTO.getDeliveryNum());
			
			@SuppressWarnings("unchecked")
			List<StoCsDelivery> stoCsDelList = (List<StoCsDelivery>) query.getResultList();

			return stoCsDelList!=null && stoCsDelList.size()>0?stoCsDelList:new ArrayList<StoCsDelivery>();
		} catch (Exception e) {
			return new ArrayList<StoCsDelivery>();
		} finally {
			em.close();
		}
	}

}
