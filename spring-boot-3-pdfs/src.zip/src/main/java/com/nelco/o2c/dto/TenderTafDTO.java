/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.ClauseMst;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.LeadBidderMst;
import com.nelco.o2c.model.LeaseMst;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.PreCriteria;
import com.nelco.o2c.model.TendBidDet;

/**
 * @author Jayashankar.r
 *
 */
@Component
public class TenderTafDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<OppDetails> oppDetails= new ArrayList<OppDetails>();
	private TendBidDet tenderBidDetails = new TendBidDet();
	private List<PreCriteria> preCriterias= new ArrayList<PreCriteria>();
	private List<OppUploadDetail> oppUploadDetails= new ArrayList<OppUploadDetail>();
	private List<UserEmailDetailsBean> verticalHeads= new ArrayList<UserEmailDetailsBean>();
	private List<UserEmailDetailsBean> salesHeads= new ArrayList<UserEmailDetailsBean>();
	
	private List<LeaseMst> leaseList= new ArrayList<LeaseMst>();
	private List<ClauseMst> clauseList= new ArrayList<ClauseMst>();
	private List<FileTypeMst> fileTypeList= new ArrayList<FileTypeMst>();
	private List<LeadBidderMst> leadBidderList= new ArrayList<LeadBidderMst>();
	private Integer oppId;
	private String zohoStatus;
	private String sbu;

	public String getSbu() {
		return sbu;
	}

	public void setSbu(String sbu) {
		this.sbu = sbu;
	}

	public Integer getOppId() {
		return oppId;
	}

	public void setOppId(Integer oppId) {
		this.oppId = oppId;
	}

	public String getZohoStatus() {
		return zohoStatus;
	}

	public void setZohoStatus(String zohoStatus) {
		this.zohoStatus = zohoStatus;
	}

	public List<LeadBidderMst> getLeadBidderList() {
		return leadBidderList;
	}

	public void setLeadBidderList(List<LeadBidderMst> leadBidderList) {
		this.leadBidderList = leadBidderList;
	}

	public List<UserEmailDetailsBean> getVerticalHeads() {
		return verticalHeads;
	}

	public void setVerticalHeads(List<UserEmailDetailsBean> verticalHeads) {
		this.verticalHeads = verticalHeads;
	}

	public List<UserEmailDetailsBean> getSalesHeads() {
		return salesHeads;
	}

	public void setSalesHeads(List<UserEmailDetailsBean> salesHeads) {
		this.salesHeads = salesHeads;
	}

	public List<LeaseMst> getLeaseList() {
		return leaseList;
	}

	public void setLeaseList(List<LeaseMst> leaseList) {
		this.leaseList = leaseList;
	}

	public List<ClauseMst> getClauseList() {
		return clauseList;
	}

	public void setClauseList(List<ClauseMst> clauseList) {
		this.clauseList = clauseList;
	}

	public List<FileTypeMst> getFileTypeList() {
		return fileTypeList;
	}

	public void setFileTypeList(List<FileTypeMst> fileTypeList) {
		this.fileTypeList = fileTypeList;
	}

	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}

	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}

	public List<OppDetails> getOppDetails() {
		return oppDetails;
	}

	public void setOppDetails(List<OppDetails> oppDetails) {
		this.oppDetails = oppDetails;
	}

	public TendBidDet getTenderBidDetails() {
		return tenderBidDetails;
	}

	public void setTenderBidDetails(TendBidDet tenderBidDetails) {
		this.tenderBidDetails = tenderBidDetails;
	}

	public List<PreCriteria> getPreCriterias() {
		return preCriterias;
	}

	public void setPreCriterias(List<PreCriteria> preCriterias) {
		this.preCriterias = preCriterias;
	}

}
