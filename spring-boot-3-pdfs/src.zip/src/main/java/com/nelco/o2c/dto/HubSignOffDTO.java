/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.AntennaLocationMst;
import com.nelco.o2c.model.HsoTransactionDetail;
import com.nelco.o2c.model.HsoTransactionStatusMst;
import com.nelco.o2c.model.HubTechMst;
import com.nelco.o2c.model.NatureMst;

/**
 * @author Jayshankar.r
 *
 */
public class HubSignOffDTO  implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	private Integer userMstId;
	private String roleCode;
	private String fromDate;
	private String toDate;
	private List<HsoTransactionDetail> hsoList;
	private List<HsoTransactionStatusMst> statusHubList;
	private List<HubTechMst> hubTechList;
	private List<NatureMst> natureList;
	private Integer hsoTransactionStatusMstId;
	private List<AntennaLocationMst> antennaLocationList;
	private String fileName;
	private String isNext="Y";
	private Integer hsoTransactionDetailsId;
	
	
	
	
	
	
	
	
	public Integer getHsoTransactionDetailsId() {
		return hsoTransactionDetailsId;
	}
	public void setHsoTransactionDetailsId(Integer hsoTransactionDetailsId) {
		this.hsoTransactionDetailsId = hsoTransactionDetailsId;
	}
	public String getIsNext() {
		return isNext;
	}
	public void setIsNext(String isNext) {
		this.isNext = isNext;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public List<AntennaLocationMst> getAntennaLocationList() {
		return antennaLocationList;
	}
	public void setAntennaLocationList(List<AntennaLocationMst> antennaLocationList) {
		this.antennaLocationList = antennaLocationList;
	}
	public Integer getHsoTransactionStatusMstId() {
		return hsoTransactionStatusMstId;
	}
	public void setHsoTransactionStatusMstId(Integer hsoTransactionStatusMstId) {
		this.hsoTransactionStatusMstId = hsoTransactionStatusMstId;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public List<HsoTransactionDetail> getHsoList() {
		return hsoList;
	}
	public void setHsoList(List<HsoTransactionDetail> hsoList) {
		this.hsoList = hsoList;
	}
	
	public List<HsoTransactionStatusMst> getStatusHubList() {
		return statusHubList;
	}
	public void setStatusHubList(List<HsoTransactionStatusMst> statusHubList) {
		this.statusHubList = statusHubList;
	}
	public List<HubTechMst> getHubTechList() {
		return hubTechList;
	}
	public void setHubTechList(List<HubTechMst> hubTechList) {
		this.hubTechList = hubTechList;
	}
	public List<NatureMst> getNatureList() {
		return natureList;
	}
	public void setNatureList(List<NatureMst> natureList) {
		this.natureList = natureList;
	}
	
}
