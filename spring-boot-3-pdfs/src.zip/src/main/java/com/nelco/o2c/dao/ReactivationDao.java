package com.nelco.o2c.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.nelco.o2c.dto.DisconnectionReconnectionDatesToCSVDTO;
import com.nelco.o2c.dto.ReactivationListDTO;
import com.nelco.o2c.dto.ReqctivationRequestDetailsDTO;
import com.nelco.o2c.model.ReactivationRequestMst;

public interface ReactivationDao {

	List<ReactivationListDTO> getReactivationRequestsList(HttpServletRequest request);

	ReactivationRequestMst appRejReactivationRequest(ReactivationRequestMst toBeStatuses);

	ReactivationRequestMst initiateDisconnectionNotice(ReactivationRequestMst reactivationRequest);

	ReactivationRequestMst reactivateSite(ReactivationRequestMst toBeStatuses);

	String getInvoiceNoFromRequestId(String parameter);

	ReqctivationRequestDetailsDTO getReconnectionRequestDetails(String parameter);

	List<DisconnectionReconnectionDatesToCSVDTO> getBillingStartDate(String requestId);

}
