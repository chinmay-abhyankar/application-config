/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

import com.nelco.o2c.model.BrfStatusTracker;

/**
 * @author Amol.l
 *
 */
public class BrfStatusTrackerDTO   implements Serializable {

	private static final long serialVersionUID = 75L;
	
	private BrfStatusTracker brfStatusTracker = new BrfStatusTracker();

	public BrfStatusTracker getBrfStatusTracker() {
		return brfStatusTracker;
	}

	public void setBrfStatusTracker(BrfStatusTracker brfStatusTracker) {
		this.brfStatusTracker = brfStatusTracker;
	}

	
}
