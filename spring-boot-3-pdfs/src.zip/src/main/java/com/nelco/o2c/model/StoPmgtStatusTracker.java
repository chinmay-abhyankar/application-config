package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the sto_pmgt_status_tracker database table.
 * 
 */
@Entity
@Table(name = "sto_pmgt_status_tracker")
@NamedQuery(name = "StoPmgtStatusTracker.findAll", query = "SELECT s FROM StoPmgtStatusTracker s")
public class StoPmgtStatusTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sto_pmgt_status_tracker_id")
	private Integer stoPmgtStatusTrackerId;

	@Column(name = "req_by_id")
	private Integer reqById;

	@Column(name = "req_date")
	private String reqDate;

	@Column(name = "status_mst_id")
	private Integer statusMstId;

	@Column(name = "sto_pmgt_id")
	private Integer stoPmgtId;

	public Integer getStoPmgtStatusTrackerId() {
		return stoPmgtStatusTrackerId;
	}

	public void setStoPmgtStatusTrackerId(Integer stoPmgtStatusTrackerId) {
		this.stoPmgtStatusTrackerId = stoPmgtStatusTrackerId;
	}

	public Integer getReqById() {
		return reqById;
	}

	public void setReqById(Integer reqById) {
		this.reqById = reqById;
	}

	public String getReqDate() {
		return reqDate;
	}

	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}

	public Integer getStatusMstId() {
		return statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}

	public Integer getStoPmgtId() {
		return stoPmgtId;
	}

	public void setStoPmgtId(Integer stoPmgtId) {
		this.stoPmgtId = stoPmgtId;
	}

}