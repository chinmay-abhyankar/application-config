package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the material_child_contract database table.
 * 
 */
@Entity
@Table(name = "material_child_contract")
@NamedQueries({
@NamedQuery(name = "MaterialChildContract.findAll", query = "SELECT m FROM MaterialChildContract m"),
@NamedQuery(name = "MaterialChildContract.getMaterialChildContractById", query = "SELECT mcc FROM MaterialChildContract mcc where mcc.childContractId=?1 order by mcc.itemNum,mcc.createdDate ASC "),
@NamedQuery(name = "MaterialChildContract.materialListByChildContId", query = "SELECT mcc FROM MaterialChildContract mcc where mcc.childContractId=?1  order by mcc.itemNum,mcc.createdDate ASC "),
@NamedQuery(name = "MaterialChildContract.sumOfOrderQtyByChildContId", query = "SELECT sum(mcc.orderQty) FROM MaterialChildContract mcc where mcc.childContractId=?1  and mcc.materialNo not like '1201%'"),
})

public class MaterialChildContract implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "material_child_contract_id")
	private Integer materialChildContractId;

	@Column(name = "child_contract_id")
	private Integer childContractId;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "material_desc")
	private String materialDesc;

	@Column(name = "material_no")
	private String materialNo;

	@Column(name = "order_qty")
	private Integer orderQty;

	private String plant;

	private String rate;

	@Column(name = "sales_unit")
	private String salesUnit;
	
	@Column(name = "item_no")
	private String itemNum;
	
	@Column(name = "sales_org")
	private String salesOrg;
	
	@Column(name = "pricing_group_code")
	private String pricingGroupCode;
	
	@Column(name = "condition_type_code")
	private String conditionTypeCode;
	
	@Column(name = "dist_channel")
	private String distChannel;
	
	@Transient
	private Boolean disableMatNum = false;
	
	
	
	public String getDistChannel() {
		return distChannel;
	}

	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}

	public String getPricingGroupCode() {
		return pricingGroupCode;
	}

	public void setPricingGroupCode(String pricingGroupCode) {
		this.pricingGroupCode = pricingGroupCode;
	}

	public String getConditionTypeCode() {
		return conditionTypeCode;
	}

	public void setConditionTypeCode(String conditionTypeCode) {
		this.conditionTypeCode = conditionTypeCode;
	}

	public String getSalesOrg() {
		return salesOrg;
	}

	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

	public Boolean getDisableMatNum() {
		return disableMatNum;
	}

	public void setDisableMatNum(Boolean disableMatNum) {
		this.disableMatNum = disableMatNum;
	}

	public Integer getMaterialChildContractId() {
		return materialChildContractId;
	}

	public void setMaterialChildContractId(Integer materialChildContractId) {
		this.materialChildContractId = materialChildContractId;
	}

	public Integer getChildContractId() {
		return childContractId;
	}

	public void setChildContractId(Integer childContractId) {
		this.childContractId = childContractId;
	}

	private String value;

	public MaterialChildContract() {
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getMaterialDesc() {
		return this.materialDesc;
	}

	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}

	public String getMaterialNo() {
		return this.materialNo;
	}

	public void setMaterialNo(String materialNo) {
		this.materialNo = materialNo;
	}

	public Integer getOrderQty() {
		return this.orderQty;
	}

	public void setOrderQty(Integer orderQty) {
		this.orderQty = orderQty;
	}

	public String getPlant() {
		return this.plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getRate() {
		return this.rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getSalesUnit() {
		return this.salesUnit;
	}

	public void setSalesUnit(String salesUnit) {
		this.salesUnit = salesUnit;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getItemNum() {
		return itemNum;
	}

	public void setItemNum(String itemNum) {
		this.itemNum = itemNum;
	}

}