package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.AntennaSizeMaster;
import com.nelco.o2c.model.CountryMst;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.SegmentMst;
import com.nelco.o2c.model.StateMst;
import com.nelco.o2c.model.TechnologyMaster;

public class SiteSurveyFormDTO implements Serializable {
	private static final long serialVersionUID = 75L;
	
	private List<HubMst> hubMaster = new ArrayList<HubMst>();
	private List<TechnologyMaster> technologyMaster = new ArrayList<TechnologyMaster>();
	private List<AntennaSizeMaster> antennaSizeMaster = new ArrayList<AntennaSizeMaster>();
	private List<CountryMst> countryMaster = new ArrayList<CountryMst>();
	private List<StateMst> stateMst = new ArrayList<StateMst>();
	
	public List<CountryMst> getCountryMaster() {
		return countryMaster;
	}
	public void setCountryMaster(List<CountryMst> countryMaster) {
		this.countryMaster = countryMaster;
	}
	public List<StateMst> getStateMst() {
		return stateMst;
	}
	public void setStateMst(List<StateMst> stateMst) {
		this.stateMst = stateMst;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	//private List<AntennaSizeMaster> antennaSizeMaster = new ArrayList<AntennaSizeMaster>();
	public List<HubMst> getHubMaster() {
		return hubMaster;
	}
	public void setHubMaster(List<HubMst> hubMaster) {
		this.hubMaster = hubMaster;
	}
	public List<TechnologyMaster> getTechnologyMaster() {
		return technologyMaster;
	}
	public void setTechnologyMaster(List<TechnologyMaster> technologyMaster) {
		this.technologyMaster = technologyMaster;
	}
	public List<AntennaSizeMaster> getAntennaSizeMaster() {
		return antennaSizeMaster;
	}
	public void setAntennaSizeMaster(List<AntennaSizeMaster> antennaSizeMaster) {
		this.antennaSizeMaster = antennaSizeMaster;
	}
	
	
	
}
