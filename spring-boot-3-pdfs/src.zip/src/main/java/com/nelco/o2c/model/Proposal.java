package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;

/**
 * The persistent class for the proposal database table.
 * 
 */
@Entity
@Table(name = "proposal")
@NamedQueries({
		@NamedQuery(name = "Proposal.getExistingProposalByOpportunity", query = "select p from Proposal p where p.opportunityId=?1"),
		@NamedQuery(name = "Proposal.findAll", query = "SELECT p FROM Proposal p"),
		@NamedQuery(name = "Proposal.getMaxProposalnumber", query = "select max(p.proposalId) from Proposal p"),
		@NamedQuery(name = "Proposal.findByProposalId", query = "SELECT p FROM Proposal p where p.proposalId=?1 "),
		@NamedQuery(name = "Proposal.updateAccMgrRemarksByProposalId", query = " update Proposal p set p.accMgrRem=?1 where p.proposalId=?2 "),
		@NamedQuery(name="Proposal.findByOppIdAndProDate",query="select p FROM Proposal p where p.opportunityId=?1 and p.createdDate >= ?2 and p.createdDate <?3")
})
public class Proposal implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "proposal_id")
	private Integer proposalId;

	@Column(name = "acc_mgr_rem")
	private String accMgrRem;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date", updatable= false)
	private String createdDate;

	@Column(name = "current_status")
	private String currentStatus;

	@Column(name = "ent_banking_appr_id")
	private Integer entBankingApprId;

	@Column(name = "exp_del_date")
	private String expDelDate;

	@Column(name = "finance_id")
	private Integer financeId;

	@Column(name = "hub_mst_id")
	private Integer hubMstId;

	private String ipschema;

	@Column(name = "is_rate_change")
	private String isRateChange = "N";

	@Column(name = "net_design")
	private String netDesign;

	@Column(name = "opc_nochead_id")
	private Integer opcNocheadId;

	@Column(name = "opc_pmgthead_id")
	private Integer opcPmgtheadId;

	@Column(name = "opportunity_id")
	private Integer opportunityId;

	@Column(name = "pm_id")
	private Integer pmId;

	@Column(name = "presaleshead_appr_id")
	private Integer presalesheadApprId;

	@Column(name = "product_type_mst_id")
	private Integer productTypeMstId;

	@Column(name = "proposal_gen_id")
	private String proposalGenId;

	@Column(name = "service_order_det_id")
	private Integer serviceOrderDetId;

	@Column(name = "smowner_id")
	private String smownerId;

	@Column(name = "type_code")
	private String typeCode;

	@Column(name = "zoho_created_time")
	private String zohoCreatedTime;

	@Column(name = "zoho_id")
	private String zohoId;

	@Column(name = "zoho_modified_time")
	private String zohoModifiedTime;
	
	@Column(name = "sales_coord_id")
	private Integer salesCoordId;
	
	@Column(name = "po_number")
	private String poNumber;
	
	@Column(name = "po_date")
	private String poDate;
	
	@Column(name = "status_mst_id")
	private Integer statusMstId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "service_order_det_id", referencedColumnName = "service_order_det_id", insertable = false, updatable = false)
	private ServiceOrderMst serviceOrderMst;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "product_type_mst_id", referencedColumnName = "product_type_mst_id", insertable = false, updatable = false)
	private ProductTypeMst productTypeMst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "smowner_id", referencedColumnName = "sm_owner_id", insertable = false, updatable = false)
	private UserMst userMst;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "status_mst_id", referencedColumnName = "status_mst_id", insertable = false, updatable = false)
	private StatusMst statusMst;
	
	@Column(name = "order_type_mst_id")
	private Integer orderTypeMstId;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "order_type_mst_id", referencedColumnName = "order_type_mst_id", insertable = false, updatable = false)
	private OrderTypeMst orderTypeMst;
	
	@Column(name = "finance_tnsl_id")
	private Integer financeTnslId;
	
	
	
	public Integer getOrderTypeMstId() {
		return orderTypeMstId;
	}

	public void setOrderTypeMstId(Integer orderTypeMstId) {
		this.orderTypeMstId = orderTypeMstId;
	}

	public OrderTypeMst getOrderTypeMst() {
		return orderTypeMst;
	}

	public void setOrderTypeMst(OrderTypeMst orderTypeMst) {
		this.orderTypeMst = orderTypeMst;
	}

	public Integer getFinanceTnslId() {
		return financeTnslId;
	}

	public void setFinanceTnslId(Integer financeTnslId) {
		this.financeTnslId = financeTnslId;
	}

	public Integer getStatusMstId() {
		return statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}

	public StatusMst getStatusMst() {
		return statusMst;
	}

	public void setStatusMst(StatusMst statusMst) {
		this.statusMst = statusMst;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getPoDate() {
		return DateUtil.convertDateTimeToString(this.poDate);
		//return poDate;
	}

	public void setPoDate(String poDate) {
		this.poDate = poDate;
	}

	public Integer getSalesCoordId() {
		return salesCoordId;
	}

	public void setSalesCoordId(Integer salesCoordId) {
		this.salesCoordId = salesCoordId;
	}

	public ProductTypeMst getProductTypeMst() {
		return productTypeMst;
	}

	public void setProductTypeMst(ProductTypeMst productTypeMst) {
		this.productTypeMst = productTypeMst;
	}

	public ServiceOrderMst getServiceOrderMst() {
		return serviceOrderMst;
	}

	public void setServiceOrderMst(ServiceOrderMst serviceOrderMst) {
		this.serviceOrderMst = serviceOrderMst;
	}

	public Integer getProposalId() {
		return proposalId;
	}

	public void setProposalId(Integer proposalId) {
		this.proposalId = proposalId;
	}

	public String getAccMgrRem() {
		return accMgrRem;
	}

	public void setAccMgrRem(String accMgrRem) {
		this.accMgrRem = accMgrRem;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public Integer getEntBankingApprId() {
		return entBankingApprId;
	}

	public void setEntBankingApprId(Integer entBankingApprId) {
		this.entBankingApprId = entBankingApprId;
	}

	public String getExpDelDate() {
		return expDelDate;
	}

	public void setExpDelDate(String expDelDate) {
		this.expDelDate = expDelDate;
	}

	public Integer getFinanceId() {
		return financeId;
	}

	public void setFinanceId(Integer financeId) {
		this.financeId = financeId;
	}

	public Integer getHubMstId() {
		return hubMstId;
	}

	public void setHubMstId(Integer hubMstId) {
		this.hubMstId = hubMstId;
	}

	public String getIpschema() {
		return ipschema;
	}

	public void setIpschema(String ipschema) {
		this.ipschema = ipschema;
	}

	public String getIsRateChange() {
		return isRateChange;
	}

	public void setIsRateChange(String isRateChange) {
		this.isRateChange = isRateChange;
	}

	public String getNetDesign() {
		return netDesign;
	}

	public void setNetDesign(String netDesign) {
		this.netDesign = netDesign;
	}

	public Integer getOpcNocheadId() {
		return opcNocheadId;
	}

	public void setOpcNocheadId(Integer opcNocheadId) {
		this.opcNocheadId = opcNocheadId;
	}

	public Integer getOpcPmgtheadId() {
		return opcPmgtheadId;
	}

	public void setOpcPmgtheadId(Integer opcPmgtheadId) {
		this.opcPmgtheadId = opcPmgtheadId;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public Integer getPmId() {
		return pmId;
	}

	public void setPmId(Integer pmId) {
		this.pmId = pmId;
	}

	public Integer getPresalesheadApprId() {
		return presalesheadApprId;
	}

	public void setPresalesheadApprId(Integer presalesheadApprId) {
		this.presalesheadApprId = presalesheadApprId;
	}

	public Integer getProductTypeMstId() {
		return productTypeMstId;
	}

	public void setProductTypeMstId(Integer productTypeMstId) {
		this.productTypeMstId = productTypeMstId;
	}

	public String getProposalGenId() {
		return proposalGenId;
	}

	public void setProposalGenId(String proposalGenId) {
		this.proposalGenId = proposalGenId;
	}

	public Integer getServiceOrderDetId() {
		return serviceOrderDetId;
	}

	public void setServiceOrderDetId(Integer serviceOrderDetId) {
		this.serviceOrderDetId = serviceOrderDetId;
	}

	public String getSmownerId() {
		return smownerId;
	}

	public void setSmownerId(String smownerId) {
		this.smownerId = smownerId;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getZohoCreatedTime() {
		return zohoCreatedTime;
	}

	public void setZohoCreatedTime(String zohoCreatedTime) {
		this.zohoCreatedTime = zohoCreatedTime;
	}

	public String getZohoId() {
		return zohoId;
	}

	public void setZohoId(String zohoId) {
		this.zohoId = zohoId;
	}

	public String getZohoModifiedTime() {
		return zohoModifiedTime;
	}

	public void setZohoModifiedTime(String zohoModifiedTime) {
		this.zohoModifiedTime = zohoModifiedTime;
	}

	public UserMst getUserMst() {
		return userMst;
	}

	public void setUserMst(UserMst userMst) {
		this.userMst = userMst;
	}

	@Override
	public String toString() {
		return "Proposal [proposalId=" + proposalId + ", accMgrRem=" + accMgrRem + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + ", currentStatus=" + currentStatus + ", entBankingApprId="
				+ entBankingApprId + ", expDelDate=" + expDelDate + ", financeId=" + financeId + ", hubMstId="
				+ hubMstId + ", ipschema=" + ipschema + ", isRateChange=" + isRateChange + ", netDesign=" + netDesign
				+ ", opcNocheadId=" + opcNocheadId + ", opcPmgtheadId=" + opcPmgtheadId + ", opportunityId="
				+ opportunityId + ", pmId=" + pmId + ", presalesheadApprId=" + presalesheadApprId
				+ ", productTypeMstId=" + productTypeMstId + ", proposalGenId=" + proposalGenId + ", serviceOrderDetId="
				+ serviceOrderDetId + ", smownerId=" + smownerId + ", typeCode=" + typeCode + ", zohoCreatedTime="
				+ zohoCreatedTime + ", zohoId=" + zohoId + ", zohoModifiedTime=" + zohoModifiedTime + ", salesCoordId="
				+ salesCoordId + ", poNumber=" + poNumber + ", poDate=" + poDate + ", statusMstId=" + statusMstId
				+ ", serviceOrderMst=" + serviceOrderMst + ", productTypeMst=" + productTypeMst + ", userMst=" + userMst
				+ ", statusMst=" + statusMst + ", orderTypeMstId=" + orderTypeMstId + ", orderTypeMst=" + orderTypeMst
				+ ", financeTnslId=" + financeTnslId + "]";
	}
	

}