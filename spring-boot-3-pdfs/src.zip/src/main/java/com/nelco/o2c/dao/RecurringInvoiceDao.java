package com.nelco.o2c.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nelco.o2c.dto.RecurringInvoiceReportDTO;
import com.nelco.o2c.dto.SalesOrderReportDTO;
import com.nelco.o2c.dto.SalesReturnListDTO;
import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.service.RecurringInvoiceService;
import com.nelco.o2c.service.SalesReturnService;

public interface RecurringInvoiceDao {
	public List<SalesOrderReportDTO> getSalesOrderReport(HttpServletRequest request) ;
	
	public List<CustomerSapmst> getListCustomerAutoComplete(HttpServletRequest request); 
	
	public List<RecurringInvoiceReportDTO> getRecurringInvoiceReport(HttpServletRequest request);
	
	
}
