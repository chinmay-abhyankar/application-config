package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the hso_transaction_status_mst database table.
 * 
 */
@Entity
@Table(name="hso_transaction_status_mst")
@NamedQuery(name="HsoTransactionStatusMst.findAll", query="SELECT h FROM HsoTransactionStatusMst h")
public class HsoTransactionStatusMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="hso_transaction_status_mst_id")
	private Integer hsoTransactionStatusMstId;

	@Column(name="hso_transaction_status_code")
	private String hsoTransactionStatusCode;

	@Column(name="hso_transaction_status_value")
	private String hsoTransactionStatusValue;

	public HsoTransactionStatusMst() {
	}

	public Integer getHsoTransactionStatusMstId() {
		return this.hsoTransactionStatusMstId;
	}

	public void setHsoTransactionStatusMstId(Integer hsoTransactionStatusMstId) {
		this.hsoTransactionStatusMstId = hsoTransactionStatusMstId;
	}

	public String getHsoTransactionStatusCode() {
		return this.hsoTransactionStatusCode;
	}

	public void setHsoTransactionStatusCode(String hsoTransactionStatusCode) {
		this.hsoTransactionStatusCode = hsoTransactionStatusCode;
	}

	public String getHsoTransactionStatusValue() {
		return this.hsoTransactionStatusValue;
	}

	public void setHsoTransactionStatusValue(String hsoTransactionStatusValue) {
		this.hsoTransactionStatusValue = hsoTransactionStatusValue;
	}

}