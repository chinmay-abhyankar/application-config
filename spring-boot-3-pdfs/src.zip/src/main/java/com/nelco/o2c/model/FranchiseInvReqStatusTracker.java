package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the franchise_inv_req_status_tracker database table.
 * 
 */
@Entity
@Table(name="franchise_inv_req_status_tracker")
@NamedQuery(name="FranchiseInvReqStatusTracker.findAll", query="SELECT f FROM FranchiseInvReqStatusTracker f")
public class FranchiseInvReqStatusTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="franchise_inv_req_status_tracker_id")
	private Integer franchiseInvReqStatusTrackerId;

	@Column(name="franchise_inv_req_id")
	private Integer franchiseInvReqId;

	@Column(name="req_by_id")
	private Integer reqById;

	@Column(name="req_date")
	private String reqDate;

	@Column(name="status_code")
	private String statusCode;
	
	@Column(name = "rej_remarks")
	private String rejRemarks;
	
	

	public String getRejRemarks() {
		return rejRemarks;
	}

	public void setRejRemarks(String rejRemarks) {
		this.rejRemarks = rejRemarks;
	}

	public FranchiseInvReqStatusTracker() {
	}

	public Integer getFranchiseInvReqStatusTrackerId() {
		return franchiseInvReqStatusTrackerId;
	}

	public void setFranchiseInvReqStatusTrackerId(Integer franchiseInvReqStatusTrackerId) {
		this.franchiseInvReqStatusTrackerId = franchiseInvReqStatusTrackerId;
	}

	public Integer getFranchiseInvReqId() {
		return franchiseInvReqId;
	}

	public void setFranchiseInvReqId(Integer franchiseInvReqId) {
		this.franchiseInvReqId = franchiseInvReqId;
	}

	public Integer getReqById() {
		return reqById;
	}

	public void setReqById(Integer reqById) {
		this.reqById = reqById;
	}

	public String getReqDate() {
		return reqDate;
	}

	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	

	

	

}