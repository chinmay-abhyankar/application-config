package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the status_mst database table.
 * 
 */
@Entity
@Table(name="status_mst")
@NamedQueries({
	@NamedQuery(name="StatusMst.findAll", query="SELECT s FROM StatusMst s"),
	@NamedQuery(name="StatusMst.findByCode", query="SELECT s FROM StatusMst s where s.statusCode in :statusCodeList "),
	@NamedQuery(name="StatusMst.searchByStatusCode",query="select s from StatusMst s where status_code like ?1")
})

public class StatusMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="status_mst_id")
	private Integer statusMstId;

	@Column(name="status_code")
	private String statusCode;

	@Column(name="status_name")
	private String statusName;

	public Integer getStatusMstId() {
		return statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	@Override
	public String toString() {
		return "StatusMst [statusMstId=" + statusMstId + ", statusCode=" + statusCode + ", statusName=" + statusName
				+ "]";
	}

	

}