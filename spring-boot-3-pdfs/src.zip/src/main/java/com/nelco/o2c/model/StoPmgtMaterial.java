package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the sto_pmgt_material database table.
 * 
 */
@Entity
@Table(name = "sto_pmgt_material")
@NamedQuery(name = "StoPmgtMaterial.findAll", query = "SELECT s FROM StoPmgtMaterial s")
public class StoPmgtMaterial implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sto_pmgt_material_id")
	private Integer stoPmgtMaterialId;

	@Column(name = "avail_material_num")
	private String availMaterialNum;

	@Column(name = "avail_quantity")
	private String availQuantity;

	@Column(name = "rec_plant_code")
	private String recPlantCode;

	@Column(name = "req_material_desc")
	private String reqMaterialDesc;

	@Column(name = "req_material_num")
	private String reqMaterialNum;

	@Column(name = "req_quantity")
	private String reqQuantity;

	@Column(name = "storage_code")
	private String storageCode;

	@Column(name = "sto_pmgt_id")
	private Integer stoPmgtId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "rec_plant_code", referencedColumnName = "plant_code", insertable = false, updatable = false)
	private PlantSapmst plantSapmst;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({@JoinColumn(name = "storage_code", referencedColumnName = "storage_code", insertable = false, updatable = false),
		@JoinColumn(name = "rec_plant_code", referencedColumnName = "plant_code", insertable = false, updatable = false)})
	private StorageSapmst storageSapmst;

	public PlantSapmst getPlantSapmst() {
		return plantSapmst;
	}

	public void setPlantSapmst(PlantSapmst plantSapmst) {
		this.plantSapmst = plantSapmst;
	}

	public StorageSapmst getStorageSapmst() {
		return storageSapmst;
	}

	public void setStorageSapmst(StorageSapmst storageSapmst) {
		this.storageSapmst = storageSapmst;
	}

	public Integer getStoPmgtId() {
		return stoPmgtId;
	}

	public void setStoPmgtId(Integer stoPmgtId) {
		this.stoPmgtId = stoPmgtId;
	}

	public Integer getStoPmgtMaterialId() {
		return stoPmgtMaterialId;
	}

	public void setStoPmgtMaterialId(Integer stoPmgtMaterialId) {
		this.stoPmgtMaterialId = stoPmgtMaterialId;
	}

	public String getAvailMaterialNum() {
		return availMaterialNum;
	}

	public void setAvailMaterialNum(String availMaterialNum) {
		this.availMaterialNum = availMaterialNum;
	}

	public String getAvailQuantity() {
		return availQuantity;
	}

	public void setAvailQuantity(String availQuantity) {
		this.availQuantity = availQuantity;
	}

	public String getRecPlantCode() {
		return recPlantCode;
	}

	public void setRecPlantCode(String recPlantCode) {
		this.recPlantCode = recPlantCode;
	}

	public String getReqMaterialDesc() {
		return reqMaterialDesc;
	}

	public void setReqMaterialDesc(String reqMaterialDesc) {
		this.reqMaterialDesc = reqMaterialDesc;
	}

	public String getReqMaterialNum() {
		return reqMaterialNum;
	}

	public void setReqMaterialNum(String reqMaterialNum) {
		this.reqMaterialNum = reqMaterialNum;
	}

	public String getReqQuantity() {
		return reqQuantity;
	}

	public void setReqQuantity(String reqQuantity) {
		this.reqQuantity = reqQuantity;
	}

	public String getStorageCode() {
		return storageCode;
	}

	public void setStorageCode(String storageCode) {
		this.storageCode = storageCode;
	}

}