package com.nelco.o2c.dto;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class InvoiceInfoDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3707312261781043535L;
	private String invoiceNo="";
	private String invoiceDate="";
	private String invoiceSubmissionDate="";
	private String paymentDueDate="";
	private String soNo="";
	private String outstandingAmt="";
	
//	public InvoiceInfoDTO(String invoiceNo,String invoiceDate,String invoiceSubmissionDate,String paymentDueDate,String soNo,String outstandingAmt){
//		this.invoiceNo=invoiceNo;
//		this.invoiceDate=invoiceDate;
//		this.invoiceSubmissionDate=invoiceSubmissionDate;
//		this.paymentDueDate=paymentDueDate;
//		this.soNo=soNo;
//		this.outstandingAmt=outstandingAmt;
//	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getInvoiceSubmissionDate() {
		return invoiceSubmissionDate;
	}
	public void setInvoiceSubmissionDate(String invoiceSubmissionDate) {
		this.invoiceSubmissionDate = invoiceSubmissionDate;
	}
	public String getPaymentDueDate() {
		return paymentDueDate;
	}
	public void setPaymentDueDate(String paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}
	public String getSoNo() {
		return soNo;
	}
	public void setSoNo(String soNo) {
		this.soNo = soNo;
	}
	public String getOutstandingAmt() {
		return outstandingAmt;
	}
	public void setOutstandingAmt(String outstandingAmt) {
		this.outstandingAmt = outstandingAmt;
	}
	
}
