/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.GeoTempDTO;
import com.nelco.o2c.dto.GeoTemplateDTO;
import com.nelco.o2c.model.GeoTemplate;
import com.nelco.o2c.model.GeoTemplateStatusTracker;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Amol.l
 *
 */
@Repository
public class GeoTemplateDaoImpl implements GeoTemplateDao {

	@PersistenceContext
	private EntityManager em;

	Query query;
	StoredProcedureQuery spQuery;
	
	@Override
	public List<GeoTempDTO> getGeoTemplateListByBrfId(GeoTemplateDTO geoTemplateDTO) {

		try {
//Need to check query getting double records
			String queryString = "";
			String fromDate ="";
			String toDate ="";
			if(geoTemplateDTO.getFromDate() != null && !geoTemplateDTO.getFromDate().equalsIgnoreCase("")) {
			fromDate = DateUtil.convertDateToSqlDate(geoTemplateDTO.getFromDate());
			}else {
				fromDate = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			}
			if(geoTemplateDTO.getToDate() != null && !geoTemplateDTO.getToDate().equalsIgnoreCase("")) {
			toDate = DateUtil.convertDateToSqlDate(geoTemplateDTO.getToDate());
			}else {
				toDate = DateUtil.getSimpleUIDateFromSqlDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
			}
			
/*			
			queryString = "select c.con_start_date,c.con_end_date,c.sap_contract_num,c.quarter,c.market_segment,"
					+ " b.old_so_num,b.bw_allocation,b.existing_site, gt.geo_template_id,gt.brf_id,gt.request_date,"
					+ " gt.request_type,gt.hub,gt.sold_to_party,gt.sub_sold_to_party,gt.technology,gt.band,gt.vsat_id,gt.vsat_ip,"
					+ " gt.new_vsat_ip,gt.vsat_subnet_mask,gt.lan_ip,gt.lan_subnet_mask,gt.so_num,gt.latitude,gt.longitude,gt.rac_code,"
					+ " gt.amsl,gt.height_of_antenna,gt.height_of_mast,gt.height_of_building,gt.tramsmitter_op_power,gt.bw_satellite_det,"
					+ " gt.po_num,gt.install_date,gt.antenna_size,gt.antenna_make,gt.cable_length,gt.idu_serial,gt.lnbc_serial_num,"
					+ " gt.buc_serial_num,gt.ladder_lenght,gt.monkey_cage,gt.ups,gt.franchise_mst_id,gt.hsn_num,gt.sacfa,gt.status_mst_id,"
					+ " gt.new_postal_address,gt.region,gt.location,gt.created_date,gt.ic_invoice,gt.serial_num,"
					+ " sm.status_name,sm.status_code,fm.franchise_name,b.site_name  "
					+ " from child_contract c "
					+ " inner join contract con on c.contract_id = con.contract_id "
					+ " inner join proposal p on con.proposal_id = p.proposal_id "
//					+ " inner join service_order_mst som on som.service_order_det_id = con.service_order_det_id "
					+ " inner join brf b on c.child_contract_id = b.child_contract_id "
					+ " inner join geo_template gt on b.brf_id = gt.brf_id "
					+ " inner join status_mst sm on gt.status_mst_id = sm.status_mst_id "
					+ " left join franchise_mst fm on gt.franchise_mst_id = fm.franchise_mst_id "
					+ " where som.service_order_det_id is not null and gt.created_date between ?1 and ?2 and b.brf_id = ?3 ";
			
			if (geoTemplateDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)) {
				queryString = queryString
						+ " and b.prog_mgr=?4 and sm.status_code in('BRFA','GTNS','GTSTN','GTSTREG','RUSACFAN','RSSNICSN') ";
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, geoTemplateDTO.getBrfId());
				query.setParameter(4, geoTemplateDTO.getUserMstId());

			} else if (geoTemplateDTO.getRoleCode().equals(Constants.NOCMGRCODE)) {
				queryString = queryString
						+ " and b.noc_mgr_id = ?4 and sm.status_code in('GTSTN','GTSTREG','RUSACFAN','RSSNICSN') ";
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, geoTemplateDTO.getBrfId());
				query.setParameter(4, geoTemplateDTO.getUserMstId());
			} else if (geoTemplateDTO.getRoleCode().equals(Constants.REGULATORYHEAD)) {
				queryString = queryString
						+ " and b.regulatory_id = ?4 and sm.status_code in('GTSTREG','RUSACFAN','RSSNICSN') ";
				
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, geoTemplateDTO.getBrfId());
				query.setParameter(4, geoTemplateDTO.getUserMstId());
			}
			
			*/
			List<GeoTempDTO> geoTempDTOList = new ArrayList<GeoTempDTO>();
			GeoTempDTO geoTempDTO = null;

			spQuery = em.createStoredProcedureQuery("isp_getGeoTemplateListByBrfId")
					.registerStoredProcedureParameter("fromDate", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("toDate", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("userMstId", Integer.class, ParameterMode.IN)
					.registerStoredProcedureParameter("roleCode", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("brfId", Integer.class, ParameterMode.IN);
			spQuery.setParameter("fromDate", fromDate)
					.setParameter("toDate", toDate + " 23:59:59")
					.setParameter("userMstId", geoTemplateDTO.getUserMstId())
					.setParameter("roleCode", geoTemplateDTO.getRoleCode())
					.setParameter("brfId", geoTemplateDTO.getBrfId());
			
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) spQuery.getResultList();
			
			for (Object[] objects : resultList) {
				geoTempDTO = new GeoTempDTO();
				
				geoTempDTO.setConStartDate(DateUtil.convertDateTimeToString(objects[0].toString()));
				geoTempDTO.setConEndDate(DateUtil.convertDateTimeToString(objects[1].toString()));
				geoTempDTO.setSapContractNum((String) objects[2]);
				geoTempDTO.setQuarter((String) objects[3]);
				geoTempDTO.setMarketSegment((String) objects[4]);
				geoTempDTO.setOldSoNum((String) objects[5]);
				geoTempDTO.setBwAllocation((String) objects[6]);
				geoTempDTO.setExistingSite((String) objects[7]);
				geoTempDTO.setGeoTemplateId((Integer) objects[8]);
				geoTempDTO.setBrfId((Integer) objects[9]);
				geoTempDTO.setRequestDate(DateUtil.convertDateTimeToString(objects[10].toString()));
				geoTempDTO.setRequestType((String) objects[11]);
				geoTempDTO.setHub((String) objects[12]);
				geoTempDTO.setSoldToParty((String) objects[13]);
				geoTempDTO.setSubSoldToParty((String) objects[14]);        
				geoTempDTO.setTechnology((String) objects[15]);       
				geoTempDTO.setBand((String) objects[16]);
				geoTempDTO.setVsatId((String) objects[17]);
				geoTempDTO.setVsatIp((String) objects[18]);
				geoTempDTO.setNewVsatIp((String) objects[19]);
				geoTempDTO.setVsatSubnetMask((String) objects[20]);
				geoTempDTO.setLanIp((String) objects[21]);
				geoTempDTO.setLanSubnetMask((String) objects[22]);
				geoTempDTO.setSoNum((String) objects[23]);
				geoTempDTO.setLatitude((String) objects[24]);
				geoTempDTO.setLongitude((String) objects[25]);
				geoTempDTO.setRacCode((String) objects[26]);
				geoTempDTO.setAmsl((String) objects[27]);
				geoTempDTO.setHeightOfAntenna((String) objects[28]);
				geoTempDTO.setHeightOfMast((String) objects[29]);
				geoTempDTO.setHeightOfBuilding((String) objects[30]);
				geoTempDTO.setTramsmitterOpPower((String) objects[31]);
				geoTempDTO.setBwSatelliteDet((String) objects[32]);
				geoTempDTO.setPoNum((String) objects[33]);
				geoTempDTO.setInstallDate(DateUtil.convertDateTimeToString(objects[34].toString()));
				geoTempDTO.setAntennaSize((String) objects[35]);
				geoTempDTO.setAntennaMake((String) objects[36]);     
				geoTempDTO.setCableLength((String) objects[37]);
				geoTempDTO.setIduSerial((String) objects[38]);      
				geoTempDTO.setLnbcSerialNum((String) objects[39]);
				geoTempDTO.setBucSerialNum((String) objects[40]);
				geoTempDTO.setLadderLenght((String) objects[41]);
				geoTempDTO.setMonkeyCage((String) objects[42]);
				geoTempDTO.setUps((String) objects[43]);
				geoTempDTO.setFranchiseMstId((Integer) objects[44]);
				geoTempDTO.setHsnNum((String) objects[45]);
				geoTempDTO.setSacfa((String) objects[46]);
				geoTempDTO.setStatusMstId((Integer) objects[47]);
				geoTempDTO.setNewPostalAddress((String) objects[48]);
				geoTempDTO.setRegion((String) objects[49]);
				geoTempDTO.setLocation((String) objects[50]);
				geoTempDTO.setCreatedDate(DateUtil.convertDateTimeToString(objects[51].toString()));
				geoTempDTO.setIcInvoice((String) objects[52]);
				geoTempDTO.setSerialNum((String) objects[53]);
				geoTempDTO.setStatusName((String) objects[54]);
				geoTempDTO.setStatusCode((String) objects[55]);
				geoTempDTO.setFranchiseName((String) objects[56]);
				geoTempDTO.setSiteName((String) objects[57]);
				geoTempDTOList.add(geoTempDTO);
			}
			return geoTempDTOList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<GeoTempDTO>();
		} finally {
			em.close();
		}
	}

	@Override
	public GeoTemplate getGeoTempByGeoTempId(Integer geoTemplateId) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("GeoTemplate.getGeoTempByGeoTempId");
			query.setParameter(1, geoTemplateId);
			GeoTemplate geoTemplate = (GeoTemplate) query.getSingleResult();
			return geoTemplate;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new GeoTemplate();
		} finally {
			em.close();
		}
	}

	@Override
	public GeoTemplate saveGeoTemplate(GeoTemplate geoTemplate) {
		// TODO Auto-generated method stub
		geoTemplate.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		GeoTemplate geoTemplateNew = em.merge(geoTemplate);
		if (geoTemplate.getGeoTemplateId() == null) {
			em.refresh(geoTemplateNew);
		}
		return geoTemplateNew;
	}

	@Override
	public GeoTemplateStatusTracker saveGeoTemplateStatusTracker(GeoTemplateStatusTracker geoTemplateStatusTracker) {
		try {
			// TODO Auto-generated method stub
			geoTemplateStatusTracker.setStatusReqDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
			GeoTemplateStatusTracker geoTemplateStatusTrackerNew = em.merge(geoTemplateStatusTracker);
			if (geoTemplateStatusTracker.getGeoTemplateStatusTrackerId() == null) {
				em.refresh(geoTemplateStatusTrackerNew);
			}
			return geoTemplateStatusTrackerNew;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

}
