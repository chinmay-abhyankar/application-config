package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the payment_collection_customerwise database table.
 * 
 */
@Entity
@Table(name="payment_collection_customerwise")
@NamedQuery(name="PaymentCollectionCustomerwise.findAll", query="SELECT p FROM PaymentCollectionCustomerwise p")
@NamedNativeQueries({
	@NamedNativeQuery(name = "PaymentCollectionCustomerwise.getRequestId", query = "SELECT 'PC_'+FORMAT(GETDATE(),'dd')+'_'+FORMAT(GETDATE(),'MM')+'_'+FORMAT(GETDATE(),'yyyy')+'_'+CAST(COALESCE(MAX(typeid),0)+1 AS VARCHAR)FROM payment_collection_customerwise"),
	
	})
public class PaymentCollectionCustomerwise implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private int typeid;

	@Column(insertable=false, updatable=false, length=2)
	private String actflag;

	@Column(name="collected_amt", precision=18, scale=2)
	private BigDecimal collectedAmt;

	@Column(length=50)
	private String customer;

	@Column(name="payment_date")
	private String paymentDate;

	@Column(name="payment_no", length=50)
	private String paymentNo;

	@Column(name="updated_on", insertable=false, updatable=false)
	private Timestamp updatedOn;

	private String updatedby;
	
	@Column(name="cheque_date")
	private String chequeDate;

	@Column(name="cheque_no", length=50)
	private String chequeNo;

	public PaymentCollectionCustomerwise() {
	}

	public String getChequeDate() {
		return chequeDate;
	}

	public void setChequeDate(String chequeDate) {
		this.chequeDate = chequeDate;
	}

	public String getChequeNo() {
		return chequeNo;
	}

	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public BigDecimal getCollectedAmt() {
		return this.collectedAmt;
	}

	public void setCollectedAmt(BigDecimal collectedAmt) {
		this.collectedAmt = collectedAmt;
	}

	public String getCustomer() {
		return this.customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getPaymentDate() {
		return this.paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getPaymentNo() {
		return this.paymentNo;
	}

	public void setPaymentNo(String paymentNo) {
		this.paymentNo = paymentNo;
	}

	public Timestamp getUpdatedOn() {
		return this.updatedOn;
	}

	public void setUpdatedOn(Timestamp updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getUpdatedby() {
		return this.updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

}