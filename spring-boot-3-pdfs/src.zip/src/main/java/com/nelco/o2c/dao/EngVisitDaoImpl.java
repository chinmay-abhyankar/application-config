/**
 * 
 */
package com.nelco.o2c.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.ConstantProperties;
import com.nelco.o2c.dto.HubSignOffDTO;
import com.nelco.o2c.dto.PaymentRequestDTO;
import com.nelco.o2c.dto.VisitCommonDTO;
import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.ActivityTypeMst;
import com.nelco.o2c.model.AntennaLocationMst;
import com.nelco.o2c.model.AntennaSizeMaster;
import com.nelco.o2c.model.AntennaTypeMst;
import com.nelco.o2c.model.DocSubRecDetail;
import com.nelco.o2c.model.FaEngVisitDetail;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.FranchiseInvReq;
import com.nelco.o2c.model.FranchiseInvReqStatusTracker;
import com.nelco.o2c.model.FranchiseInvReqUserMap;
import com.nelco.o2c.model.HsoStatusChangeTracker;
import com.nelco.o2c.model.HsoTransactionDetail;
import com.nelco.o2c.model.HsoTransactionStatusMst;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.HubTechMst;
import com.nelco.o2c.model.IncAttributionMst;
import com.nelco.o2c.model.IncInvoice;
import com.nelco.o2c.model.InstallationStatusMst;
import com.nelco.o2c.model.KmApplMst;
import com.nelco.o2c.model.NatureMst;
import com.nelco.o2c.model.NonFeasibleOptionMst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.SiteSurveyCost;
import com.nelco.o2c.model.SiteSurveyEngineerMst;
import com.nelco.o2c.model.SiteSurveyMaster;
import com.nelco.o2c.model.SiteSurveyTrackerMaster;
import com.nelco.o2c.model.SsEngVisitDetail;
import com.nelco.o2c.model.StatusMst;
import com.nelco.o2c.model.TechnologyMaster;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.model.WorkCompletionStatusMst;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class EngVisitDaoImpl implements EngVisitDao {
	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	CommonPotentialsDao commonPOtentialsDao;
	
	@Autowired
	SchedulerDao schedulerDao;
	
	@Autowired
	ConstantProperties properties;
	
	@Autowired
	ConstantProperties prop;

	Query query;

	@Override
	public SsEngVisitDetail getVisitDetails(VisitCommonDTO visitCommonDTOInput) {
		try {
			// TODO Auto-generated method stub
			SsEngVisitDetail ssEngVisitDetail = em.find(SsEngVisitDetail.class,
					visitCommonDTOInput.getSsEngVisitDetailsId());
			return ssEngVisitDetail;
		} catch (Exception e) {
			// TODO: handle exception
			return new SsEngVisitDetail();
		} finally {
			//em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SsEngVisitDetail> getVisitListBySurveyMstId(VisitCommonDTO visitCommonDTOInput) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("SsEngVisitDetail.findBySiteSurveyMstId");
			query.setParameter(1, visitCommonDTOInput.getSiteSurveyMstId());
			List<SsEngVisitDetail> resultList = (List<SsEngVisitDetail>) query.getResultList();
			for (SsEngVisitDetail ssEngVisitDetail : resultList) {
				query = em.createNamedQuery("SiteSurveyMaster.findById");
				query.setParameter(1, visitCommonDTOInput.getSiteSurveyMstId());
				List<SiteSurveyMaster> smList = (List<SiteSurveyMaster>) query.getResultList();
				ssEngVisitDetail.setSiteSurveyId(smList!=null && smList.size()>0? smList.get(0).getUniq_id():"");
				query = em.createNamedQuery("SiteSurveyEngineerMst.findById");
				query.setParameter(1, ssEngVisitDetail.getSiteSurveyEngMstId());
				List<SiteSurveyEngineerMst> engList = query.getResultList();
				if(engList.size()>0) {
					SiteSurveyEngineerMst siteSurveyEngineerMst = engList.get(0);
					ssEngVisitDetail.setEngName(siteSurveyEngineerMst.getName());
					ssEngVisitDetail.setFranchiseName(siteSurveyEngineerMst.getFranchiseeMaster().getFranchise_name());
				}
				
			}
			return resultList;
		} finally {
			//em.close();
		}
	}

	@Override
	public List<AntennaSizeMaster> getAntennaSizeList() {
		try {
			query = em.createNamedQuery("AntennaSizeMaster.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<AntennaSizeMaster> antennaSizeList = (List<AntennaSizeMaster>) query.getResultList();
			return antennaSizeList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<AntennaSizeMaster>();
		} finally {
			//em.close();
		}
	}

	@Override
	public List<WorkCompletionStatusMst> getWorkCompletionStatusList() {
		try {
			query = em.createNamedQuery("WorkCompletionStatusMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<WorkCompletionStatusMst> workCompletionStatusList = (List<WorkCompletionStatusMst>) query
					.getResultList();
			return workCompletionStatusList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<WorkCompletionStatusMst>();
		} finally {
			//em.close();
		}
	}

	@Override
	public SsEngVisitDetail saveVisitDetails(VisitCommonDTO visitCommonDTOInput) {
		// TODO Auto-generated method stub
		try {
			SsEngVisitDetail ssEngVisitDetailToSave = visitCommonDTOInput.getSsEngVisitDetail();
			if(ssEngVisitDetailToSave.getSsEngVisitDetailsId()==null) {
				String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
				ssEngVisitDetailToSave.setCreatedDate(currTime);
			}
			
			String visitDate = DateUtil.convertDateToSqlDate(ssEngVisitDetailToSave.getVisitDate());
			ssEngVisitDetailToSave.setVisitDate(visitDate);
			ssEngVisitDetailToSave.setSiteSurveyId(null);
			ssEngVisitDetailToSave.setEngName(null);
			ssEngVisitDetailToSave.setFranchiseName(null);
			SsEngVisitDetail ssEngVisitDetail = em.merge(ssEngVisitDetailToSave);
			return ssEngVisitDetail;
		} finally {
			//em.close();
		}

	}

	@Override
	public void updateSiteSurveyStatus(SsEngVisitDetail ssEngVisitDetail, Integer sitesurveysuccesscode,Integer userMstId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("SiteSurveyMaster.updateEngineerAllocatedStatus");
			query.setParameter(1, sitesurveysuccesscode);
			query.setParameter(2, ssEngVisitDetail.getSiteSurveyMstId());
			query.executeUpdate();
			
			SiteSurveyTrackerMaster siteSurveyTrackerMaster=new SiteSurveyTrackerMaster();
			siteSurveyTrackerMaster.setSite_survey_id(ssEngVisitDetail.getSiteSurveyMstId());
			siteSurveyTrackerMaster.setStatus(sitesurveysuccesscode);
			siteSurveyTrackerMaster.setUser_id(userMstId);
			siteSurveyTrackerMaster.setComm_date((DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS)));
			em.merge(siteSurveyTrackerMaster);
			
		} finally {
			//em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SiteSurveyCost> getSiteSurveyCostList(VisitCommonDTO visitCommonDTOInput) {
		// TODO Auto-generated method stub
		String fromDate = DateUtil.convertDateToSqlDate(visitCommonDTOInput.getFromDate());
		String toDate = DateUtil.convertDateToSqlDate(visitCommonDTOInput.getToDate()) + Constants.MAXDAYTIME;
		if(visitCommonDTOInput.getRoleCode().equals(Constants.SUPPEXECROLECODE)) {
			query = em.createNamedQuery("SiteSurveyCost.findAllForSuppExec");
			query.setParameter("userMstId", visitCommonDTOInput.getUserMstId());
			query.setParameter("fromDate", fromDate);
			query.setParameter("toDate", toDate);
		} /*else if(visitCommonDTOInput.getRoleCode().equals(Constants.HOCSROLECODE)) {
			query = em.createNamedQuery("SiteSurveyCost.findAllForHoCs");
			query.setParameter(1, visitCommonDTOInput.getUserMstId());
			query.setParameter(2, fromDate);
			query.setParameter(3, toDate);
		}*/ /*else if(visitCommonDTOInput.getRoleCode().equals(Constants.PMGTHEADCODE)) {
			query = em.createNamedQuery("SiteSurveyCost.findAllPmgtCSHead");
			query.setParameter(1, visitCommonDTOInput.getUserMstId());
			query.setParameter(2, fromDate);
			query.setParameter(3, toDate);
		}*/ else if(visitCommonDTOInput.getRoleCode().equals(Constants.FRANCHISECOORDCODE)) {
			//query = em.createNativeQuery("select franchisee_id from user_to_franchisee_mst where user_mst_id = "+visitCommonDTOInput.getUserMstId());
			/*List<Object> franchObjList = query.getResultList();
			List<Integer> franchiseParamList = new ArrayList<Integer>();
			for (Object object : franchObjList) {
				franchiseParamList.add((Integer)object);
			}*/
			
			query = em.createNamedQuery("SiteSurveyCost.findAllFranCoord");
			query.setParameter("userMstId", visitCommonDTOInput.getUserMstId());
			query.setParameter("fromDate", fromDate);
			query.setParameter("toDate", toDate);
		} /*else {
			query = em.createNamedQuery("SiteSurveyCost.findAllWithDateFilter");
			query.setParameter(1, fromDate);
			query.setParameter(2, toDate);
		}*/
		List<Object[]> queryResult = (List<Object[]>) query.getResultList();
		List<SiteSurveyCost> resultList = new ArrayList<SiteSurveyCost>();
		for (Object[] objects : queryResult) {
			SiteSurveyCost siteSurveyCost = new SiteSurveyCost();
			siteSurveyCost.setSiteSurveyCostId(objects[0]!=null?(Integer)objects[0]:null);
			siteSurveyCost.setAppCost(objects[1]!=null?(String)objects[1]:"");
			siteSurveyCost.setCreatedDate(objects[2]!=null?(String)objects[2]:"");
			siteSurveyCost.setCsAppr(objects[3]!=null?(String)objects[3]:"");
			siteSurveyCost.setCsApprDate(objects[4]!=null?(String)objects[4]:"");
			siteSurveyCost.setCsApprRemarks(objects[5]!=null?(String)objects[5]:"");
			siteSurveyCost.setCsHeadAppr(objects[6]!=null?(String)objects[6]:"");
			siteSurveyCost.setCsHeadApprDate(objects[7]!=null?(String)objects[7]:"");
			siteSurveyCost.setCsHeadApprRemarks(objects[8]!=null?(String)objects[8]:"");
			siteSurveyCost.setCsHeadId(objects[9]!=null?(Integer)objects[9]:null);
			siteSurveyCost.setCsId(objects[10]!=null?(Integer)objects[10]:null);
			siteSurveyCost.setDefaultCost(objects[11]!=null?(BigDecimal)objects[11]:null);
			siteSurveyCost.setFranchiseMstId(objects[12]!=null?(Integer)objects[12]:null);
			siteSurveyCost.setHoCsAppr(objects[13]!=null?(String)objects[13]:null);
			siteSurveyCost.setHoCsApprDate(objects[14]!=null?(String)objects[14]:null);
			siteSurveyCost.setHoCsApprRemarks(objects[15]!=null?(String)objects[15]:null);
			siteSurveyCost.setHoCsId(objects[16]!=null?(Integer)objects[16]:null);
			siteSurveyCost.setMannualCost(objects[17]!=null?(BigDecimal)objects[17]:null);
			siteSurveyCost.setOtherCost(objects[18]!=null?(BigDecimal)objects[18]:null);
			siteSurveyCost.setSiteSurveyMstId(objects[19]!=null?(Integer)objects[19]:null);
			siteSurveyCost.setStatusMstId(objects[20]!=null?(Integer)objects[20]:null);
			siteSurveyCost.setTotalCost(objects[21]!=null?(BigDecimal)objects[21]:null);
			siteSurveyCost.setFranchiseeAllocationMstId(objects[22]!=null?(Integer)objects[22]:null);
			siteSurveyCost.setFranchiseInvReqId(objects[23]!=null?(Integer)objects[23]:null);
			siteSurveyCost.setSiteSurveyId(objects[24]!=null?(String)objects[24]:null);
			siteSurveyCost.setFranchiseAllocUniqId(objects[25]!=null?(String)objects[25]:null);
			siteSurveyCost.setFranchiseName(objects[26]!=null?(String)objects[26]:"");
			
			StatusMst statusMst = new StatusMst();
			statusMst.setStatusMstId(objects[27]!=null?(Integer)objects[27]:null);
			statusMst.setStatusCode(objects[28]!=null?(String)objects[28]:"");
			statusMst.setStatusName(objects[29]!=null?(String)objects[29]:"");
			siteSurveyCost.setStatusMst(statusMst);
			resultList.add(siteSurveyCost);
		}
		
		/*for (SiteSurveyCost siteSurveyCost : resultList) {
			query = em.createNamedQuery("SiteSurveyMaster.findById");
			query.setParameter(1, siteSurveyCost.getSiteSurveyMstId());
			List<SiteSurveyMaster> smList = (List<SiteSurveyMaster>) query.getResultList();
			siteSurveyCost.setSiteSurveyId(smList!=null && smList.size()>0? smList.get(0).getUniq_id():"");
			
			FranchiseeMaster franchiseeMaster = em.find(FranchiseeMaster.class, siteSurveyCost.getFranchiseMstId());
			siteSurveyCost.setFranchiseName(franchiseeMaster.getFranchise_name());
		}*/
		return resultList;
	}

	@Override
	public List<KmApplMst> getKmApplMstList() {
		try {
			query = em.createNamedQuery("KmApplMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<KmApplMst> kmApplMstList = (List<KmApplMst>) query
					.getResultList();
			return kmApplMstList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<KmApplMst>();
		} finally {
			//em.close();
		}
	}

	@Override
	public SiteSurveyCost saveCost(SiteSurveyCost siteSurveyCost) {
		try {
			// TODO Auto-generated method stub
			if(siteSurveyCost.getSiteSurveyCostId()==null) {
				String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
				siteSurveyCost.setCreatedDate(currTime);
				siteSurveyCost.setAppCost("D");
			} else {
                String createdDate = siteSurveyCost.getCreatedDate();
                DateUtil.convertDateToSqlDate(createdDate);
                siteSurveyCost.setCreatedDate(createdDate);
            }
			
			siteSurveyCost.setSiteSurveyId(null);
			siteSurveyCost.setFranchiseName(null);
			
			SiteSurveyCost siteSurveyCostSaved = em.merge(siteSurveyCost);
			return siteSurveyCostSaved;
		} finally {
			// TODO: handle finally clause
			//em.close();
		}
	}

	@Override
	public void updateSubmitFlag(SsEngVisitDetail ssEngVisitDetail) {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("SsEngVisitDetail.updateSubmitFlag");
			query.setParameter(1, ssEngVisitDetail.getSsEngVisitDetailsId());
			query.executeUpdate();
		} finally {
			// TODO: handle finally clause
			//em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public SiteSurveyCost getSiteSurveyCostBySurveyMstIdAndFranchiseId(SsEngVisitDetail ssEngVisitDetail) {
		// TODO Auto-generated method stub
		query = em.createNativeQuery("select distinct eng.franchisee_id from ss_eng_visit_details sv inner join site_survey_eng_mst eng on sv.site_survey_eng_mst_id = eng.id  inner join site_survey_mst sm on eng.franchisee_id = sm.franchisee_id where sv.site_survey_mst_id=?1 and sv.site_survey_eng_mst_id = ?2 ");
		query.setParameter(1, ssEngVisitDetail.getSiteSurveyMstId());
		query.setParameter(2, ssEngVisitDetail.getSiteSurveyEngMstId());
		List<Integer> fraIds = (List<Integer>) query.getResultList();
		
		Integer franchiseId = fraIds!=null && fraIds.size()>0?fraIds.get(0):null;
		
		query = em.createQuery("SELECT s FROM SiteSurveyCost s where s.siteSurveyMstId=?1 and s.franchiseMstId=?2 ");
		query.setParameter(1, ssEngVisitDetail.getSiteSurveyMstId());
		query.setParameter(2, franchiseId);
		
		SiteSurveyCost siteSurveyCostRet = new SiteSurveyCost();
		List<SiteSurveyCost> result = (List<SiteSurveyCost>) query.getResultList();
		if(result!=null && result.size()>0) {
			siteSurveyCostRet = result.get(0);
		} else {
			siteSurveyCostRet.setFranchiseMstId(franchiseId);
			//List<UserMst> hocs = commonPOtentialsDao.getUserListByJobCode(Constants.HOCSROLECODE);
			UserMst csHead = schedulerDao.getHeadByDeptId(Constants.PMGTDEPTID);
			//siteSurveyCostRet.setHoCsId(hocs.get(0).getUserMstId()); 
			siteSurveyCostRet.setCsHeadId(csHead.getUserMstId());
			
			query = em.createNativeQuery("select distinct ur.user_id from site_survey_mst s left outer join customer_sapmst c on s.customer_id = c.customer_sapmst_id left outer join user_to_region_mst ur on s.state_id = ur.region_code where s.id = ?1");
			query.setParameter(1, ssEngVisitDetail.getSiteSurveyMstId());
			List<Integer> csIds = (List<Integer>) query.getResultList();
			
			Integer csId = (csIds!=null && csIds.size()>0)? csIds.get(0):null;
			siteSurveyCostRet.setCsId(csId);
			siteSurveyCostRet.setSiteSurveyMstId(ssEngVisitDetail.getSiteSurveyMstId());
		}
		
		
		return siteSurveyCostRet;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public SiteSurveyCost getSiteSurveyCostByFranchiseAllocIdAndFranchiseId(FaEngVisitDetail faEngVisitDetail) {
		// TODO Auto-generated method stub
		//query = em.createNativeQuery("select distinct eng.franchisee_id from fa_eng_visit_details sv inner join site_survey_eng_mst eng on sv.site_survey_eng_mst_id = eng.id  inner join franchisee_allocation_mst fam on eng.franchisee_id = sm.franchisee_id where sv.site_survey_mst_id=?1 and sv.site_survey_eng_mst_id = ?2 ");
		query = em.createNativeQuery("select distinct eng.franchisee_id from fa_eng_visit_details fev inner join franchisee_alloc_eng_mst eng on fev.engineer_id = eng.id  inner join franchisee_allocation_mst fam on eng.franchisee_id = fam.franchisee_id where fev.franchisee_alloc_id=?1 and fev.engineer_id = ?2");
		query.setParameter(1, faEngVisitDetail.getFranchiseeAllocId());
		query.setParameter(2, faEngVisitDetail.getEngineerId());
		List<Integer> fraIds = (List<Integer>) query.getResultList();
		Integer franchiseId = (fraIds!=null && fraIds.size()>0)?fraIds.get(0):0;
		
		query = em.createQuery("SELECT s FROM SiteSurveyCost s where s.franchiseeAllocationMstId=?1 and s.franchiseMstId=?2 ");
		query.setParameter(1, faEngVisitDetail.getFranchiseeAllocId());
		query.setParameter(2, franchiseId);
		
		SiteSurveyCost siteSurveyCostRet = new SiteSurveyCost();
		List<SiteSurveyCost> result = (List<SiteSurveyCost>) query.getResultList();
		if(result!=null && result.size()>0) {
			siteSurveyCostRet = result.get(0);
		} else {
			siteSurveyCostRet.setFranchiseMstId(franchiseId);
			//List<UserMst> hocs = commonPOtentialsDao.getUserListByJobCode(Constants.HOCSROLECODE);
			/*UserMst csHead = schedulerDao.getHeadByDeptId(Constants.PMGTDEPTID);
			//siteSurveyCostRet.setHoCsId(hocs.get(0).getUserMstId()); 
			siteSurveyCostRet.setCsHeadId(csHead.getUserMstId());*/
			
			query = em.createNativeQuery("select distinct ur.user_id from franchisee_allocation_mst fam inner join so_orders so on fam.so_number = so.so_number and fam.item = so.item inner join customer_sapmst cs on so.sold_to_party = cs.customer_num and so.dist_channel = cs.dist_channel and so.division = cs.division and so.sales_org = cs.sales_org inner join state_mst s on cs.region_code = s.state_code  left outer join user_to_region_mst ur on s.state_mst_id = ur.region_code left outer join delivery d on fam.delivery_id = d.delivery_id where fam.id = ?1");
			query.setParameter(1, faEngVisitDetail.getFranchiseeAllocId());
			List<Integer> csIds = (List<Integer>) query.getResultList();
			Integer csId = ((csIds!=null && csIds.size()>0)?csIds.get(0):0);
			siteSurveyCostRet.setCsId(csId);
			siteSurveyCostRet.setFranchiseeAllocationMstId(faEngVisitDetail.getFranchiseeAllocId());
		}
		
		
		return siteSurveyCostRet;
	}

	@Override
	public BigDecimal getRateForSiteSurvey(Integer franProcId, Integer actId, Integer kmApplMstId) {
		// TODO Auto-generated method stub
		query = em.createNativeQuery("select cost from price_mst where activity_type_mst_id=?1 and franchise_proc_type_mst=?2 and km_appl_mst_id=?3 ");
		query.setParameter(1, actId);
		query.setParameter(2, franProcId);
		query.setParameter(3, kmApplMstId);
		BigDecimal rate = (BigDecimal) query.getSingleResult();
		return rate;
	}
	
	@Override
	public BigDecimal getRateForFranchiseAllocation(Integer franProcId, Integer actId, Integer kmApplMstId,Integer antennaSizeMstId) {
		// TODO Auto-generated method stub
		StringBuilder queryString = new StringBuilder("select cost from price_mst where activity_type_mst_id=?1 and franchise_proc_type_mst=?2 and km_appl_mst_id=?3 and is_active = 'Y' ");
		if(antennaSizeMstId!=null)
			queryString.append(" and antenna_size_mst_id = ?4 ");
		else
			queryString.append(" and antenna_size_mst_id is null ");
		
		query = em.createNativeQuery(queryString.toString());
		query.setParameter(1, actId);
		query.setParameter(2, franProcId);
		query.setParameter(3, kmApplMstId);
		if(antennaSizeMstId!=null)
			query.setParameter(4, antennaSizeMstId);
		BigDecimal rate = (BigDecimal) query.getSingleResult();
		return rate;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppUploadDetail> getUploadListByVisitId(VisitCommonDTO visitCommonDTOInput) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("OppUploadDetail.findByssEngVisitDetailsId");
		query.setParameter(1, visitCommonDTOInput.getSsEngVisitDetail().getSsEngVisitDetailsId());
		List<OppUploadDetail> upList = (List<OppUploadDetail>) query.getResultList();
		return upList;
	}

	@Override
	public List<FileTypeMst> getFileList(List<Integer> fileIdList) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("FileTypeMst.getFileIdIn");
		query.setParameter("fileIdList", fileIdList);
		List<FileTypeMst> resultList = (List<FileTypeMst>) query.getResultList();
		return resultList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TechnologyMaster> getTechList() {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("TechnologyMaster.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			return (List<TechnologyMaster>)query.getResultList();
		} finally {
			//em.close();
		}
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<HubMst> getHubList() {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("HubMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			return (List<HubMst>)query.getResultList();
		} finally {
			//em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppUploadDetail> getUploadDetailsByCostId(VisitCommonDTO visitCommonDTOInput) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("OppUploadDetail.findBysiteSurveyCostId");
			query.setParameter(1, visitCommonDTOInput.getSiteSurveyCostId());
			return (List<OppUploadDetail>) query.getResultList();
		} finally {
			//em.close();
		}	
	}

	@Override
	public SiteSurveyMaster getSiteSurveyById(VisitCommonDTO visitCommonDTOInput) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("SiteSurveyMaster.findById");
			query.setParameter(1, visitCommonDTOInput.getSiteSurveyMstId());
			SiteSurveyMaster siteSurveyMaster = (SiteSurveyMaster) query.getSingleResult();
			return siteSurveyMaster;
		} catch (Exception e) {
			return new SiteSurveyMaster();
		}
		finally {
			//em.close();
		}
	}

	@Override
	public List<NonFeasibleOptionMst> getNonFeasibleList() {
		try {
			query = em.createNamedQuery("NonFeasibleOptionMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<NonFeasibleOptionMst> nonFeasibleList = (List<NonFeasibleOptionMst>) query.getResultList();
			return nonFeasibleList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<NonFeasibleOptionMst>();
		} finally {
			//em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public UserEmailDetailsBean getPmUser(SiteSurveyMaster siteSurveyMaster) {
		try {
			// TODO Auto-generated method stub
			query = em.createNativeQuery(
					"select u.user_mst_id,u.user_name,u.user_email from site_survey_mst ssm inner join user_mst u on ssm.user_id = u.user_mst_id where ssm.id ="
							+ siteSurveyMaster.getId());
			List<Object[]> result = (List<Object[]>) query.getResultList();
			UserEmailDetailsBean uBean = null;
			for (Object[] objects : result) {
				uBean = new UserEmailDetailsBean();
				uBean.setUserName((String) objects[1]);
				uBean.setUserMail((String) objects[2]);
			}
			return uBean;
		}catch(Exception e) {
			return null;
		} 
		finally {
			// TODO: handle finally clause
			//em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public UserEmailDetailsBean getCsUser(SiteSurveyMaster siteSurveyMaster) {
		try {
			// TODO Auto-generated method stub
			query = em.createNativeQuery("select user_id,user_name,user_email,fzm.franchise_zone_email from user_to_region_mst ur inner join user_mst u on ur.user_id = u.user_mst_id left join cs_user_franchise_zone_mapping_mst cuzm on u.user_mst_id = cuzm.user_mst_id left join franchise_zone_mst fzm on cuzm.franchise_zone_mst_id = fzm.franchise_zone_mst_id where region_code ="+siteSurveyMaster.getState_id());
			List<Object[]> result = (List<Object[]>) query.getResultList();
			UserEmailDetailsBean uBean = null;
			for (Object[] objects : result) {
				uBean = new UserEmailDetailsBean();
				Integer userId = null;
				if(objects[0]!=null)
					userId = (Integer) objects[0];
				if(userId!=null)
					uBean.setUserId(userId.toString());
				
				uBean.setUserName((String) objects[1]);
				uBean.setUserMail((String) objects[2]);
				uBean.setZoneMail((String) objects[3]);
			}
			return uBean;
		}catch(Exception e) {
			return null;
		} 
		finally {
			// TODO: handle finally clause
			//em.close();
		}
	}

	@Override
	public List<AntennaTypeMst> getAntennaTypeList() {
		try {
			query = em.createNamedQuery("AntennaTypeMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<AntennaTypeMst> antennaTypeList = (List<AntennaTypeMst>) query.getResultList();
			return antennaTypeList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<AntennaTypeMst>();
		} finally {
			//em.close();
		}
	}

	@Override
	public List<AntennaLocationMst> getAntennaLocationList() {
		try {
			query = em.createNamedQuery("AntennaLocationMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<AntennaLocationMst> antennaLocationList = (List<AntennaLocationMst>) query.getResultList();
			return antennaLocationList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<AntennaLocationMst>();
		} finally {
			//em.close();
		}
	}

	@Override
	public List<SiteSurveyCost> getCostListReadOnly(VisitCommonDTO visitCommonDTOInput) {
		// TODO Auto-generated method stub
		String fromDate = DateUtil.convertDateToSqlDate(visitCommonDTOInput.getFromDate());
		String toDate = DateUtil.convertDateToSqlDate(visitCommonDTOInput.getToDate()) + Constants.MAXDAYTIME;
		
		if(visitCommonDTOInput.getFranchiseInvReqId()!=null) {
			query = em.createNamedQuery("SiteSurveyCost.findAllByInvoiceRequest");
			query.setParameter("franchiseInvReqId", visitCommonDTOInput.getFranchiseInvReqId());
			
		} else {
			if(visitCommonDTOInput.getRoleCode().equals(Constants.SUPPEXECROLECODE)) {
				query = em.createNamedQuery("SiteSurveyCost.findAllForSuppExec");
				query.setParameter("userMstId", visitCommonDTOInput.getUserMstId());
				query.setParameter("fromDate", fromDate);
				query.setParameter("toDate", toDate);
			}  else if(visitCommonDTOInput.getRoleCode().equals(Constants.FRANCHISECOORDCODE)) {
				query = em.createNamedQuery("SiteSurveyCost.findAllFranCoordPaymentRaiseRequest");
				query.setParameter("userMstId", visitCommonDTOInput.getUserMstId());
				query.setParameter("fromDate", fromDate);
				query.setParameter("toDate", toDate);
				
			}
		}
		 /*else {
			query = em.createNamedQuery("SiteSurveyCost.findAllWithDateFilter");
			query.setParameter(1, fromDate);
			query.setParameter(2, toDate);
		}*/
		List<Object[]> queryResult = (List<Object[]>) query.getResultList();
		List<SiteSurveyCost> resultList = new ArrayList<SiteSurveyCost>();
		for (Object[] objects : queryResult) {SiteSurveyCost siteSurveyCost = new SiteSurveyCost();
		siteSurveyCost.setSiteSurveyCostId(objects[0]!=null?(Integer)objects[0]:null);
		siteSurveyCost.setAppCost(objects[1]!=null?(String)objects[1]:"");
		siteSurveyCost.setCreatedDate(objects[2]!=null?(String)objects[2]:"");
		siteSurveyCost.setCsAppr(objects[3]!=null?(String)objects[3]:"");
		siteSurveyCost.setCsApprDate(objects[4]!=null?(String)objects[4]:"");
		siteSurveyCost.setCsApprRemarks(objects[5]!=null?(String)objects[5]:"");
		siteSurveyCost.setCsHeadAppr(objects[6]!=null?(String)objects[6]:"");
		siteSurveyCost.setCsHeadApprDate(objects[7]!=null?(String)objects[7]:"");
		siteSurveyCost.setCsHeadApprRemarks(objects[8]!=null?(String)objects[8]:"");
		siteSurveyCost.setCsHeadId(objects[9]!=null?(Integer)objects[9]:null);
		siteSurveyCost.setCsId(objects[10]!=null?(Integer)objects[10]:null);
		siteSurveyCost.setDefaultCost(objects[11]!=null?(BigDecimal)objects[11]:null);
		siteSurveyCost.setFranchiseMstId(objects[12]!=null?(Integer)objects[12]:null);
		siteSurveyCost.setHoCsAppr(objects[13]!=null?(String)objects[13]:null);
		siteSurveyCost.setHoCsApprDate(objects[14]!=null?(String)objects[14]:null);
		siteSurveyCost.setHoCsApprRemarks(objects[15]!=null?(String)objects[15]:null);
		siteSurveyCost.setHoCsId(objects[16]!=null?(Integer)objects[16]:null);
		siteSurveyCost.setMannualCost(objects[17]!=null?(BigDecimal)objects[17]:null);
		siteSurveyCost.setOtherCost(objects[18]!=null?(BigDecimal)objects[18]:null);
		siteSurveyCost.setSiteSurveyMstId(objects[19]!=null?(Integer)objects[19]:null);
		siteSurveyCost.setStatusMstId(objects[20]!=null?(Integer)objects[20]:null);
		siteSurveyCost.setTotalCost(objects[21]!=null?(BigDecimal)objects[21]:null);
		siteSurveyCost.setFranchiseeAllocationMstId(objects[22]!=null?(Integer)objects[22]:null);
		siteSurveyCost.setFranchiseInvReqId(objects[23]!=null?(Integer)objects[23]:null);
		siteSurveyCost.setSiteSurveyId(objects[24]!=null?(String)objects[24]:null);
		siteSurveyCost.setFranchiseAllocUniqId(objects[25]!=null?(String)objects[25]:null);
		siteSurveyCost.setFranchiseName(objects[26]!=null?(String)objects[26]:"");
		
		StatusMst statusMst = new StatusMst();
		statusMst.setStatusMstId(objects[27]!=null?(Integer)objects[27]:null);
		statusMst.setStatusCode(objects[28]!=null?(String)objects[28]:"");
		statusMst.setStatusName(objects[29]!=null?(String)objects[29]:"");
		siteSurveyCost.setStatusMst(statusMst);
		resultList.add(siteSurveyCost);
		}
		
		return resultList;
	}

	@Override
	public Integer getCurrentDayCountPaymentRequest() {
		try {
			String currentDate = DateUtil.getCurrentISTDateOnlyAsString(DateUtil.DATE_ONLY_FORMAT_MSSQL);
			query = em.createNamedQuery("FranchiseInvReq.getCurrentDayCountStoCs");
			query.setParameter(1, currentDate);
			query.setParameter(2, currentDate + " 23:59:59.999");
			Long maxNumber = (Long) query.getSingleResult();
			return maxNumber.intValue();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public FranchiseInvReq saveFranchiseInvReq(FranchiseInvReq franchiseInvReq) {
		// TODO Auto-generated method stub
		FranchiseInvReq savedFranchiseInvReq = em.merge(franchiseInvReq);
		if(franchiseInvReq.getFranchiseInvReqId()==null)
			em.refresh(savedFranchiseInvReq);
		return savedFranchiseInvReq;
	}

	@Override
	public FranchiseInvReqUserMap saveFranchiseInvReqUserMap(FranchiseInvReqUserMap franchiseInvReqUserMap) {
		// TODO Auto-generated method stub
		return em.merge(franchiseInvReqUserMap);
	}

	@Override
	public FranchiseInvReqStatusTracker saveFranchiseInvReqStatusTracker(
			FranchiseInvReqStatusTracker franchiseInvReqStatusTracker) {
		// TODO Auto-generated method stub
		return em.merge(franchiseInvReqStatusTracker);
	}

	@Override
	public void updateInvReqIdInSS(List<Integer> siteSurveyCostIds, Integer franchiseInvReqId) {
		// TODO Auto-generated method stub
		query = em.createQuery("update SiteSurveyCost s set s.franchiseInvReqId = :franchiseInvReqId where s.siteSurveyCostId in :siteSurveyCostIds ");
		query.setParameter("siteSurveyCostIds", siteSurveyCostIds);
		query.setParameter("franchiseInvReqId", franchiseInvReqId);
		query.executeUpdate();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserEmailDetailsBean> getCseUsers() {
		// TODO Auto-generated method stub
		query = em.createNativeQuery("select distinct user_id,user_name,user_email,fzm.franchise_zone_email,u.role_mst_id from user_to_region_mst ur inner join user_mst u on ur.user_id = u.user_mst_id inner join role_mst r on u.role_mst_id = r.role_mst_id inner join cs_user_franchise_zone_mapping_mst cuzm on u.user_mst_id = cuzm.user_mst_id inner join franchise_zone_mst fzm on cuzm.franchise_zone_mst_id = fzm.franchise_zone_mst_id where r.role_cd = 'SUPEXE' order by u.user_name");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		List<Object[]> result = (List<Object[]>)query.getResultList();
		List<UserEmailDetailsBean> returnList = new ArrayList<UserEmailDetailsBean>();
		for (Object[] objects : result) {
			UserEmailDetailsBean userEmailDetailsBean = new UserEmailDetailsBean();
			userEmailDetailsBean.setUserMstId((Integer)objects[0]);
			userEmailDetailsBean.setUserName((String)objects[1]);
			userEmailDetailsBean.setUserMail((String)objects[2]);
			userEmailDetailsBean.setZoneMail((String)objects[3]);
			userEmailDetailsBean.setRoleMstId((Integer)objects[4]);
			returnList.add(userEmailDetailsBean);
		}
		return returnList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserEmailDetailsBean> getHoCsUsers() {
		// TODO Auto-generated method stub
		query = em.createNativeQuery("select distinct user_mst_id,user_name,user_email,u.role_mst_id from user_mst u inner join role_mst r on u.role_mst_id = r.role_mst_id  where r.role_cd = 'SUPMGR' and user_name!='IT SUPPMGR' order by u.user_name");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		List<Object[]> result = (List<Object[]>)query.getResultList();
		List<UserEmailDetailsBean> returnList = new ArrayList<UserEmailDetailsBean>();
		for (Object[] objects : result) {
			UserEmailDetailsBean userEmailDetailsBean = new UserEmailDetailsBean();
			userEmailDetailsBean.setUserMstId((Integer)objects[0]);
			userEmailDetailsBean.setUserName((String)objects[1]);
			userEmailDetailsBean.setUserMail((String)objects[2]);
			//userEmailDetailsBean.setZoneMail((String)objects[3]);
			userEmailDetailsBean.setRoleMstId((Integer)objects[3]);
			returnList.add(userEmailDetailsBean);
		}
		return returnList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserEmailDetailsBean> getCsHeadUsers() {
		// TODO Auto-generated method stub
		query = em.createNativeQuery("select distinct user_mst_id,user_name,user_email,u.role_mst_id from user_mst u inner join role_mst r on u.role_mst_id = r.role_mst_id  where r.role_cd = 'PMGT&CSH' order by u.user_name ");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		List<Object[]> result = (List<Object[]>)query.getResultList();
		List<UserEmailDetailsBean> returnList = new ArrayList<UserEmailDetailsBean>();
		for (Object[] objects : result) {
			UserEmailDetailsBean userEmailDetailsBean = new UserEmailDetailsBean();
			userEmailDetailsBean.setUserMstId((Integer)objects[0]);
			userEmailDetailsBean.setUserName((String)objects[1]);
			userEmailDetailsBean.setUserMail((String)objects[2]);
			//userEmailDetailsBean.setZoneMail((String)objects[3]);
			userEmailDetailsBean.setRoleMstId((Integer)objects[3]);
			returnList.add(userEmailDetailsBean);
		}
		return returnList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FranchiseInvReq> getPayReqList(PaymentRequestDTO paymentRequestDTOInput) {
		// TODO Auto-generated method stub
		String fromDate = DateUtil.convertDateToSqlDate(paymentRequestDTOInput.getFromDate());
		String toDate = DateUtil.convertDateToSqlDate(paymentRequestDTOInput.getToDate()) + Constants.MAXDAYTIME;
		
		query = em.createNamedQuery("FranchiseInvReq.getPaymentRequestListByRoleandUserId");
		query.setParameter("userMstId", paymentRequestDTOInput.getUserMstId());
		query.setParameter("roleMstId", paymentRequestDTOInput.getRoleMstId());
		query.setParameter("statusCode", paymentRequestDTOInput.getStatusCode());
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		List<Object[]> result = (List<Object[]>) query.getResultList();
		List<FranchiseInvReq> returnList = new ArrayList<FranchiseInvReq>();
		for (Object[] objects : result) {
			FranchiseInvReq franchiseInvReq = new FranchiseInvReq();
			franchiseInvReq.setFranchiseInvReqId((Integer)objects[0]);
			franchiseInvReq.setCreatedDate(DateUtil.convertDateTimeToString((String)objects[1]));
			franchiseInvReq.setModifiedDate(DateUtil.convertDateTimeToString((String)objects[2]));
			franchiseInvReq.setStatusCode((String)objects[3]);
			franchiseInvReq.setUniqId((String)objects[4]);
			franchiseInvReq.setCreatedBy((Integer)objects[5]);
			StatusMst statusMst = new StatusMst();
			statusMst.setStatusMstId((Integer)objects[6]);
			statusMst.setStatusCode((String)objects[7]);
			statusMst.setStatusName((String)objects[8]);
			franchiseInvReq.setStatusMst(statusMst);
			franchiseInvReq.setRejRemarks(objects[9]!=null?(String)objects[9]:"");
			franchiseInvReq.setCsId(objects[10]!=null?(Integer)objects[10]:null);
			franchiseInvReq.setHoCsId(objects[11]!=null?(Integer)objects[11]:null);
			franchiseInvReq.setCsHead(objects[12]!=null?(Integer)objects[12]:null);
			franchiseInvReq.setTotalCost(objects[13]!=null?(BigDecimal)objects[13]:null);
			returnList.add(franchiseInvReq);
		}
		return returnList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StatusMst> getStatusList(List<String> statusCodeList) {
		// TODO Auto-generated method stub
		try {
			query = em.createQuery("select s from StatusMst s where s.statusCode in :statusCodeList");
			query.setParameter("statusCodeList", statusCodeList);
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			return (List<StatusMst>) query.getResultList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<StatusMst>();
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppUploadDetail> getUploadListByFranchiseInvReqId(PaymentRequestDTO paymentRequestDTOInput) {
		// TODO Auto-generated method stub
		try {
			query = em.createQuery(
					"select o from OppUploadDetail o where o.franchiseInvReqId=:franchiseInvReqId and o.isDelete='N'");
			query.setParameter("franchiseInvReqId", paymentRequestDTOInput.getFranchiseInvReqId());
			return (List<OppUploadDetail>) query.getResultList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<OppUploadDetail>();
		} finally {
			em.close();
		}
	}

	@Override
	public boolean getFranchiseInvReqUserMapCount(FranchiseInvReq franchiseInvReq, UserEmailDetailsBean user) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("FranchiseInvReqUserMap.getUserInvIdCount");
			query.setParameter("userMstId", user.getUserMstId());
			query.setParameter("roleMstId", user.getRoleMstId());
			query.setParameter("franchiseInvReqId", franchiseInvReq.getFranchiseInvReqId());
			Long maxNumber = (Long) query.getSingleResult();
			return maxNumber.intValue()>0?true:false;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<IncInvoice> getIncInvoiceList(PaymentRequestDTO paymentRequestDTOInput) {
		// TODO Auto-generated method stub
		try {
			
			String fromDate = DateUtil.convertDateToSqlDate(paymentRequestDTOInput.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(paymentRequestDTOInput.getToDate()) + Constants.MAXDAYTIME;
			
			query = em.createNamedQuery("IncInvoice.findAllByInvoiceDate");
			query.setParameter("fromDate", fromDate);
			query.setParameter("toDate", toDate);
		
			List<IncInvoice> resultList = (List<IncInvoice>) query.getResultList();
			
			return resultList;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public List<HubTechMst> getHubTechList() {
		try {
			query = em.createNamedQuery("HubTechMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<HubTechMst> returnList = (List<HubTechMst>) query.getResultList();
			return returnList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<HubTechMst>();
		} finally {
			//em.close();
		}
	}

	@Override
	public List<NatureMst> getNatureList() {
		try {
			query = em.createNamedQuery("NatureMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<NatureMst> returnList = (List<NatureMst>) query.getResultList();
			return returnList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<NatureMst>();
		} finally {
			//em.close();
		}
	}

	@Override
	public List<HsoTransactionStatusMst> getStatusHubList() {
		try {
			query = em.createNamedQuery("HsoTransactionStatusMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<HsoTransactionStatusMst> returnList = (List<HsoTransactionStatusMst>) query.getResultList();
			return returnList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<HsoTransactionStatusMst>();
		} finally {
			//em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<HsoTransactionDetail> getHsoList(HubSignOffDTO hubSignOffDTOInput) {
		// TODO Auto-generated method stub
		
		String fromDate = DateUtil.convertDateToSqlDate(hubSignOffDTOInput.getFromDate());
		String toDate = DateUtil.convertDateToSqlDate(hubSignOffDTOInput.getToDate()); // + Constants.MAXDAYTIME
		
		if (hubSignOffDTOInput.getIsNext().equals(prop.getyFlag())) {
			query = em.createNamedQuery("HsoTransactionDetail.findAllByStatusAndHubUserIdGreaterThan");
		} else {
			query = em.createNamedQuery("HsoTransactionDetail.findAllByStatusAndHubUserIdLessThan");
		}
		
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		query.setParameter("hsoTransactionStatusMstId", hubSignOffDTOInput.getHsoTransactionStatusMstId());
		query.setParameter("userMstId", hubSignOffDTOInput.getUserMstId());
		query.setParameter("hsoTransactionDetailsId", hubSignOffDTOInput.getHsoTransactionDetailsId());
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		query.setMaxResults(10);
		List<HsoTransactionDetail> resultList = (List<HsoTransactionDetail>) query.getResultList();
		
		return resultList;
	}

	@Override
	public HsoTransactionDetail saveHsoTransactionDetail(HsoTransactionDetail hsoTransactionDetail) {
		// TODO Auto-generated method stub
		try {
			return em.merge(hsoTransactionDetail);
		} finally {
			em.close();
		}
		
	}

	@Override
	public HsoStatusChangeTracker setHsoStatusChangeTracker(HsoStatusChangeTracker hsoStatusChangeTracker) {
		// TODO Auto-generated method stub
		try {
			return em.merge(hsoStatusChangeTracker);
		} finally {
			em.close();
		}
	}

	@Override
	public void updateOppUploadDetails(PaymentRequestDTO paymentRequestDTOInput) {
		// TODO Auto-generated method stub
		String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
		List<OppUploadDetail> oppUploadDetails = paymentRequestDTOInput.getOppUploadDetails();
		for (OppUploadDetail oppUploadDetail : oppUploadDetails) {
			if(paymentRequestDTOInput.getRoleCode().equals(properties.getFranCoordRoleCode())) {
				oppUploadDetail.setFrcUpdatedTime(currTime);
			} else {
				oppUploadDetail.setCsUpdatedTime(currTime);
			}
			
			DocSubRecDetail docSubRecDetail = new DocSubRecDetail();
			docSubRecDetail.setOppUploadDetailsId(oppUploadDetail.getOppUploadDetailsId());
			docSubRecDetail.setUpdateBy(paymentRequestDTOInput.getUserMstId());
			docSubRecDetail.setUpdateTime(currTime);
			
			em.merge(docSubRecDetail);
			
			em.merge(oppUploadDetail);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserEmailDetailsBean> getFrcUserList(Integer franchiseMstId,Integer siteSurveyMstId,Integer franchiseeAllocationMstId) {
		// TODO Auto-generated method stub
		List<UserEmailDetailsBean> returnList = new ArrayList<UserEmailDetailsBean>();
		
		query = em.createNativeQuery("select u.user_mst_id,u.user_name,u.user_email from user_to_franchisee_mst uf inner join user_mst u on uf.user_mst_id = u.user_mst_id where uf.franchisee_id="+franchiseMstId);
		
		List<Object[]> resultList = (List<Object[]>) query.getResultList();
		for (Object[] objects : resultList) {
			UserEmailDetailsBean uBean = new UserEmailDetailsBean();
			uBean.setUserMstId((Integer)objects[0]);
			uBean.setUserName((String)objects[1]);
			uBean.setUserMail((String)objects[2]);
	
			returnList.add(uBean);
		}
		
		return returnList;
	}

	@Override
	public List<InstallationStatusMst> getInstallationStatusList() {
		try {
			query = em.createNamedQuery("InstallationStatusMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<InstallationStatusMst> installationStatusList = (List<InstallationStatusMst>) query.getResultList();
			return installationStatusList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<InstallationStatusMst>();
		} finally {
			//em.close();
		}
	}

	@Override
	public List<IncAttributionMst> getIncAttributionList() {
		try {
			query = em.createNamedQuery("IncAttributionMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<IncAttributionMst> incAttributionList = (List<IncAttributionMst>) query.getResultList();
			return incAttributionList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<IncAttributionMst>();
		} finally {
			//em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ActivityTypeMst> getLstActivityTypeMst() {
		try {
			query = em.createNamedQuery("ActivityFranchiseProcMapping.findFranchiseDropDown");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<ActivityTypeMst> actitvityTypeMstList = (List<ActivityTypeMst>) query.getResultList();
			return actitvityTypeMstList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<ActivityTypeMst>();
		} finally {
			em.close();
		}
	}


	
}
