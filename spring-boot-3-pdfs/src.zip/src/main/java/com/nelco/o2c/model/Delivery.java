package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.utility.DateUtil;

/**
 * The persistent class for the delivery database table.
 * 
 */
@Entity
@Table(name = "delivery")
@NamedQueries({ @NamedQuery(name = "Delivery.findAll", query = "SELECT d FROM Delivery d"),
		@NamedQuery(name = "Delivery.getDelListByDateNext", query = "SELECT d.deliveryNum,"
				+ " d.dispatchDate,d.docketNum,"
				+ " d.courierName,d.eddate,d.boxes,d.receivName,d.receivContact,"
				+ " psm.podStatusMstId,psm.podStatusCode,psm.podStatusName,"
				+ " dsm.deliveryStatusMstId,dsm.delStatusCode,dsm.delStatusName,"
				+ " d.sapDelDate,d.anteenaType,d.cbl,d.weight,d.danRaisedBy,d.iduSerialNum,"
				+ " d.bucSerialNum,d.lnbSerialNum,so.contractNum,so.soNumber,d.month,"
				+ " d.challanNum,"
				+ " d.taxInvoice,d.addate,d.custName,d.state,d.materialNum,"
				+ " d.dispatchType,d.modelDesc,"
				+ " d.quantity,d.deliveryId,d.deliveryStatusMstId,d.podStatusMstId,"
				+ " d.shipToParty,"
				+ " d.location,d.modOfTransp,d.value,d.contactPerson,d.contactPersMob,"
				+ " d.contactPersAddress,d.wbsElement,d.isSalesReturn,d.plant "
				+ " FROM Delivery d inner join d.deliveryStatusMst dsm "
				+ "inner join d.podStatusMst psm inner join d.soOrders so  "
				+ "where d.sapDelDate between ?1 and ?2 and d.deliveryId > ?3 order by d.deliveryId asc"),
		@NamedQuery(name = "Delivery.getDelListByDatePrev", query = "SELECT d.deliveryNum,"
				+ " d.dispatchDate,d.docketNum,"
				+ " d.courierName,d.eddate,d.boxes,d.receivName,d.receivContact,"
				+ " psm.podStatusMstId,psm.podStatusCode,psm.podStatusName,"
				+ " dsm.deliveryStatusMstId,dsm.delStatusCode,dsm.delStatusName,"
				+ " d.sapDelDate,d.anteenaType,d.cbl,d.weight,d.danRaisedBy,d.iduSerialNum,"
				+ " d.bucSerialNum,d.lnbSerialNum,so.contractNum,so.soNumber,d.month,"
				+ " d.challanNum,"
				+ " d.taxInvoice,d.addate,d.custName,d.state,d.materialNum,"
				+ " d.dispatchType,d.modelDesc,"
				+ " d.quantity,d.deliveryId,d.deliveryStatusMstId,d.podStatusMstId,"
				+ " d.shipToParty,"
				+ " d.location,d.modOfTransp,d.value,d.contactPerson,d.contactPersMob,"
				+ " d.contactPersAddress,d.wbsElement,d.isSalesReturn,d.plant "
				+ " FROM Delivery d inner join d.deliveryStatusMst dsm "
				+ "inner join d.podStatusMst psm inner join d.soOrders so  "
				+ "where d.sapDelDate between ?1 and ?2 and d.deliveryId < ?3 order by d.deliveryId asc"),
		@NamedQuery(name = "Delivery.getDelListByDateAndDelStatusCode", query = "SELECT d.deliveryNum,"
				+ " d.dispatchDate,d.docketNum,"
				+ " d.courierName,d.eddate,d.boxes,d.receivName,d.receivContact,"
				+ " psm.podStatusMstId,psm.podStatusCode,psm.podStatusName,"
				+ " dsm.deliveryStatusMstId,dsm.delStatusCode,dsm.delStatusName,"
				+ " d.sapDelDate,d.anteenaType,d.cbl,d.weight,d.danRaisedBy,d.iduSerialNum,"
				+ " d.bucSerialNum,d.lnbSerialNum,so.contractNum,so.soNumber,d.month,"
				+ " d.challanNum,"
				+ " d.taxInvoice,d.addate,d.custName,d.state,d.materialNum,"
				+ " d.dispatchType,d.modelDesc,"
				+ " d.quantity,d.deliveryId,d.deliveryStatusMstId,d.podStatusMstId,"
				+ " d.shipToParty,"
				+ " d.location,d.modOfTransp,d.value,d.contactPerson,d.contactPersMob,"
				+ " d.contactPersAddress,d.wbsElement,d.isSalesReturn,d.plant,d.challanDate"
				+ " FROM Delivery d inner join d.deliveryStatusMst dsm "
				+ " inner join d.podStatusMst psm inner join d.soOrders so  "
				+ " where d.sapDelDate between ?1 and ?2 and dsm.delStatusCode in :status"),
		@NamedQuery(name = "Delivery.getDelByDelId", query = "SELECT d FROM Delivery d where d.deliveryId =?1 "),
		@NamedQuery(name = "Delivery.getDelByDelNum", query = "SELECT d FROM Delivery d where d.deliveryNum =?1 "),
		@NamedQuery(name = "Delivery.getWrongAddressList", query = " SELECT d.deliveryNum,"
				+ " d.dispatchDate,d.docketNum,"
				+ " d.courierName,d.eddate,d.boxes,d.receivName,d.receivContact,"
				+ " psm.podStatusMstId,psm.podStatusCode,psm.podStatusName,"
				+ " dsm.deliveryStatusMstId,dsm.delStatusCode,dsm.delStatusName,"
				+ " d.sapDelDate,d.anteenaType,d.cbl,d.weight,d.danRaisedBy,d.iduSerialNum,"
				+ " d.bucSerialNum,d.lnbSerialNum,so.contractNum,so.soNumber,d.month,"
				+ " d.challanNum,"
				+ " d.taxInvoice,d.addate,d.custName,d.state,d.materialNum,"
				+ " d.dispatchType,d.modelDesc,"
				+ " d.quantity,d.deliveryId,d.deliveryStatusMstId,d.podStatusMstId,"
				+ " d.shipToParty,"
				+ " d.location,d.modOfTransp,d.value,d.contactPerson,d.contactPersMob,"
				+ " d.contactPersAddress,d.wbsElement,d.isSalesReturn,d.plant "
				+ " FROM Delivery d inner join d.deliveryStatusMst dsm "
				+ " inner join d.podStatusMst psm inner join d.soOrders so "
				+ " where d.deliveryStatusMstId=4 "),
		@NamedQuery(name = "Delivery.getDeliveryListForPMGT", query = " SELECT d.deliveryNum,"
				+ " d.dispatchDate,d.docketNum,"
				+ " d.courierName,d.eddate,d.boxes,d.receivName,d.receivContact,"
				+ " psm.podStatusMstId,psm.podStatusCode,psm.podStatusName,"
				+ " dsm.deliveryStatusMstId,dsm.delStatusCode,dsm.delStatusName,"
				+ " d.sapDelDate,d.anteenaType,d.cbl,d.weight,d.danRaisedBy,d.iduSerialNum,"
				+ " d.bucSerialNum,d.lnbSerialNum,so.contractNum,so.soNumber,d.month,"
				+ " d.challanNum,"
				+ " d.taxInvoice,d.addate,d.custName,d.state,d.materialNum,"
				+ " d.dispatchType,d.modelDesc,"
				+ " d.quantity,d.deliveryId,d.deliveryStatusMstId,d.podStatusMstId,"
				+ " d.shipToParty,"
				+ " d.location,d.modOfTransp,d.value,d.contactPerson,d.contactPersMob,"
				+ " d.contactPersAddress,d.wbsElement,d.isSalesReturn,d.plant "
				+ " FROM Delivery d inner join d.deliveryStatusMst dsm "
				+ " inner join d.podStatusMst psm inner join d.soOrders so ")
})

public class Delivery implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "delivery_id")
	private Integer deliveryId;

	private String addate;

	@Column(name = "anteena_type")
	private String anteenaType;

	private String boxes;

	@Column(name = "buc_serial_num")
	private String bucSerialNum;

	private String cbl;

	@Column(name = "challan_num")
	private String challanNum;

	@Column(name = "courier_name")
	private String courierName;

	@Column(name = "created_date",updatable = false)
	private String createdDate;

	@Column(name = "cust_name")
	private String custName;

	@Column(name = "dan_raised_by")
	private String danRaisedBy;

	@Column(name = "delivery_status_mst_id")
	private Integer deliveryStatusMstId;

	@Column(name = "delivery_num")
	private String deliveryNum;

	@Column(name = "dispatch_date")
	private String dispatchDate;

	@Column(name = "dispatch_type")
	private String dispatchType;

	@Column(name = "docket_num")
	private String docketNum;

	private String eddate;

	@Column(name = "idu_serial_num")
	private String iduSerialNum;

	@Column(name = "lnb_serial_num")
	private String lnbSerialNum;

	private String location;

	@Column(name = "material_num")
	private String materialNum;

	@Column(name = "mod_of_transp")
	private String modOfTransp;

	@Column(name = "model_desc")
	private String modelDesc;

	private String month;

	@Column(name = "pod_status_mst_id")
	private Integer podStatusMstId;

	private String quantity;

	@Column(name = "receiv_contact")
	private String receivContact;

	@Column(name = "receiv_name")
	private String receivName;

	@Column(name = "so_number")
	private String soNumber;

	private String state;

	@Column(name = "tax_invoice")
	private String taxInvoice;

	private String value;

	private String weight;

	@Column(name = "contact_person")
	private String contactPerson;

	@Column(name = "contact_pers_mob")
	private String contactPersMob;

	@Column(name = "contact_pers_address")
	private String contactPersAddress;
	
	@Column(name = "ship_to_party")
	private String shipToParty;
	
	@Column(name = "is_sales_return")
	private String isSalesReturn;
	
	@Column(name = "sap_del_date",updatable = false)
	private String sapDelDate;
	
	@Column(name = "wbs_element")
	private String wbsElement;
	
	@Column(name = "plant")
	private String plant;
	
	@Column(name="challan_date")
	private String challanDate;
	
	public String getChallanDate() {
		return challanDate;
	}

	public void setChallanDate(String challanDate) {
		this.challanDate = challanDate;
	}

	@Transient
	private Integer rowNumber;

	public Integer getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(Integer rowNumber) {
		this.rowNumber = rowNumber;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "delivery_status_mst_id", referencedColumnName = "delivery_status_mst_id", insertable = false, updatable = false)
	private DeliveryStatusMst deliveryStatusMst;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "pod_status_mst_id", referencedColumnName = "pod_status_mst_id", insertable = false, updatable = false)
	private PodStatusMst podStatusMst;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({@JoinColumn(name = "so_number", referencedColumnName = "so_number", insertable = false, updatable = false),
		@JoinColumn(name = "wbs_element", referencedColumnName = "wbs_element", insertable = false, updatable = false)})
	private SoOrders soOrders;
	
	/*@ManyToOne(fetch = FetchType.LAZY)
	
	@JoinColumns({@JoinColumn(name = "delivery_id", referencedColumnName = "delivery_id", insertable = false, updatable = false)		
	})
	private FranchiseeAllocationMst franchiseeAllocationMst;
	
	public FranchiseeAllocationMst getFranchiseeAllocationMst() {
		return franchiseeAllocationMst;
	}

	public void setFranchiseeAllocationMst(FranchiseeAllocationMst franchiseeAllocationMst) {
		this.franchiseeAllocationMst = franchiseeAllocationMst;
	}*/

	public SoOrders getSoOrders() {
		return soOrders;
	}

	public void setSoOrders(SoOrders soOrders) {
		this.soOrders = soOrders;
	}

	public String getShipToParty() {
		return shipToParty;
	}

	public void setShipToParty(String shipToParty) {
		this.shipToParty = shipToParty;
	}

	public String getWbsElement() {
		return wbsElement;
	}

	public void setWbsElement(String wbsElement) {
		this.wbsElement = wbsElement;
	}

	public Delivery() {
	}

	public Integer getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(Integer deliveryId) {
		this.deliveryId = deliveryId;
	}

	public String getAddate() {
//		return addate;
		return DateUtil.convertDateTimeToString(this.addate);
	}

	public void setAddate(String addate) {
		this.addate = addate;
	}

	public String getAnteenaType() {
		return anteenaType;
	}

	public void setAnteenaType(String anteenaType) {
		this.anteenaType = anteenaType;
	}

	public String getBoxes() {
		return boxes;
	}

	public void setBoxes(String boxes) {
		this.boxes = boxes;
	}

	public String getBucSerialNum() {
		return bucSerialNum;
	}

	public void setBucSerialNum(String bucSerialNum) {
		this.bucSerialNum = bucSerialNum;
	}

	public String getCbl() {
		return cbl;
	}

	public void setCbl(String cbl) {
		this.cbl = cbl;
	}

	public String getChallanNum() {
		return challanNum;
	}

	public void setChallanNum(String challanNum) {
		this.challanNum = challanNum;
	}

	public String getCourierName() {
		return courierName;
	}

	public void setCourierName(String courierName) {
		this.courierName = courierName;
	}

	public String getCreatedDate() {
//		return createdDate;
		return DateUtil.convertDateTimeToString(this.createdDate);
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getDanRaisedBy() {
		return danRaisedBy;
	}

	public void setDanRaisedBy(String danRaisedBy) {
		this.danRaisedBy = danRaisedBy;
	}

	public String getDeliveryNum() {
		return deliveryNum;
	}

	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}

	public String getDispatchDate() {
//		return dispatchDate;
		return DateUtil.convertDateTimeToString(this.dispatchDate);
	}

	public void setDispatchDate(String dispatchDate) {
		this.dispatchDate = dispatchDate;
	}

	public String getDispatchType() {
		return dispatchType;
	}

	public void setDispatchType(String dispatchType) {
		this.dispatchType = dispatchType;
	}

	public String getDocketNum() {
		return docketNum;
	}

	public void setDocketNum(String docketNum) {
		this.docketNum = docketNum;
	}

	public String getEddate() {
//		return eddate;
		return DateUtil.convertDateTimeToString(this.eddate);
	}

	public void setEddate(String eddate) {
		this.eddate = eddate;
	}

	public String getIduSerialNum() {
		return iduSerialNum;
	}

	public void setIduSerialNum(String iduSerialNum) {
		this.iduSerialNum = iduSerialNum;
	}

	public String getLnbSerialNum() {
		return lnbSerialNum;
	}

	public void setLnbSerialNum(String lnbSerialNum) {
		this.lnbSerialNum = lnbSerialNum;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getMaterialNum() {
		return materialNum;
	}

	public void setMaterialNum(String materialNum) {
		this.materialNum = materialNum;
	}

	public String getModOfTransp() {
		return modOfTransp;
	}

	public void setModOfTransp(String modOfTransp) {
		this.modOfTransp = modOfTransp;
	}

	public String getModelDesc() {
		return modelDesc;
	}

	public void setModelDesc(String modelDesc) {
		this.modelDesc = modelDesc;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public Integer getDeliveryStatusMstId() {
		return deliveryStatusMstId;
	}

	public void setDeliveryStatusMstId(Integer deliveryStatusMstId) {
		this.deliveryStatusMstId = deliveryStatusMstId;
	}

	public Integer getPodStatusMstId() {
		return podStatusMstId;
	}

	public void setPodStatusMstId(Integer podStatusMstId) {
		this.podStatusMstId = podStatusMstId;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getReceivContact() {
		return receivContact;
	}

	public void setReceivContact(String receivContact) {
		this.receivContact = receivContact;
	}

	public String getReceivName() {
		return receivName;
	}

	public void setReceivName(String receivName) {
		this.receivName = receivName;
	}

	public String getSoNumber() {
		return soNumber;
	}

	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getTaxInvoice() {
		return taxInvoice;
	}

	public void setTaxInvoice(String taxInvoice) {
		this.taxInvoice = taxInvoice;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public DeliveryStatusMst getDeliveryStatusMst() {
		return deliveryStatusMst;
	}

	public void setDeliveryStatusMst(DeliveryStatusMst deliveryStatusMst) {
		this.deliveryStatusMst = deliveryStatusMst;
	}

	public PodStatusMst getPodStatusMst() {
		return podStatusMst;
	}

	public void setPodStatusMst(PodStatusMst podStatusMst) {
		this.podStatusMst = podStatusMst;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getContactPersMob() {
		return contactPersMob;
	}

	public void setContactPersMob(String contactPersMob) {
		this.contactPersMob = contactPersMob;
	}

	public String getContactPersAddress() {
		return contactPersAddress;
	}

	public void setContactPersAddress(String contactPersAddress) {
		this.contactPersAddress = contactPersAddress;
	}

	public String getSapDelDate() {
//		return sapDelDate;
		return DateUtil.convertDateTimeToString(this.sapDelDate);
	}

	public void setSapDelDate(String sapDelDate) {
		this.sapDelDate = sapDelDate;
	}

	public String getIsSalesReturn() {
		return isSalesReturn;
	}

	public void setIsSalesReturn(String isSalesReturn) {
		this.isSalesReturn = isSalesReturn;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}
	
}