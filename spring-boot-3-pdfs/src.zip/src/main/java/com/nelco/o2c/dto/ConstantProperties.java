/**
 * 
 */
package com.nelco.o2c.dto;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/**
 * @author Jayshankar.r
 *
 */
@Component
@PropertySource({"classpath:constants.properties"})
public class ConstantProperties {

	@Value("${inv.pay.req.by.franchise}")
	private String invoicePayReqByFranchiseStatusCode;
	
	@Value("${inv.pay.app.by.cs}")
	private String invoicePayAppByCsStatusCode;
	
	@Value("${inv.pay.app.by.hocs}")
	private String invoicePayAppByHocsStatusCode;
	
	@Value("${inv.pay.app.by.cshead}")
	private String invoicePayAppByCsheadStatusCode;
	
	@Value("${inv.pay.rejected}")
	private String invoicePayRejStatusCode;
	
	@Value("${appr.flag}")
	private String apprFlag;
	
	@Value("${rej.flag}")
	private String rejFlag;
	
	@Value("${supp.exec.role.code}")
	private String suppExecRoleCode;
	
	@Value("${supp.mgr.role.code}")
	private String suppMgrRoleCode;
	
	@Value("${cs.head.role.code}")
	private String csHeadRoleCode;
	
	@Value("${fran.coord.role.code}")
	private String franCoordRoleCode;
	
	@Value("${y.flag}")
	private String yFlag;
	
	@Value("${pmgt.spare.so.type}")
	private String pmgtSpareSoType;
	
	@Value("${cs.spare.so.type}")
	private String csSpareSoType;
	
	@Value("${supp.coord.role.code}")
	private String suppCoordRoleCode;
	
	@Value("${sales.coord.role.code}")
	private String salesCoordRoleCode;
	
	@Value("${pmgt.coord.role.code}")
	private String pmgtCoordRoleCode;
	
	@Value("${yes.flag}")
	private String yesFlag;
	
	@Value("${no.flag}")
	private String noFlag;
	
	@Value("${drf.ext.appr.status.code}")
	private String drfExtApprStatusCode;
	
	@Value("${drf.stceo.ext.appr.status.code}")
	private String drfStceoExtApprStatusCode;
	
	
	//added for opp details statuses by Jay 16:40 05-02-2020 begins
	@Value("${op.det.account.name}")
	private String opDetAccountName;
	
	@Value("${op.det.potential.name}")
	private String opDetPotentialName;
	
	@Value("${op.det.business.line}")
	private String opDetBusinessLine;
	
	@Value("${op.det.potential.owner}")
	private String poDetPotentialOwner;
	
	@Value("${op.det.current.status}")
	private String opDetCurrentStatus;
	
	//added for opp details statuses by Jay 16:40 05-02-2020 begins
	
	
	
	public String getOpDetCurrentStatus() {
		return opDetCurrentStatus;
	}

	public void setOpDetCurrentStatus(String opDetCurrentStatus) {
		this.opDetCurrentStatus = opDetCurrentStatus;
	}

	public String getOpDetAccountName() {
		return opDetAccountName;
	}

	public void setOpDetAccountName(String opDetAccountName) {
		this.opDetAccountName = opDetAccountName;
	}

	public String getOpDetPotentialName() {
		return opDetPotentialName;
	}

	public void setOpDetPotentialName(String opDetPotentialName) {
		this.opDetPotentialName = opDetPotentialName;
	}

	public String getOpDetBusinessLine() {
		return opDetBusinessLine;
	}

	public void setOpDetBusinessLine(String opDetBusinessLine) {
		this.opDetBusinessLine = opDetBusinessLine;
	}

	public String getPoDetPotentialOwner() {
		return poDetPotentialOwner;
	}

	public void setPoDetPotentialOwner(String poDetPotentialOwner) {
		this.poDetPotentialOwner = poDetPotentialOwner;
	}

	public String getDrfStceoExtApprStatusCode() {
		return drfStceoExtApprStatusCode;
	}

	public void setDrfStceoExtApprStatusCode(String drfStceoExtApprStatusCode) {
		this.drfStceoExtApprStatusCode = drfStceoExtApprStatusCode;
	}

	public String getDrfExtApprStatusCode() {
		return drfExtApprStatusCode;
	}

	public void setDrfExtApprStatusCode(String drfExtApprStatusCode) {
		this.drfExtApprStatusCode = drfExtApprStatusCode;
	}

	public String getPmgtCoordRoleCode() {
		return pmgtCoordRoleCode;
	}

	public void setPmgtCoordRoleCode(String pmgtCoordRoleCode) {
		this.pmgtCoordRoleCode = pmgtCoordRoleCode;
	}

	public String getSuppCoordRoleCode() {
		return suppCoordRoleCode;
	}

	public void setSuppCoordRoleCode(String suppCoordRoleCode) {
		this.suppCoordRoleCode = suppCoordRoleCode;
	}

	public String getSalesCoordRoleCode() {
		return salesCoordRoleCode;
	}

	public void setSalesCoordRoleCode(String salesCoordRoleCode) {
		this.salesCoordRoleCode = salesCoordRoleCode;
	}

	public String getyFlag() {
		return yFlag;
	}

	public void setyFlag(String yFlag) {
		this.yFlag = yFlag;
	}

	public String getPmgtSpareSoType() {
		return pmgtSpareSoType;
	}

	public void setPmgtSpareSoType(String pmgtSpareSoType) {
		this.pmgtSpareSoType = pmgtSpareSoType;
	}

	public String getCsSpareSoType() {
		return csSpareSoType;
	}

	public void setCsSpareSoType(String csSpareSoType) {
		this.csSpareSoType = csSpareSoType;
	}

	public String getFranCoordRoleCode() {
		return franCoordRoleCode;
	}

	public void setFranCoordRoleCode(String franCoordRoleCode) {
		this.franCoordRoleCode = franCoordRoleCode;
	}

	public String getSuppExecRoleCode() {
		return suppExecRoleCode;
	}

	public void setSuppExecRoleCode(String suppExecRoleCode) {
		this.suppExecRoleCode = suppExecRoleCode;
	}

	public String getSuppMgrRoleCode() {
		return suppMgrRoleCode;
	}

	public void setSuppMgrRoleCode(String suppMgrRoleCode) {
		this.suppMgrRoleCode = suppMgrRoleCode;
	}

	public String getCsHeadRoleCode() {
		return csHeadRoleCode;
	}

	public void setCsHeadRoleCode(String csHeadRoleCode) {
		this.csHeadRoleCode = csHeadRoleCode;
	}

	public String getApprFlag() {
		return apprFlag;
	}

	public void setApprFlag(String apprFlag) {
		this.apprFlag = apprFlag;
	}

	public String getRejFlag() {
		return rejFlag;
	}

	public void setRejFlag(String rejFlag) {
		this.rejFlag = rejFlag;
	}

	public String getInvoicePayAppByCsStatusCode() {
		return invoicePayAppByCsStatusCode;
	}

	public void setInvoicePayAppByCsStatusCode(String invoicePayAppByCsStatusCode) {
		this.invoicePayAppByCsStatusCode = invoicePayAppByCsStatusCode;
	}

	public String getInvoicePayAppByHocsStatusCode() {
		return invoicePayAppByHocsStatusCode;
	}

	public void setInvoicePayAppByHocsStatusCode(String invoicePayAppByHocsStatusCode) {
		this.invoicePayAppByHocsStatusCode = invoicePayAppByHocsStatusCode;
	}

	public String getInvoicePayAppByCsheadStatusCode() {
		return invoicePayAppByCsheadStatusCode;
	}

	public void setInvoicePayAppByCsheadStatusCode(String invoicePayAppByCsheadStatusCode) {
		this.invoicePayAppByCsheadStatusCode = invoicePayAppByCsheadStatusCode;
	}

	public String getInvoicePayRejStatusCode() {
		return invoicePayRejStatusCode;
	}

	public void setInvoicePayRejStatusCode(String invoicePayRejStatusCode) {
		this.invoicePayRejStatusCode = invoicePayRejStatusCode;
	}

	public String getInvoicePayReqByFranchiseStatusCode() {
		return invoicePayReqByFranchiseStatusCode;
	}

	public void setInvoicePayReqByFranchiseStatusCode(String invoicePayReqByFranchiseStatusCode) {
		this.invoicePayReqByFranchiseStatusCode = invoicePayReqByFranchiseStatusCode;
	}

	public String getYesFlag() {
		return yesFlag;
	}

	public void setYesFlag(String yesFlag) {
		this.yesFlag = yesFlag;
	}

	public String getNoFlag() {
		return noFlag;
	}

	public void setNoFlag(String noFlag) {
		this.noFlag = noFlag;
	}
		
}
