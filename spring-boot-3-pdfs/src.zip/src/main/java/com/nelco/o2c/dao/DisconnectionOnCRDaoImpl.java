package com.nelco.o2c.dao;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.servlet.http.HttpServletRequest;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.nelco.o2c.dto.DisconnectionOnCRDTO;
import com.nelco.o2c.dto.DisconnectionReconnectionDatesToCSVDTO;
import com.nelco.o2c.dto.OutstandingInvoicesDTO;
import com.nelco.o2c.model.AntennaSizeMaster;
import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.model.DisconnectionRequestAction;
import com.nelco.o2c.model.DisconnectionRequestOnCrMst;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.SiteSurveyMaster;
import com.nelco.o2c.model.StateMst;
import com.nelco.o2c.model.TechnologyMaster;
import com.nelco.o2c.model.TempDisconnectionCrDetail;
import com.nelco.o2c.model.TemplateDownloadRequest;
import com.nelco.o2c.utility.DateUtil;
import com.nelco.o2c.utility.SDCommonUtil;

@Repository
public class DisconnectionOnCRDaoImpl implements DisconnectionOnCRDao{
	@Autowired
	private Environment env;
	
	@PersistenceContext
	private EntityManager em;

	Query query;
	
	StoredProcedureQuery spQuery;
	
	@Override
	public List<DisconnectionOnCRDTO> getSoListForDisconnection(HttpServletRequest request) {
		spQuery = em.createStoredProcedureQuery("isp_getListForDeactivationonCustomerRequest")
				.registerStoredProcedureParameter("customer", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("ip", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("userId", String.class, ParameterMode.IN);
		spQuery.setParameter("customer", request.getParameter("customer"))
				.setParameter("ip", request.getParameter("ip"))
				.setParameter("userId", request.getParameter("userId"));
		List<Object[]> soList=spQuery.getResultList();
		return soList.stream().map(result -> new DisconnectionOnCRDTO(
		          String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2])
		         ,String.valueOf(result[3]),String.valueOf(result[4]),Integer.parseInt(String.valueOf(result[5]))
		         ,String.valueOf(result[6]),String.valueOf(result[7]),String.valueOf(result[8]),String.valueOf(result[9])
		        		 ,String.valueOf(result[10]),String.valueOf(result[11]),String.valueOf(result[12])
		   )).collect(Collectors.toList());
		
	}
	@Transactional
	@Override
	public String generateTemplate(List<TemplateDownloadRequest> templateDownloadRequest) {
		Object[] obj;
		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmssSSSSSS").format(Calendar.getInstance().getTime());
		String uniqueId="DIS_CR_"+timeStamp;
		for (TemplateDownloadRequest requestDetails : templateDownloadRequest) {
			requestDetails.setUniqueId(uniqueId);
			requestDetails.setDisconnectionRequestDate(DateUtil.convertDateToSqlDate(requestDetails.getDisconnectionRequestDate()));
			requestDetails.setTypeid(null);
			em.merge(requestDetails);
		}
		/*String FILE_NAME = env.getProperty("tempuploadfolder") + uniqueId+".xlsx";

	        XSSFWorkbook workbook = new XSSFWorkbook();
	        XSSFSheet sheet = workbook.createSheet("Sheet0");
	        
	        spQuery = em.createStoredProcedureQuery("isp_getTemplateDetailsForDownload")
					.registerStoredProcedureParameter("uniqueId", String.class, ParameterMode.IN);
			spQuery.setParameter("uniqueId", uniqueId);
			List<Object[]> templateDetails=spQuery.getResultList();
			Object[] header = 
	                {"IP", "SO No.", "Customer Name","Disconnection Request Date","Notice Period","Billing End Date"};
			int colNum = 0;
			int rowNum = 0;
			//For header row
			{
				Row row = sheet.createRow(rowNum++);
				for (Object field : header) {
	                Cell cell = row.createCell(colNum++);	                
	                    cell.setCellValue((String) field);	                
	            }
			}
			
			for(int i=0;i<templateDetails.size();i++){				
				colNum = 0;
				Row row = sheet.createRow(rowNum++);
				obj=templateDetails.get(i);
	            for (Object field : obj) {
	                Cell cell = row.createCell(colNum++);
	                if (field instanceof String) {
	                    cell.setCellValue((String) field);
	                } else if (field instanceof Integer) {
	                    cell.setCellValue((Integer) field);
	                }
	            }
			}

	        try {
	            FileOutputStream outputStream = new FileOutputStream(FILE_NAME);
	            workbook.write(outputStream);
	            workbook.close();
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }

	        System.out.println("Done");
	    
		return FILE_NAME;*/
		
		return uniqueId;
	}
	
	public int getCount(String table, String column, String value) {
		String lQuery = "select count(*) from " + table + " where " + column + "=?1";
		query = em.createNativeQuery(lQuery);
		query.setParameter(1, value);
		int num = (int) query.getSingleResult();
		return num;
	}
	
	@SuppressWarnings("unchecked")
	public String validateIpforDisconnection(String value) {
		String result ="";
		Object[] obj=null;
		spQuery = em.createStoredProcedureQuery("isp_validateIPForDisconnection")
				.registerStoredProcedureParameter("ip", String.class, ParameterMode.IN);
		spQuery.setParameter("ip",value);
		List<Object[]> soList=spQuery.getResultList();
		for(int i=0;i<soList.size();i++){
		result = String.valueOf(soList.get(i));
		}
		return result;
	}

	@Override
	public List<DisconnectionOnCRDTO> uploadFile(MultipartFile file, String userId, HashMap<String, String> resultMap)throws IOException {
		String requestId="";
		HSSFWorkbook workbook = new HSSFWorkbook(file.getInputStream());
		HSSFRow row = null;
		int i = 1;

		String uniq_id = "";
		HSSFSheet worksheet = workbook.getSheetAt(0);
		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmssSSSSSS").format(Calendar.getInstance().getTime());
		String uniqueId="DIS_CR_"+timeStamp;
		
		while (i <= worksheet.getLastRowNum()) {
			row = worksheet.getRow(i++);			
			TempDisconnectionCrDetail tempdisconnectionRequestOnCr=new TempDisconnectionCrDetail();
			tempdisconnectionRequestOnCr.setUniqueId(uniqueId);
			tempdisconnectionRequestOnCr.setIp(String.valueOf(row.getCell(0)));
			tempdisconnectionRequestOnCr.setDisconnectionRequestDate(DateUtil.convertDateToSqlDate(String.valueOf(row.getCell(1))));
			tempdisconnectionRequestOnCr.setUserid(userId);
			if(resultMap.containsKey(String.valueOf(row.getCell(0)))){
				tempdisconnectionRequestOnCr.setStatus("N");
				tempdisconnectionRequestOnCr.setMessage(resultMap.get(String.valueOf(row.getCell(0))));
			}else{
				tempdisconnectionRequestOnCr.setStatus("Y");
				tempdisconnectionRequestOnCr.setMessage("");
			}
				
			em.merge(tempdisconnectionRequestOnCr);					
	}
		
		spQuery = em.createStoredProcedureQuery("isp_getTempDisconnectionCustomerRequest")
				.registerStoredProcedureParameter("uniqueId", String.class, ParameterMode.IN);
		spQuery.setParameter("uniqueId",uniqueId);
		List<Object[]> soList=spQuery.getResultList();
		return soList.stream().map(result -> new DisconnectionOnCRDTO(
		          String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2])
		         ,String.valueOf(result[3]),String.valueOf(result[4]),String.valueOf(result[5])
		         ,Integer.parseInt(String.valueOf(result[6])),String.valueOf(result[7]),String.valueOf(result[10]),String.valueOf(result[11])
		   )).collect(Collectors.toList());

}
	
	/*@Override
	public void uploadFile(MultipartFile file, String userId)throws IOException {
		String requestId="";
		HSSFWorkbook workbook = new HSSFWorkbook(file.getInputStream());
		HSSFRow row = null;
		int i = 1;
		BigDecimal alternateMobNo = null;
		BigDecimal contact_person_no = null;

		String uniq_id = "";
		HSSFSheet worksheet = workbook.getSheetAt(0);
		CustomerSapmst customerSapmst=null;
		while (i <= worksheet.getLastRowNum()) {
			row = worksheet.getRow(i++);
			synchronized (this) {
				query=em.createNamedQuery("DisconnectionRequestOnCrMst.getRequestId");
				requestId=String.valueOf(query.getSingleResult());							
			}
			DisconnectionRequestOnCrMst disconnectionRequestOnCrMst=new DisconnectionRequestOnCrMst();
			disconnectionRequestOnCrMst.setRequestId(requestId);
			disconnectionRequestOnCrMst.setUserId(userId);
			
			if (!(String.valueOf(row.getCell(0)).equals("") || String.valueOf(row.getCell(0)).equals("null"))) {
				disconnectionRequestOnCrMst.setIp(String.valueOf(row.getCell(0)));
				disconnectionRequestOnCrMst.setSoNo(String.valueOf(row.getCell(1)));
				disconnectionRequestOnCrMst.setDisconnectionRequestDate(DateUtil.convertDateToSqlDate(String.valueOf(row.getCell(3))));
				disconnectionRequestOnCrMst.setNoticePeriod(Integer.parseInt((String.valueOf(row.getCell(4)))));
				disconnectionRequestOnCrMst.setBillingEndDate(DateUtil.convertDateToSqlDate(String.valueOf(row.getCell(5))));
				disconnectionRequestOnCrMst.setDisconnectionStatus("0");		
			em.merge(disconnectionRequestOnCrMst);
		}
	}

}*/
	@Override
	public DisconnectionRequestOnCrMst disconnectSite(DisconnectionRequestOnCrMst toBeStatuses) {
		query=em.createNamedQuery("DisconnectionRequestOnCrMst.updateDisconnectionStatus");
		query.setParameter("requestStatus", toBeStatuses.getDisconnectionStatus());
		query.setParameter("requestId", toBeStatuses.getRequestId());
		query.executeUpdate();
		return toBeStatuses;
	}
	@Override
	public List<DisconnectionReconnectionDatesToCSVDTO> getBillingEndDate(String requestId) {
		DisconnectionReconnectionDatesToCSVDTO dto;
		List<DisconnectionReconnectionDatesToCSVDTO> result=new ArrayList<DisconnectionReconnectionDatesToCSVDTO>();
		query = em.createNativeQuery("SELECT drm.so_no,CONVERT(VARCHAR,drm.billing_end_date,105)as enddate"
				+ " FROM disconnection_request_on_cr_mst drm"
				+ " WHERE drm.request_id='"+requestId+"'");
		
		@SuppressWarnings("unchecked")
		List<Object[]> resultList = (List<Object[]>) query.getResultList();
		if( resultList!=null && resultList.size()>0) { 		
		for (Object[] objects : resultList) {
			dto=new DisconnectionReconnectionDatesToCSVDTO();
			dto.setSo_no(String.valueOf(objects[0]));
			dto.setEndDate(String.valueOf(objects[1]));
			result.add(dto);
		}		
	}	
		return result;
	}
	@Override
	public List<DisconnectionOnCRDTO> getDisconnectionForCustomerRequestReport(HttpServletRequest request) {
		spQuery = em.createStoredProcedureQuery("isp_getDisconnectionOnCRReport")
				.registerStoredProcedureParameter("customer", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("disconnectionStartDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("disconnectionEndDate", String.class, ParameterMode.IN);
		spQuery.setParameter("customer", request.getParameter("customer"))
				.setParameter("disconnectionStartDate", DateUtil.convertDateToSqlDate(request.getParameter("startDate")))
				.setParameter("disconnectionEndDate", DateUtil.convertDateToSqlDate(request.getParameter("EndDate")));
		List<Object[]> soList=spQuery.getResultList();
		return soList.stream().map(result -> new DisconnectionOnCRDTO(
		          String.valueOf(result[0]),String.valueOf(result[1]),String.valueOf(result[2])
		         ,String.valueOf(result[3]),String.valueOf(result[4]),String.valueOf(result[5])
		         ,String.valueOf(result[6]),String.valueOf(result[7]),String.valueOf(result[8]),String.valueOf(result[9])
		         ,String.valueOf(result[10]),String.valueOf(result[11]),String.valueOf(result[12]),String.valueOf(result[13])
		         ,String.valueOf(result[14]),String.valueOf(result[15]),String.valueOf(result[16]),String.valueOf(result[17]),String.valueOf(result[18])
		         
		   )).collect(Collectors.toList());
	}
	@Override
	public DisconnectionRequestOnCrMst createDisconnectionRequestOnCR(DisconnectionRequestOnCrMst toBeStatuses) {
		String requestId="";		
				query=em.createNamedQuery("DisconnectionRequestOnCrMst.getRequestId");
				requestId=String.valueOf(query.getSingleResult());										
			DisconnectionRequestOnCrMst disconnectionRequestOnCrMst=new DisconnectionRequestOnCrMst();
			toBeStatuses.setRequestId(requestId);			
			toBeStatuses.setDisconnectionRequestDate(DateUtil.convertDateToSqlDate(toBeStatuses.getDisconnectionRequestDate()));		
			toBeStatuses.setBillingEndDate(DateUtil.convertDateToSqlDate(toBeStatuses.getBillingEndDate()));
			toBeStatuses.setDisconnectionStatus("0");		
			em.merge(toBeStatuses);
			
			
		return disconnectionRequestOnCrMst;
		
		
	}
	
	public void sendDisconnectionOnCRIntimation(String commonId){
		spQuery = em.createStoredProcedureQuery("isp_SendDisconnectionOnCRNotificationsForExeccution")
				.registerStoredProcedureParameter("commonId", String.class, ParameterMode.IN);
		spQuery.setParameter("commonId", commonId);
		spQuery.execute();
	}
}
