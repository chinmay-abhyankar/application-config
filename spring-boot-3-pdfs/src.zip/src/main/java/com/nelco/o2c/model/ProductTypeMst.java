package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the product_type_mst database table.
 * 
 */
@Entity
@Table(name="product_type_mst")
@NamedQuery(name="ProductTypeMst.findAll", query="SELECT p FROM ProductTypeMst p where p.isActive='Y' ")
public class ProductTypeMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="product_type_mst_id")
	private Integer productTypeMstId;

	@Column(name="is_active")
	private String isActive;

	@Column(name="product_type_code")
	private String productTypeCode;

	@Column(name="product_type_desc")
	private String productTypeDesc;

	public Integer getProductTypeMstId() {
		return productTypeMstId;
	}

	public void setProductTypeMstId(Integer productTypeMstId) {
		this.productTypeMstId = productTypeMstId;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getProductTypeCode() {
		return productTypeCode;
	}

	public void setProductTypeCode(String productTypeCode) {
		this.productTypeCode = productTypeCode;
	}

	public String getProductTypeDesc() {
		return productTypeDesc;
	}

	public void setProductTypeDesc(String productTypeDesc) {
		this.productTypeDesc = productTypeDesc;
	}
}