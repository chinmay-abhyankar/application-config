package com.nelco.o2c.dto;

public class MaterialReturnBean {
	private Integer id;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}
