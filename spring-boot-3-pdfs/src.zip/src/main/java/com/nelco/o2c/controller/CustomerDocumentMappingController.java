package com.nelco.o2c.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.CustomerDocumentMappingFormDTO;
import com.nelco.o2c.dto.InvoiceSubmissionFormDTO;
import com.nelco.o2c.dto.ReactivationOnCRFormDTO;
import com.nelco.o2c.service.CustomerDocumentMappingService;

@RestController
public class CustomerDocumentMappingController {
	@Autowired
	CustomerDocumentMappingService customerDocumentMappingService;

	@RequestMapping(value = "/getCustomerDocumentMappingList.do", method = RequestMethod.GET)
	public CustomerDocumentMappingFormDTO getCustomerDocumentMappingList(CustomerDocumentMappingFormDTO customerDocumentMappingFormDTO, HttpServletRequest request) {	
	return customerDocumentMappingService.getCustomerDocumentMappingList(customerDocumentMappingFormDTO, request);
}
	
	@RequestMapping(value = "/addDocumentsForCustomer.do", method = RequestMethod.POST)
	public CustomerDocumentMappingFormDTO addDocumentsForCustomer(@RequestBody CustomerDocumentMappingFormDTO customerDocumentMappingFormDTO, HttpServletRequest request) {
		return customerDocumentMappingService.addDocumentsForCustomer(customerDocumentMappingFormDTO, request);
	}
	
	@RequestMapping(value = "/removeDocumentsForCustomer.do", method = RequestMethod.POST)
	public String removeDocumentsForCustomer(@RequestBody CustomerDocumentMappingFormDTO customerDocumentMappingFormDTO, HttpServletRequest request) {
		try{
		return customerDocumentMappingService.removeDocumentsForCustomer(customerDocumentMappingFormDTO, request);
		}catch(Exception e){
			e.printStackTrace();
		return "Failure";
		}
		
	}
	
	@RequestMapping(value = "/getCustomerDocumentMappingMaster.do", method = RequestMethod.GET)
	public CustomerDocumentMappingFormDTO getCustomerDocumentMappingMaster(CustomerDocumentMappingFormDTO customerDocumentMappingFormDTO, HttpServletRequest request) {	
	return customerDocumentMappingService.getCustomerDocumentMappingMaster(customerDocumentMappingFormDTO, request);
}
	
}
