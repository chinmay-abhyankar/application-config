package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the spares_so_del_pgi database table.
 * 
 */
@Entity
@Table(name="spares_so_del_pgi")
@NamedQuery(name="SparesSoDelPgi.findAll", query="SELECT s FROM SparesSoDelPgi s")
public class SparesSoDelPgi implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="spares_so_del_pgi_id")
	private Integer sparesSoDelPgiId;

	@Column(name="billing_type")
	private String billingType;

	@Column(name="created_date")
	private String createdDate;

	@Column(name="del_creation_date")
	private String delCreationDate;

	@Column(name="del_no")
	private String delNo;

	@Column(name="del_type")
	private String delType;

	@Column(name="inv_date")
	private String invDate;

	@Column(name="inv_no")
	private String invNo;

	@Column(name="inv_type")
	private String invType;

	@Column(name="modified_date")
	private String modifiedDate;

	@Column(name="pgi_num")
	private String pgiNum;

	@Column(name="posting_date")
	private String postingDate;

	private String proforma;

	@Column(name="proforma_date")
	private String proformaDate;

	@Column(name="proforma_email_flag")
	private String proformaEmailFlag;

	@Column(name="so_creation_date")
	private String soCreationDate;

	@Column(name="so_item")
	private String soItem;

	@Column(name="so_number")
	private String soNumber;

	@Column(name="so_type")
	private String soType;

	@Column(name="spares_req_id")
	private String sparesReqId;

	@Column(name="tax_inv_email_flag")
	private String taxInvEmailFlag;

	public SparesSoDelPgi() {
	}

	public Integer getSparesSoDelPgiId() {
		return this.sparesSoDelPgiId;
	}

	public void setSparesSoDelPgiId(Integer sparesSoDelPgiId) {
		this.sparesSoDelPgiId = sparesSoDelPgiId;
	}

	public String getBillingType() {
		return this.billingType;
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

	public String getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getDelCreationDate() {
		return this.delCreationDate;
	}

	public void setDelCreationDate(String delCreationDate) {
		this.delCreationDate = delCreationDate;
	}

	public String getDelNo() {
		return this.delNo;
	}

	public void setDelNo(String delNo) {
		this.delNo = delNo;
	}

	public String getDelType() {
		return this.delType;
	}

	public void setDelType(String delType) {
		this.delType = delType;
	}

	public String getInvDate() {
		return this.invDate;
	}

	public void setInvDate(String invDate) {
		this.invDate = invDate;
	}

	public String getInvNo() {
		return this.invNo;
	}

	public void setInvNo(String invNo) {
		this.invNo = invNo;
	}

	public String getInvType() {
		return this.invType;
	}

	public void setInvType(String invType) {
		this.invType = invType;
	}

	public String getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getPgiNum() {
		return this.pgiNum;
	}

	public void setPgiNum(String pgiNum) {
		this.pgiNum = pgiNum;
	}

	public String getPostingDate() {
		return this.postingDate;
	}

	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}

	public String getProforma() {
		return this.proforma;
	}

	public void setProforma(String proforma) {
		this.proforma = proforma;
	}

	public String getProformaDate() {
		return this.proformaDate;
	}

	public void setProformaDate(String proformaDate) {
		this.proformaDate = proformaDate;
	}

	public String getProformaEmailFlag() {
		return this.proformaEmailFlag;
	}

	public void setProformaEmailFlag(String proformaEmailFlag) {
		this.proformaEmailFlag = proformaEmailFlag;
	}

	public String getSoCreationDate() {
		return this.soCreationDate;
	}

	public void setSoCreationDate(String soCreationDate) {
		this.soCreationDate = soCreationDate;
	}

	public String getSoItem() {
		return this.soItem;
	}

	public void setSoItem(String soItem) {
		this.soItem = soItem;
	}

	public String getSoNumber() {
		return this.soNumber;
	}

	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}

	public String getSoType() {
		return this.soType;
	}

	public void setSoType(String soType) {
		this.soType = soType;
	}

	public String getSparesReqId() {
		return this.sparesReqId;
	}

	public void setSparesReqId(String sparesReqId) {
		this.sparesReqId = sparesReqId;
	}

	public String getTaxInvEmailFlag() {
		return this.taxInvEmailFlag;
	}

	public void setTaxInvEmailFlag(String taxInvEmailFlag) {
		this.taxInvEmailFlag = taxInvEmailFlag;
	}

}