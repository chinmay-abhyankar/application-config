package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the nature_mst database table.
 * 
 */
@Entity
@Table(name="nature_mst")
@NamedQuery(name="NatureMst.findAll", query="SELECT n FROM NatureMst n")
public class NatureMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="nature_mst_id")
	private int natureMstId;

	@Column(name="nature_code")
	private String natureCode;

	@Column(name="nature_val")
	private String natureVal;

	public NatureMst() {
	}

	public int getNatureMstId() {
		return this.natureMstId;
	}

	public void setNatureMstId(int natureMstId) {
		this.natureMstId = natureMstId;
	}

	public String getNatureCode() {
		return this.natureCode;
	}

	public void setNatureCode(String natureCode) {
		this.natureCode = natureCode;
	}

	public String getNatureVal() {
		return this.natureVal;
	}

	public void setNatureVal(String natureVal) {
		this.natureVal = natureVal;
	}

}