package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the franchise_proc_type_mst database table.
 * 
 */
@Entity
@Table(name="franchise_proc_type_mst")
@NamedQuery(name="FranchiseProcTypeMst.findAll", query="SELECT f FROM FranchiseProcTypeMst f")
public class FranchiseProcTypeMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="franchise_proc_type_mst_id")
	private Integer franchiseProcTypeMstId;

	@Column(name="franchise_proc_type_val")
	private String franchiseProcTypeVal;

	@Column(name="is_active")
	private String isActive;

	public FranchiseProcTypeMst() {
	}

	public Integer getFranchiseProcTypeMstId() {
		return this.franchiseProcTypeMstId;
	}

	public void setFranchiseProcTypeMstId(Integer franchiseProcTypeMstId) {
		this.franchiseProcTypeMstId = franchiseProcTypeMstId;
	}

	public String getFranchiseProcTypeVal() {
		return this.franchiseProcTypeVal;
	}

	public void setFranchiseProcTypeVal(String franchiseProcTypeVal) {
		this.franchiseProcTypeVal = franchiseProcTypeVal;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

}