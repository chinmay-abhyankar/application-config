package com.nelco.o2c.dao;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.nelco.o2c.dto.CustomerInfoDTO;
import com.nelco.o2c.dto.DisconnectionDTO;
import com.nelco.o2c.dto.DisconnectionFormDTO;
import com.nelco.o2c.dto.DisconnectionOnCRDTO;
import com.nelco.o2c.dto.DisconnectionReconnectionDatesToCSVDTO;
import com.nelco.o2c.dto.DisconnectionRequestDetailsDTO;
import com.nelco.o2c.dto.DisconnectionRequestTrackerDTO;
import com.nelco.o2c.dto.InvoiceInfoDTO;
import com.nelco.o2c.dto.OutstandingInvoicesDTO;
import com.nelco.o2c.dto.ReminderDetailsDTO;
import com.nelco.o2c.dto.SiteInfoDTO;
import com.nelco.o2c.model.CustomerAgeingDetails;
import com.nelco.o2c.model.DisconnectionAlltypesMst;
import com.nelco.o2c.model.DisconnectionNoticeRequestMst;
import com.nelco.o2c.model.DisconnectionRequestAction;
import com.nelco.o2c.model.DisconnectionRequestMst;

public interface DisconnectionDao {
	public List<CustomerAgeingDetails> getCustomerwiseOutstanding(DisconnectionDTO disconnectionDTO);
	public List<CustomerAgeingDetails> getOutstandingforCustomer(HttpServletRequest request);
	
	public List<OutstandingInvoicesDTO> getOutstandingInvoicesList(HttpServletRequest request);
	public DisconnectionFormDTO getDisconnectionMasters(DisconnectionFormDTO disconnectionFormDTO);
	public DisconnectionRequestAction saveReminders(DisconnectionRequestAction toBeSavedReminders);
	public List<Map<String, Object>> getReminderIdFromInvoiceNo(String invoiceNo);
	public DisconnectionRequestAction updateReminderStatus(DisconnectionRequestAction toBeSavedReminders);
	public DisconnectionNoticeRequestMst initiateDisconnectionNotice(DisconnectionNoticeRequestMst disconnectionNotice);
	public CustomerInfoDTO getCustomerInfoFromInvoiceNo(String parameter);
	public InvoiceInfoDTO getInvoiceInfoFromInvoiceNo(String parameter);
	public List<ReminderDetailsDTO> getReminderDetailsFromInvoiceNo(String parameter);
	public DisconnectionNoticeRequestMst updateNoticeRequestStatus(DisconnectionNoticeRequestMst toBeStatuses);
	public DisconnectionRequestDetailsDTO getDisconnectionRequestDetails(String parameter);
	public DisconnectionRequestMst updateDisconnectionRequestStatus(DisconnectionRequestMst toBeStatuses);
	public DisconnectionRequestMst disconnectSite(DisconnectionRequestMst toBeStatuses);
	public List<DisconnectionReconnectionDatesToCSVDTO> getBillingEndDate(String requestId);
	public List<DisconnectionOnCRDTO> getDisconnectionForNonPaymentReport(HttpServletRequest request);
	public List<DisconnectionRequestTrackerDTO> getDisconnectionRequestTracker(String invoiceNo);
	public SiteInfoDTO getSiteDetailsFromInvoiceNo(String invoiceNo);
	public void sendDisconnectionNotifications(String requestId);
}
