package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.utility.DateUtil;

/**
 * The persistent class for the spares_so database table.
 * 
 */
@Entity
@Table(name = "spares_so")
@NamedQueries({ @NamedQuery(name = "SparesSo.findAll", query = "SELECT s FROM SparesSo s"),
		@NamedQuery(name = "SparesSo.findByCreatedId", query = "SELECT s FROM SparesSo s inner join fetch s.sparesSoUserMapList userList left join fetch s.sparesSoDetailsList sl left join fetch s.sparesSoDelPgiSet ssdp  where userList.userMstId = :userMstId and s.createdDate between :fromDate and :toDate order by s.sparesSoId desc "),
		@NamedQuery(name = "SparesSo.findById", query = "SELECT s FROM SparesSo s left join s.sparesSoDetailsList sl where s.sparesSoId= :sparesSoId and sl.delFlg='N' "),
		@NamedQuery(name = "SparesSo.sparesSoByIncidentId", query = "SELECT s FROM SparesSo s left join s.sparesSoDetailsList sl where s.incidentId= :incidentId and sl.delFlg='N' "),
		@NamedQuery(name = "SparesSo.getCurrentDayMaxCount", query = " select (count(s)+1) from SparesSo "
				+ " s where s.createdDate between ?1 and ?2 ") })
public class SparesSo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "spares_so_id")
	private Integer sparesSoId;

	@Column(name = "challan_no")
	private String challanNo;

	@Column(name = "created_by_id", updatable = false)
	private Integer createdById;

	@Column(name = "created_date", updatable = false)
	private String createdDate;

	@Column(name = "modified_date")
	private String modifiedDate;

	@Column(name = "delivery_num")
	private String deliveryNum;

	@Column(name = "grn_no")
	private String grnNo;

	private String pgi;

	@Column(name = "plant_sapmst_id")
	private Integer plantSapmstId;

	@Column(name = "po_number")
	private String poNumber;

	private String quantity;

	@Column(name = "ship_to_party")
	private String shipToParty;

	@Column(name = "ship_to_party_id")
	private String shipToPartyId;

	@Column(name = "shtp_address")
	private String shtpAddress;

	@Column(name = "sold_to_party")
	private String soldToParty;

	@Column(name = "sold_to_party_id")
	private String soldToPartyId;

	@Column(name = "spares_so_type")
	private String sparesSoType;

	@Column(name = "special_instructions")
	private String specialInstructions;

	@Column(name = "tax_inv_no")
	private String taxInvNo;

	@Column(name = "uniq_id")
	private String uniqId;

	@Column(name = "incident_id")
	private String incidentId;

	@Column(name = "is_submit")
	private String isSubmit = "N";
	
	@Column(name="bill_to_party")
	private String billToParty;
	
	@Column(name="region_code")
	private String region;
	
	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getBillToParty() {
		return billToParty;
	}

	public void setBillToParty(String billToParty) {
		this.billToParty = billToParty;
	}

	@Transient
	private String plantCode;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "spares_so_id", referencedColumnName = "spares_so_id", insertable = false, updatable = false)
	private List<SparesSoDetail> sparesSoDetailsList;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "spares_so_id", referencedColumnName = "spares_so_id", insertable = false, updatable = false)
	private Set<SparesSoUserMap> sparesSoUserMapList;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "spares_req_id", referencedColumnName = "uniq_id", insertable = false, updatable = false)
	private Set<SparesSoDelPgi> sparesSoDelPgiSet;

	public Set<SparesSoDelPgi> getSparesSoDelPgiSet() {
		return sparesSoDelPgiSet;
	}

	public void setSparesSoDelPgiSet(Set<SparesSoDelPgi> sparesSoDelPgiSet) {
		this.sparesSoDelPgiSet = sparesSoDelPgiSet;
	}

	public SparesSo() {
	}

	public String getSoldToPartyId() {
		return soldToPartyId;
	}

	public Set<SparesSoUserMap> getSparesSoUserMapList() {
		return sparesSoUserMapList;
	}

	public void setSparesSoUserMapList(Set<SparesSoUserMap> sparesSoUserMapList) {
		this.sparesSoUserMapList = sparesSoUserMapList;
	}

	public String getIsSubmit() {
		return isSubmit;
	}

	public void setIsSubmit(String isSubmit) {
		this.isSubmit = isSubmit;
	}

	public List<SparesSoDetail> getSparesSoDetailsList() {
		return sparesSoDetailsList;
	}

	public void setSparesSoDetailsList(List<SparesSoDetail> sparesSoDetailsList) {
		this.sparesSoDetailsList = sparesSoDetailsList;
	}

	public Integer getSparesSoId() {
		return this.sparesSoId;
	}

	public void setSparesSoId(Integer sparesSoId) {
		this.sparesSoId = sparesSoId;
	}

	public String getChallanNo() {
		return this.challanNo;
	}

	public void setChallanNo(String challanNo) {
		this.challanNo = challanNo;
	}

	public Integer getCreatedById() {
		return this.createdById;
	}

	public void setCreatedById(Integer createdById) {
		this.createdById = createdById;
	}

	public String getCreatedDate() {
		return DateUtil.convertDateTimeToString(this.createdDate);
		// return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getDeliveryNum() {
		return this.deliveryNum;
	}

	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}

	public String getGrnNo() {
		return this.grnNo;
	}

	public void setGrnNo(String grnNo) {
		this.grnNo = grnNo;
	}

	public String getPgi() {
		return this.pgi;
	}

	public void setPgi(String pgi) {
		this.pgi = pgi;
	}

	public Integer getPlantSapmstId() {
		return this.plantSapmstId;
	}

	public void setPlantSapmstId(Integer plantSapmstId) {
		this.plantSapmstId = plantSapmstId;
	}

	public String getPoNumber() {
		return this.poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getQuantity() {
		return this.quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getShipToParty() {
		return this.shipToParty;
	}

	public void setShipToParty(String shipToParty) {
		this.shipToParty = shipToParty;
	}

	public String getShipToPartyId() {
		return shipToPartyId;
	}

	public void setShipToPartyId(String shipToPartyId) {
		this.shipToPartyId = shipToPartyId;
	}

	public void setSoldToPartyId(String soldToPartyId) {
		this.soldToPartyId = soldToPartyId;
	}

	public String getShtpAddress() {
		return shtpAddress;
	}

	public void setShtpAddress(String shtpAddress) {
		this.shtpAddress = shtpAddress;
	}

	public String getSoldToParty() {
		return this.soldToParty;
	}

	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}

	public String getSparesSoType() {
		return this.sparesSoType;
	}

	public void setSparesSoType(String sparesSoType) {
		this.sparesSoType = sparesSoType;
	}

	public String getSpecialInstructions() {
		return this.specialInstructions;
	}

	public void setSpecialInstructions(String specialInstructions) {
		this.specialInstructions = specialInstructions;
	}

	public String getTaxInvNo() {
		return this.taxInvNo;
	}

	public void setTaxInvNo(String taxInvNo) {
		this.taxInvNo = taxInvNo;
	}

	public String getUniqId() {
		return this.uniqId;
	}

	public void setUniqId(String uniqId) {
		this.uniqId = uniqId;
	}

	public String getIncidentId() {
		return incidentId;
	}

	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}
	
}