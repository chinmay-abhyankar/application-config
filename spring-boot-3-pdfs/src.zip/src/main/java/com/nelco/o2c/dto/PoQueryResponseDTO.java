/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.PoQueryDetail;
import com.nelco.o2c.model.PoResponseDetail;

/**
 * @author Jayashankar.r
 *
 */
public class PoQueryResponseDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer userMstId;
	private Integer proposalId;
	private Integer opportunityId;
	private List<PoQueryDetail> queries;
	private PoQueryDetail query;
	private PoResponseDetail response;
	
	public PoQueryDetail getQuery() {
		return query;
	}
	public void setQuery(PoQueryDetail query) {
		this.query = query;
	}
	public PoResponseDetail getResponse() {
		return response;
	}
	public void setResponse(PoResponseDetail response) {
		this.response = response;
	}
	public List<PoQueryDetail> getQueries() {
		return queries;
	}
	public void setQueries(List<PoQueryDetail> queries) {
		this.queries = queries;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public Integer getProposalId() {
		return proposalId;
	}
	public void setProposalId(Integer proposalId) {
		this.proposalId = proposalId;
	}
	public Integer getOpportunityId() {
		return opportunityId;
	}
	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}
	
}
