package com.nelco.o2c.dto;

public class DisconnectionRequestDetailsDTO {
private String requestId="";
private String requestDate="";
private String requester="";
private String salesHeadAppStatus="";
private String financeHeadAppStatus="";
private String businessHeadAppStatus="";
private String mdAPPStatus="";
private String requestType="";
private String requestTypeCode="";
private String disconnectionDate="";
private String disconnectionStatus="";

public String getDisconnectionStatus() {
	return disconnectionStatus;
}
public void setDisconnectionStatus(String disconnectionStatus) {
	this.disconnectionStatus = disconnectionStatus;
}
public String getDisconnectionDate() {
	return disconnectionDate;
}
public void setDisconnectionDate(String disconnectionDate) {
	this.disconnectionDate = disconnectionDate;
}
public String getBusinessHeadAppStatus() {
	return businessHeadAppStatus;
}
public void setBusinessHeadAppStatus(String businessHeadAppStatus) {
	this.businessHeadAppStatus = businessHeadAppStatus;
}
public String getMdAPPStatus() {
	return mdAPPStatus;
}
public void setMdAPPStatus(String mdAPPStatus) {
	this.mdAPPStatus = mdAPPStatus;
}
public String getRequestType() {
	return requestType;
}
public void setRequestType(String requestType) {
	this.requestType = requestType;
}
public String getRequestTypeCode() {
	return requestTypeCode;
}
public void setRequestTypeCode(String requestTypeCode) {
	this.requestTypeCode = requestTypeCode;
}
public String getSalesHeadAppStatus() {
	return salesHeadAppStatus;
}
public void setSalesHeadAppStatus(String salesHeadAppStatus) {
	this.salesHeadAppStatus = salesHeadAppStatus;
}
public String getFinanceHeadAppStatus() {
	return financeHeadAppStatus;
}
public void setFinanceHeadAppStatus(String financeHeadAppStatus) {
	this.financeHeadAppStatus = financeHeadAppStatus;
}
public String getRequestId() {
	return requestId;
}
public void setRequestId(String requestId) {
	this.requestId = requestId;
}
public String getRequestDate() {
	return requestDate;
}
public void setRequestDate(String requestDate) {
	this.requestDate = requestDate;
}
public String getRequester() {
	return requester;
}
public void setRequester(String requester) {
	this.requester = requester;
}

}
