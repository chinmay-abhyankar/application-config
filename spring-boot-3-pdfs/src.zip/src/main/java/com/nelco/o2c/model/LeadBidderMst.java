package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the lead_bidder_mst database table.
 * 
 */
@Entity
@Table(name="lead_bidder_mst")
@NamedQuery(name="LeadBidderMst.findAll", query="SELECT l FROM LeadBidderMst l")
public class LeadBidderMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="lead_bidder_mst_id")
	private Integer leadBidderMstId;

	@Column(name="lead_bidder_code")
	private String leadBidderCode;

	@Column(name="lead_bidder_val")
	private String leadBidderVal;

	public Integer getLeadBidderMstId() {
		return leadBidderMstId;
	}

	public void setLeadBidderMstId(Integer leadBidderMstId) {
		this.leadBidderMstId = leadBidderMstId;
	}

	public String getLeadBidderCode() {
		return leadBidderCode;
	}

	public void setLeadBidderCode(String leadBidderCode) {
		this.leadBidderCode = leadBidderCode;
	}

	public String getLeadBidderVal() {
		return leadBidderVal;
	}

	public void setLeadBidderVal(String leadBidderVal) {
		this.leadBidderVal = leadBidderVal;
	}

	

}