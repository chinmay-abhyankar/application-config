package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the doc_sub_rec_details database table.
 * 
 */
@Entity
@Table(name="doc_sub_rec_details")
@NamedQuery(name="DocSubRecDetail.findAll", query="SELECT d FROM DocSubRecDetail d")
public class DocSubRecDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="doc_sub_rec_details_id")
	private Integer docSubRecDetailsId;

	@Column(name="opp_upload_details_id")
	private Integer oppUploadDetailsId;

	@Column(name="update_by")
	private Integer updateBy;

	@Column(name="update_time")
	private String updateTime;

	public DocSubRecDetail() {
	}

	public Integer getDocSubRecDetailsId() {
		return this.docSubRecDetailsId;
	}

	public void setDocSubRecDetailsId(Integer docSubRecDetailsId) {
		this.docSubRecDetailsId = docSubRecDetailsId;
	}

	public Integer getOppUploadDetailsId() {
		return this.oppUploadDetailsId;
	}

	public void setOppUploadDetailsId(Integer oppUploadDetailsId) {
		this.oppUploadDetailsId = oppUploadDetailsId;
	}

	public Integer getUpdateBy() {
		return this.updateBy;
	}

	public void setUpdateBy(Integer updateBy) {
		this.updateBy = updateBy;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	

}