package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the state_mst database table.
 * 
 */
@Entity
@Table(name="state_mst")
@NamedQueries({
@NamedQuery(name="StateMst.findAll", query="SELECT s FROM StateMst s")
,@NamedQuery(name="StateMst.findByName", query="SELECT s FROM StateMst s where s.stateVal=?1")
})
public class StateMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="state_mst_id")
	private Integer stateMstId;

	@Column(name="state_code")
	private String stateCode;

	@Column(name="state_val")
	private String stateVal;
	
	@Column(name="country_code")
	private String countryCode;

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public Integer getStateMstId() {
		return stateMstId;
	}

	public void setStateMstId(Integer stateMstId) {
		this.stateMstId = stateMstId;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getStateVal() {
		return stateVal;
	}

	public void setStateVal(String stateVal) {
		this.stateVal = stateVal;
	}

	

}