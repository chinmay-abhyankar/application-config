package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;

import com.nelco.o2c.utility.DateUtil;

import java.sql.Timestamp;


/**
 * The persistent class for the sales_return_mst database table.
 * 
 */
@Entity
@Table(name="sales_return_mst")
@NamedQueries({ @NamedQuery(name="SalesReturnMst.findAll", query="SELECT s FROM SalesReturnMst s"),
	@NamedQuery(name = "SalesReturnMst.getCurrentDayMaxCount", query = " select (count(s)+1) from SalesReturnMst"
			+ " s where s.creation_date between ?1 and ?2 "),
	@NamedQuery(name = "SalesReturnMst.findById", query = " select s from SalesReturnMst"
			+ " s where s.id= ?1  ")

})



public class SalesReturnMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="credit_note_no_equipment")
	private String creditNoteNoEquipment;

	@Column(name="customer_id")
	private int customerId;

	@Column(name="disconnection_date")
	private String disconnectionDate;

	@Column(name="hub_id")
	private int hubId;

	@Column(name="invoice_no_equipment")
	private String invoiceNoEquipment;

	private String matnr;

	@Column(name="matnr_return_status")
	private String matnrReturnStatus;

	@Column(name="noc_remarks")
	private String nocRemarks;

	@Column(name="return_type")
	private String returnType;

	@Column(name="sales_order_no_bw")
	private String salesOrderNoBw;

	@Column(name="sales_order_no_equipment")
	private String salesOrderNoEquipment;

	@Column(name="uniq_id")
	private String uniqId;
	
	@Column(name="invoice_no_bw")
	private String invoiceNoBW;
	
	@Column(name="credit_note_no_bw")
	private String creditNoteNoBW;
	
	@Column(name="plant")
	private String plant;
	
	@Column(name="sales_org")
	private String salesOrg;
	
	@Column(name="dist_channel")
	private String distChannel;
	
	@Column(name="creation_date")
	private String creation_date;
	
	@Column(name="mdApproved")
	private String mdApproved;
	
	@Column(name="status")
	private Integer status;
	
	@Column(name="created_user_id")
	private Integer created_user_id;
	
	@Column(name="invoice_date")
	private String invoiceDate;	
	
	
	public String getInvoiceDate() {
		return DateUtil.convertDBToSDFormatDate(this.invoiceDate);
		//return DateUtil.convertDateTimeToString(this.invoiceDate);		
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "matnr", referencedColumnName = "material_num", insertable = false, updatable = false),
			@JoinColumn(name = "plant", referencedColumnName = "plant", insertable = false, updatable = false),
			@JoinColumn(name = "sales_org", referencedColumnName = "sales_org", insertable = false, updatable = false),
			@JoinColumn(name = "dist_channel", referencedColumnName = "dist_channel", insertable = false, updatable = false)})
	private MaterialSapmst materialSapmst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status", referencedColumnName = "status_mst_id"
	, insertable = false, updatable = false)
	private StatusMst statusMst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "customer_id", referencedColumnName = "customer_sapmst_id"
	, insertable = false, updatable = false)
	private CustomerSapmst customerSapmst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "credit_note_no_equipment", referencedColumnName = "credit_note_no", insertable = false, updatable = false)
			})
	private CreditNoteEquipMst creditNoteEquipMst;	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "credit_note_no_bw", referencedColumnName = "bandwidth_cr_no", insertable = false, updatable = false)
			})
	private CreditNoteBwMst creditNoteBwMst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name = "sales_order_no_equipment", referencedColumnName = "so_number"
				, insertable = false, updatable = false)
		,@JoinColumn(name = "matnr", referencedColumnName = "material_num", insertable = false, updatable = false)
		})	
	private SoOrders soOrders;
	
	public SoOrders getSoOrders() {
		return soOrders;
	}

	public void setSoOrders(SoOrders soOrders) {
		this.soOrders = soOrders;
	}

	public CreditNoteBwMst getCreditNoteBwMst() {
		return creditNoteBwMst;
	}

	public void setCreditNoteBwMst(CreditNoteBwMst creditNoteBwMst) {
		this.creditNoteBwMst = creditNoteBwMst;
	}

	public CustomerSapmst getCustomerSapmst() {
		return customerSapmst;
	}

	public void setCustomerSapmst(CustomerSapmst customerSapmst) {
		this.customerSapmst = customerSapmst;
	}	
	
	public String getMdApproved() {
		return mdApproved;
	}

	public void setMdApproved(String mdApproved) {
		this.mdApproved = mdApproved;
	}

	public StatusMst getStatusMst() {
		return statusMst;
	}

	public void setStatusMst(StatusMst statusMst) {
		this.statusMst = statusMst;
	}

	public Integer getCreated_user_id() {
		return created_user_id;
	}

	public void setCreated_user_id(Integer created_user_id) {
		this.created_user_id = created_user_id;
	}

	public MaterialSapmst getMaterialSapmst() {
		return materialSapmst;
	}

	public void setMaterialSapmst(MaterialSapmst materialSapmst) {
		this.materialSapmst = materialSapmst;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(String creation_date) {
		this.creation_date = creation_date;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getSalesOrg() {
		return salesOrg;
	}

	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

	public String getDistChannel() {
		return distChannel;
	}

	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}

	public String getCreditNoteNoBW() {
		return creditNoteNoBW;
	}

	public void setCreditNoteNoBW(String creditNoteNoBW) {
		this.creditNoteNoBW = creditNoteNoBW;
	}

	
	
	public CreditNoteEquipMst getCreditNoteEquipMst() {
		return creditNoteEquipMst;
	}

	public String getCreditNoteNoEquipment() {
		return creditNoteNoEquipment;
	}

	public void setCreditNoteNoEquipment(String creditNoteNoEquipment) {
		this.creditNoteNoEquipment = creditNoteNoEquipment;
	}

	public String getInvoiceNoEquipment() {
		return invoiceNoEquipment;
	}

	public void setInvoiceNoEquipment(String invoiceNoEquipment) {
		this.invoiceNoEquipment = invoiceNoEquipment;
	}

	public String getInvoiceNoBW() {
		return invoiceNoBW;
	}

	public void setInvoiceNoBW(String invoiceNoBW) {
		this.invoiceNoBW = invoiceNoBW;
	}

	public void setCreditNoteEquipMst(CreditNoteEquipMst creditNoteEquipMst) {
		this.creditNoteEquipMst = creditNoteEquipMst;
	}

	public String getDisconnectionDate() {
		return DateUtil.convertDateTimeToString(this.disconnectionDate);
		//convertDateTimeToString
		//return disconnectionDate;
	}

	public void setDisconnectionDate(String disconnectionDate) {
		this.disconnectionDate = disconnectionDate;
	}

	public SalesReturnMst() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}
	

	

	public int getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	

	public int getHubId() {
		return this.hubId;
	}

	public void setHubId(int hubId) {
		this.hubId = hubId;
	}

	

	public String getMatnr() {
		return this.matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}

	public String getMatnrReturnStatus() {
		return this.matnrReturnStatus;
	}

	public void setMatnrReturnStatus(String matnrReturnStatus) {
		this.matnrReturnStatus = matnrReturnStatus;
	}

	public String getNocRemarks() {
		return this.nocRemarks;
	}

	public void setNocRemarks(String nocRemarks) {
		this.nocRemarks = nocRemarks;
	}

	public String getReturnType() {
		return this.returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	public Object getSalesOrderNoBw() {
		return this.salesOrderNoBw;
	}	

	public String getSalesOrderNoEquipment() {
		return salesOrderNoEquipment;
	}

	public void setSalesOrderNoBw(String salesOrderNoBw) {
		this.salesOrderNoBw = salesOrderNoBw;
	}

	public void setSalesOrderNoEquipment(String salesOrderNoEquipment) {
		this.salesOrderNoEquipment = salesOrderNoEquipment;
	}

	public String getUniqId() {
		return this.uniqId;
	}

	public void setUniqId(String uniqId) {
		this.uniqId = uniqId;
	}

}