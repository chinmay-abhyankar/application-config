/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.utility.Constants;

/**
 * @author Jayashankar.r   OppDetails.bidManagerPotentialInfo
 *
 */
@Entity
@Table(name="opp_details")
@NamedQueries({@NamedQuery(name = "OppDetails.amPotentialInfo", query = "select od from OppDetails od inner join od.opportunity op left join op.drfDetails drf where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.SMOWNERID+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"','"+Constants.MARKETSEGMENT+"') and op.smownerId=?1 and op.zohoModifiedTime between ?2 and ?3 "),
		@NamedQuery(name = "OppDetails.preSalesPotentialInfo", query = "select od from OppDetails od inner join od.opportunity op inner join op.drfDetails drf where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.ACCOUNTNAME+"','"+Constants.MARKETSEGMENT+"','"+Constants.CLOSING_TIME+"') and drf.preSalesResName=?1 "),
		@NamedQuery(name = "OppDetails.salesCoordPotentialInfo", query = "select od from OppDetails od inner join od.opportunity op inner join op.drfDetails drf inner join drf.drfStatusTrackerList stl where stl.statusMstId in (2,3,4,5) and od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"','"+Constants.MARKETSEGMENT+"') "),
		@NamedQuery(name = "OppDetails.NOCheadPotentialInfo", query = "select od from OppDetails od inner join od.opportunity op inner join op.drfDetails drf inner join drf.drfStatusTrackerList stl where stl.statusMstId in (2,3,4,5) and od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"','"+Constants.MARKETSEGMENT+"') and drf.opHead=?1 "),
		@NamedQuery(name = "OppDetails.PMGTheadPotentialInfo", query = "select od from OppDetails od inner join od.opportunity op inner join op.drfDetails drf inner join drf.drfStatusTrackerList stl where stl.statusMstId in (2,3,4,5) and od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"','"+Constants.MARKETSEGMENT+"') and drf.pmgtHead=?1 "),
		@NamedQuery(name = "OppDetails.PREheadPotentialInfo", query = "select od from OppDetails od inner join od.opportunity op inner join op.drfDetails drf inner join drf.drfStatusTrackerList stl where stl.statusMstId in (2,3,4,5) and od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"','"+Constants.MARKETSEGMENT+"') and drf.preSalesHead=?1 "),
		@NamedQuery(name = "OppDetails.preBidRespMatrixForBidMgr", query = "select od from OppDetails od inner join od.opportunity op inner join op.taf t where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"','"+Constants.MARKETSEGMENT+"') and t.preBidId=?1 "),
		@NamedQuery(name = "OppDetails.RespMatrixForBidMgr", query = "select od from OppDetails od inner join od.opportunity op inner join op.taf t  where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"')  and t.preBidId=?1 "),
		@NamedQuery(name = "OppDetails.preBidTaskDetailsbyOppId", query = "select od from OppDetails od inner join od.opportunity op where od.opportunityId in (?1) and od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"','"+Constants.MARKETSEGMENT+"')"),
		@NamedQuery(name = "OppDetails.getOppDetbyOppId", query = "select od from OppDetails od inner join od.opportunity op where od.opportunityId = ?1 and od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"','"+Constants.MARKETSEGMENT+"')"),
		@NamedQuery(name = "OppDetails.getPotentialNameByOppId", query = "select od.content from OppDetails od where od.val = '"+Constants.COMPANY+"' and od.opportunityId = ?1 "),
		@NamedQuery(name = "OppDetails.getCustomerNameByOppId", query = "select od.content from OppDetails od where od.val = '"+Constants.ACCOUNTNAME+"' and od.opportunityId = ?1 "),
		@NamedQuery(name = "OppDetails.getNatureByOppId", query = "select od.content from OppDetails od where od.val = '"+Constants.NATUREOFOPP+"' and od.opportunityId = ?1 "),
		@NamedQuery(name = "OppDetails.getPoDetails", query = "select od from OppDetails od inner join od.opportunity op inner join op.proposal p  where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"')  and p.createdDate between ?1 and ?2 and p.salesCoordId=?3 order by p.createdDate desc "),
		@NamedQuery(name = "OppDetails.getPoDetailsPreSalesHead", query = "select od from OppDetails od inner join od.opportunity op inner join op.proposal p  where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"')  and p.createdDate between ?1 and ?2 and p.presalesheadApprId=?3  order by p.createdDate desc "),
		@NamedQuery(name = "OppDetails.getPoDetailsEboHead", query = "select od from OppDetails od inner join od.opportunity op inner join op.proposal p  where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"')  and p.createdDate between ?1 and ?2 and p.entBankingApprId=?3  order by p.createdDate desc "),
		@NamedQuery(name = "OppDetails.getPoDetailsNocHead", query = "select od from OppDetails od inner join od.opportunity op inner join op.proposal p  where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"')  and p.createdDate between ?1 and ?2 and p.opcNocheadId=?3  order by p.createdDate desc "),
		@NamedQuery(name = "OppDetails.getPoDetailsPmgtHead", query = "select od from OppDetails od inner join od.opportunity op inner join op.proposal p  where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"')  and p.createdDate between ?1 and ?2 and p.opcPmgtheadId=?3  order by p.createdDate desc "),
		@NamedQuery(name = "OppDetails.getPoDetailsFinance", query = "select od from OppDetails od inner join od.opportunity op inner join op.proposal p  where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"')  and p.createdDate between ?1 and ?2 and p.financeId=?3  order by p.createdDate desc "),
		@NamedQuery(name = "OppDetails.getPoDetailsFinanceTnsl", query = "select od from OppDetails od inner join od.opportunity op inner join op.proposal p  where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"')  and p.createdDate between ?1 and ?2 and p.financeTnslId=?3  order by p.createdDate desc "),
		@NamedQuery(name = "OppDetails.getPoDetailsAM", query = "select od from OppDetails od inner join od.opportunity op inner join op.proposal p  where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.CLOSING_TIME+"','"+Constants.ACCOUNTNAME+"')  and p.createdDate between ?1 and ?2 and p.smownerId=?3  order by p.createdDate desc "),
		@NamedQuery(name = "OppDetails.vpsPotentialInfo", query = "select od from OppDetails od inner join od.opportunity op inner join op.drfDetails drf where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.ACCOUNTNAME+"','"+Constants.MARKETSEGMENT+"') and drf.vpSalesId=?1 "),
		@NamedQuery(name = "OppDetails.eboHeadPotentialInfo", query = "select od from OppDetails od inner join od.opportunity op inner join op.drfDetails drf where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.ACCOUNTNAME+"','"+Constants.MARKETSEGMENT+"') and drf.eboSalesHeadId=?1 "),
		@NamedQuery(name = "OppDetails.mdPotentialInfo", query = "select od from OppDetails od inner join od.opportunity op inner join op.drfDetails drf where od.val in ('"+Constants.CURRENTSTATUS+"','"+Constants.COMPANY+"','"+Constants.PRODANDSERVICES+"','"+Constants.CREATED_TIME+"','"+Constants.CREATEDBY+"','"+Constants.MODIFIEDTIME+"','"+Constants.ACCOUNTNAME+"','"+Constants.MARKETSEGMENT+"') and drf.ceoId=?1 ")})  // and od.content='Proposal/ bid Submitted' 
public class OppDetails implements Serializable {

	private static final long serialVersionUID = 2L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="opp_details_id")
	private Integer oppDetailsId;
	
	@Column(name="opportunity_id")
	private Integer opportunityId;
	
	@Column(name="val",length=100)
	private String val;
	
	@Column(name="content")
	private String content;

	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="opportunity_id",referencedColumnName="opportunity_id", insertable = false, updatable = false)
	private Opportunity opportunity;
	
	@Transient
	private String showDrfButton = "N";
	
	@Transient
	private String proposalGenId;
	
	@Transient
	private String tenderNo;
	
	@Transient
	private Integer proposalId;
	
	@Transient
	private String poCreatedDate;
	
	@Transient
	private String poNumber;
	
	@Transient
	private String poStatusCode;
	
	@Transient
	private String poStatus;
	
	@Transient
	private String poDate;
	
	@Transient
	private String zohoId;
	
	@Transient
	private String smownerId;
	
	
	
	
	public String getSmownerId() {
		return smownerId;
	}

	public void setSmownerId(String smownerId) {
		this.smownerId = smownerId;
	}

	public String getZohoId() {
		return zohoId;
	}

	public void setZohoId(String zohoId) {
		this.zohoId = zohoId;
	}

	public String getPoDate() {
		return poDate;
	}

	public void setPoDate(String poDate) {
		this.poDate = poDate;
	}

	public String getPoStatusCode() {
		return poStatusCode;
	}

	public void setPoStatusCode(String poStatusCode) {
		this.poStatusCode = poStatusCode;
	}

	public String getPoStatus() {
		return poStatus;
	}

	public void setPoStatus(String poStatus) {
		this.poStatus = poStatus;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getPoCreatedDate() {
		return poCreatedDate;
	}

	public void setPoCreatedDate(String poCreatedDate) {
		this.poCreatedDate = poCreatedDate;
	}

	public String getProposalGenId() {
		return proposalGenId;
	}

	public void setProposalGenId(String proposalGenId) {
		this.proposalGenId = proposalGenId;
	}

	public Integer getProposalId() {
		return proposalId;
	}

	public void setProposalId(Integer proposalId) {
		this.proposalId = proposalId;
	}

	public String getTenderNo() {
		return tenderNo;
	}

	public void setTenderNo(String tenderNo) {
		this.tenderNo = tenderNo;
	}

	public String getShowDrfButton() {
		return showDrfButton;
	}

	public void setShowDrfButton(String showDrfButton) {
		this.showDrfButton = showDrfButton;
	}

	public Integer getOppDetailsId() {
		return oppDetailsId;
	}

	public void setOppDetailsId(Integer oppDetailsId) {
		this.oppDetailsId = oppDetailsId;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getVal() {
		return val;
	}

	public void setVal(String val) {
		this.val = val;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Opportunity getOpportunity() {
		return opportunity;
	}

	public void setOpportunity(Opportunity opportunity) {
		this.opportunity = opportunity;
	}

	@Override
	public String toString() {
		return "OppDetails [oppDetailsId=" + oppDetailsId + ", opportunityId=" + opportunityId + ", val=" + val
				+ ", content=" + content + ", opportunity=" + opportunity + ", showDrfButton=" + showDrfButton
				+ ", proposalGenId=" + proposalGenId + ", tenderNo=" + tenderNo + ", proposalId=" + proposalId
				+ ", poCreatedDate=" + poCreatedDate + ", poNumber=" + poNumber + ", poStatusCode=" + poStatusCode
				+ ", poStatus=" + poStatus + ", poDate=" + poDate + ", zohoId=" + zohoId + ", smownerId=" + smownerId
				+ "]";
	}
	
}
