/**
 * 
 */
package com.nelco.o2c.dto;

import java.util.List;

import org.springframework.stereotype.Component;

import com.nelco.o2c.model.BWSizingDetails;
import com.nelco.o2c.model.CityMst;
import com.nelco.o2c.model.CountryMst;
import com.nelco.o2c.model.CustomerMst;
import com.nelco.o2c.model.ErrorJobLog;
import com.nelco.o2c.model.LocationMst;
import com.nelco.o2c.model.StateMst;

/**
 * @author Jayashankar.r
 *
 */
@Component
public class BwSizingDTO {
	private Integer drfDetailsId;
	private List<CustomerMst> customerList;
	private BWSizingDetails bWSizingDetails = new BWSizingDetails();
	private List<CityMst> cityMst;
	private List<StateMst> stateMst;
	private List<CountryMst> countryMst;
	private List<LocationMst> locationMst;
	private Boolean submitFlag;
	private Integer bwSizingDetailsId;
	private String currDate;
	private List<ErrorJobLog> errorLogs;
	
	public List<ErrorJobLog> getErrorLogs() {
		return errorLogs;
	}

	public void setErrorLogs(List<ErrorJobLog> errorLogs) {
		this.errorLogs = errorLogs;
	}

	public String getCurrDate() {
		return currDate;
	}

	public void setCurrDate(String currDate) {
		this.currDate = currDate;
	}

	public Integer getBwSizingDetailsId() {
		return bwSizingDetailsId;
	}

	public void setBwSizingDetailsId(Integer bwSizingDetailsId) {
		this.bwSizingDetailsId = bwSizingDetailsId;
	}

	public Boolean getSubmitFlag() {
		return submitFlag;
	}

	public void setSubmitFlag(Boolean submitFlag) {
		this.submitFlag = submitFlag;
	}

	public List<CityMst> getCityMst() {
		return cityMst;
	}

	public void setCityMst(List<CityMst> cityMst) {
		this.cityMst = cityMst;
	}

	public List<StateMst> getStateMst() {
		return stateMst;
	}

	public void setStateMst(List<StateMst> stateMst) {
		this.stateMst = stateMst;
	}

	public List<CountryMst> getCountryMst() {
		return countryMst;
	}

	public void setCountryMst(List<CountryMst> countryMst) {
		this.countryMst = countryMst;
	}

	public List<LocationMst> getLocationMst() {
		return locationMst;
	}

	public void setLocationMst(List<LocationMst> locationMst) {
		this.locationMst = locationMst;
	}

	public BWSizingDetails getbWSizingDetails() {
		return bWSizingDetails;
	}

	public void setbWSizingDetails(BWSizingDetails bWSizingDetails) {
		this.bWSizingDetails = bWSizingDetails;
	}

	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}

	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}

	public List<CustomerMst> getCustomerList() {
		return customerList;
	}

	public void setCustomerList(List<CustomerMst> customerList) {
		this.customerList = customerList;
	}

}
