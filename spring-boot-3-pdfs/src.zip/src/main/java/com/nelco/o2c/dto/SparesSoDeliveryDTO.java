/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.SparesSoDelivery;

/**
 * @author Jayshankar.r
 *
 */
public class SparesSoDeliveryDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Integer userMstId;
	private String roleCode;
	private String fromDate;
	private String toDate;
	private Integer sparesSoDeliveryId;
	private List<SparesSoDelivery> sparesSoDeliveryList;
	private Integer deliveryStatusMstId;
	private String isNext="Y";
	private String selectedStatus;
	private Boolean isSaved = false;
	

	public Boolean getIsSaved() {
		return isSaved;
	}
	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}
	public String getSelectedStatus() {
		return selectedStatus;
	}
	public void setSelectedStatus(String selectedStatus) {
		this.selectedStatus = selectedStatus;
	}
	public String getIsNext() {
		return isNext;
	}
	public void setIsNext(String isNext) {
		this.isNext = isNext;
	}
	public Integer getDeliveryStatusMstId() {
		return deliveryStatusMstId;
	}
	public void setDeliveryStatusMstId(Integer deliveryStatusMstId) {
		this.deliveryStatusMstId = deliveryStatusMstId;
	}
	public List<SparesSoDelivery> getSparesSoDeliveryList() {
		return sparesSoDeliveryList;
	}
	public void setSparesSoDeliveryList(List<SparesSoDelivery> sparesSoDeliveryList) {
		this.sparesSoDeliveryList = sparesSoDeliveryList;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public Integer getSparesSoDeliveryId() {
		return sparesSoDeliveryId;
	}
	public void setSparesSoDeliveryId(Integer sparesSoDeliveryId) {
		this.sparesSoDeliveryId = sparesSoDeliveryId;
	}
	
	

}
