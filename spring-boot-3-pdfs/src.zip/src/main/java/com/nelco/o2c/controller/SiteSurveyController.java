package com.nelco.o2c.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.nelco.o2c.dto.ResponseDTO;
import com.nelco.o2c.dto.SiteSurveyDTO;
import com.nelco.o2c.dto.SiteSurveyEngineerDTO;
import com.nelco.o2c.dto.SiteSurveyFormDTO;
import com.nelco.o2c.dto.SiteSurveyListDTO;
import com.nelco.o2c.dto.UpdateFranchiseDTO;
import com.nelco.o2c.model.FranchiseeMaster;
import com.nelco.o2c.model.SiteSurveyEngineerMst;
import com.nelco.o2c.model.SiteSurveyMaster;
import com.nelco.o2c.service.SiteSurveyService;

@RestController
public class SiteSurveyController {
	@Autowired
	SiteSurveyService siteSurveyService;
	
	@RequestMapping(value = "/getSiteSurveyFormJson.do", method = RequestMethod.GET)
	public SiteSurveyFormDTO getSoDetailsBySoNumber() {
		
		SiteSurveyFormDTO siteSurveyFormDTO = new SiteSurveyFormDTO();
		siteSurveyService.getSiteSurveyFormMasters(siteSurveyFormDTO);
		
		return siteSurveyFormDTO;
	}
	
	@RequestMapping(value = "/getListCustomerAutoComplete.do", method = RequestMethod.GET)
	public SiteSurveyDTO getListCustomerAutoComplete(HttpServletRequest request) {
		SiteSurveyDTO siteSurveyDTO = new SiteSurveyDTO();
		siteSurveyDTO.setCustList(siteSurveyService.getListCustomerAutoComplete(request));
		return siteSurveyDTO;
	}
	
	@RequestMapping(value = "/saveSiteSurvey.do", method = RequestMethod.POST)
	public SiteSurveyMaster saveSiteSurvey(@RequestBody SiteSurveyDTO siteSurveyDTO) {
		return siteSurveyService.saveSiteSurveyDTO(siteSurveyDTO);
	}
	
	@RequestMapping(value = "/submitSiteSurvey.do", method = RequestMethod.POST)
	public SiteSurveyMaster submitSiteSurvey(@RequestBody SiteSurveyDTO siteSurveyDTO) {
		return siteSurveyService.submitSiteSurveyDTO(siteSurveyDTO);
	}
	
	@RequestMapping(value = "/getSiteSurveyById.do", method = RequestMethod.GET)
	public SiteSurveyMaster getSiteSurveyById(HttpServletRequest request) {
		return siteSurveyService.getSiteSurveyById(request);
	}
	
	@RequestMapping(value = "/getFranchiseeList.do", method = RequestMethod.GET)
	public List<FranchiseeMaster> getFranchiseeList() {
		return siteSurveyService.getFranchiseeList();
	}
	//This is FOR PM after raising request.
		@RequestMapping(value = "/getSitSurveyListCSByUser.do", method = RequestMethod.GET)
		public List<SiteSurveyListDTO> getSitSurveyListCSByUser(HttpServletRequest request) {
			return siteSurveyService.getSitSurveyListByUser(request);
	}
	//This is For CS for Allocating Franchisee
	@RequestMapping(value = "/getSitSurveyListCS.do", method = RequestMethod.GET)
	public List<SiteSurveyListDTO> getSitSurveyListCS(HttpServletRequest request) {
		return siteSurveyService.getSiteSurveyListCS(request);
	}
	//This is for updating franchisee
		@RequestMapping(value = "/updateFranchisee.do", method = RequestMethod.POST)
		public SiteSurveyMaster updateFranchisee(@RequestBody UpdateFranchiseDTO input) {
			return siteSurveyService.updateFranchisee(input);
		}
	
	//This is for franchisee co-ordinator for getting list for engineer assigmment
	@RequestMapping(value = "/getSitSurveyListForFranchisee.do", method = RequestMethod.GET)
	public List<SiteSurveyListDTO> getSitSurveyListForFranchisee(HttpServletRequest request) {
		return siteSurveyService.getSitSurveyListForFranchisee(request);
	}	
	//This is for Saving Engineer For Franchisee Co-ordinator
	@RequestMapping(value = "/saveSiteSurveyEngineer.do", method = RequestMethod.POST)
	public SiteSurveyEngineerMst saveSiteSurveyEngineer(@RequestBody SiteSurveyEngineerDTO siteSurveyEngineerDTO) {
		return siteSurveyService.saveSiteSurveyEngineer(siteSurveyEngineerDTO);
	}
	//This is for getting engineer by site survey id and franchisee
	@RequestMapping(value = "/getEngineerById.do", method = RequestMethod.GET)
	public SiteSurveyEngineerMst getEngineerById(HttpServletRequest request) {
		return siteSurveyService.getEngineerById(request);
	}
	//This is for getting engineer list by site survey id and franchisee
		@RequestMapping(value = "/getEngineerListBySiteIdFrachiseeId.do", method = RequestMethod.GET)
		public List<SiteSurveyEngineerMst> getEngineerListBySiteIdFrachiseeId(HttpServletRequest request) {
			return siteSurveyService.getEngineerListBySiteIdFrachiseeId(request);
	}
	//This is for uploading of site survey request from PMGT login
	@RequestMapping(value = "/uploadSiteSurveyRequest.do", method = RequestMethod.POST)
	public ResponseDTO uploadSiteSurveyRequest(MultipartHttpServletRequest request,@RequestParam String userId) throws Exception {
		ResponseDTO responseDTO=new ResponseDTO();		
		MultipartFile file = request.getFile("theFile");
		if(siteSurveyService.validateFile(file, userId,responseDTO)){
			siteSurveyService.uploadFile(file, userId);
			responseDTO.setStatus("Success");
		}else{
			return responseDTO;
		}
		return responseDTO;		
	}
	
	@RequestMapping(value = "/getSiteSurveyByUniqId.do", method = RequestMethod.GET)
	public SiteSurveyMaster getSiteSurveyByUniqId(HttpServletRequest request) {
		SiteSurveyDTO siteSurveyDTO = new SiteSurveyDTO();
		siteSurveyDTO.setUniq_id(request.getParameter("uniq_id"));
		return siteSurveyService.getSiteSurveyByUniqId(siteSurveyDTO);
	}
	
}
