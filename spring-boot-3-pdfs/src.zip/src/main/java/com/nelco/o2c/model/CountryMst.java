package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the country_mst database table.
 * 
 */
@Entity
@Table(name="country_mst")
@NamedQuery(name="CountryMst.findAll", query="SELECT c FROM CountryMst c")
public class CountryMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="country_mst_id")
	private Integer countryMstId;

	@Column(name="country_code")
	private String countryCode;

	@Column(name="country_val")
	private String countryVal;

	public Integer getCountryMstId() {
		return countryMstId;
	}

	public void setCountryMstId(Integer countryMstId) {
		this.countryMstId = countryMstId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCountryVal() {
		return countryVal;
	}

	public void setCountryVal(String countryVal) {
		this.countryVal = countryVal;
	}
}