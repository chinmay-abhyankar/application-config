package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.utility.DateUtil;

/**
 * The persistent class for the brf_status_tracker database table.
 * 
 */
@Entity
@Table(name = "brf_status_tracker")
		@NamedQueries({ @NamedQuery(name = "BrfStatusTracker.findAll", query = "SELECT b FROM BrfStatusTracker b"),
		@NamedQuery(name = "BrfStatusTracker.checkBrfRejectStatus", query = "select bst from BrfStatusTracker bst where bst.brfId =?1  and bst.statusMstId=22"),
		@NamedQuery(name="BrfStatusTracker.findByBrfReqById", query="SELECT b FROM BrfStatusTracker b where b.brfId=?1 ORDER BY b.createdDate DESC "),
		@NamedQuery(name="BrfStatusTracker.getBrfStatusTrackByBrfId", query= "select new BrfStatusTracker( bst.brfId, bst.reqBy, u.userName, "
				+ " bst.apprReason, bst.statusMstId, sm.statusName, bst.createdDate) "
				+ "from BrfStatusTracker bst inner join UserMst u on bst.reqBy = u.userMstId inner join StatusMst sm on bst.statusMstId=sm.statusMstId where bst.brfId=?1 and sm.statusMstId in(19,20,21,22)")})
public class BrfStatusTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "brf_status_tracker_id")
	private Integer brfStatusTrackerId;

	@Column(name = "brf_id")
	private Integer brfId;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "req_by")
	private Integer reqBy;

	@Column(name = "status_mst_id")
	private Integer statusMstId;
	
	@Column(name = "appr_flg")
	private String apprFlg;
	
	@Column(name = "appr_reason")
	private String apprReason;
	
	@Transient
	private String approverName;
	
	@Transient
	private String statusName;
	
	public BrfStatusTracker() {
	}
	
	public BrfStatusTracker(Integer brfId, Integer reqBy,String approverName,String apprReason, Integer statusMstId, String statusName, String createdDate) {
		super();
		this.brfId = brfId;
		this.reqBy = reqBy;
		this.approverName = approverName;
		this.apprReason = apprReason;
		this.statusMstId = statusMstId;
		this.statusName = statusName;
		this.createdDate = createdDate;
	}

	public Integer getBrfStatusTrackerId() {
		return brfStatusTrackerId;
	}

	public void setBrfStatusTrackerId(Integer brfStatusTrackerId) {
		this.brfStatusTrackerId = brfStatusTrackerId;
	}

	public Integer getBrfId() {
		return brfId;
	}

	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}

	public String getCreatedDate() {
//		return createdDate;
		return DateUtil.convertDateTimeToString(this.createdDate);
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getReqBy() {
		return reqBy;
	}

	public void setReqBy(Integer reqBy) {
		this.reqBy = reqBy;
	}

	public Integer getStatusMstId() {
		return statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}

	public String getApprFlg() {
		return apprFlg;
	}

	public void setApprFlg(String apprFlg) {
		this.apprFlg = apprFlg;
	}

	public String getApprReason() {
		return apprReason;
	}

	public void setApprReason(String apprReason) {
		this.apprReason = apprReason;
	}

	public String getApproverName() {
		return approverName;
	}

	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	
}