/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.OldSoDTO;
import com.nelco.o2c.model.ChildContract;
import com.nelco.o2c.model.ContractCsvTemp;
import com.nelco.o2c.model.NewOppDetails;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.Opportunity;
import com.nelco.o2c.model.Proposal;
import com.nelco.o2c.model.UserMst;

/**
 * @author Jayashankar.r
 *
 */
public interface SchedulerDao {
	public Opportunity getExistingOpportunity(String zohoId);
	public Opportunity insertOpportunity(Opportunity insertObj);
	public OppDetails getExistingOppDet(String val,Opportunity oppObj);
	public void insertUpdateOppDet(OppDetails oppDetails);
	public Proposal getExistingProposalByOpportunity(Integer opportunityId);
	public void saveProposal(Proposal existingProposal);
	public Integer getMaxProposalnumber();
	public UserMst getHeadBySubDeptId(Integer subDeptId);
	public UserMst getHeadByDeptId(Integer deptId);
	public List<ContractCsvTemp> getContractCsvBeans(Integer childContractId);
	public void deleteTempContractTable(Integer childContractId);
	public List<ChildContract> getChilContracts();
	public void saveFileName(Integer childContractId, String fileNameFinal);
	public void updateSentFileFlag(List<OldSoDTO> oldSoList);
	public OppDetails getOppDetByOppIdAndVal(Integer opportunityId, String val);
	public NewOppDetails saveNewOppDetails(NewOppDetails newOppDetails);
	public NewOppDetails getNewOppDetailsByZohoId(String zohoId);
	public List<OppDetails> getNewOppDetailsListByIds(String newOppDetailsIds);
	
	/*
	public NewOpportunity insertNewOpportunity(NewOpportunity insertObj);
	public NewOpportunity getExistingNewOpportunity(String zohoId);
	public NewProposal getExistingNewProposalByOpportunity(Integer opportunityId);
	void saveNewProposal(NewProposal existingProposal);
	public Integer getMaxNewProposalnumber();
	public CopyOppDetail getCopyOppDetByOppIdAndVal(Integer opportunityId, String val);
	*/
	
}
