/**
 * 
 */
package com.nelco.o2c.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.nelco.o2c.utility.GenJasperReportUtility;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;

/**
 * @author Jayashankar.r
 *
 */
@Controller
public class DownloadReportsController {
	
	@Autowired
	DataSource ds;
	
	@RequestMapping(value = "/downloadTafPdf.do", method = RequestMethod.GET)
	public String generatePOReport(HttpServletRequest request, HttpServletResponse response,@RequestParam String oppId)
	    throws ParseException, SQLException, JRException, NamingException, IOException {
	
	Connection conn = ds.getConnection();

	String reportFileName = "TenderAssmntFmtReport";

	// Parameters as Map to be passed to Jasper reports
	Map<String, Object> parameter = new HashMap<String, Object>();	

	parameter.put("opp_id", oppId);
	JasperReport jasperReport = GenJasperReportUtility.getCompiledFile(reportFileName, request);
	GenJasperReportUtility.generateReportPDF(response, parameter, jasperReport, conn); // For
	conn.close();

	return null;

	}
	
	@RequestMapping(value = "/downloadExcel.do", method = RequestMethod.GET)
	public String generateExcelReport(HttpServletRequest request, HttpServletResponse resp,@RequestParam String status_mst_id)
	    throws ParseException, SQLException, JRException, NamingException, IOException {
	
	Connection conn = ds.getConnection();

	String reportFileName = "Excel_Report";

	// Parameters as Map to be passed to Jasper reports
	Map<String, Object> parameter = new HashMap<String, Object>();	

	parameter.put("status_mst_id", status_mst_id);
	JasperReport jasperReport = GenJasperReportUtility.getCompiledFile(reportFileName, request);
	GenJasperReportUtility.generateReportXLS(resp, parameter, jasperReport, conn); // For
	conn.close();

	return null;

	}

}
