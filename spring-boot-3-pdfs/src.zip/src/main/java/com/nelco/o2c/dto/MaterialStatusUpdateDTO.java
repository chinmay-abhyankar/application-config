package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

public class MaterialStatusUpdateDTO {
	private List<SalesDTO> list = new ArrayList();

	public List<SalesDTO> getList() {
		return list;
	}

	public void setList(List<SalesDTO> list) {
		this.list = list;
	}

	

	

}
