package com.nelco.o2c.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.InvoiceDTO;
import com.nelco.o2c.dto.MaterialDetailsDTO;
import com.nelco.o2c.dto.MaterialStatusUpdateDTO;
import com.nelco.o2c.dto.SalesDTO;
import com.nelco.o2c.dto.SalesReturnDTO;
import com.nelco.o2c.dto.SalesReturnFormDTO;
import com.nelco.o2c.dto.SalesReturnListDTO;
import com.nelco.o2c.dto.SalesReturnSaveDTO;
import com.nelco.o2c.jsonbeanmap.EmailBean;
import com.nelco.o2c.model.CreditNoteBwMst;
import com.nelco.o2c.model.CreditNoteEquipMst;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.SalesReturnMst;
import com.nelco.o2c.service.TenderTafService;
import com.nelco.o2c.utility.DateUtil;
import com.nelco.o2c.utility.SDCommonUtil;

@Repository
public class SalesReturnDaoImpl implements SalesReturnDao {
	@PersistenceContext
	private EntityManager em;
	@Autowired
	SparesSoDao sparesSoDao;
	@Autowired
	CallSpDao callSpDao;
	Query query;
	StoredProcedureQuery spQuery;
	@Autowired
	private Environment env;
	@Autowired
	private TenderTafService tenderTafService;
	
	@Override
	public SalesReturnDTO getSalesReturnMasters(SalesReturnDTO salesReturnDTO) {
		try {
			query = em.createNamedQuery("HubMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<HubMst> hubMst = query.getResultList();
			salesReturnDTO.setHubMst(hubMst != null ? hubMst : new ArrayList<HubMst>());			
			List<String> fileCodeList = new ArrayList<String>();
			fileCodeList.add("MDEM");				
			salesReturnDTO.setFileList(sparesSoDao.getFileListByCode(fileCodeList));
			
		} finally {
			em.close();
		}
		return salesReturnDTO;
	}

	@Override
	public List<InvoiceDTO> getListInvoiceAutoComplete(HttpServletRequest request) {
		List<InvoiceDTO> lst = new ArrayList<InvoiceDTO>();
		InvoiceDTO bean = null;
		String lQuery = "SELECT distinct "
				+ " invoice_num,billing_type,equip_so_num as so_num,cast(i.inv_creation_date as date) as invoice_date"
				+ " ,c.customer_num,c.customer_name,c.customer_sapmst_id as customer_id,so.ship_to_party"
				+",p.plant_code,p.plant_name"
				+ " FROM tax_inv_so_sapmst i inner join so_orders so on i.equip_so_num=so.so_number"
				+ " inner join customer_sapmst c on so.sold_to_party=c.customer_num and so.dist_channel=c.dist_channel"
				+ " and so.division=c.division and so.sales_org=c.sales_org"
				+" inner join plant_sapmst p on so.plant=p.plant_code"
				+ " where i.invoice_num like '%"
				+ request.getParameter("input") + "%'"
				+" and billing_type='ZPRI'";				
		query = em.createNativeQuery(lQuery);
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			bean = new InvoiceDTO();
			bean.setInvoiceNumber(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setBillingType(SDCommonUtil.convertNullToBlank(String.valueOf(o[1]), false));
			bean.setSoNumber(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
			bean.setInvoiceDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
			bean.setCustomerNumber(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
			bean.setCustomerName(SDCommonUtil.convertNullToBlank(String.valueOf(o[5]), false));
			bean.setCustomerId(SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false));
			bean.setShipToPartyCode(SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false));
			bean.setPlantCode(SDCommonUtil.convertNullToBlank(String.valueOf(o[8]), false));
			bean.setPlantName(SDCommonUtil.convertNullToBlank(String.valueOf(o[9]), false));
			lst.add(bean);
		}
		return lst;
	}

	@Override
	public List<InvoiceDTO> getListInvoiceBWAutoComplete(HttpServletRequest request) {
		List<InvoiceDTO> lst = new ArrayList<InvoiceDTO>();
		InvoiceDTO bean = null;
		String lQuery = "SELECT distinct "
				+ " invoice_num,billing_type,equip_so_num as so_num,cast(i.inv_creation_date as date) as invoice_date"
				+ " ,c.customer_num,c.customer_name,c.customer_sapmst_id as customer_id,so.ship_to_party"
				+ " FROM tax_inv_so_sapmst i inner join so_orders so on i.equip_so_num=so.so_number"
				+ " inner join customer_sapmst c on so.sold_to_party=c.customer_num and so.dist_channel=c.dist_channel"
				+ " and so.division=c.division and so.sales_org=c.sales_org" + " where i.invoice_num like '%"
				+ request.getParameter("input") + "%'"
				+" and billing_type in('ZTAW','ZTPW')";
				
		query = em.createNativeQuery(lQuery);
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			bean = new InvoiceDTO();
			bean.setInvoiceNumber(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setBillingType(SDCommonUtil.convertNullToBlank(String.valueOf(o[1]), false));
			bean.setSoNumber(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
			bean.setInvoiceDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
			bean.setCustomerNumber(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
			bean.setCustomerName(SDCommonUtil.convertNullToBlank(String.valueOf(o[5]), false));
			bean.setCustomerId(SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false));
			bean.setShipToPartyCode(SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false));
			lst.add(bean);
		}
		return lst;
	}

	@Override
	public List<MaterialDetailsDTO> getMaterialDetailsAutoComplete(HttpServletRequest request) {
		List<MaterialDetailsDTO> lst = new ArrayList<MaterialDetailsDTO>();
		MaterialDetailsDTO bean = null;
		String lQuery = "SELECT m.material_num,m.material_desc,m.plant,m.sales_org,m.dist_channel"
				+ " FROM so_orders so  inner join material_sapmst m on so.material_num=m.material_num"
				+ " and so.plant=m.plant and so.sales_org=m.sales_org and so.dist_channel=m.dist_channel"
				+ " and so.so_number=:so_number";
		query = em.createNativeQuery(lQuery);
		query.setParameter("so_number", request.getParameter("so_number"));
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			bean = new MaterialDetailsDTO();
			bean.setMatnr(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setMaterialName(SDCommonUtil.convertNullToBlank(String.valueOf(o[1]), false));
			bean.setPlant(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
			bean.setSalesOrg(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
			bean.setDistChannel(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
			lst.add(bean);
		}
		return lst;
	}

	@Override
	public SalesReturnMst saveSalesReturn(SalesReturnFormDTO salesReturnFormDTO) {
		String uniq_id = "";
		SalesDTO salesDTO=salesReturnFormDTO.getSalesDTO();
		SalesReturnMst salesReturnMst = new SalesReturnMst();
		System.out.println("Id" + salesDTO.getId());
		if (salesDTO.getId() == null || salesDTO.getId().equals("")) {
			synchronized (this) {
				Integer maxProposalNumber = getCurrentDayCountSiteSurveyMaster();
				uniq_id = "SAL_RET_" + (DateUtil.getCurrentISTDateAsString(DateUtil.SIMPLE_DATE_FORMAT)
						.replace("-", "_").concat("_").concat(maxProposalNumber.toString()));
			}
			salesDTO.setUniqId(uniq_id);
		}
		if(salesDTO.getId()!=null){
			salesReturnMst.setId(salesDTO.getId());
		}		
		salesReturnMst.setUniqId(salesDTO.getUniqId());
		salesReturnMst.setCreditNoteNoBW(salesDTO.getCreditNoteNoBW());
		salesReturnMst.setCreditNoteNoEquipment(salesDTO.getCreditNoteNoEquipment());
		salesReturnMst.setCustomerId(salesDTO.getCustomerId());
		salesReturnMst.setDisconnectionDate(DateUtil.convertDateToSqlDate(salesDTO.getDisconnectionDate()));
		salesReturnMst.setDistChannel(salesDTO.getDistChannel());
		salesReturnMst.setMdApproved(salesDTO.getMdApproved());
		salesReturnMst.setHubId(salesDTO.getHubId());
		salesReturnMst.setInvoiceDate(salesDTO.getInvoiceDate());
		salesReturnMst.setInvoiceNoBW(salesDTO.getInvoiceNoBW());
		salesReturnMst.setInvoiceNoEquipment(salesDTO.getInvoiceNoEquipment());
		salesReturnMst.setMatnr(salesDTO.getMatnr());
		salesReturnMst.setMatnrReturnStatus(salesDTO.getMatnrReturnStatus());
		salesReturnMst.setNocRemarks(salesDTO.getNocRemarks());
		salesReturnMst.setPlant(salesDTO.getPlant());
		salesReturnMst.setReturnType(salesDTO.getReturnType());
		salesReturnMst.setSalesOrderNoBw(salesDTO.getSalesOrderNoBw());
		salesReturnMst.setSalesOrderNoEquipment(salesDTO.getSalesOrderNoEquipment());
		salesReturnMst.setSalesOrg(salesDTO.getSalesOrg());
		salesReturnMst.setCreated_user_id(salesDTO.getCreatedUserId());
		salesReturnMst.setCreation_date(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		salesReturnMst.setStatus(34);
		salesReturnMst = em.merge(salesReturnMst);
		List<OppUploadDetail> oppUploadDetails = salesReturnFormDTO.getOppUploadDetails();
		for (OppUploadDetail oppUploadDetail : oppUploadDetails) {
			oppUploadDetail.setSalesReturnId(salesReturnMst.getId());
			oppUploadDetail.setCreatedBy(salesDTO.getCreatedUserId() != null ? salesDTO.getCreatedUserId().toString() : null);
			try {
				tenderTafService.moveFiles(oppUploadDetail);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return salesReturnMst;
	}

	@Override
	public SalesReturnMst submitSalesReturn(SalesReturnFormDTO salesReturnFormDTO) {
		SalesReturnMst salesReturnMst_ = null;
		SalesDTO salesDTO=salesReturnFormDTO.getSalesDTO();
		try {
			query = em.createNamedQuery("SalesReturnMst.findById");
			query.setParameter(1, salesDTO.getId());
			salesReturnMst_ = (SalesReturnMst) query.getSingleResult();
		} catch (Exception e) {
			return new SalesReturnMst();
		} finally {
			em.close();
		}
		SalesReturnMst salesReturnMst = new SalesReturnMst();
		salesReturnMst.setId(salesDTO.getId());
		salesReturnMst.setUniqId(salesDTO.getUniqId());
		salesReturnMst.setCreditNoteNoBW(salesDTO.getCreditNoteNoBW());
		salesReturnMst.setCreditNoteNoEquipment(salesDTO.getCreditNoteNoEquipment());
		salesReturnMst.setDisconnectionDate(DateUtil.convertDateToSqlDate(salesDTO.getDisconnectionDate()));
		salesReturnMst.setCustomerId(salesDTO.getCustomerId());
		salesReturnMst.setDistChannel(salesDTO.getDistChannel());
		salesReturnMst.setHubId(salesDTO.getHubId());
		salesReturnMst.setMdApproved(salesDTO.getMdApproved());
		salesReturnMst.setInvoiceNoBW(salesDTO.getInvoiceNoBW());
		salesReturnMst.setInvoiceDate(salesDTO.getInvoiceDate());
		salesReturnMst.setInvoiceNoEquipment(salesDTO.getInvoiceNoEquipment());
		salesReturnMst.setMatnr(salesDTO.getMatnr());
		salesReturnMst.setMatnrReturnStatus(salesDTO.getMatnrReturnStatus());
		salesReturnMst.setNocRemarks(salesDTO.getNocRemarks());
		salesReturnMst.setPlant(salesDTO.getPlant());
		salesReturnMst.setReturnType(salesDTO.getReturnType());
		salesReturnMst.setSalesOrderNoBw(salesDTO.getSalesOrderNoBw());
		salesReturnMst.setSalesOrderNoEquipment(salesDTO.getSalesOrderNoEquipment());
		salesReturnMst.setSalesOrg(salesDTO.getSalesOrg());
		salesReturnMst.setCreated_user_id(salesDTO.getCreatedUserId());
		salesReturnMst.setCreation_date(salesReturnMst_.getCreation_date());
		if (salesReturnMst.getReturnType().equals("Installed")) {
			salesReturnMst.setStatus(46);
		}else{
			//salesReturnMst.setStatus(47);
			salesReturnMst.setStatus(48);
		}		
		salesReturnMst = em.merge(salesReturnMst);
		if (salesReturnMst.getReturnType().equals("Installed")) {
			// send email to NOC
			EmailBean emailBean = new EmailBean();
			emailBean.setToMail(this.getToEmailId(salesReturnMst.getId(), "NOC_PM"));	
			emailBean.setSubject("Sales Return Request Raised For Id : " + salesReturnMst.getUniqId());
			emailBean.setEmailBody(this.setEmailBody(salesReturnMst.getId(), "NOC_PM"));
			callSpDao.sendEmail(emailBean);
			String lQuery = "update sales_return_mst set noc_pm_email_sent='Y'"
					+" where id=:id";			
			query = em.createNativeQuery(lQuery);			
			query.setParameter("id", salesDTO.getId());
			query.executeUpdate();
		} else {
			// send email stores team
			EmailBean emailBean = new EmailBean();
			//emailBean.setToMail(this.getToEmailId(salesReturnMst.getId(), "FIN_PM"));	
			System.out.println("Email Id"+this.getStoresToEmailId(salesReturnMst.getId(), "STORES"));
			emailBean.setToMail(this.getStoresToEmailId(salesReturnMst.getId(), "STORES"));
			emailBean.setSubject("Sales Return Request Raised For Id : " + salesReturnMst.getUniqId());
			emailBean.setEmailBody(this.setEmailBody(salesReturnMst.getId(), "FIN_PM"));
			callSpDao.sendEmail(emailBean);
			//String lQuery = "update sales_return_mst set finance_email_sent='Y'"
				//	+" where id=:id";	
			String lQuery = "update sales_return_mst set stores_email_sent='Y'"
				+" where id=:id";	  	
			query = em.createNativeQuery(lQuery);			
			query.setParameter("id", salesDTO.getId());
			query.executeUpdate();
		}

		return salesReturnMst;
	}

	@Override
	public Integer getCurrentDayCountSiteSurveyMaster() {
		Integer maxNumber;
		try {
			query = em.createNativeQuery("select count(*)+1 from sales_return_mst "
					+ " s where cast(s.creation_date as date) =cast(getdate() as date)");
			Object result =  (Object) query.getSingleResult();
			maxNumber=(Integer)result;

			return maxNumber.intValue();
		} finally {
			em.close();
		}
	}

	@Override
	public SalesReturnSaveDTO getSalesReturnRequestById(HttpServletRequest request) {
		try {
			SalesReturnSaveDTO salesReturnSaveDTO=new SalesReturnSaveDTO();
			query = em.createNamedQuery("SalesReturnMst.findById");
			query.setParameter(1, Integer.parseInt(request.getParameter("id")));
			SalesReturnMst salesReturnMst = (SalesReturnMst) query.getSingleResult();
			query = em.createNamedQuery("OppUploadDetail.findBySalesReturnId");
			query.setParameter(1, Integer.parseInt(request.getParameter("id")));
			List<OppUploadDetail> upList = (List<OppUploadDetail>) query.getResultList();
			System.out.println("Id****************"+salesReturnMst.getId());
			salesReturnSaveDTO.setOppUploadDetails(upList);
			salesReturnSaveDTO.setSalesReturnMst(salesReturnMst);
			return salesReturnSaveDTO;
		} catch (Exception e) {
			e.printStackTrace();
			return new SalesReturnSaveDTO();
		} finally {
			em.close();
		}
	}

	@Override
	public List<SalesReturnListDTO> getSalesReturnRequestForSalesTeam(HttpServletRequest request) {
		List<SalesReturnListDTO> lst = new ArrayList<SalesReturnListDTO>();
		SalesReturnListDTO bean = null;
		String lQuery = "SELECT sr.id as request_id,sr.invoice_no_equipment,sr.invoice_no_bw,c.customer_num,c.customer_name"
				+ ",sr.sales_order_no_bw,sr.sales_order_no_equipment,m.material_num,m.material_desc,sr.md_approved"
				+ ",sr.return_type,cne.credit_note_no as credit_note_no_equipment,cnbw.bandwidth_cr_no as credit_note_no_bw"
				+ ",convert(varchar,disconnection_date, 105) as disconnection_date,sr.status,s.status_name"
				+ ",sr.uniq_id" + ",cne.amount as equipment_credit_note_amount,"
				+ "convert(varchar,cne.creation_date, 105) as equipment_credit_date"
				+",cnbw.amount,convert(varchar,cnbw.doc_date, 105) as doc_date_credit_note_bw"
				+",convert(varchar,cnbw.posting_date, 105) as posting_date_credit_note_bw"
				+",sr.consumption_no"
				+ " FROM  sales_return_mst"
				+ " sr left outer join so_orders so on sr.sales_order_no_equipment=so.so_number and so.material_num=sr.matnr"
				+ " left outer join credit_note_equip_mst cne on sr.invoice_no_equipment=cne.cancelled_invoice_no"
				+ " left outer join credit_note_bw_mst cnbw on sr.invoice_no_bw=cnbw.assignment"
				+ " inner join customer_sapmst c on sr.customer_id=c.customer_sapmst_id"
				+ " inner join material_sapmst m on sr.matnr=m.material_num and sr.dist_channel=m.dist_channel"
				+ " and sr.sales_org=m.sales_org and sr.plant=m.plant"
				+ " left outer join hub_mst h on sr.hub_id=h.hub_mst_id"
				+ " inner join status_mst s on sr.status=s.status_mst_id"
				+" order by sr.creation_date desc";
		int flag = 0;
		query = em.createNativeQuery(lQuery);
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			flag++;
			bean = new SalesReturnListDTO();
			bean.setId(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setInvoiceNoEquipment(SDCommonUtil.convertNullToBlank(String.valueOf(o[1]), false));
			bean.setInvoiceNoBW(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
			bean.setCustomerNum(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
			bean.setCustomerName(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
			bean.setSalesOrderNoBW(SDCommonUtil.convertNullToBlank(String.valueOf(o[5]), false));
			bean.setSalesOrderNoEquipment(SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false));
			bean.setMaterialNum(SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false));
			bean.setMaterialDesc(SDCommonUtil.convertNullToBlank(String.valueOf(o[8]), false));
			bean.setMdApproved(SDCommonUtil.convertNullToBlank(String.valueOf(o[9]), false));
			bean.setReturnType(SDCommonUtil.convertNullToBlank(String.valueOf(o[10]), false));
			bean.setCreditNoteNoEquipment(SDCommonUtil.convertNullToBlank(String.valueOf(o[11]), false));
			bean.setCreditNoteNoBW(SDCommonUtil.convertNullToBlank(String.valueOf(o[12]), false));
			bean.setDisconnectionDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[13]), false));
			bean.setStatus(SDCommonUtil.convertNullToBlank(String.valueOf(o[14]), false));
			bean.setStatusName(SDCommonUtil.convertNullToBlank(String.valueOf(o[15]), false));
			bean.setUniqId(SDCommonUtil.convertNullToBlank(String.valueOf(o[16]), false));
			bean.setEquipmentCreditNoteAmount(SDCommonUtil.convertNullToBlank(String.valueOf(o[17]), false));
			bean.setEquipmentCreditNoteDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[18]), false));
			bean.setBwCreditAmount(SDCommonUtil.convertNullToBlank(String.valueOf(o[19]), false));
			bean.setBwCreditNoteDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[20]), false));
			bean.setBwCreditPostingDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[21]), false));
			bean.setConsumtionNo(SDCommonUtil.convertNullToBlank(String.valueOf(o[22]), false));
			lst.add(bean);
		}
		if (flag > 0) {
			return lst;
		} else {
			lst.add(new SalesReturnListDTO());
			return lst;
		}
	}

	@Override
	public List<SalesReturnListDTO> getSalesReturnRequestForNOCTeam(HttpServletRequest request) {
		List<SalesReturnListDTO> lst = new ArrayList<SalesReturnListDTO>();
		SalesReturnListDTO bean = null;
		String lQuery = "SELECT sr.id as request_id,sr.invoice_no_equipment,sr.invoice_no_bw,c.customer_num,c.customer_name"
				+ ",sr.sales_order_no_bw,sr.sales_order_no_equipment,m.material_num,m.material_desc,sr.md_approved"
				+ ",sr.return_type,cne.credit_note_no as credit_note_no_equipment,cnbw.bandwidth_cr_no as credit_note_no_bw"
				+ ",convert(varchar,disconnection_date, 105) as disconnection_date,sr.status,s.status_name"
				+ ",sr.uniq_id" + ",cne.amount as equipment_credit_note_amount,"
				+ "convert(varchar,cne.creation_date, 105) as equipment_credit_date"
				+",cnbw.amount,convert(varchar,cnbw.doc_date, 105) as doc_date_credit_note_bw"
				+",convert(varchar,cnbw.posting_date, 105) as posting_date_credit_note_bw"
				+",sr.consumption_no"
				+ "" + " FROM  sales_return_mst"
				+ " sr left outer join so_orders so on sr.sales_order_no_equipment=so.so_number and so.material_num=sr.matnr"
				+ " left outer join credit_note_equip_mst cne on sr.invoice_no_equipment=cne.cancelled_invoice_no"
				+ " left outer join credit_note_bw_mst cnbw on sr.invoice_no_bw=cnbw.assignment"
				+ " inner join customer_sapmst c on sr.customer_id=c.customer_sapmst_id"
				+ " inner join material_sapmst m on sr.matnr=m.material_num and sr.dist_channel=m.dist_channel"
				+ " and sr.sales_org=m.sales_org and sr.plant=m.plant"
				+ " left outer join hub_mst h on sr.hub_id=h.hub_mst_id"
				+ " inner join status_mst s on sr.status=s.status_mst_id"
				+ " inner join user_to_hub uh on sr.hub_id=uh.hub_mst_id"
				+ " and uh.user_mst_id=:user_id where  sr.status !=34"
				+" order by sr.creation_date desc";
		int flag = 0;
		query = em.createNativeQuery(lQuery);
		query.setParameter("user_id", request.getParameter("user_id"));
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			flag++;
			bean = new SalesReturnListDTO();
			bean.setId(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setInvoiceNoEquipment(SDCommonUtil.convertNullToBlank(String.valueOf(o[1]), false));
			bean.setInvoiceNoBW(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
			bean.setCustomerNum(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
			bean.setCustomerName(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
			bean.setSalesOrderNoBW(SDCommonUtil.convertNullToBlank(String.valueOf(o[5]), false));
			bean.setSalesOrderNoEquipment(SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false));
			bean.setMaterialNum(SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false));
			bean.setMaterialDesc(SDCommonUtil.convertNullToBlank(String.valueOf(o[8]), false));
			bean.setMdApproved(SDCommonUtil.convertNullToBlank(String.valueOf(o[9]), false));
			bean.setReturnType(SDCommonUtil.convertNullToBlank(String.valueOf(o[10]), false));
			bean.setCreditNoteNoEquipment(SDCommonUtil.convertNullToBlank(String.valueOf(o[11]), false));
			bean.setCreditNoteNoBW(SDCommonUtil.convertNullToBlank(String.valueOf(o[12]), false));
			bean.setDisconnectionDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[13]), false));
			bean.setStatus(SDCommonUtil.convertNullToBlank(String.valueOf(o[14]), false));
			bean.setStatusName(SDCommonUtil.convertNullToBlank(String.valueOf(o[15]), false));
			bean.setUniqId(SDCommonUtil.convertNullToBlank(String.valueOf(o[16]), false));
			bean.setEquipmentCreditNoteAmount(SDCommonUtil.convertNullToBlank(String.valueOf(o[17]), false));
			bean.setEquipmentCreditNoteDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[18]), false));
			bean.setBwCreditAmount(SDCommonUtil.convertNullToBlank(String.valueOf(o[19]), false));
			bean.setBwCreditNoteDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[20]), false));
			bean.setBwCreditPostingDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[21]), false));
			bean.setConsumtionNo(SDCommonUtil.convertNullToBlank(String.valueOf(o[22]), false));
			lst.add(bean);
		}
		if (flag > 0) {
			return lst;
		} else {
			lst.add(new SalesReturnListDTO());
			return lst;
		}

	}

	@Override
	public SalesReturnMst updateNOCRwmarks(SalesReturnFormDTO salesReturnFormDTO) {
		try {
			SalesDTO salesDTO=salesReturnFormDTO.getSalesDTO();
			String lQuery = "update sales_return_mst set disconnection_date=:disc_date"
					+ " ,noc_remarks=:remarks,status=47 where id=:id";
			System.out.println(salesDTO.getId());
			query = em.createNativeQuery(lQuery);
			query.setParameter("disc_date",
					DateUtil.convertDateToSqlDate(salesDTO.getDisconnectionDate()) + " 23:59:58.999");
			query.setParameter("remarks", salesDTO.getNocRemarks());
			query.setParameter("id", salesDTO.getId());
			query.executeUpdate();
			query = em.createNamedQuery("SalesReturnMst.findById");
			query.setParameter(1, salesDTO.getId());
			SalesReturnMst salesReturnMst = (SalesReturnMst) query.getSingleResult();
			EmailBean emailBean = new EmailBean();
			emailBean.setToMail(this.getToEmailId(salesReturnMst.getId(), "FIN_PM"));	
			emailBean.setSubject("Sales Return Request Raised For Id : " + salesReturnMst.getId());
			emailBean.setEmailBody(this.setEmailBody(salesReturnMst.getId(), "FIN_PM"));
			callSpDao.sendEmail(emailBean);
			lQuery = "update sales_return_mst set finance_email_sent='Y'"
					+" where id=:id";			
			query = em.createNativeQuery(lQuery);			
			query.setParameter("id", salesDTO.getId());
			query.executeUpdate();
			return salesReturnMst;
		} catch (Exception e) {
			e.printStackTrace();
			return new SalesReturnMst();
		} finally {
			em.close();
		}
	}

	@Override
	public List<SalesReturnListDTO> getSalesReturnRequestForStoresTeam(HttpServletRequest request) {
		List<SalesReturnListDTO> lst = new ArrayList<SalesReturnListDTO>();
		try {

			SalesReturnListDTO bean = null;
			String lQuery = "SELECT sr.id as request_id,sr.invoice_no_equipment,sr.invoice_no_bw,c.customer_num,c.customer_name"
					+ ",sr.sales_order_no_bw,sr.sales_order_no_equipment,m.material_num,m.material_desc,sr.md_approved"
					+ ",sr.return_type,cne.credit_note_no as credit_note_no_equipment,cnbw.bandwidth_cr_no as credit_note_no_bw"
					+ ",convert(varchar,disconnection_date, 105) as disconnection_date,sr.status,s.status_name"
					+ ",cne.amount as equipment_credit_note_amount,"
					+ "convert(varchar,cne.creation_date, 105) as equipment_credit_date" + ",sr.uniq_id"
					+",cnbw.amount,convert(varchar,cnbw.doc_date, 105) as doc_date_credit_note_bw"
					+",convert(varchar,cnbw.posting_date, 105) as posting_date_credit_note_bw"
					+",sr.consumption_no"
					+ " FROM  sales_return_mst"
					+ " sr left outer join so_orders so on sr.sales_order_no_equipment=so.so_number and so.material_num=sr.matnr"
					+ " left outer join credit_note_equip_mst cne on sr.invoice_no_equipment=cne.cancelled_invoice_no"
					+ " left outer join credit_note_bw_mst cnbw on sr.invoice_no_bw=cnbw.assignment"
					+ " inner join customer_sapmst c on sr.customer_id=c.customer_sapmst_id"
					+ " inner join material_sapmst m on sr.matnr=m.material_num and sr.dist_channel=m.dist_channel"
					+ " and sr.sales_org=m.sales_org and sr.plant=m.plant"
					+ " left outer join hub_mst h on sr.hub_id=h.hub_mst_id"
					+ " inner join status_mst s on sr.status=s.status_mst_id"
					+ " where :user_id in (SELECT user_mst_id FROM user_mst where role_mst_id in(28,29,30))"
					+ " and sr.status !=34"
					+" order by sr.creation_date desc";
			int flag = 0;
			query = em.createNativeQuery(lQuery);
			query.setParameter("user_id", request.getParameter("user_id"));
			List<Object[]> objList = query.getResultList();
			for (Object[] o : objList) {
				flag++;
				bean = new SalesReturnListDTO();
				bean.setId(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
				bean.setInvoiceNoEquipment(SDCommonUtil.convertNullToBlank(String.valueOf(o[1]), false));
				bean.setInvoiceNoBW(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
				bean.setCustomerNum(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
				bean.setCustomerName(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
				bean.setSalesOrderNoBW(SDCommonUtil.convertNullToBlank(String.valueOf(o[5]), false));
				bean.setSalesOrderNoEquipment(SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false));
				bean.setMaterialNum(SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false));
				bean.setMaterialDesc(SDCommonUtil.convertNullToBlank(String.valueOf(o[8]), false));
				bean.setMdApproved(SDCommonUtil.convertNullToBlank(String.valueOf(o[9]), false));
				bean.setReturnType(SDCommonUtil.convertNullToBlank(String.valueOf(o[10]), false));
				bean.setCreditNoteNoEquipment(SDCommonUtil.convertNullToBlank(String.valueOf(o[11]), false));
				bean.setCreditNoteNoBW(SDCommonUtil.convertNullToBlank(String.valueOf(o[12]), false));
				bean.setDisconnectionDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[13]), false));
				bean.setStatus(SDCommonUtil.convertNullToBlank(String.valueOf(o[14]), false));
				bean.setStatusName(SDCommonUtil.convertNullToBlank(String.valueOf(o[15]), false));
				bean.setEquipmentCreditNoteAmount(SDCommonUtil.convertNullToBlank(String.valueOf(o[16]), false));
				bean.setEquipmentCreditNoteDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[17]), false));
				bean.setUniqId(SDCommonUtil.convertNullToBlank(String.valueOf(o[18]), false));
				bean.setBwCreditAmount(SDCommonUtil.convertNullToBlank(String.valueOf(o[19]), false));
				bean.setBwCreditNoteDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[20]), false));
				bean.setBwCreditPostingDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[21]), false));
				bean.setConsumtionNo(SDCommonUtil.convertNullToBlank(String.valueOf(o[22]), false));
				lst.add(bean);
			}
			if (flag > 0) {
				return lst;
			} else {
				lst.add(new SalesReturnListDTO());
				return lst;
			}
		} catch (Exception e) {
			e.printStackTrace();
			lst.add(new SalesReturnListDTO());
			return lst;
		} finally {
			em.close();
		}

	}

	@Override
	public SalesReturnMst updateMaterialReturn(SalesReturnFormDTO salesReturnFormDTO) {
		String lQuery = "";
		SalesDTO salesDTO=salesReturnFormDTO.getSalesDTO();
		try {
			if (salesDTO.getMatnrReturnStatus().equals("Yes")) {
//				lQuery = "update sales_return_mst set matnr_return_status='Yes'"
//						//+" ,consumption_no=:consumption_no"
//						+ " ,status=49 where id=:id";
				lQuery = "update sales_return_mst set matnr_return_status='Yes'"
						+" ,consumption_no=:consumption_no"
						+ " ,status=47 where id=:id";
			} else {
				lQuery = "update sales_return_mst set matnr_return_status='No'" + " where id=:id";
			}
			System.out.println(salesDTO.getId());	
			System.out.println("Email"+this.getToEmailId(salesDTO.getId(), "FIN_PM"));			
			query = em.createNativeQuery(lQuery);
			query.setParameter("id", salesDTO.getId());
			query.setParameter("consumption_no", salesDTO.getConsumptionNo());
			query.executeUpdate();
			//code to send email to finance and pm****************
			spQuery = em.createStoredProcedureQuery("usp_send_stores_email_sales_return")
					.registerStoredProcedureParameter("email_id", String.class, ParameterMode.IN)
			.registerStoredProcedureParameter("id_",  Integer.class, ParameterMode.IN);
			spQuery.setParameter("email_id", this.getToEmailId(salesDTO.getId(), "FIN_PM"));	
			spQuery.setParameter("id_", salesDTO.getId());		
			spQuery.execute();
			//*************************
			query = em.createNamedQuery("SalesReturnMst.findById");
			query.setParameter("id", salesDTO.getId());
			//query.setParameter("consumption_no", salesDTO.getConsumptionNo());
			
			SalesReturnMst salesReturnMst = (SalesReturnMst) query.getSingleResult();
			return salesReturnMst;
		} catch (Exception e) {
			e.printStackTrace();
			return new SalesReturnMst();
		} finally {
			em.close();
		}
	}

	@Override
	public String getToEmailId(int id, String level) {
		List lstEmail=new ArrayList();
		String emailId="";
		String lQuery = "";
		try {		
				lQuery = "SELECT "
						//+ "u.user_email as noc_email,"	
						+ "'' as noc_email,"	
						+ "u1.user_email as pm_email,u2.user_email as finance_email" 
						+ " FROM  sales_return_mst"
						+ " sr left outer join so_orders so on sr.sales_order_no_equipment=so.so_number and so.material_num=sr.matnr"
						//+ "  left join hub_mst h on sr.hub_id=h.hub_mst_id"
						//+ " inner join user_to_hub uh on h.hub_mst_id=uh.hub_mst_id"
						//+ " inner join user_mst u on uh.user_mst_id=u.user_mst_id	"
						+ " left outer join child_contract cc on so.contract_num=cc.sap_contract_num"
						+ " left join user_mst u1 on cc.pm_id=u1.user_mst_id"
						+ " left join user_mst u2 on cc.finance_id=u2.user_mst_id" + " where sr.id=:id";
				query = em.createNativeQuery(lQuery);
				query.setParameter("id", id);
				List<Object[]> objList = query.getResultList();
				for (Object[] o : objList) {
					if(level.equals("NOC_PM")){
						if(!lstEmail.contains(String.valueOf(o[0]))){
							lstEmail.add(String.valueOf(o[0]));
						}if(!lstEmail.contains(String.valueOf(o[1]))){
							lstEmail.add(String.valueOf(o[1]));
						}
					}else if(level.equals("FIN_PM")){
						if(!lstEmail.contains(String.valueOf(o[1]))){
							lstEmail.add(String.valueOf(o[1]));
						}if(!lstEmail.contains(String.valueOf(o[2]))){
							lstEmail.add(String.valueOf(o[2]));
						}
					}
										
				}
				for(int i=0;i<lstEmail.size();i++){
					if(emailId.equals("")){
						emailId=(String) lstEmail.get(i);
					}else{
						emailId+=";"+(String) lstEmail.get(i);
					}
				}
			
			return emailId;
		} catch (Exception e) {
			e.printStackTrace();

		} finally {			
			em.close();
			return emailId;
		}
	}

	@Override
	public String setEmailBody(int requestId, String level) {
		String body="";
		String start="Dear User",mainContent="",end="";
		try {
			SalesReturnListDTO bean = null;
			String lQuery = "SELECT sr.id as request_id,sr.invoice_no_equipment,sr.invoice_no_bw,c.customer_num,c.customer_name"
					+",sr.sales_order_no_bw,sr.sales_order_no_equipment,m.material_num,m.material_desc,sr.md_approved"
					+",sr.return_type,cne.credit_note_no as credit_note_no_equipment,credit_note_no_bw"
					+",convert(varchar,disconnection_date, 105) as disconnection_date,sr.status,s.status_name"
					+",cne.amount as equipment_credit_note_amount,"
					+"convert(varchar,cne.creation_date, 105) as equipment_credit_date,sr.uniq_id"
					+",d.delivery_num,d.wbs_element"
					+" FROM  sales_return_mst"
					+" sr left outer join so_orders so on sr.sales_order_no_equipment=so.so_number and so.material_num=sr.matnr"
					+" left outer join delivery d on sr.sales_order_no_equipment=d.so_number and sr.matnr=d.material_num"
					+" left outer join credit_note_equip_mst cne on sr.invoice_no_equipment=cne.cancelled_invoice_no"
					+" inner join customer_sapmst c on sr.customer_id=c.customer_sapmst_id"
					+" inner join material_sapmst m on sr.matnr=m.material_num and sr.dist_channel=m.dist_channel"
					+" and sr.sales_org=m.sales_org and sr.plant=m.plant"
					+" left outer join hub_mst h on sr.hub_id=h.hub_mst_id"
					+" inner join status_mst s on sr.status=s.status_mst_id"
					+" where sr.id=:id";			
			query = em.createNativeQuery(lQuery);
			query.setParameter("id",requestId);
			List<Object[]> objList = query.getResultList();
			for (Object[] o : objList) {
				mainContent= "<br><br>Sales Return Request Has Been Raised With Id : " + SDCommonUtil.convertNullToBlank(String.valueOf(o[18]), false) + ".";
				mainContent+= "<br>Details are as below : " ;
				mainContent+="<br>Customer : "+ SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false) 
				+" "+ SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false) ;
				mainContent+="<br>Invoice No : "+ SDCommonUtil.convertNullToBlank(String.valueOf(o[1]), false) ;
				mainContent+="<br>Sales Order No : "+ SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false) ;
				mainContent+="<br>Material : "+ SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false)
				+" "+ SDCommonUtil.convertNullToBlank(String.valueOf(o[8]), false) ;
				mainContent+="<br>Delivery No : "+ SDCommonUtil.convertNullToBlank(String.valueOf(o[19]), false) ;
				mainContent+="<br>Wbs : "+ SDCommonUtil.convertNullToBlank(String.valueOf(o[20]), false) ;
			}
			end="<br> Click here to login :  <a href="
					+ env.getProperty("emaillink") + ">O2C portal link</a>  " + "<br><br>Sincerely";
			return start+mainContent+end;
		} catch (Exception e) {
			e.printStackTrace();		
		} finally {
			em.close();
			return start+mainContent+end;
		}

	}

	@Override
	public void updateMultipleMaterialReturn(MaterialStatusUpdateDTO materialStatusUpdateDTO) {
		String lQuery = "";		
		List<SalesDTO> lst=materialStatusUpdateDTO.getList();
		try {
			for(SalesDTO dto:lst){
				if (dto.getMatnrReturnStatus().equals("Yes")) {
					lQuery = "update sales_return_mst set matnr_return_status='Yes'"
							//+" ,consumption_no=:consumption_no"				
							+ " ,status=49 where id=:id";
				} else {
					lQuery = "update sales_return_mst set matnr_return_status='No'" + " where id=:id";
				}				
				query = em.createNativeQuery(lQuery);
				query.setParameter("id", dto.getId());
				//query.setParameter("consumption_no", dto.getConsumptionNo());
				query.executeUpdate();				
			}		
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			em.close();
		}
	}

	@Override
	public CreditNoteEquipMst getEquipmentCrNoById(HttpServletRequest request) {
		try {
			query = em.createNamedQuery("CreditNoteEquipMst.findByCrNo");
			query.setParameter(1, request.getParameter("credit_note_no"));			
			CreditNoteEquipMst creditNoteEquipMst = (CreditNoteEquipMst) query.getSingleResult();			
			return creditNoteEquipMst != null ? creditNoteEquipMst : new CreditNoteEquipMst();
		} catch (Exception e) {
			return new CreditNoteEquipMst();
		} finally {
			em.close();
		}
	}

	@Override
	public CreditNoteBwMst getBandWidthCrNoById(HttpServletRequest request) {
		try {
			query = em.createNamedQuery("CreditNoteBwMst.findByCrNo");
			query.setParameter(1, request.getParameter("bandwidth_cr_no"));			
			CreditNoteBwMst creditNoteEquipMst = (CreditNoteBwMst) query.getSingleResult();			
			return creditNoteEquipMst != null ? creditNoteEquipMst : new CreditNoteBwMst();
		} catch (Exception e) {
			return new CreditNoteBwMst();
		} finally {
			em.close();
		}
	}

	@Override
	public String getStoresToEmailId(int id, String level) {
		spQuery = em.createStoredProcedureQuery("usp_get_stores_email_id");
				//.registerStoredProcedureParameter("sum", Double.class, ParameterMode.OUT);		
		Object result =  (Object) spQuery.getSingleResult();
		return result.toString();
	}

}
