package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;

/**
 * The persistent class for the brf_approver_details database table.
 * 
 */
@Entity
@Table(name = "brf_approver_details")
@NamedQueries({
		@NamedQuery(name = "BrfApproverDetail.findAll", query = "SELECT b FROM BrfApproverDetail b"),
		@NamedQuery(name="BrfApproverDetail.findByBrfApprId", query="SELECT b FROM BrfApproverDetail b where b.brfId=?1 and b.apprById=?2"),
		@NamedQuery(name="BrfApproverDetail.findByBrfId", query="SELECT b FROM BrfApproverDetail b where b.brfId=?1")})

public class BrfApproverDetail implements Serializable {
	private static final long serialVersionUID = 82L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "brf_approver_details_id")
	private Integer brfApproverDetailsId;

	@Column(name = "act_time")
	private String actTime;

	@Column(name = "appr_by_id")
	private Integer apprById;

	@Column(name = "appr_flg")
	private String apprFlg;

	@Column(name = "brf_id")
	private Integer brfId;

	@Column(name = "appr_reason")
	private Integer apprReason;

	public BrfApproverDetail() {
	}

	public Integer getBrfApproverDetailsId() {
		return brfApproverDetailsId;
	}

	public void setBrfApproverDetailsId(Integer brfApproverDetailsId) {
		this.brfApproverDetailsId = brfApproverDetailsId;
	}

	public String getActTime() {
//		return actTime;
		return DateUtil.convertDateTimeToString(this.actTime);
	}

	public void setActTime(String actTime) {
		this.actTime = actTime;
	}

	public Integer getApprById() {
		return apprById;
	}

	public void setApprById(Integer apprById) {
		this.apprById = apprById;
	}

	public String getApprFlg() {
		return apprFlg;
	}

	public void setApprFlg(String apprFlg) {
		this.apprFlg = apprFlg;
	}

	public Integer getBrfId() {
		return brfId;
	}

	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}

	public Integer getApprReason() {
		return apprReason;
	}

	public void setApprReason(Integer apprReason) {
		this.apprReason = apprReason;
	}

}