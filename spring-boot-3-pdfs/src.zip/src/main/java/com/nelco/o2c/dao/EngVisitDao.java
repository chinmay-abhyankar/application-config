/**
 * 
 */
package com.nelco.o2c.dao;

import java.math.BigDecimal;
import java.util.List;

import com.nelco.o2c.dto.HubSignOffDTO;
import com.nelco.o2c.dto.PaymentRequestDTO;
import com.nelco.o2c.dto.VisitCommonDTO;
import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.ActivityTypeMst;
import com.nelco.o2c.model.AntennaLocationMst;
import com.nelco.o2c.model.AntennaSizeMaster;
import com.nelco.o2c.model.AntennaTypeMst;
import com.nelco.o2c.model.FaEngVisitDetail;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.FranchiseInvReq;
import com.nelco.o2c.model.FranchiseInvReqStatusTracker;
import com.nelco.o2c.model.FranchiseInvReqUserMap;
import com.nelco.o2c.model.HsoStatusChangeTracker;
import com.nelco.o2c.model.HsoTransactionDetail;
import com.nelco.o2c.model.HsoTransactionStatusMst;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.HubTechMst;
import com.nelco.o2c.model.IncAttributionMst;
import com.nelco.o2c.model.IncInvoice;
import com.nelco.o2c.model.InstallationStatusMst;
import com.nelco.o2c.model.KmApplMst;
import com.nelco.o2c.model.NatureMst;
import com.nelco.o2c.model.NonFeasibleOptionMst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.SiteSurveyCost;
import com.nelco.o2c.model.SiteSurveyMaster;
import com.nelco.o2c.model.SsEngVisitDetail;
import com.nelco.o2c.model.StatusMst;
import com.nelco.o2c.model.TechnologyMaster;
import com.nelco.o2c.model.WorkCompletionStatusMst;

/**
 * @author Jayashankar.r
 *
 */
public interface EngVisitDao {

	SsEngVisitDetail getVisitDetails(VisitCommonDTO visitCommonDTOInput);

	List<SsEngVisitDetail> getVisitListBySurveyMstId(VisitCommonDTO visitCommonDTOInput);

	List<AntennaSizeMaster> getAntennaSizeList();

	List<WorkCompletionStatusMst> getWorkCompletionStatusList();

	SsEngVisitDetail saveVisitDetails(VisitCommonDTO visitCommonDTOInput);

	void updateSiteSurveyStatus(SsEngVisitDetail ssEngVisitDetail, Integer sitesurveysuccesscode,Integer userMstId);

	List<SiteSurveyCost> getSiteSurveyCostList(VisitCommonDTO visitCommonDTOInput);

	List<KmApplMst> getKmApplMstList();

	SiteSurveyCost saveCost(SiteSurveyCost siteSurveyCost);

	void updateSubmitFlag(SsEngVisitDetail ssEngVisitDetail);

	SiteSurveyCost getSiteSurveyCostBySurveyMstIdAndFranchiseId(SsEngVisitDetail ssEngVisitDetail);

	BigDecimal getRateForSiteSurvey(Integer franProcId, Integer actId, Integer kmApplMstId);

	List<OppUploadDetail> getUploadListByVisitId(VisitCommonDTO visitCommonDTOInput);

	List<FileTypeMst> getFileList(List<Integer> fileIdList);

	List<TechnologyMaster> getTechList();

	List<HubMst> getHubList();

	List<OppUploadDetail> getUploadDetailsByCostId(VisitCommonDTO visitCommonDTOInput);

	SiteSurveyMaster getSiteSurveyById(VisitCommonDTO visitCommonDTOInput);

	List<NonFeasibleOptionMst> getNonFeasibleList();

	UserEmailDetailsBean getPmUser(SiteSurveyMaster siteSurveyMaster);

	UserEmailDetailsBean getCsUser(SiteSurveyMaster siteSurveyMaster);

	List<AntennaTypeMst> getAntennaTypeList();

	List<AntennaLocationMst> getAntennaLocationList();
	
	SiteSurveyCost getSiteSurveyCostByFranchiseAllocIdAndFranchiseId(FaEngVisitDetail faEngVisitDetail);
	BigDecimal getRateForFranchiseAllocation(Integer franProcId, Integer actId, Integer kmApplMstId,Integer antennaSizeMstId);

	List<SiteSurveyCost> getCostListReadOnly(VisitCommonDTO visitCommonDTOInput);

	Integer getCurrentDayCountPaymentRequest();

	FranchiseInvReq saveFranchiseInvReq(FranchiseInvReq franchiseInvReq);

	FranchiseInvReqUserMap saveFranchiseInvReqUserMap(FranchiseInvReqUserMap franchiseInvReqUserMap);

	FranchiseInvReqStatusTracker saveFranchiseInvReqStatusTracker(
			FranchiseInvReqStatusTracker franchiseInvReqStatusTracker);

	void updateInvReqIdInSS(List<Integer> siteSurveyCostIds, Integer franchiseInvReqId);

	List<UserEmailDetailsBean> getCseUsers();

	List<UserEmailDetailsBean> getHoCsUsers();

	List<UserEmailDetailsBean> getCsHeadUsers();

	List<FranchiseInvReq> getPayReqList(PaymentRequestDTO paymentRequestDTOInput);

	List<StatusMst> getStatusList(List<String> statusCodeList);

	List<OppUploadDetail> getUploadListByFranchiseInvReqId(PaymentRequestDTO paymentRequestDTOInput);

	boolean getFranchiseInvReqUserMapCount(FranchiseInvReq franchiseInvReq, UserEmailDetailsBean user);

	List<IncInvoice> getIncInvoiceList(PaymentRequestDTO paymentRequestDTOInput);

	List<HubTechMst> getHubTechList();

	List<NatureMst> getNatureList();

	List<HsoTransactionStatusMst> getStatusHubList();

	List<HsoTransactionDetail> getHsoList(HubSignOffDTO hubSignOffDTOInput);

	HsoTransactionDetail saveHsoTransactionDetail(HsoTransactionDetail hsoTransactionDetail);

	HsoStatusChangeTracker setHsoStatusChangeTracker(HsoStatusChangeTracker hsoStatusChangeTracker);

	void updateOppUploadDetails(PaymentRequestDTO paymentRequestDTOInput);

	List<UserEmailDetailsBean> getFrcUserList(Integer franchiseMstId,Integer siteSurveyMstId,Integer franchiseeAllocationMstId);

	List<InstallationStatusMst> getInstallationStatusList();

	List<IncAttributionMst> getIncAttributionList();

	List<ActivityTypeMst> getLstActivityTypeMst();

	

}
