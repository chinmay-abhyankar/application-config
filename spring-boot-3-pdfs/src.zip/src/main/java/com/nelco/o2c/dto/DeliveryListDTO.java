/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.Delivery;

/**
 * @author Amol.l
 *
 */
public class DeliveryListDTO implements Serializable {

	private static final long serialVersionUID = 78L;
	
	
	private String fromDate;
	private String toDate;
	private List<Delivery> deliveryList = new ArrayList<Delivery>();
	private Integer userMstId;
	private String roleCode;
	private String finRemarks;
	private Integer childContractId;
	private Boolean isSaved = false;
	private String selectedStatus;
	private String deliveryNum;
	private Integer deliveryId;
	private String isNext;
	private String plant;
	private Integer rowNum;
		
	public Integer getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(Integer deliveryId) {
		this.deliveryId = deliveryId;
	}
	public String getDeliveryNum() {
		return deliveryNum;
	}
	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public List<Delivery> getDeliveryList() {
		return deliveryList;
	}
	public void setDeliveryList(List<Delivery> deliveryList) {
		this.deliveryList = deliveryList;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getFinRemarks() {
		return finRemarks;
	}
	public void setFinRemarks(String finRemarks) {
		this.finRemarks = finRemarks;
	}
	public Integer getChildContractId() {
		return childContractId;
	}
	public void setChildContractId(Integer childContractId) {
		this.childContractId = childContractId;
	}
	public Boolean getIsSaved() {
		return isSaved;
	}
	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}
	public String getSelectedStatus() {
		return selectedStatus;
	}
	public void setSelectedStatus(String selectedStatus) {
		this.selectedStatus = selectedStatus;
	}
	public String getIsNext() {
		return isNext;
	}
	public void setIsNext(String isNext) {
		this.isNext = isNext;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public Integer getRowNum() {
		return rowNum;
	}
	public void setRowNum(Integer rowNum) {
		this.rowNum = rowNum;
	}
	
}
