package com.nelco.o2c.dto;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class DisconnectionRequestDTO implements Serializable{
private String requestId="";
private String requestDate="";
private String customerId="";
private String customerName="";
private String outstandingAmt="";
private String requestedBy="";
private String requestStatus="";
private String salesheadAppStatus="";
private String financeheadAppStatus="";
private String userRole="";

private String customerCity="";
private String customerRegion="";
private String customerCountry="";
private String customerSalesOrg="";

private String invoiceNo="";
private String invoiceDate="";
private String invoiceSubmissionDate="";
private String paymentDueDate="";
private String soNo="";

private String reminder="";
private String reminderDate="";
private String reminderStatus="";


public String getCustomerCity() {
	return customerCity;
}
public void setCustomerCity(String customerCity) {
	this.customerCity = customerCity;
}
public String getCustomerRegion() {
	return customerRegion;
}
public void setCustomerRegion(String customerRegion) {
	this.customerRegion = customerRegion;
}
public String getCustomerCountry() {
	return customerCountry;
}
public void setCustomerCountry(String customerCountry) {
	this.customerCountry = customerCountry;
}
public String getCustomerSalesOrg() {
	return customerSalesOrg;
}
public void setCustomerSalesOrg(String customerSalesOrg) {
	this.customerSalesOrg = customerSalesOrg;
}
public String getInvoiceNo() {
	return invoiceNo;
}
public void setInvoiceNo(String invoiceNo) {
	this.invoiceNo = invoiceNo;
}
public String getInvoiceDate() {
	return invoiceDate;
}
public void setInvoiceDate(String invoiceDate) {
	this.invoiceDate = invoiceDate;
}
public String getInvoiceSubmissionDate() {
	return invoiceSubmissionDate;
}
public void setInvoiceSubmissionDate(String invoiceSubmissionDate) {
	this.invoiceSubmissionDate = invoiceSubmissionDate;
}
public String getPaymentDueDate() {
	return paymentDueDate;
}
public void setPaymentDueDate(String paymentDueDate) {
	this.paymentDueDate = paymentDueDate;
}
public String getSoNo() {
	return soNo;
}
public void setSoNo(String soNo) {
	this.soNo = soNo;
}
public String getReminder() {
	return reminder;
}
public void setReminder(String reminder) {
	this.reminder = reminder;
}
public String getReminderDate() {
	return reminderDate;
}
public void setReminderDate(String reminderDate) {
	this.reminderDate = reminderDate;
}
public String getReminderStatus() {
	return reminderStatus;
}
public void setReminderStatus(String reminderStatus) {
	this.reminderStatus = reminderStatus;
}
public String getRequestId() {
	return requestId;
}
public void setRequestId(String requestId) {
	this.requestId = requestId;
}
public String getRequestDate() {
	return requestDate;
}
public void setRequestDate(String requestDate) {
	this.requestDate = requestDate;
}
public String getCustomerId() {
	return customerId;
}
public void setCustomerId(String customerId) {
	this.customerId = customerId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getOutstandingAmt() {
	return outstandingAmt;
}
public void setOutstandingAmt(String outstandingAmt) {
	this.outstandingAmt = outstandingAmt;
}
public String getRequestedBy() {
	return requestedBy;
}
public void setRequestedBy(String requestedBy) {
	this.requestedBy = requestedBy;
}
public String getRequestStatus() {
	return requestStatus;
}
public void setRequestStatus(String requestStatus) {
	this.requestStatus = requestStatus;
}
public String getSalesheadAppStatus() {
	return salesheadAppStatus;
}
public void setSalesheadAppStatus(String salesheadAppStatus) {
	this.salesheadAppStatus = salesheadAppStatus;
}
public String getFinanceheadAppStatus() {
	return financeheadAppStatus;
}
public void setFinanceheadAppStatus(String financeheadAppStatus) {
	this.financeheadAppStatus = financeheadAppStatus;
}
public String getUserRole() {
	return userRole;
}
public void setUserRole(String userRole) {
	this.userRole = userRole;
}

}
