/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

import com.nelco.o2c.model.CustomerSapmst;

/**
 * @author Amol.l
 *
 */
public class CustomerMstDTO  implements Serializable {
	private static final long serialVersionUID = 36L;
	
	private String customerNum;
	private Integer customerSapmstId;
	private CustomerSapmst customerSapmst = new CustomerSapmst();

	public Integer getCustomerSapmstId() {
		return customerSapmstId;
	}
	public void setCustomerSapmstId(Integer customerSapmstId) {
		this.customerSapmstId = customerSapmstId;
	}
	public String getCustomerNum() {
		return customerNum;
	}
	public void setCustomerNum(String customerNum) {
		this.customerNum = customerNum;
	}
	
	public CustomerSapmst getCustomerSapmst() {
		return customerSapmst;
	}
	public void setCustomerSapmst(CustomerSapmst customerSapmst) {
		this.customerSapmst = customerSapmst;
	}

}
