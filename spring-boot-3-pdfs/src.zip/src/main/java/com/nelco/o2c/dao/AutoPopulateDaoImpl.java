/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.AutoCompleteDTO;
import com.nelco.o2c.model.CustomerMstBilling;
import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.model.HsoDetail;
import com.nelco.o2c.model.MaterialContract;
import com.nelco.o2c.model.MaterialSapmst;
import com.nelco.o2c.model.PayTermsMst;
import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.SoOrders;
import com.nelco.o2c.model.StorageSapmst;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class AutoPopulateDaoImpl implements AutoPopulateDao {

	@PersistenceContext
	EntityManager em;

	Query query;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.nelco.o2c.dao.AutoPopulateDao#searchMaterial(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<MaterialSapmst> searchMaterial(String material) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("MaterialSapmst.searchMaterial");
			query.setMaxResults(20);
			query.setParameter(1, "%" + material + "%");
			query.setParameter(2, "%" + material + "%");
			List<MaterialSapmst> materialList = (List<MaterialSapmst>) query.getResultList();
			return materialList != null ? materialList : new ArrayList<MaterialSapmst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CustomerSapmst> searchSoldToParty(String soldToParty) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("CustomerSapmst.searchSoldToParty");
			query.setMaxResults(20);
			query.setParameter(1, "%" + soldToParty + "%");
			query.setParameter(2, "%" + soldToParty + "%");
			List<CustomerSapmst> custList = (List<CustomerSapmst>) query.getResultList();
			return custList != null ? custList : new ArrayList<CustomerSapmst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PlantSapmst> searchPlant(String plant) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("PlantSapmst.searchPlant");
			query.setMaxResults(20);
			query.setParameter(1, "%" + plant + "%");
			query.setParameter(2, "%" + plant + "%");
			List<PlantSapmst> plantList = (List<PlantSapmst>) query.getResultList();
			return plantList != null ? plantList : new ArrayList<PlantSapmst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StorageSapmst> searchStorage(String storage) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("StorageSapmst.searchStorage");
			query.setMaxResults(20);
			query.setParameter(1, "%" + storage + "%");
			query.setParameter(2, "%" + storage + "%");
			List<StorageSapmst> storageList = (List<StorageSapmst>) query.getResultList();
			return storageList != null ? storageList : new ArrayList<StorageSapmst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MaterialContract> searchMaterialMasterContract(String material, Integer contractId) {
		try {
			// TODO Auto-generated method stub
			// query = em.createNamedQuery("MaterialContract.searchContractMaterial");
			query = em.createNamedQuery("MaterialContract.searchValidContractMaterial");
			if(material!=null) {
				query.setMaxResults(20);	
			} else {
				material ="";
			}
			query.setParameter("materialNumParam", "%" + material + "%");
			query.setParameter("materialDescParam", "%" + material + "%");
			query.setParameter("contractIdParam", contractId);
			List<Object[]> result = (List<Object[]>) query.getResultList();
			List<MaterialContract> materialList = new ArrayList<MaterialContract>();
			for (Object[] objects : result) {
				MaterialContract materialContract = new MaterialContract();
				materialContract.setContractId(objects[0] != null ? (Integer) objects[0] : null);
				materialContract.setMaterialNo(objects[1] != null ? (String) objects[1] : null);
				materialContract.setOrderQty(objects[2] != null ? (Integer) objects[2] : null);
				MaterialSapmst materialSapmst = new MaterialSapmst();
				materialSapmst.setMaterialSapmstId(objects[3] != null ? (Integer) objects[3] : null);
				materialSapmst.setMaterialNo(objects[4] != null ? (String) objects[4] : null);
				materialSapmst.setMaterialDesc(objects[5] != null ? (String) objects[5] : null);
				materialSapmst.setMaterialType(objects[6] != null ? (String) objects[6] : null);
				materialSapmst.setMaterialGroup(objects[7] != null ? (String) objects[7] : null);
				materialSapmst.setBaseUnit(objects[8] != null ? (String) objects[8] : null);
				materialSapmst.setDivision(objects[9] != null ? (String) objects[9] : null);
				materialSapmst.setPlant(objects[10] != null ? (String) objects[10] : null);
				materialSapmst.setSalesOrg(objects[11] != null ? (String) objects[11] : null);
				materialSapmst.setDistChannel(objects[12] != null ? (String) objects[12] : null);
				materialSapmst.setSalesUnit(objects[13] != null ? (String) objects[13] : null);
				materialSapmst.setItemCategory(objects[14] != null ? (String) objects[14] : null);
				materialSapmst.setDeliveryPlant(objects[15] != null ? (String) objects[15] : null);
				materialSapmst.setAccAssignGroup(objects[16] != null ? (String) objects[16] : null);
				materialSapmst.setControlGroup(objects[17] != null ? (String) objects[17] : null);
				//materialSapmst.setCreatedDate(objects[18] != null ? (String) objects[18] : null);
				materialContract.setMaterialSapmst(materialSapmst);
				materialContract.setPlant(materialSapmst.getPlant());
				materialContract.setRate(objects[18] != null ? (String) objects[18] : null);
				materialContract.setItemNum(objects[19] != null ? (String) objects[19] : null);
				materialContract.setPricingGroupCode(objects[20] != null ? (String) objects[20] : null);
				materialContract.setConditionTypeCode(objects[21] != null ? (String) objects[21] : null);
				
				Integer val = 0;
				if(materialContract.getRate()!=null && materialContract.getOrderQty()!=null) {
					val = Integer.valueOf(materialContract.getRate())*Integer.valueOf(materialContract.getOrderQty());
				}
				
				materialContract.setValue(val.toString());
				materialList.add(materialContract);
			}

			return materialList != null ? materialList : new ArrayList<MaterialContract>();
		} finally {
			em.close();
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MaterialSapmst> searchMaterialBySalesOrg(String material, String salesOrg) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("MaterialSapmst.searchMaterialBySalesOrg");
			query.setMaxResults(500);
			query.setParameter(1, salesOrg);
			query.setParameter(2, "%" + material + "%");
			query.setParameter(3, "%" + material + "%");
			List<MaterialSapmst> materialList = (List<MaterialSapmst>) query.getResultList();
			return materialList != null ? materialList : new ArrayList<MaterialSapmst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MaterialSapmst> searchMaterialByPlant(String material, String plant) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("MaterialSapmst.searchMaterialByPlant");
			query.setMaxResults(20);
			query.setParameter(1, plant);
			query.setParameter(2, "%" + material + "%");
			query.setParameter(3, "%" + material + "%");
			List<MaterialSapmst> materialList = (List<MaterialSapmst>) query.getResultList();
			return materialList != null ? materialList : new ArrayList<MaterialSapmst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CustomerSapmst> searchAccountMgrCode(String accMgrCode) {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("CustomerSapmst.searchAccountMgrCode");
			query.setMaxResults(20);
			query.setParameter(1, "%" + accMgrCode + "%");
			query.setParameter(2, "%" + accMgrCode + "%");
			List<CustomerSapmst> custList = (List<CustomerSapmst>) query.getResultList();
			return custList != null ? custList : new ArrayList<CustomerSapmst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PayTermsMst> searchPaymentTerms(String payTermsCode) {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("PayTermsMst.searchPaymentTerms");
			query.setMaxResults(20);
			query.setParameter(1, "%" + payTermsCode + "%");
			query.setParameter(2, "%" + payTermsCode + "%");
			List<PayTermsMst> payTermsList = (List<PayTermsMst>) query.getResultList();
			return payTermsList != null ? payTermsList : new ArrayList<PayTermsMst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public List<SoOrders> searchSObySoNumber(String soNumber) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("SoOrders.searchSObySoNumber");
			query.setMaxResults(20);
			query.setParameter(1, "%" + soNumber + "%");
			List<SoOrders> soOrders = (List<SoOrders>) query.getResultList();
			return soOrders != null ? soOrders : new ArrayList<SoOrders>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CustomerSapmst> searchSoldToPartySparesSo(String soldToParty) {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("CustomerSapmst.searchSoldToPartySparesSo");
			query.setMaxResults(20);
			query.setParameter(1, "%" + soldToParty + "%");
			query.setParameter(2, "%" + soldToParty + "%");
			List<CustomerSapmst> custList = (List<CustomerSapmst>) query.getResultList();
			return custList != null ? custList : new ArrayList<CustomerSapmst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CustomerSapmst> searchShipToPartySparesSo(String shipToParty) {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("CustomerSapmst.searchShipToPartySparesSo");
			query.setMaxResults(20);
			query.setParameter(1, "%" + shipToParty + "%");
			query.setParameter(2, "%" + shipToParty + "%");
			List<CustomerSapmst> custList = (List<CustomerSapmst>) query.getResultList();
			return custList != null ? custList : new ArrayList<CustomerSapmst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MaterialSapmst> searchMaterialSparesSo(String material) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("MaterialSapmst.searchMaterialSparesSo");
			query.setMaxResults(20);
			query.setParameter(1, "%" + material + "%");
			query.setParameter(2, "%" + material + "%");
			List<MaterialSapmst> materialList = (List<MaterialSapmst>) query.getResultList();
			return materialList != null ? materialList : new ArrayList<MaterialSapmst>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public List<SoOrders> searchSObySoNumberForRelocation(String soNumber) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("SoOrders.searchSObySoNumberForRelocation");
			query.setMaxResults(20);
			query.setParameter(1, "%" + soNumber + "%");
			List<SoOrders> soOrders = (List<SoOrders>) query.getResultList();
			return soOrders != null ? soOrders : new ArrayList<SoOrders>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<HsoDetail> searchIp(String ip) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("HsoDetail.searchIp");
			query.setMaxResults(20);
			query.setParameter(1, "%" + ip + "%");
			List<HsoDetail> ipList = (List<HsoDetail>) query.getResultList();
			
			return ipList != null ? ipList : new ArrayList<HsoDetail>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public String getBillToParty(AutoCompleteDTO auto) {
		try {
			query = em.createQuery("select customerNum from CustomerMstBilling where regionCode = :region and customerName = :cusName");
			query.setParameter("region", auto.getRegion());
			query.setParameter("cusName", auto.getCustomerName());
			
			String billToParty = (String) query.getSingleResult();
			
			return ((billToParty!=null) && (billToParty.length()>0)) ? billToParty : "";
		}catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

}
