/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Jayashankar.r
 *
 */
public class RowBean {

	@JsonProperty("no")
	private String no;

	@JsonProperty("FL")
	private List<ValContentBean> flList;

	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		this.no = no;
	}

	public List<ValContentBean> getFlList() {
		return flList;
	}

	public void setFlList(List<ValContentBean> flList) {
		this.flList = flList;
	}

}
