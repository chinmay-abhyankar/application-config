/**
 * 
 */
package com.nelco.o2c.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.nelco.o2c.dto.ChildContractDTO;
import com.nelco.o2c.dto.ChildContractDropDownDTO;
import com.nelco.o2c.dto.ChildContractListDTO;
import com.nelco.o2c.dto.ResponseDTO;
import com.nelco.o2c.model.ChildContract;
import com.nelco.o2c.service.ChildContractService;

/**
 * @author Amol.l
 *
 */
@RestController
public class ChildContractController {
	
	@Autowired
	ChildContractService childContractService;
	
	@RequestMapping(value = "/getChildConBychildConId.do", method = RequestMethod.POST)
	public ChildContractDTO getChildConBychildConId(@RequestBody ChildContractDTO childContractDTO) {
		ChildContractDTO childContractDTONew = new ChildContractDTO();
		ChildContract childContract = new ChildContract();
		childContract = childContractService.getChildConBychildConId(childContractDTO);
		childContractDTONew.setChildContractId(childContractDTO.getChildContractId());
		childContractDTONew.setChildContract(childContract);
		childContractDTONew.setOppUploadDetails(childContractService.getUploadListByChildContractId(childContract)); 
		childContractDTONew.setAccManagerName(childContractService.getAccountManager(String.valueOf(childContractDTO.getContractId())));
		return childContractDTONew;
	}
	
	@RequestMapping(value = "/getChildConBySapContNum.do", method = RequestMethod.POST)
	public ChildContractDTO getChildConBySapContNum(@RequestBody ChildContractDTO childContractDTO) {
		ChildContractDTO childContractDTONew = new ChildContractDTO();
		ChildContract childContract = new ChildContract();
		childContract = childContractService.getChildConBySapContNum(childContractDTO);
		childContractDTONew.setChildContractId(childContractDTO.getChildContractId());
		childContractDTONew.setChildContract(childContract);
		return childContractDTONew;
	}
	
	@RequestMapping(value = "/getChildContractDropDowns.do", method = RequestMethod.POST)
	public ChildContractDropDownDTO getContractDropDowns(@RequestBody ChildContractDropDownDTO childContractDropDownDTO) {
		return childContractService.getChildContractDropDowns(childContractDropDownDTO);
	}
	
	@RequestMapping(value = "/saveChildContract.do", method = RequestMethod.POST)
	public ChildContractDTO saveChildContract(@RequestBody ChildContractDTO childContractDTO) {
		ChildContractDTO childContractDTONew = new ChildContractDTO();
//		ChildContract childContract = new ChildContract();
		ChildContractDTO childContractDTOObj = childContractService.saveChildContract(childContractDTO);
		synchronized (this) {
			childContractService.callContGenProcBychildConId(childContractDTOObj);
			childContractService.generateFile(childContractDTOObj);
		}
		
		
//		childContract = childContractService.getChildConBychildConId(childContractDTOObj.getChildContract().getChildContractId());
//		childContractDTONew.setChildContract(childContract);
//		return childContractDTONew;
		
		if(childContractDTOObj.getChildContract().getChildContractId() != null)
		{
			childContractDTONew.setIsSave("Y");
		}else {
			childContractDTONew.setIsSave("N");
		}
		
		return childContractDTONew;
	}
	
	@RequestMapping(value = "/getChildConByConIdAndDate.do", method = RequestMethod.POST)
	public ChildContractListDTO getChildConByConIdAndDate(@RequestBody ChildContractListDTO childContractListDTO) {
		ChildContractListDTO childContractListDTONew = new ChildContractListDTO();
		List<ChildContract> childContractList = new ArrayList<ChildContract>();
		childContractList = childContractService.getChildConByConIdAndDate(childContractListDTO);
		childContractListDTONew.setToDate(childContractListDTO.getToDate());
		childContractListDTONew.setFromDate(childContractListDTO.getFromDate());
		childContractListDTONew.setChildContractDTOList(childContractList);
		childContractListDTONew.setContractId(childContractListDTO.getContractId());
		return childContractListDTONew;
	}	
	
	@RequestMapping(value = "/updateContractRemarkFinance.do", method = RequestMethod.POST)
	public ChildContractListDTO updateContractRemarkFinance(@RequestBody ChildContractListDTO childContractListDTO,HttpServletRequest request) {
		return childContractService.updateContractRemarkFinance(childContractListDTO,request);
	}
	
	//This is for uploading Multiple Child Contract request from Sales Co-Ordinator login
	@RequestMapping(value = "/uploadChildContract.do", method = RequestMethod.POST)
	public ResponseDTO uploadChildContract(MultipartHttpServletRequest request,@RequestParam String userMstId,@RequestParam String contractId) throws Exception {
		ResponseDTO responseDTO=new ResponseDTO();		
		MultipartFile file = request.getFile("childContFile");
		if(childContractService.validateFile(file, userMstId,responseDTO)){
			responseDTO = childContractService.uploadFile(file, userMstId, contractId);
			
		}else{
			return responseDTO;
		}
		responseDTO.setContractId(Integer.parseInt(contractId));
		return responseDTO;
		
	}

}
