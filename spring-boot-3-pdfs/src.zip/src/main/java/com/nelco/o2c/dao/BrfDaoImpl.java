/**
 * 
 */
package com.nelco.o2c.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.nelco.o2c.dto.BrfDTO;
import com.nelco.o2c.dto.BrfDetailsDTO;
import com.nelco.o2c.dto.BrfDetailsListDTO;
import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.CustomerMstDTO;
import com.nelco.o2c.dto.OldSoDTO;
import com.nelco.o2c.dto.UserToHubDTO;
import com.nelco.o2c.model.Brf;
import com.nelco.o2c.model.BrfApproverDetail;
import com.nelco.o2c.model.BrfSoDetails;
import com.nelco.o2c.model.BrfStatusTracker;
import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.model.MaterialChildContract;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Amol.l
 *
 */
@Repository
public class BrfDaoImpl implements BrfDao {

	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	CustomerMstDao customerMstDao;

	Query query;
	StoredProcedureQuery spQuery;
	
	@Override
	public List<BrfDetailsDTO> getBrfListByDate(BrfDetailsListDTO brfDetailsListDTO) {
		// TODO Auto-generated method stub
		try {
			String queryString = "";
			String fromDate = DateUtil.convertDateToSqlDate(brfDetailsListDTO.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(brfDetailsListDTO.getToDate());
//		    queryString = "SELECT c from ChildContract c inner join c.contract con inner join con.proposal p inner join p.serviceOrderMst som left join c.brf b left join b.statusMst sm where som.serviceOrderDetId in (3,4) and c.createdDate between ?1 and ?2 and c.sapContractNum is not null";				
			
			if (brfDetailsListDTO.getRoleCode().equals(Constants.FINANCEROLECODE) || brfDetailsListDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE) || brfDetailsListDTO.getRoleCode().equals(Constants.REGULATORYHEAD)) {
			queryString = "select distinct c.sap_contract_num,c.con_start_date,c.con_end_date,c.quarter,c.market_segment,um.user_mst_id as acco_mgr,c.po_number,c.child_contract_id, "
										
					+ " con.sold_to_party,csm.customer_name, um.user_name as acco_mgr_name,c.created_date " 
					+ " from child_contract c "
					+ " inner join contract con on c.contract_id = con.contract_id "
					+ " inner join proposal p on con.proposal_id = p.proposal_id "
//					+ " inner join service_order_mst som on som.service_order_det_id = con.service_order_det_id "
					+ " inner join customer_sapmst csm on (con.sold_to_party = csm.customer_num and con.dist_channel=csm.dist_channel and con.division=csm.division and con.sales_org=csm.sales_org) "
					+ " inner join user_mst um on um.sm_owner_id = p.smowner_id "
					+ " left join brf b on c.child_contract_id = b.child_contract_id "
					+ " where con.sales_org = 'TNET' and c.sap_contract_num is not null and c.created_date between ?1 and ?2 ";
			}
			else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCMGRCODE) || brfDetailsListDTO.getRoleCode().equals(Constants.OPERATIONSHEADCODE) || brfDetailsListDTO.getRoleCode().equals(Constants.NOCENGINEERCODE)) {
			queryString = "select distinct c.sap_contract_num,c.con_start_date,c.con_end_date,c.quarter,c.market_segment,um.user_mst_id as acco_mgr,c.po_number,c.child_contract_id, "
					
					+ " con.sold_to_party,csm.customer_name, um.user_name as acco_mgr_name,c.created_date " 
					+ " from child_contract c "
					+ " inner join contract con on c.contract_id = con.contract_id "
					+ " inner join proposal p on con.proposal_id = p.proposal_id "
//					+ " inner join service_order_mst som on som.service_order_det_id = con.service_order_det_id "
					+ " inner join customer_sapmst csm on (con.sold_to_party = csm.customer_num and con.dist_channel=csm.dist_channel and con.division=csm.division and con.sales_org=csm.sales_org) "
					+ " inner join user_mst um on um.sm_owner_id = p.smowner_id "
					+ " inner join brf b on c.child_contract_id = b.child_contract_id "
					+ " inner join status_mst sm on b.status_mst_id = sm.status_mst_id " 
					+ " inner join user_to_hub utb on b.hub_mst_id = utb.hub_mst_id"
					+ " where con.sales_org = 'TNET' and c.sap_contract_num is not null and c.created_date between ?1 and ?2 ";
			}
			
			if (brfDetailsListDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)) {
				queryString = queryString + " and c.pm_id=?3 ";
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, brfDetailsListDTO.getUserMstId());
			}
			else if (brfDetailsListDTO.getRoleCode().equals(Constants.FINANCEROLECODE)) {
				queryString = queryString + " and b.finance_id=?3  ";
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, brfDetailsListDTO.getUserMstId());

			} 
			else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCENGINEERCODE)) {
				queryString = queryString + " and utb.user_mst_id =?3  ";
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, brfDetailsListDTO.getUserMstId());
			} 
			else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCMGRCODE) || brfDetailsListDTO.getRoleCode().equals(Constants.OPERATIONSHEADCODE)) {
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
			}
			else if (brfDetailsListDTO.getRoleCode().equals(Constants.REGULATORYHEAD)) {
				queryString = queryString + " and b.regulatory_id = ?3  ";
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, brfDetailsListDTO.getUserMstId());
			}

			List<BrfDetailsDTO> brfDetailsDTOList = new ArrayList<BrfDetailsDTO>();
			BrfDetailsDTO brfDetailsDTO = null;
			List<MaterialChildContract> materialChildContractList = null;
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			
			for (Object[] objects : resultList) {
				brfDetailsDTO = new BrfDetailsDTO();
							
				brfDetailsDTO.setSapContractNum((String) objects[0]);
				brfDetailsDTO.setConStartDate(DateUtil.convertDateTimeToString(objects[1].toString()));
				brfDetailsDTO.setConEndDate(DateUtil.convertDateTimeToString(objects[2].toString()));
				brfDetailsDTO.setQuarter((String) objects[3]);
				brfDetailsDTO.setMarketSegment((String) objects[4]);
				brfDetailsDTO.setAccoMgr((Integer) objects[5]);
				brfDetailsDTO.setPoNum((String) objects[6]);
				brfDetailsDTO.setChildContractId((Integer) objects[7]);
				brfDetailsDTO.setSoldToParty((String) objects[8]);
				brfDetailsDTO.setCustomerName((String) objects[9]);
				brfDetailsDTO.setAccoMgrName((String) objects[10]);
				if(objects[0] != null) {
				brfDetailsDTO.setNumOfBrf(this.getBrfCountByContractNum((String) objects[0]));
				}
								
				if(objects[0] != null) {
//				materialChildContract = new MaterialChildContract();
//				materialChildContract = this.getMaterialChildContractById((Integer) objects[7]);
//				brfDetailsDTO.setMaterialDesc(materialChildContract.getMaterialDesc());
				materialChildContractList = new ArrayList<MaterialChildContract>() ;
				materialChildContractList = this.materialListByChildContId((Integer) objects[7]);
				brfDetailsDTO.setMaterialChildContractList(materialChildContractList);
				brfDetailsDTO.setOrderQty(this.sumOfOrderQtyByChildContId((Integer) objects[7]));
				}
				if(objects[0] != null) {
					brfDetailsDTO.setBrfNumOfSiteCreated(this.getRemainNumSiteByContractNum((String) objects[0]));
					}
				
				brfDetailsDTO.setCreatedDate(DateUtil.convertDateTimeToString(objects[11].toString()));		
				brfDetailsDTOList.add(brfDetailsDTO);
			}
			
			return brfDetailsDTOList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<BrfDetailsDTO>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<BrfDetailsDTO> getBrfListByContNumAndDate(BrfDetailsListDTO brfDetailsListDTO) {	
		// TODO Auto-generated method stub
		try {
			String queryString = "";
			String fromDate = DateUtil.convertDateToSqlDate(brfDetailsListDTO.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(brfDetailsListDTO.getToDate());
//			    queryString = "SELECT c from ChildContract c inner join c.contract con inner join con.proposal p inner join p.serviceOrderMst som left join c.brf b left join b.statusMst sm where som.serviceOrderDetId in (3,4) and c.createdDate between ?1 and ?2 and c.sapContractNum is not null";
				
			queryString = "select distinct c.con_start_date,c.con_end_date,c.sap_contract_num,c.quarter,c.market_segment,"
					+ " b.brf_id,um.user_mst_id as acco_mgr,b.bandwidth,b.brf_plan,b.bw_allocation,b.contract_num,b.created_date,b.existing_site,"
					+ " b.product,b.old_so_num,c.po_number,b.site_name,con.sold_to_party,"
					+ " sm.status_mst_id,sm.status_name,sm.status_code,b.technology,b.tent_act_date,c.child_contract_id,b.finance_id,"
					+ " b.noc_mgr_id,b.prog_mgr,b.regulatory_id,b.sales_org,b.dist_channel,b.division,b.finance_remark,b.noc_remark,"
					+ " csm.customer_name, um.user_name as acco_mgr_name,csm.customer_sapmst_id,b.pm_remark,b.hub_mst_id,hm.hub_desc "
					+ " from child_contract c " + " inner join contract con on c.contract_id = con.contract_id "
					+ " inner join proposal p on con.proposal_id = p.proposal_id "
//					+ " inner join service_order_mst som on som.service_order_det_id = con.service_order_det_id "
					+ " inner join brf b on c.child_contract_id = b.child_contract_id "
					+ " inner join customer_sapmst csm on (con.sold_to_party = csm.customer_num and con.dist_channel=csm.dist_channel and con.division=csm.division and con.sales_org=csm.sales_org) "
					+ " inner join user_mst um on um.sm_owner_id = p.smowner_id "
					+ " inner join hub_mst hm  on b.hub_mst_id = hm.hub_mst_id ";

			if (brfDetailsListDTO.getRoleCode().equals(Constants.FINANCEROLECODE)
					|| brfDetailsListDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)
					|| brfDetailsListDTO.getRoleCode().equals(Constants.REGULATORYHEAD)) {
				queryString = queryString + " left join status_mst sm on b.status_mst_id = sm.status_mst_id "
						+ " where con.sales_org = 'TNET' and c.sap_contract_num is not null and b.created_date between ?1 and ?2 ";
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCMGRCODE)
					|| brfDetailsListDTO.getRoleCode().equals(Constants.OPERATIONSHEADCODE)
					|| brfDetailsListDTO.getRoleCode().equals(Constants.NOCENGINEERCODE)) {
				queryString = queryString + " inner join status_mst sm on b.status_mst_id = sm.status_mst_id "
						+ " inner join user_to_hub utb on b.hub_mst_id = utb.hub_mst_id "
						+ " where con.sales_org = 'TNET' and c.sap_contract_num is not null and b.created_date between ?1 and ?2 ";
			}

			if (brfDetailsListDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)) {

				if (brfDetailsListDTO.getPendingList().equals(Constants.YESPENDINGLIST)) {
					queryString = queryString + "  and sm.status_code in ('BRFNA','BRFR') and c.pm_id =?3 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getUserMstId());
				} else if (brfDetailsListDTO.getPendingList().equals(Constants.NOPENDINGLIST)) {
					queryString = queryString + "  and b.contract_num = ?3 and c.pm_id=?4 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getContractNum());
					query.setParameter(4, brfDetailsListDTO.getUserMstId());
				}
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.FINANCEROLECODE)) {
				if (brfDetailsListDTO.getPendingList().equals(Constants.YESPENDINGLIST)) {
					queryString = queryString + " and sm.status_code in('BRFSTF') and b.finance_id=?3 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getUserMstId());
				} else if (brfDetailsListDTO.getPendingList().equals(Constants.NOPENDINGLIST)) {
					queryString = queryString
							+ " and sm.status_code in('BRFSTF','BRFSTNOC','BRFA','BRFR') and b.contract_num = ?3 and b.finance_id=?4 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getContractNum());
					query.setParameter(4, brfDetailsListDTO.getUserMstId());
				}
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCENGINEERCODE)) {
				if (brfDetailsListDTO.getPendingList().equals(Constants.YESPENDINGLIST)) {
					queryString = queryString + "  and sm.status_code in ('BRFSTNOC') and utb.user_mst_id=?3 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getUserMstId());
				} else if (brfDetailsListDTO.getPendingList().equals(Constants.NOPENDINGLIST)) {
					queryString = queryString + " and sm.status_code in('BRFSTNOC','BRFA','BRFR') and b.contract_num = ?3 and utb.user_mst_id=?4 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getContractNum());
					query.setParameter(4, brfDetailsListDTO.getUserMstId());
				}
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCMGRCODE)
					|| brfDetailsListDTO.getRoleCode().equals(Constants.OPERATIONSHEADCODE)) {
				if (brfDetailsListDTO.getPendingList().equals(Constants.YESPENDINGLIST)) {
					queryString = queryString + "  and sm.status_code in ('BRFSTNOC') ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
				} else if (brfDetailsListDTO.getPendingList().equals(Constants.NOPENDINGLIST)) {
					queryString = queryString
							+ " and sm.status_code in('BRFSTNOC','BRFA','BRFR') and b.contract_num = ?3 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getContractNum());
				}
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.REGULATORYHEAD)) {
				queryString = queryString + " and b.regulatory_id = ?4 and sm.status_code in('BRFA') ";
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, brfDetailsListDTO.getContractNum());
				query.setParameter(4, brfDetailsListDTO.getUserMstId());
			}

			List<BrfDetailsDTO> brfDetailsDTOList = new ArrayList<BrfDetailsDTO>();
			BrfDetailsDTO brfDetailsDTO = null;
			List<MaterialChildContract> materialChildContractList = null;
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) query.getResultList();

			for (Object[] objects : resultList) {
				brfDetailsDTO = new BrfDetailsDTO();

				brfDetailsDTO.setConStartDate(DateUtil.convertDateTimeToString(objects[0].toString()));
				brfDetailsDTO.setConEndDate(DateUtil.convertDateTimeToString(objects[1].toString()));
				brfDetailsDTO.setSapContractNum((String) objects[2]);
				brfDetailsDTO.setQuarter((String) objects[3]);
				brfDetailsDTO.setMarketSegment((String) objects[4]);
				brfDetailsDTO.setBrfId((Integer) objects[5]);
				brfDetailsDTO.setAccoMgr((Integer) objects[6]);
				brfDetailsDTO.setBandwidth((String) objects[7]);
				brfDetailsDTO.setBrfPlan((String) objects[8]);
				brfDetailsDTO.setBwAllocation((String) objects[9]);
				brfDetailsDTO.setContractNum((String) objects[2]);
				if (objects[11] != null) {
					brfDetailsDTO.setCreatedDate(DateUtil.convertDateTimeToString(objects[11].toString()));
				}
				brfDetailsDTO.setExistingSite((String) objects[12]);
				brfDetailsDTO.setProduct((String) objects[13]);
				brfDetailsDTO.setOldSoNum((String) objects[14]);
				brfDetailsDTO.setPoNum((String) objects[15]);
				brfDetailsDTO.setSiteName((String) objects[16]);
				brfDetailsDTO.setSoldToParty((String) objects[17]);
				brfDetailsDTO.setStatusMstId((Integer) objects[18]);
				brfDetailsDTO.setStatusName((String) objects[19]);
				brfDetailsDTO.setStatusCode((String) objects[20]);
				brfDetailsDTO.setTechnology((String) objects[21]);
				if (objects[22] != null) {
					brfDetailsDTO.setTentActDate(DateUtil.convertDateTimeToString(objects[22].toString()));
				}
				brfDetailsDTO.setChildContractId((Integer) objects[23]);
				brfDetailsDTO.setFinanceId((Integer) objects[24]);
				brfDetailsDTO.setNocMgrId((Integer) objects[25]);
				brfDetailsDTO.setProgMgr((Integer) objects[26]);
				brfDetailsDTO.setRegulatoryId((Integer) objects[27]);
				brfDetailsDTO.setSalesOrg((String) objects[28]);
				brfDetailsDTO.setDistChannel((String) objects[29]);
				brfDetailsDTO.setDivision((String) objects[30]);
				brfDetailsDTO.setFinanceRemark((String) objects[31]);
				brfDetailsDTO.setNocRemark((String) objects[32]);
				brfDetailsDTO.setCustomerName((String) objects[33]);
				brfDetailsDTO.setAccoMgrName((String) objects[34]);
				brfDetailsDTO.setPmRemark((String) objects[36]);
				brfDetailsDTO.setHubMstId((Integer) objects[37]);
				brfDetailsDTO.setHubDesc((String) objects[38]);

				if (objects[2] != null) {
					brfDetailsDTO.setNumOfBrf(this.getBrfCountByContractNum((String) objects[2]));
				}

				if (objects[2] != null) {
//					materialChildContract = new MaterialChildContract();
//					materialChildContract = this.getMaterialChildContractById((Integer) objects[23]);
//					brfDetailsDTO.setMaterialDesc(materialChildContract.getMaterialDesc());
					
					materialChildContractList = new ArrayList<MaterialChildContract>() ;
					materialChildContractList = this.materialListByChildContId((Integer) objects[23]);
					brfDetailsDTO.setMaterialChildContractList(materialChildContractList);
					brfDetailsDTO.setOrderQty(this.sumOfOrderQtyByChildContId((Integer) objects[23]));
				}
				if (objects[2] != null) {
					brfDetailsDTO.setBrfNumOfSiteCreated(this.getRemainNumSiteByContractNum((String) objects[2]));
				}

//				brfDetailsDTO.setItem((String) objects[36]);
//				brfDetailsDTO.setMaterialNum((String) objects[37]);
//				brfDetailsDTO.setSoOrdersId((Integer)objects[38]);
//				brfDetailsDTO.setCustomerName((String) objects[39]);
				if (objects[35] != null) {
					CustomerSapmst customerSapmst = new CustomerSapmst();
					CustomerMstDTO customerMstDTO = new CustomerMstDTO();
					customerMstDTO.setCustomerSapmstId((Integer) objects[35]);
					customerSapmst = customerMstDao.getCustomerdetailsByCustomerNum(customerMstDTO);
					brfDetailsDTO.setCustomerSapmst(customerSapmst);
				}

				brfDetailsDTOList.add(brfDetailsDTO);
			}

			return brfDetailsDTOList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<BrfDetailsDTO>();
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Brf getBrfByBrfId(Integer brfId) {
		// TODO Auto-generated method stub
		try {

//			query = em.createQuery(
//					"SELECT b.brfId,b.accoMgr,b.bandwidth,b.brfPlan,b.bwAllocation,b.contractNum,b.createdDate,b.existingSite,b.product,b.oldSoNum,b.poNum,b.progMgr,b.financeRemark,b.siteName,b.soldToParty,csm.customerName,b.statusMstId,sm.statusName,b.technology,b.tentActDate,b.childContractId,sm.statusCode,b.financeId,b.nocMgrId,b.nocRemark,b.distChannel,b.division,b.salesOrg,b.regulatoryId,b.item,b.materialNum,b.soOrdersId FROM Brf b inner join CustomerSapmst csm on b.soldToParty = csm.soldToParty  inner join StatusMst sm on b.statusMstId = sm.statusMstId where b.brfId =?1 ");
//			query.setParameter(1, brfId);
		
			query = em.createNativeQuery(" select b.brf_id,um.user_mst_id as acco_mgr,b.bandwidth,b.brf_plan,b.bw_allocation,b.contract_num,b.created_date,"
					+ " b.existing_site,b.product,b.old_so_num,b.po_num,b.site_name,b.sold_to_party,b.status_mst_id,sm.status_name,"
					+ " sm.status_code,b.technology,b.tent_act_date,b.child_contract_id,b.finance_id,b.noc_mgr_id,b.prog_mgr,b.regulatory_id,"
					+ " b.sales_org,b.dist_channel,b.division,b.finance_remark,b.noc_remark,csm.customer_name,"
					+ " bsd.brf_so_details_id,bsd.brf_id as bsd_brf_id,bsd.old_so_num as bsd_old_so_num ,bsd.new_so_num as bsd_new_so_num,"
					+ " bsd.existing_site as bsd_existing_site, bsd.technology as bsd_technology,bsd.brf_plan as bsd_brf_plan,"
					+ " bsd.bandwidth as bsd_bandwidth,bsd.tent_act_date as bsd_tent_act_date,bsd.new_so_act_date as bsd_new_so_act_date,"
					+ " bsd.modified_date as bsd_modified_date,bsd.created_date as bsd_created_date,um.user_name as acco_mgr_name, um2.user_name as progMgrName, "
					+ " b.pm_remark,b.hub_mst_id,hm.hub_desc,ROW_NUMBER() OVER(ORDER BY bsd.brf_so_details_id ASC) AS rowNumber  "
					+ " from brf b "
					+ " inner join status_mst sm on b.status_mst_id = sm.status_mst_id "
					+ " inner join child_contract c on c.child_contract_id = b.child_contract_id "
					+ " inner join contract con on c.contract_id = con.contract_id "
					+ " inner join proposal p on con.proposal_id = p.proposal_id "
//					+ " inner join service_order_mst som on som.service_order_det_id = con.service_order_det_id "
					+ " inner join customer_sapmst csm on (b.sold_to_party = csm.customer_num and b.dist_channel=csm.dist_channel and b.division=csm.division and b.sales_org=csm.sales_org) "
					+ " inner join user_mst um on um.sm_owner_id = p.smowner_id "
					+ " inner join user_mst um2 on um2.user_mst_id = b.prog_mgr "
					+ " inner join hub_mst hm  on b.hub_mst_id = hm.hub_mst_id" 
					+ " left join brf_so_details bsd on b.brf_id=bsd.brf_id "
					+ " where b.brf_id =?1  order by rowNumber asc ");
			query.setParameter(1, brfId);
			query.setMaxResults(50);
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			Brf brf = new Brf();
			List<BrfSoDetails> brfSoDetailsList = new ArrayList<BrfSoDetails>();
			BrfSoDetails brfSoDetails = null;
			int count =1;
			for (Object[] objects : resultList) {
				brfSoDetails = new BrfSoDetails();
				if(count == 1 )
				{
				brf.setBrfId((Integer) objects[0]);
				brf.setAccoMgr((Integer) objects[1]);
				brf.setBandwidth((String) objects[2]);
				brf.setBrfPlan((String) objects[3]);
				brf.setBwAllocation((String) objects[4]);
				brf.setContractNum((String) objects[5]);
				if(objects[6] != null) {
					brf.setCreatedDate(DateUtil.convertDateTimeToString(objects[6].toString()));
				}
				brf.setExistingSite((String) objects[7]);
				brf.setProduct((String) objects[8]);
				brf.setOldSoNum((String) objects[9]);
				brf.setPoNum((String) objects[10]);
				brf.setSiteName((String) objects[11]);
				brf.setSoldToParty((String) objects[12]);
				brf.setStatusMstId((Integer) objects[13]);
				brf.setStatusName((String) objects[14]);
				brf.setStatusCode((String) objects[15]);
				brf.setTechnology((String) objects[16]);
				if(objects[17] != null) {
					brf.setTentActDate(DateUtil.convertDateTimeToString(objects[17].toString()));
				}
				brf.setChildContractId((Integer) objects[18]);
				brf.setFinanceId((Integer) objects[19]);
				brf.setNocMgrId((Integer) objects[20]);
				brf.setProgMgr((Integer) objects[21]);
				brf.setRegulatoryId((Integer)objects[22]);
				brf.setSalesOrg((String) objects[23]);
				brf.setDistChannel((String) objects[24]);
				brf.setDivision((String) objects[25]);
				brf.setFinanceRemark((String) objects[26]);
				brf.setNocRemark((String) objects[27]);
				brf.setCustomerName((String) objects[28]);
				brf.setAccoMgrName((String) objects[41]);
				brf.setProgMgrName((String) objects[42]);
				brf.setPmRemark((String) objects[43]);
				brf.setHubMstId((Integer)objects[44]);
				brf.setHubDesc((String)objects[45]);
				
				if(objects[5] != null) {
					brf.setBrfNumOfSiteCreated(this.getRemainNumSiteByContractNum((String) objects[5]));
					}
				}
				
				brfSoDetails.setBrfSoDetailsId((Integer) objects[29]);
				brfSoDetails.setBrfId((Integer) objects[30]);
				brfSoDetails.setOldSoNum((String) objects[31]);
				brfSoDetails.setNewSoNum((String) objects[32]);
				brfSoDetails.setExistingSite((String) objects[33]);
				brfSoDetails.setTechnology((String) objects[34]);
				brfSoDetails.setBrfPlan((String) objects[35]);
				brfSoDetails.setBandwidth((String) objects[36]);
				
				if(objects[37] != null) {
				brfSoDetails.setTentActDate(DateUtil.convertDateTimeToString(objects[37].toString()));
				}
				if(objects[38] != null) {				
				brfSoDetails.setNewSoActDate(DateUtil.convertDateTimeToString(objects[38].toString()));
				}
				if(objects[39] != null) {
				brfSoDetails.setModifiedDate(DateUtil.convertDateTimeToString(objects[39].toString()));
				}
				if(objects[40] != null) {
				brfSoDetails.setCreatedDate(DateUtil.convertDateTimeToString(objects[40].toString()));
				}
				brfSoDetails.setRowNumber(((BigInteger) objects[46]).intValue());
				count ++;
				brfSoDetailsList.add(brfSoDetails);
				
				
			}
			if (brf != null) {
				brf.setBrfSoDetailsList(brfSoDetailsList);
				
			} 
			return brf;
	/*		else {
				return new Brf();
			}
*/
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new Brf();
		} finally {
			em.close();
		}
	}

	@Override
	public Brf saveBrf(Brf brf) {
		// TODO Auto-generated method stub
		brf.setUpdatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		Brf brfNew = em.merge(brf);
		if (brf.getBrfId() == null) {
			em.refresh(brfNew);
		}
		return brfNew;
	}

	@Override
	public BrfApproverDetail saveSingleBrfApprovals(BrfApproverDetail brfApproverDetail) {
		try {
			// TODO Auto-generated method stub
			brfApproverDetail.setActTime(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
			BrfApproverDetail brfApproverDetailNew = em.merge(brfApproverDetail);
			if (brfApproverDetail.getBrfApproverDetailsId() == null) {
				em.refresh(brfApproverDetailNew);
			}
			return brfApproverDetailNew;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public boolean checkAllApproved(BrfApproverDetail brfApproverDetail) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("BrfApproverDetail.findByBrfId", BrfApproverDetail.class);
			query.setParameter(1, brfApproverDetail.getBrfId());
			@SuppressWarnings("unchecked")
			List<BrfApproverDetail> brfApproverDetailList = query.getResultList();
			boolean returnFlag = false;

			for (BrfApproverDetail brfApproverDetailNew : brfApproverDetailList) {
				if (brfApproverDetailNew.getApprFlg().equals(Constants.BRFAPPROVALSTATUS))
					returnFlag = true;
				else {
					returnFlag = false;
//					break;
				}
			}
			return returnFlag;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		} finally {
			em.close();
		}
	}

	@Override
	public BrfStatusTracker saveBrfStatusTracker(BrfStatusTracker brfStatusTracker) {
		try {
			// TODO Auto-generated method stub
			brfStatusTracker.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
			BrfStatusTracker brfStatusTrackerNew = em.merge(brfStatusTracker);
			if (brfStatusTracker.getBrfStatusTrackerId() == null) {
				em.refresh(brfStatusTrackerNew);
			}
			return brfStatusTrackerNew;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public boolean checkBrfRejectStatus(BrfStatusTracker brfStatusTracker) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("BrfStatusTracker.checkBrfRejectStatus", BrfStatusTracker.class);
			query.setParameter(1, brfStatusTracker.getBrfId());
			@SuppressWarnings("unchecked")
			List<BrfStatusTracker> brfStatusTrackerList = query.getResultList();
			boolean returnFlag = false;

			if (brfStatusTrackerList != null && brfStatusTrackerList.size() > 0) {
				returnFlag = true;
			} else {
				returnFlag = false;
			}

			return returnFlag;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		} finally {
			em.close();
		}
	}

	@Override
	public BrfStatusTracker getBrfStatusTracker(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		try {
			//BrfStatusTracker brfStatusTracker = new BrfStatusTracker();
			query = em.createNamedQuery("BrfStatusTracker.findByBrfReqById", BrfStatusTracker.class);
			query.setParameter(1, commonDTO.getBrfId());
			query.setMaxResults(1);
			@SuppressWarnings("unchecked")
			List<BrfStatusTracker> brfStatusTrackers = (List<BrfStatusTracker>) query.getResultList();
			return brfStatusTrackers!=null && brfStatusTrackers.size()>0?brfStatusTrackers.get(0):new BrfStatusTracker(); 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new BrfStatusTracker();
		} finally {
			em.close();
		}
	}

	@Override
	public List<OldSoDTO> getOldSoList(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		try {
			
			List<OldSoDTO> oldSoDTOList = new ArrayList<OldSoDTO>();
			OldSoDTO oldSoDTO = null;
			/*
			query = em.createNativeQuery("select "
					+ " distinct bsd.old_so_num,bsd.new_so_num,bsd.tent_act_date,bsd.new_so_act_date "
					+ " from brf_so_details bsd inner join brf b " 
					+ " on bsd.brf_id = bsd.brf_id "  
					+ " where (bsd.is_file_sent='N' or bsd.is_file_sent='' or bsd.is_file_sent is null) and b.bw_allocation='ES' and bsd.old_so_num !='' and b.status_mst_id=21  ");
			*/
			
			query = em.createNativeQuery("select "
					+ " distinct bsd.old_so_num,bsd.new_so_num,DATEADD(DAY, -1, bsd.new_so_act_date)as tentActDate,bsd.new_so_act_date"
					+ " from brf_so_details bsd inner join brf b on bsd.brf_id = bsd.brf_id  "
					+ " where (bsd.is_file_sent='N' or bsd.is_file_sent='' or bsd.is_file_sent is null) and b.bw_allocation='ES' "
					+ " and bsd.old_so_num is not null and bsd.old_so_num !='' and bsd.old_so_num is not null "
					+ " and new_so_act_date is not null and b.status_mst_id=21");
			
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			if( resultList!=null && resultList.size()>0) { 
			
			for (Object[] objects : resultList) {
				oldSoDTO = new OldSoDTO();
				oldSoDTO.setOldSoNum((String) objects[0]);
				if(objects[1] != null) {
				oldSoDTO.setNewSoNum((String) objects[1]);
				}
				if(objects[3] != null) {
				oldSoDTO.setTentActDate(DateUtil.convertDateTimeToString(objects[2].toString()).replace('-', '.'));
				}
				if(objects[3] != null) {
				oldSoDTO.setNewSoActDate(DateUtil.convertDateTimeToString(objects[3].toString()).replace('-', '.'));
				}
				oldSoDTOList.add(oldSoDTO);
			}
			}else {
				oldSoDTOList = new ArrayList<OldSoDTO>();
				}
			return oldSoDTOList;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<OldSoDTO>();
		} finally {
			em.close();
		}
	}

	@Override
	public Integer getBrfCountByContractNum(String contractNum) {
		// TODO Auto-generated method stub
				Integer numOfBrf = null;
			
				try {
					query = em.createNativeQuery("select count(b.contract_num)  as num_of_brf from brf b where  b.contract_num =?1 GROUP BY b.contract_num");
					query.setParameter(1, contractNum);
					
					Object resultList = (Object) query.getSingleResult();
					if( resultList!=null) { 
						numOfBrf = (Integer) resultList;
					}
					return numOfBrf;
					
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return 0;
				} finally {
					em.close();
				}
	}

	@Override
	public MaterialChildContract getMaterialChildContractById(Integer childContractId) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("MaterialChildContract.getMatListChildContById");
			query.setParameter(1, childContractId);
			query.setMaxResults(1);
			MaterialChildContract materialChildContract = (MaterialChildContract) query.getSingleResult();
			
			return materialChildContract;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new MaterialChildContract();
		} finally {
			em.close();
		}
	}

	@Override
	public BrfSoDetails saveBrfSoDetails(BrfSoDetails brfSoDetails) {
		try {
			// TODO Auto-generated method stub
			brfSoDetails.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
			BrfSoDetails brfSoDetailsNew = em.merge(brfSoDetails);
			if (brfSoDetails.getBrfSoDetailsId() == null) {
				em.refresh(brfSoDetailsNew);
			}
			return brfSoDetailsNew;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<OppUploadDetail> getUploadDetailsByBrfId(Integer brfId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("OppUploadDetail.findByBrfId");
			query.setParameter(1, brfId);
			return (List<OppUploadDetail>) query.getResultList();
		} finally {
			em.close();
		}
	}

	@Override
	public Integer getRemainNumSiteByContractNum(String contractNum) {
		// TODO Auto-generated method stub
		Integer brfNumOfSiteCreated = null;
	
		try {
			
			/*
			query = em.createNativeQuery(" select (a.availQty-b.brfQty) as remainNumSite from ("
					+ " select cast(mcc.order_qty as int) as availQty,cc.sap_contract_num as sapContractNum from material_child_contract mcc "
					+ " inner join child_contract cc on mcc.child_contract_id = cc.child_contract_id "
					+ " where mcc.item_no = '10' and cc.sap_contract_num =?1) a left join "
					+ " (select  contract_num as brfContract,sum(cast(site_name as int)) as brfQty from brf where status_mst_id != 22 group by contract_num) b "
					+ " on a.sapContractNum = b.brfContract where b.brfContract =?2 ");
			*/
			
			query = em.createNativeQuery(" select  sum(cast(site_name as int)) as brfQty from brf where contract_num =?1 group by contract_num  ");
			
			query.setParameter(1, contractNum);
//			query.setParameter(2, contractNum);
			
			Object resultList = (Object) query.getSingleResult();
			if( resultList!=null) { 
				brfNumOfSiteCreated = (Integer) resultList;
			}
			return brfNumOfSiteCreated;
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		} finally {
			em.close();
		}
	}

	@Override
	public void deleteBrfSoDetByBrfId(Integer brfId) {
		// TODO Auto-generated method stub
		query = em.createNativeQuery("delete from brf_so_details where brf_id = ?1 ");
		query.setParameter(1, brfId);
		query.executeUpdate();
	}

	@Override
	public List<BrfStatusTracker> getBrfStatusTrack(BrfDTO brfDTO) {
		try {
			query = em.createNamedQuery("BrfStatusTracker.getBrfStatusTrackByBrfId");
			query.setParameter(1, brfDTO.getBrfId());
			return (List<BrfStatusTracker>) query.getResultList();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<BrfStatusTracker>();
		} finally {
			em.close();
		}
	}

	@Override
	public void uploadFile(MultipartFile file, String userId, String brfId) throws Exception {
		HSSFWorkbook workbook = new HSSFWorkbook(file.getInputStream());
		HSSFRow row = null;
		int i = 1;
		BigDecimal oldSoNum = null;
		BigDecimal newSoNum = null;
		HSSFSheet worksheet = workbook.getSheetAt(0);
		while (i <= worksheet.getLastRowNum()) {
			row = worksheet.getRow(i++);

			BrfSoDetails brfSoDetails = new BrfSoDetails();

			if (!(String.valueOf(row.getCell(0)).equals("") || String.valueOf(row.getCell(0)).equals("null"))) {
				brfSoDetails.setBrfId(Integer.parseInt(brfId));
				try {
					oldSoNum = new BigDecimal(String.valueOf(row.getCell(0)));
					brfSoDetails.setOldSoNum(oldSoNum.toPlainString());
				} catch(NumberFormatException ex) {
					brfSoDetails.setOldSoNum(String.valueOf(row.getCell(0)));
				}
//				System.out.print("Old So " + oldSoNum.toPlainString());
				try {
					newSoNum = new BigDecimal(String.valueOf(row.getCell(1)));
					brfSoDetails.setNewSoNum(newSoNum.toPlainString());
				} catch (Exception e) {
					brfSoDetails.setNewSoNum(String.valueOf(row.getCell(1)));
				}
				
//				System.out.println(" New So " + newSoNum.toPlainString()  + "row no. " +i );
				
				brfSoDetails.setExistingSite(String.valueOf(row.getCell(2)));
				brfSoDetails.setTechnology(String.valueOf(row.getCell(3)));
				brfSoDetails.setBrfPlan(String.valueOf(row.getCell(4)));
				brfSoDetails.setBandwidth(String.valueOf(row.getCell(5)));
				String tentActDateNew = DateUtil.convertDateToSqlDate(String.valueOf(row.getCell(6)));
				brfSoDetails.setTentActDate(tentActDateNew);
				brfSoDetails.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
				em.merge(brfSoDetails);

			}
		}

	}

	public int getCount(String table, String column, String value) {
		String lQuery = "select count(*) from " + table + " where " + column + "=?1";
		query = em.createNativeQuery(lQuery);
		query.setParameter(1, value);
		int num = (int) query.getSingleResult();
		return num;
	}

	@Override
	public void softDeleteByOpUpDetId(Integer oppUploadDetailsId) {
		query = em.createNativeQuery(" update opp_upload_details set is_delete='Y' where opp_upload_details_id= ?1 ");
		query.setParameter(1, oppUploadDetailsId);
		query.executeUpdate();
	}

	@Override
	public UserToHubDTO getUserAndHubDetByHubMstId(Integer hubMstId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNativeQuery("select um.user_mst_id,um.user_name,um.user_email,um.is_active,um.dept_mst_id,"
					+ " um.sub_dept_mst_id,um.role_mst_id,um.zone_mst_id,um.head_flg,um.password,um.login_id,um.sm_owner_id,um.org_code,"
					+ " hm.hub_mst_id,hm.hub_code,hm.hub_desc,hm.is_active as hubIsActive,hm.noc_insta_email "
					+ " from user_to_hub uth "
					+ " inner join user_mst um on uth.user_mst_id = um.user_mst_id "
					+ " inner join role_mst rm on um.role_mst_id = rm.role_mst_id "
					+ " inner join hub_mst hm on uth.hub_mst_id = hm.hub_mst_id "
					+ " where rm.role_cd = 'NOCMGR' and um.is_active = 'Y' and uth.hub_mst_id = ?1 ");
			
			query.setParameter(1, hubMstId);
			
			UserToHubDTO userToHubDTO = null;
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			
			for (Object[] objects : resultList) {
				userToHubDTO = new UserToHubDTO();
				
				userToHubDTO.setUserMstId((Integer) objects[0]);
				userToHubDTO.setUserName((String) objects[1]);
				userToHubDTO.setUserEmail((String) objects[2]);
				userToHubDTO.setIsUserActive(String.valueOf(objects[3]));
				userToHubDTO.setDeptMstId((Integer) objects[4]);
				userToHubDTO.setSubDepMstId((Integer) objects[5]);
				userToHubDTO.setRoleId((Integer) objects[6]);
				userToHubDTO.setZoneMstId((Integer) objects[7]);
				userToHubDTO.setHeadFlag(String.valueOf(objects[8]));
				userToHubDTO.setPassword((String) objects[9]);
				userToHubDTO.setLoginId((String) objects[10]);
				userToHubDTO.setSmOwnerId((String) objects[11]);
				userToHubDTO.setOrgCode((String) objects[12]);
				userToHubDTO.setHubMstId((Integer) objects[13]);
				userToHubDTO.setHubCode((String) objects[14]);
				userToHubDTO.setHubDesc((String) objects[15]);
				userToHubDTO.setIsHubActive(String.valueOf(objects[16]));
				userToHubDTO.setNocInstaEmail((String) objects[17]);
		}
			
		return userToHubDTO;
			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new UserToHubDTO();
		} finally {
			em.close();
		}
		
	}

	@Override
	public List<MaterialChildContract> materialListByChildContId(Integer childContractId) {
		try {

			query = em.createNamedQuery("MaterialChildContract.materialListByChildContId");
			query.setParameter(1, childContractId);
			List<MaterialChildContract> materialChildContractList = (List<MaterialChildContract>) query.getResultList();
			
			return materialChildContractList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<MaterialChildContract>();
		} finally {
			em.close();
		}
	}

	@Override
	public Integer sumOfOrderQtyByChildContId(Integer childContractId) {
		Integer sumOfOrderQty = null;
		try {

			query = em.createNamedQuery("MaterialChildContract.sumOfOrderQtyByChildContId");
			query.setParameter(1, childContractId);
		
		Object resultList = (Object) query.getSingleResult();
		if( resultList!=null) { 
			sumOfOrderQty = (int) (long) resultList;
		}
		return sumOfOrderQty;
		
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return 0;
	} finally {
		em.close();
	}
	}

	@Override
	public List<BrfSoDetails> brfSoDetListByBrfId(BrfDTO brfDTO) {
		// TODO Auto-generated method stub
				try {
			String queryString = "";
					queryString = " select * from ( select top 50 * from (  "
							+ " select bsd.brf_so_details_id,bsd.brf_id as bsd_brf_id,bsd.old_so_num as bsd_old_so_num ,bsd.new_so_num as bsd_new_so_num,"
				+ " bsd.existing_site as bsd_existing_site, bsd.technology as bsd_technology,bsd.brf_plan as bsd_brf_plan,"
				+ " bsd.bandwidth as bsd_bandwidth,bsd.tent_act_date as bsd_tent_act_date,bsd.new_so_act_date as bsd_new_so_act_date,"
				+ " bsd.modified_date as bsd_modified_date,bsd.created_date as bsd_created_date,ROW_NUMBER() OVER(ORDER BY bsd.brf_so_details_id ASC) AS rowNumber "
				+ " from brf_so_details bsd "
				+ " where bsd.brf_id =?1 ";
		
		if(brfDTO.getIsNext().equals("Y")) {
			
			queryString = queryString + " ) tbl1 where tbl1.rowNumber > ?2 order by tbl1.rowNumber*(+1) asc)tbl2 order by tbl2.rowNumber ";
			query = em.createNativeQuery(queryString);
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			query.setParameter(1, brfDTO.getBrfId());
			query.setParameter(2, brfDTO.getRowNumber());
			
			}
			if(brfDTO.getIsNext().equals("N")) {
				
				queryString = queryString + "  ) tbl1 where tbl1.rowNumber < ?2 order by tbl1.rowNumber*(-1) asc)tbl2 order by tbl2.rowNumber  ";
				query = em.createNativeQuery(queryString);
				query.setHint("org.hibernate.cacheable", Boolean.TRUE);
				query.setParameter(1, brfDTO.getBrfId());;
				query.setParameter(2, brfDTO.getRowNumber());
			}
				
		query.setMaxResults(50);
		List<Object[]> resultList = (List<Object[]>) query.getResultList();
		List<BrfSoDetails> brfSoDetailsList = new ArrayList<BrfSoDetails>();
		BrfSoDetails brfSoDetails = null;
		for (Object[] objects : resultList) {
			brfSoDetails = new BrfSoDetails();
			brfSoDetails.setBrfSoDetailsId((Integer) objects[0]);
			brfSoDetails.setBrfId((Integer) objects[1]);
			brfSoDetails.setOldSoNum((String) objects[2]);
			brfSoDetails.setNewSoNum((String) objects[3]);
			brfSoDetails.setExistingSite((String) objects[4]);
			brfSoDetails.setTechnology((String) objects[5]);
			brfSoDetails.setBrfPlan((String) objects[6]);
			brfSoDetails.setBandwidth((String) objects[7]);
			
			if(objects[8] != null) {
			brfSoDetails.setTentActDate(DateUtil.convertDateTimeToString(objects[8].toString()));
			}
			if(objects[9] != null) {				
			brfSoDetails.setNewSoActDate(DateUtil.convertDateTimeToString(objects[9].toString()));
			}
			if(objects[10] != null) {
			brfSoDetails.setModifiedDate(DateUtil.convertDateTimeToString(objects[10].toString()));
			}
			if(objects[11] != null) {
			brfSoDetails.setCreatedDate(DateUtil.convertDateTimeToString(objects[11].toString()));
			}
			brfSoDetails.setRowNumber(((BigInteger) objects[12]).intValue());
			brfSoDetailsList.add(brfSoDetails);
						
		}
		return brfSoDetailsList;

	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		return new ArrayList<BrfSoDetails>();
	} finally {
		em.close();
	}
}

	@Override
	public List<BrfDetailsDTO> brfListToFillGeoTemplate(BrfDetailsListDTO brfDetailsListDTO) {	
		// TODO Auto-generated method stub
		try {
			String queryString = "";
			String fromDate = DateUtil.convertDateToSqlDate(brfDetailsListDTO.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(brfDetailsListDTO.getToDate());
			
/*				
			queryString = "select distinct c.con_start_date,c.con_end_date,c.sap_contract_num,c.quarter,c.market_segment,"
					+ " b.brf_id,um.user_mst_id as acco_mgr,b.bandwidth,b.brf_plan,b.bw_allocation,b.contract_num,b.created_date,b.existing_site,"
					+ " b.product,b.old_so_num,c.po_number,b.site_name,con.sold_to_party,"
					+ " bsm.status_mst_id,bsm.status_name,bsm.status_code,b.technology,b.tent_act_date,c.child_contract_id,b.finance_id,"
					+ " b.noc_mgr_id,b.prog_mgr,b.regulatory_id,b.sales_org,b.dist_channel,b.division,b.finance_remark,b.noc_remark,"
					+ " csm.customer_name, um.user_name as acco_mgr_name,csm.customer_sapmst_id,b.pm_remark,b.hub_mst_id,hm.hub_desc "
					+ " from child_contract c " + " inner join contract con on c.contract_id = con.contract_id "
					+ " inner join proposal p on con.proposal_id = p.proposal_id "
//					+ " inner join service_order_mst som on som.service_order_det_id = con.service_order_det_id "
					+ " inner join brf b on c.child_contract_id = b.child_contract_id "
					+ " inner join customer_sapmst csm on (con.sold_to_party = csm.customer_num and con.dist_channel=csm.dist_channel and con.division=csm.division and con.sales_org=csm.sales_org) "
					+ " inner join user_mst um on um.sm_owner_id = p.smowner_id "
					+ " inner join hub_mst hm  on b.hub_mst_id = hm.hub_mst_id "
					+ " inner join process_mst pm on b.regu_proce_mst_id = pm.process_mst_id ";

			if (brfDetailsListDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)){
				queryString = queryString + " inner join status_mst bsm on b.status_mst_id = bsm.status_mst_id "
						+ " where con.sales_org = 'TNET' and c.sap_contract_num is not null and b.created_date between ?1 and ?2 ";
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCMGRCODE)
					|| brfDetailsListDTO.getRoleCode().equals(Constants.OPERATIONSHEADCODE)
					|| brfDetailsListDTO.getRoleCode().equals(Constants.NOCENGINEERCODE)) {
				queryString = queryString + " inner join geo_template gt on b.brf_id = gt.brf_id "
						+ " inner join status_mst bsm on b.status_mst_id = bsm.status_mst_id "
						+ " inner join status_mst gsm on gt.status_mst_id = gsm.status_mst_id "
						+ " inner join user_to_hub uth on b.hub_mst_id = uth.hub_mst_id "
						+ " where con.sales_org = 'TNET' and c.sap_contract_num is not null and b.created_date between ?1 and ?2 ";
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.REGULATORYHEAD)) {
				queryString = queryString + " inner join geo_template gt on b.brf_id = gt.brf_id "
						+ " inner join status_mst bsm on b.status_mst_id = bsm.status_mst_id "
						+ " inner join user_to_process utp on b.regu_proce_mst_id = utp.process_mst_id "
						+ " inner join status_mst gsm on gt.status_mst_id = gsm.status_mst_id "
						+ " where con.sales_org = 'TNET' and c.sap_contract_num is not null and b.created_date between ?1 and ?2 ";
			}

			if (brfDetailsListDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)) {
					queryString = queryString + "  and c.pm_id=?3 and bsm.status_code in('BRFSTF','BRFSTNOC','BRFA','BRFR') ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getUserMstId());
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCENGINEERCODE)) {
					queryString = queryString + " and gsm.status_code in('GTSTN','GTSTREG','RUSACFAN','RSSNICSN') and uth.user_mst_id=?3 ";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, brfDetailsListDTO.getUserMstId());
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.NOCMGRCODE)
					|| brfDetailsListDTO.getRoleCode().equals(Constants.OPERATIONSHEADCODE)) {
					queryString = queryString
							+ " and gsm.status_code in('GTSTN','GTSTREG','RUSACFAN','RSSNICSN')";
					query = em.createNativeQuery(queryString);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
			} else if (brfDetailsListDTO.getRoleCode().equals(Constants.REGULATORYHEAD)) {
				queryString = queryString + " and utp.user_mst_id = ?3 and gsm.status_code in('GTSTREG','RUSACFAN','RSSNICSN') ";
				query = em.createNativeQuery(queryString);
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, brfDetailsListDTO.getUserMstId());
			}
			*/
			
			List<BrfDetailsDTO> brfDetailsDTOList = new ArrayList<BrfDetailsDTO>();
			BrfDetailsDTO brfDetailsDTO = null;
			List<MaterialChildContract> materialChildContractList = null;	
			
			spQuery = em.createStoredProcedureQuery("isp_getBrfListToFillGeoTemplate")
					.registerStoredProcedureParameter("fromDate", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("toDate", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("userMstId", Integer.class, ParameterMode.IN)
					.registerStoredProcedureParameter("roleCode", String.class, ParameterMode.IN);
			spQuery.setParameter("fromDate", fromDate)
					.setParameter("toDate", toDate + " 23:59:59")
					.setParameter("userMstId", brfDetailsListDTO.getUserMstId())
					.setParameter("roleCode", brfDetailsListDTO.getRoleCode());
			
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) spQuery.getResultList();

			for (Object[] objects : resultList) {
				brfDetailsDTO = new BrfDetailsDTO();

				brfDetailsDTO.setConStartDate(DateUtil.convertDateTimeToString(objects[0].toString()));
				brfDetailsDTO.setConEndDate(DateUtil.convertDateTimeToString(objects[1].toString()));
				brfDetailsDTO.setSapContractNum((String) objects[2]);
				brfDetailsDTO.setQuarter((String) objects[3]);
				brfDetailsDTO.setMarketSegment((String) objects[4]);
				brfDetailsDTO.setBrfId((Integer) objects[5]);
				brfDetailsDTO.setAccoMgr((Integer) objects[6]);
				brfDetailsDTO.setBandwidth((String) objects[7]);
				brfDetailsDTO.setBrfPlan((String) objects[8]);
				brfDetailsDTO.setBwAllocation((String) objects[9]);
				brfDetailsDTO.setContractNum((String) objects[2]);
				if (objects[11] != null) {
					brfDetailsDTO.setCreatedDate(DateUtil.convertDateTimeToString(objects[11].toString()));
				}
				brfDetailsDTO.setExistingSite((String) objects[12]);
				brfDetailsDTO.setProduct((String) objects[13]);
				brfDetailsDTO.setOldSoNum((String) objects[14]);
				brfDetailsDTO.setPoNum((String) objects[15]);
				brfDetailsDTO.setSiteName((String) objects[16]);
				brfDetailsDTO.setSoldToParty((String) objects[17]);
				brfDetailsDTO.setStatusMstId((Integer) objects[18]);
				brfDetailsDTO.setStatusName((String) objects[19]);
				brfDetailsDTO.setStatusCode((String) objects[20]);
				brfDetailsDTO.setTechnology((String) objects[21]);
				if (objects[22] != null) {
					brfDetailsDTO.setTentActDate(DateUtil.convertDateTimeToString(objects[22].toString()));
				}
				brfDetailsDTO.setChildContractId((Integer) objects[23]);
				brfDetailsDTO.setFinanceId((Integer) objects[24]);
				brfDetailsDTO.setNocMgrId((Integer) objects[25]);
				brfDetailsDTO.setProgMgr((Integer) objects[26]);
				brfDetailsDTO.setRegulatoryId((Integer) objects[27]);
				brfDetailsDTO.setSalesOrg((String) objects[28]);
				brfDetailsDTO.setDistChannel((String) objects[29]);
				brfDetailsDTO.setDivision((String) objects[30]);
				brfDetailsDTO.setFinanceRemark((String) objects[31]);
				brfDetailsDTO.setNocRemark((String) objects[32]);
				brfDetailsDTO.setCustomerName((String) objects[33]);
				brfDetailsDTO.setAccoMgrName((String) objects[34]);
				brfDetailsDTO.setPmRemark((String) objects[36]);
				brfDetailsDTO.setHubMstId((Integer) objects[37]);
				brfDetailsDTO.setHubDesc((String) objects[38]);

				if (objects[2] != null) {
					brfDetailsDTO.setNumOfBrf(this.getBrfCountByContractNum((String) objects[2]));
				}

				if (objects[2] != null) {
//					materialChildContract = new MaterialChildContract();
//					materialChildContract = this.getMaterialChildContractById((Integer) objects[23]);
//					brfDetailsDTO.setMaterialDesc(materialChildContract.getMaterialDesc());
					
					materialChildContractList = new ArrayList<MaterialChildContract>() ;
					materialChildContractList = this.materialListByChildContId((Integer) objects[23]);
					brfDetailsDTO.setMaterialChildContractList(materialChildContractList);
					brfDetailsDTO.setOrderQty(this.sumOfOrderQtyByChildContId((Integer) objects[23]));
				}
				if (objects[2] != null) {
					brfDetailsDTO.setBrfNumOfSiteCreated(this.getRemainNumSiteByContractNum((String) objects[2]));
				}

//				brfDetailsDTO.setItem((String) objects[36]);
//				brfDetailsDTO.setMaterialNum((String) objects[37]);
//				brfDetailsDTO.setSoOrdersId((Integer)objects[38]);
//				brfDetailsDTO.setCustomerName((String) objects[39]);
				if (objects[35] != null) {
					CustomerSapmst customerSapmst = new CustomerSapmst();
					CustomerMstDTO customerMstDTO = new CustomerMstDTO();
					customerMstDTO.setCustomerSapmstId((Integer) objects[35]);
					customerSapmst = customerMstDao.getCustomerdetailsByCustomerNum(customerMstDTO);
					brfDetailsDTO.setCustomerSapmst(customerSapmst);
				}

				brfDetailsDTOList.add(brfDetailsDTO);
			}

			return brfDetailsDTOList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<BrfDetailsDTO>();
		} finally {
			em.close();
		}
	}

}
