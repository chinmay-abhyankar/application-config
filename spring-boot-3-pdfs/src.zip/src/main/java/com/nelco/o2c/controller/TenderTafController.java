/**
 * 
 */
package com.nelco.o2c.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.PreCriteriaDTO;
import com.nelco.o2c.dto.TafDetailsDTO;
import com.nelco.o2c.dto.TafDropDownDTO;
import com.nelco.o2c.dto.TenderTafDTO;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.service.TenderTafService;

/**
 * @author Jayashankar.r
 *
 */
@RestController
public class TenderTafController {

	@Autowired
	TenderTafService tenderTafService;

	@RequestMapping(value = "/getOppDetails.do", method = RequestMethod.POST)
	public TenderTafDTO getOppDetails(@RequestBody CommonDTO commonDTO) {
		return tenderTafService.getOppDetails(commonDTO);
	}

	@RequestMapping(value = "/saveOppDetails.do", method = RequestMethod.POST)
	public TenderTafDTO saveOppDetails(@RequestBody TenderTafDTO tenderTafDTO) {
		return tenderTafService.saveOppDetailsCall(tenderTafDTO);
	}

	@RequestMapping(value = "/uploadTempFile.do", method = RequestMethod.POST)
	@CrossOrigin
	public OppUploadDetail uploadTempFile(MultipartHttpServletRequest request,
			/* @RequestBody MultipartFile uploadFile */@RequestParam String fileTypeMstId,
			@RequestParam String upFileName) {
		Iterator<String> fileNames = request.getFileNames();
		OppUploadDetail uploadTempFileDTO = null;
		if (fileNames.hasNext()) {
			MultipartFile file = request.getFile(fileNames.next());
			uploadTempFileDTO = tenderTafService.uploadTempFile(file, fileTypeMstId, upFileName);
		}

		return uploadTempFileDTO;

	}

	@RequestMapping(value = "/downloadFile.do", method = {RequestMethod.POST,RequestMethod.GET})
	@CrossOrigin
	public void downLoadFile(HttpServletResponse response, @RequestParam String fileName,
			@RequestParam String filePath) {
		try {
			response.setContentType("application/download");
			response.setHeader("Content-Disposition", "attachment; filename=" + fileName.replace(" ", "_"));
			FileInputStream fis1;
			fis1 = new FileInputStream(filePath);
			ServletOutputStream out;
			out = response.getOutputStream();
			int j = 0;
			while ((j = fis1.read()) != -1) {
				out.write(j);
			}
			fis1.close();
			out.flush();
		} catch (IOException e) {
			e.getMessage();
			e.printStackTrace();
		}
	}

	@RequestMapping(value = "/getTafDropDowns.do", method = RequestMethod.GET)
	public TafDropDownDTO getTafDropDowns() {
		return tenderTafService.getTafDropDowns();
	}

	@RequestMapping(value = "/getTafDetails.do", method = RequestMethod.POST)
	public TafDetailsDTO getTafDetails(@RequestBody CommonDTO commonDTO) {
		return tenderTafService.getTafDetails(commonDTO);
	}

	@RequestMapping(value = "/getPreCriteria.do", method = RequestMethod.POST)
	public PreCriteriaDTO getPreCriterias(@RequestBody CommonDTO commonDTO) {
		return tenderTafService.getPreCriterias(commonDTO);
	}
	
	@RequestMapping(value = "/savePreCriteria.do", method = RequestMethod.POST)
	public PreCriteriaDTO savePreCriterias(@RequestBody PreCriteriaDTO preCriteriaInputDTO) {
		return tenderTafService.savePreCriterias(preCriteriaInputDTO);
	}
	
	@RequestMapping(value="/saveTafDetails.do", method = RequestMethod.POST)
	public TafDetailsDTO saveTafDetails(@RequestBody TafDetailsDTO tafDetailsInputDTO) {
		
		return tenderTafService.saveTafDetails(tafDetailsInputDTO);
	}
	
	@RequestMapping(value="/submitTafDetails.do", method = RequestMethod.POST)
	public CommonDTO submitTafDetails(@RequestBody CommonDTO commonDTO,HttpServletRequest request) {
		return tenderTafService.submitTaf(commonDTO,request);
	}
	
	
	@RequestMapping(value="/rejectTafDetails.do", method = RequestMethod.POST)
	public CommonDTO rejectTafDetails(@RequestBody CommonDTO commonDTO,HttpServletRequest request) {
		return tenderTafService.rejectTaf(commonDTO,request);
	}
}
