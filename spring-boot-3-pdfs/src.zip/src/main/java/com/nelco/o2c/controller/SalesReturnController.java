package com.nelco.o2c.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.InvoiceDTO;
import com.nelco.o2c.dto.MaterialDetailsDTO;
import com.nelco.o2c.dto.MaterialStatusUpdateDTO;
import com.nelco.o2c.dto.SalesReturnDTO;
import com.nelco.o2c.dto.SalesReturnFormDTO;
import com.nelco.o2c.dto.SalesReturnListDTO;
import com.nelco.o2c.dto.SalesReturnSaveDTO;
import com.nelco.o2c.dto.SiteSurveyDTO;
import com.nelco.o2c.dto.SiteSurveyFormDTO;
import com.nelco.o2c.dto.StatusBean;
import com.nelco.o2c.model.CreditNoteBwMst;

import com.nelco.o2c.model.CreditNoteEquipMst;
import com.nelco.o2c.model.SalesReturnMst;
import com.nelco.o2c.model.SiteSurveyMaster;
import com.nelco.o2c.service.SalesReturnService;

@RestController
public class SalesReturnController {
	@Autowired
	SalesReturnService service;

	// This is for getting masters
	@RequestMapping(value = "/getSalesReturnMasters.do", method = RequestMethod.GET)
	public SalesReturnDTO getSalesReturnMasters() {
		SalesReturnDTO salesReturnDTO = new SalesReturnDTO();
		service.getSalesReturnMasters(salesReturnDTO);
		return salesReturnDTO;
	}

	// This is for getting equipment invoice list ajax auto complete for sales
	// team
	@RequestMapping(value = "/getListInvoiceAutoComplete.do", method = RequestMethod.GET)
	public SalesReturnDTO getListInvoiceAutoComplete(HttpServletRequest request) {
		SalesReturnDTO salesReturnDTO = new SalesReturnDTO();
		salesReturnDTO.setLstInvoiceDTO(service.getListInvoiceAutoComplete(request));
		return salesReturnDTO;
	}

	// This is for getting invoice list ajax auto complete for sales team
	@RequestMapping(value = "/getListInvoiceBWAutoComplete.do", method = RequestMethod.GET)
	public SalesReturnDTO getListInvoiceBWAutoComplete(HttpServletRequest request) {
		SalesReturnDTO salesReturnDTO = new SalesReturnDTO();
		salesReturnDTO.setLstInvoiceDTO(service.getListInvoiceBWAutoComplete(request));
		return salesReturnDTO;
	}

	// This is for getting invoice list ajax auto complete for sales team
	@RequestMapping(value = "/getMaterialDetailsAutoComplete.do", method = RequestMethod.GET)
	public SalesReturnDTO getMaterialDetailsAutoComplete(HttpServletRequest request) {
		SalesReturnDTO salesReturnDTO = new SalesReturnDTO();
		salesReturnDTO.setLstMaterialDetailsDTO(service.getMaterialDetailsAutoComplete(request));
		return salesReturnDTO;
	}

	// This is for getting list of Sales Return Request For Sales Team
	@RequestMapping(value = "/getSalesReturnRequestForSalesTeam.do", method = RequestMethod.GET)
	public List<SalesReturnListDTO> getSalesReturnRequestForSalesTeam(HttpServletRequest request) {
		return service.getSalesReturnRequestForSalesTeam(request);
	}

	// This is for getting list of Sales Return Request For NOC Team For
	// Installed Type Of Request
	@RequestMapping(value = "/getSalesReturnRequestForNOCTeam.do", method = RequestMethod.GET)
	public List<SalesReturnListDTO> getSalesReturnRequestForNOCTeam(HttpServletRequest request) {
		return service.getSalesReturnRequestForNOCTeam(request);
	}

	// This is for getting list of Sales Return Request For Stores Team
	@RequestMapping(value = "/getSalesReturnRequestForStoresTeam.do", method = RequestMethod.GET)
	public List<SalesReturnListDTO> getSalesReturnRequestForStoresTeam(HttpServletRequest request) {
		return service.getSalesReturnRequestForStoresTeam(request);
	}

	// This is for getting list of Sales Return Request For Stores Team
	@RequestMapping(value = "/getEquipmentCrNoById.do", method = RequestMethod.GET)
	public CreditNoteEquipMst getEquipmentCrNoById(HttpServletRequest request) {
		return service.getEquipmentCrNoById(request);
	}
	
	// This is for getting list of Sales Return Request For Stores Team
		@RequestMapping(value = "/getBandWidthCrNoById.do", method = RequestMethod.GET)
		public CreditNoteBwMst getBandWidthCrNoById(HttpServletRequest request) {
			return service.getBandWidthCrNoById(request);
		}

	// This is for getting Sales Return Request By Id
	@RequestMapping(value = "/getSalesReturnRequestById.do", method = RequestMethod.GET)
	public SalesReturnSaveDTO getSalesReturnRequestById(HttpServletRequest request) {
		return service.getSalesReturnRequestById(request);
	}

	// For Saving Sales Return Request
	@RequestMapping(value = "/saveSalesReturn.do", method = RequestMethod.POST)
	public SalesReturnMst saveSalesReturn(@RequestBody SalesReturnFormDTO salesReturnFormDTO) {
		return service.saveSalesReturn(salesReturnFormDTO);
	}

	// Update NOC Remarks
	@RequestMapping(value = "/updateNOCRemarks.do", method = RequestMethod.POST)
	public SalesReturnMst updateNOCRwmarks(@RequestBody SalesReturnFormDTO salesReturnFormDTO) {
		return service.updateNOCRwmarks(salesReturnFormDTO);
	}

	// This is for updating Sales Return Status
	@RequestMapping(value = "/updateMaterialReturn.do", method = RequestMethod.POST)
	public SalesReturnMst updateMaterialReturn(@RequestBody SalesReturnFormDTO salesReturnFormDTO) {
		return service.updateMaterialReturn(salesReturnFormDTO);
	}

	// This is for updating Sales Return Status
	@RequestMapping(value = "/updateMultipleMaterialReturn.do", method = RequestMethod.POST)
	public StatusBean updateMultipleMaterialReturn(@RequestBody MaterialStatusUpdateDTO materialStatusUpdateDTO) {
		service.updateMultipleMaterialReturn(materialStatusUpdateDTO);
		return new StatusBean("success");
	}

	// For Submiting Sales Return Request
	@RequestMapping(value = "/submitSalesReturn.do", method = RequestMethod.POST)
	public SalesReturnMst submitSalesReturn(@RequestBody SalesReturnFormDTO salesReturnFormDTO) {
		return service.submitSalesReturn(salesReturnFormDTO);
	}
}
