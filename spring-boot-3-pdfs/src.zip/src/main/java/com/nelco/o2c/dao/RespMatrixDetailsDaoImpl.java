package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.PreSalesRespMatrix;
import com.nelco.o2c.model.RespMatrixDetails;

@Repository
public class RespMatrixDetailsDaoImpl implements RespMatrixDetailsDao {

	@PersistenceContext
	EntityManager em;

	Query query;

	@Override
	public List<RespMatrixDetails> getRespMatrixDetailsByUserMstIdAndOpId(Integer userMstId, Integer opportunityId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("RespMatrixDetails.getPreBidRespMatrixByUserMstIdAndOpId");
			query.setParameter(1, userMstId);
			query.setParameter(2, opportunityId);
			@SuppressWarnings("unchecked")
			List<RespMatrixDetails> respMatrixDetailsObj = (List<RespMatrixDetails>) query.getResultList();
			return respMatrixDetailsObj;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<RespMatrixDetails>();
		} finally {
			em.close();
		}
	}

	@Override
	public RespMatrixDetails saveRespMatrixDetails(RespMatrixDetails respMatrixDetails) {
		RespMatrixDetails respMatrixDetailsNew = em.merge(respMatrixDetails);
		if (respMatrixDetails.getRespMatrixDetailsId() == null) {
			em.refresh(respMatrixDetailsNew);
		}

		return respMatrixDetailsNew;
	}

	@Override
	public List<PreSalesRespMatrix> getPSMRespMatrixByUserMstIdAndOpId(Integer userMstId, Integer opportunityId,
			Integer respMatrixDetailsId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("PreSalesRespMatrix.getPSRespMatrixByUserMstIdAndOpId");
			query.setParameter(1, userMstId);
			query.setParameter(2, opportunityId);
			query.setParameter(3, respMatrixDetailsId);
			@SuppressWarnings("unchecked")
			List<PreSalesRespMatrix> preSalesRespMatrixObj = (List<PreSalesRespMatrix>) query.getResultList();
			return preSalesRespMatrixObj;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<PreSalesRespMatrix>();
		} finally {
			em.close();
		}
	}

	@Override
	public PreSalesRespMatrix savePSMRespMatrixDetails(PreSalesRespMatrix preSalesRespMatrix) {
		PreSalesRespMatrix preSalesRespMatrixNew = em.merge(preSalesRespMatrix);
		if (preSalesRespMatrix.getPreSalesRespMatrixId() == null) {
			em.refresh(preSalesRespMatrixNew);
		}

		return preSalesRespMatrixNew;
	}

	@Override
	public List<RespMatrixDetails> PSMgrRespMatrixDetByUserId(CommonDTO commonDTO) {
		try {
			query = em.createNamedQuery("RespMatrixDetails.findByRespPerId");
			query.setParameter(1, commonDTO.getUserMstId());
			@SuppressWarnings("unchecked")
			List<RespMatrixDetails> respMatrixDetailsObjs = (List<RespMatrixDetails>) query.getResultList();
			return respMatrixDetailsObjs;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<RespMatrixDetails>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<OppDetails> getOppDetailsbyOpId(Integer opportunityId) {
		try {
			query = em.createNamedQuery("OppDetails.getOppDetbyOppId");
			query.setParameter(1, opportunityId);
			@SuppressWarnings("unchecked")
			List<OppDetails> oppDetailsList = (List<OppDetails>) query.getResultList();

			return oppDetailsList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<OppDetails>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<OppUploadDetail> getRiskDocumentsbyOppId(Integer opportunityId) {
		try {
			query = em.createNamedQuery("OppUploadDetail.findByOppIdInDesc");
			query.setParameter(1, opportunityId);
			@SuppressWarnings("unchecked")
			List<OppUploadDetail> oppDetailsList = (List<OppUploadDetail>) query.getResultList();

			return oppDetailsList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<OppUploadDetail>();
		} finally {
			em.close();
		}
	}

	@Override
	public RespMatrixDetails getRMDByRespMatrixDetailsId(Integer respMatrixDetailsId) {
		try {

			query = em.createNamedQuery("RespMatrixDetails.getByRespMatrixDetailsId");
			query.setParameter(1, respMatrixDetailsId);
			RespMatrixDetails respMatrixDetails = (RespMatrixDetails) query.getSingleResult();
			return respMatrixDetails;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new RespMatrixDetails();
		} finally {
			em.close();

		}
	}
}
