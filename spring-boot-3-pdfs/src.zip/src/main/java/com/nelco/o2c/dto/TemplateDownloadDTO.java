package com.nelco.o2c.dto;

public class TemplateDownloadDTO {
	private String soNo="";
	private String customerName="";
	private String ip="";
	private String disconnectionRequestDate="";
	private String noticePeriod="";
	private String billingEndDate="";
	private String uniqueId="";
	private String requestId="";
	
	public String getSoNo() {
		return soNo;
	}
	public void setSoNo(String soNo) {
		this.soNo = soNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getDisconnectionRequestDate() {
		return disconnectionRequestDate;
	}
	public void setDisconnectionRequestDate(String disconnectionRequestDate) {
		this.disconnectionRequestDate = disconnectionRequestDate;
	}
	public String getNoticePeriod() {
		return noticePeriod;
	}
	public void setNoticePeriod(String noticePeriod) {
		this.noticePeriod = noticePeriod;
	}
	public String getBillingEndDate() {
		return billingEndDate;
	}
	public void setBillingEndDate(String billingEndDate) {
		this.billingEndDate = billingEndDate;
	}
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	
}
