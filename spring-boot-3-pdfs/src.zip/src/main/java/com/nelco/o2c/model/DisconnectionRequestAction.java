package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the disconnectionrequest_actions database table.
 * 
 */
@Entity
@Table(name="disconnection_request_actions")
@NamedQueries({
	@NamedQuery(name="DisconnectionRequestAction.findAll", query="SELECT d FROM DisconnectionRequestAction d"),
	@NamedQuery(name="DisconnectionRequestAction.updatePrevReminderStatus",query="UPDATE DisconnectionRequestAction d SET d.requestStatus=:requestStatus WHERE d.invoiceNo=:invoiceNo"),
	@NamedQuery(name="DisconnectionRequestAction.updateReminderStatus",query="UPDATE DisconnectionRequestAction d SET d.requestStatus=:requestStatus WHERE d.requestId=:requestId"),
//	@NamedQuery(name="DisconnectionrequestAction.getLatestRequestIdFromInvoiceNo", query="SELECT d.requestId,d.userid FROM DisconnectionrequestAction d  WHERE d.invoiceNo=:invoiceNo ORDER BY typeid")
	
})
@NamedNativeQueries({
	@NamedNativeQuery(name = "DisconnectionRequestAction.getReminderId", query = "SELECT CASE :actionType WHEN '1' THEN 'REM' WHEN '2' THEN 'NOT'END+'_'+FORMAT(GETDATE(),'dd')+'_'+FORMAT(GETDATE(),'MM')+'_'+FORMAT(GETDATE(),'yyyy')+'_'+CAST(COALESCE(MAX(typeid),0)+1 AS VARCHAR)FROM disconnection_request_actions"),
	@NamedNativeQuery(name="DisconnectionRequestAction.getLatestRequestIdFromInvoiceNo", query="SELECT TOP 1 d.request_id,d.userid FROM disconnection_request_actions d  WHERE d.invoice_no=:invoiceNo ORDER BY d.typeid DESC"),
	@NamedNativeQuery(name="DisconnectionRequestAction.getReminnderCount", query="SELECT COALESCE(MAX(d.request_count)+1,1) FROM disconnection_request_actions d  WHERE d.invoice_no=:invoiceNo AND d.action_type=:actionType")
	})

public class DisconnectionRequestAction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="typeid")
	private int typeid;

	@Column(insertable=false,updatable=false)
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String actflag;

	@Column(name="action_type")
	private String actionType;

	@Column(name="action_date")
	private String actionDate;

	private String attachment;
	
	@Column(insertable=false,updatable=false)
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Timestamp changedate;

	@Column(name="invoice_no")
	private String invoiceNo;

	@Column(name="request_count")
	private int requestCount;

	@Column(name="request_id")
	private String requestId;

	@Column(name="request_status")
	private String requestStatus;

	@Column(name="request_type")
	private String requestType;

	private String userid;
	
	@Column(name="severity")
	private String severity;
	
	@Transient
	private String noticeFlag="";
	
	@Transient
	private String requestStatusCode="";
	
	@Transient
	private OppUploadDetail oppUploadDetails; 
	

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public OppUploadDetail getOppUploadDetails() {
		return oppUploadDetails;
	}

	public void setOppUploadDetails(OppUploadDetail oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}

	public String getNoticeFlag() {
		return noticeFlag;
	}

	public void setNoticeFlag(String noticeFlag) {
		this.noticeFlag = noticeFlag;
	}

	public String getRequestStatusCode() {
		return requestStatusCode;
	}

	public void setRequestStatusCode(String requestStatusCode) {
		this.requestStatusCode = requestStatusCode;
	}

	

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public String getActionType() {
		return this.actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}


	public String getActionDate() {
		return actionDate;
	}

	public void setActionDate(String actionDate) {
		this.actionDate = actionDate;
	}

	public String getAttachment() {
		return this.attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

	public Timestamp getChangedate() {
		return this.changedate;
	}

	public void setChangedate(Timestamp changedate) {
		this.changedate = changedate;
	}

	public String getInvoiceNo() {
		return this.invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public int getRequestCount() {
		return this.requestCount;
	}

	public void setRequestCount(int requestCount) {
		this.requestCount = requestCount;
	}

	public String getRequestId() {
		return this.requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getRequestStatus() {
		return this.requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	public String getRequestType() {
		return this.requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

}