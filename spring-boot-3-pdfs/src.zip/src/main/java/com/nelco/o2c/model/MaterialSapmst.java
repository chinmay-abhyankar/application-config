package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the material_sapmst database table.
 * 
 */
@Entity
@Table(name = "material_sapmst")
@NamedQueries({ @NamedQuery(name = "MaterialSapmst.findAll", query = "SELECT m FROM MaterialSapmst m"),
		@NamedQuery(name = "MaterialSapmst.searchMaterial", query = " SELECT m FROM MaterialSapmst m where m.materialNo like ?1 or m.materialDesc like ?2 "),
		@NamedQuery(name = "MaterialSapmst.searchMaterialBySalesOrg", query = " SELECT m FROM MaterialSapmst m "
				+ " where m.salesOrg = ?1 and ( m.materialNo like ?2 or m.materialDesc like ?3 ) "),
		@NamedQuery(name = "MaterialSapmst.searchMaterialByPlant", query = " SELECT m FROM MaterialSapmst m "
				+ " where m.plant = ?1 and ( m.materialNo like ?2 or m.materialDesc like ?3 ) "),
		@NamedQuery(name = "MaterialSapmst.uniqueMaterial", query = " SELECT m FROM MaterialSapmst m "
				+ " where m.materialNo =?1 and m.plant = ?2 and m.salesOrg =?3 and m.distChannel =?4 "),
		@NamedQuery(name = "MaterialSapmst.searchMaterialSparesSo", query = " SELECT distinct new MaterialSapmst(m.materialDesc, m.materialNo) FROM MaterialSapmst m where m.materialNo like ?1 or m.materialDesc like ?2 ")
})
public class MaterialSapmst implements Serializable {
	private static final long serialVersionUID = 74L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "material_sapmst_id")
	private Integer materialSapmstId;

	@Column(name = "acc_assign_group")
	private String accAssignGroup;

	@Column(name = "base_unit")
	private String baseUnit;

	@Column(name = "control_group")
	private String controlGroup;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "delivery_plant")
	private String deliveryPlant;

	@Column(name = "dist_channel")
	private String distChannel;

	private String division;

	@Column(name = "item_category")
	private String itemCategory;

	@Column(name = "material_desc")
	private String materialDesc;

	@Column(name = "material_group")
	private String materialGroup;

	@Column(name = "material_num")
	private String materialNo;

	@Column(name = "material_type")
	private String materialType;

	private String plant;

	@Column(name = "sales_org")
	private String salesOrg;

	@Column(name = "sales_unit")
	private String salesUnit;

	@Transient
	private String separator = " - ";
	
	public MaterialSapmst() {
	}

	
	
	public MaterialSapmst(String materialDesc, String materialNo) {
		super();
		this.materialDesc = materialDesc;
		this.materialNo = materialNo;
	}



	public String getSeparator() {
		return separator;
	}

	public void setSeparator(String separator) {
		this.separator = separator;
	}

	public Integer getMaterialSapmstId() {
		return materialSapmstId;
	}

	public void setMaterialSapmstId(Integer materialSapmstId) {
		this.materialSapmstId = materialSapmstId;
	}

	public String getAccAssignGroup() {
		return accAssignGroup;
	}

	public void setAccAssignGroup(String accAssignGroup) {
		this.accAssignGroup = accAssignGroup;
	}

	public String getBaseUnit() {
		return baseUnit;
	}

	public void setBaseUnit(String baseUnit) {
		this.baseUnit = baseUnit;
	}

	public String getControlGroup() {
		return controlGroup;
	}

	public void setControlGroup(String controlGroup) {
		this.controlGroup = controlGroup;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getDeliveryPlant() {
		return deliveryPlant;
	}

	public void setDeliveryPlant(String deliveryPlant) {
		this.deliveryPlant = deliveryPlant;
	}

	public String getDistChannel() {
		return distChannel;
	}

	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getItemCategory() {
		return itemCategory;
	}

	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}

	public String getMaterialDesc() {
		return materialDesc;
	}

	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}

	public String getMaterialGroup() {
		return materialGroup;
	}

	public void setMaterialGroup(String materialGroup) {
		this.materialGroup = materialGroup;
	}

	public String getMaterialNo() {
		return materialNo;
	}

	public void setMaterialNo(String materialNo) {
		this.materialNo = materialNo;
	}

	public String getMaterialType() {
		return materialType;
	}

	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getSalesOrg() {
		return salesOrg;
	}

	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

	public String getSalesUnit() {
		return salesUnit;
	}

	public void setSalesUnit(String salesUnit) {
		this.salesUnit = salesUnit;
	}

}