package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the error_job_logs database table.
 * 
 */
@Entity
@Table(name="error_job_logs")
@NamedQueries({
	@NamedQuery(name="ErrorJobLog.findAll", query="SELECT e FROM ErrorJobLog e"),
	@NamedQuery(name="ErrorJobLog.findByDate", query="SELECT e FROM ErrorJobLog e where e.runDate = :runDate "
			+ " group by e.jobId,e.name,e.stepId,e.instanceId,e.stepName,e.sqlMessageId,e.message,"
			+ " e.runDate,e.runTime,e.runDuration,e.createdDate "
			+ " order by e.instanceId desc ")
	})

public class ErrorJobLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="created_date")
	private String createdDate;

	@Id
	@Column(name="instance_id")
	private Integer instanceId;

	@Column(name="job_id")
	private String jobId;

	private String message;

	private String name;

	@Column(name="run_date")
	private Integer runDate;

	@Column(name="run_duration")
	private String runDuration;

	@Column(name="run_time")
	private String runTime;

	@Column(name="sql_message_id")
	private Integer sqlMessageId;

	@Column(name="step_id")
	private Integer stepId;

	@Column(name="step_name")
	private String stepName;

	public ErrorJobLog() {
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getInstanceId() {
		return instanceId;
	}

	public void setInstanceId(Integer instanceId) {
		this.instanceId = instanceId;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getRunDate() {
		return runDate;
	}

	public void setRunDate(Integer runDate) {
		this.runDate = runDate;
	}

	public String getRunDuration() {
		return runDuration;
	}

	public void setRunDuration(String runDuration) {
		this.runDuration = runDuration;
	}

	public String getRunTime() {
		return runTime;
	}

	public void setRunTime(String runTime) {
		this.runTime = runTime;
	}

	public Integer getSqlMessageId() {
		return sqlMessageId;
	}

	public void setSqlMessageId(Integer sqlMessageId) {
		this.sqlMessageId = sqlMessageId;
	}

	public Integer getStepId() {
		return stepId;
	}

	public void setStepId(Integer stepId) {
		this.stepId = stepId;
	}

	public String getStepName() {
		return stepName;
	}

	public void setStepName(String stepName) {
		this.stepName = stepName;
	}

	

}