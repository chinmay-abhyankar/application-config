package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the opp_upload_details database table.
 * 
 */
@Entity
@Table(name = "opp_upload_details")
@NamedQueries({ @NamedQuery(name = "OppUploadDetail.findAll", query = "SELECT o FROM OppUploadDetail o order by o.uploadTime desc "),
		@NamedQuery(name = "OppUploadDetail.findByOppId", query = "SELECT o FROM OppUploadDetail o where o.opportunityId = ?1 order by o.uploadTime desc "),
		@NamedQuery(name = "OppUploadDetail.findBySalesReturnId", query = "SELECT o FROM OppUploadDetail o where o.salesReturnId = ?1 order by o.uploadTime desc "),		
		@NamedQuery(name = "OppUploadDetail.findByOppIdInDesc", query = "SELECT oud FROM OppUploadDetail oud where oud.opportunityId = ?1 and oud.fileTypeMstId='9' order by oud.uploadTime desc "),
		@NamedQuery(name = "OppUploadDetail.findByOppIdPre", query = "SELECT o FROM OppUploadDetail o where o.opportunityId = ?1 and o.respMatrixDetailsId = ?2 order by o.uploadTime desc "),
		@NamedQuery(name = "OppUploadDetail.findByProposalIdAndOppId", query = "SELECT o FROM OppUploadDetail o where o.opportunityId = ?1 and o.proposalId = ?2 order by o.uploadTime desc "),
		@NamedQuery(name = "OppUploadDetail.findByssEngVisitDetailsId", query = "SELECT o FROM OppUploadDetail o where o.ssEngVisitDetailsId = ?1 order by o.uploadTime desc "),
		@NamedQuery(name = "OppUploadDetail.findBysiteSurveyCostId", query = "SELECT o FROM OppUploadDetail o where o.siteSurveyCostId = ?1 order by o.uploadTime desc "),
		@NamedQuery(name = "OppUploadDetail.findByBrfId", query = "SELECT o FROM OppUploadDetail o where o.brfId = ?1 and (o.isDelete ='N' or o.isDelete='' or o.isDelete is null) order by o.uploadTime desc "),
		@NamedQuery(name = "OppUploadDetail.getUploadListByChildContractId", query = "SELECT o FROM OppUploadDetail o where o.childContractId = ?1 and (o.isDelete ='N' or o.isDelete='' or o.isDelete is null) order by o.uploadTime desc "),
		@NamedQuery(name = "OppUploadDetail.getOppUploadBySparesSoId", query = "SELECT o FROM OppUploadDetail o where o.sparesSoId = :sparesSoId and o.isDelete ='N' " ),
		@NamedQuery(name = "OppUploadDetail.getOppUploadDetailsBySparesSoDeliveryId", query = "SELECT o FROM OppUploadDetail o where o.sparesSoDeliveryId = :sparesSoDeliveryId and o.isDelete ='N' " ),
		@NamedQuery(name = "OppUploadDetail.getOppUploadDetailsByRelocationSoId", query = "SELECT o FROM OppUploadDetail o where o.relocationSoId = :relocationSoId and o.isDelete ='N' " ),
		@NamedQuery(name = "OppUploadDetail.getUploadListForRemindersAndNotice", query = "SELECT o.oppUploadDetailsId,o.upFileName,o.uploadUrl FROM OppUploadDetail o where o.reminderId =:reminderId"),
		@NamedQuery(name = "OppUploadDetail.getUploadListForInvoiceSubmission", query = "SELECT o.oppUploadDetailsId,o.upFileName,o.uploadUrl FROM OppUploadDetail o where o.invoiceSubmissionId =:requestId")})

public class OppUploadDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "opp_upload_details_id")
	private Integer oppUploadDetailsId;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "opportunity_id")
	private Integer opportunityId;

	@Column(name = "up_file_name")
	private String upFileName;

	@Column(name = "upload_url")
	private String uploadUrl;
	
	@Column(name="file_type_mst_id")
	private Integer fileTypeMstId;
	
	@Column(name="upload_time")
	private String uploadTime;
	
	@Column(name="resp_matrix_details_id")
	private Integer respMatrixDetailsId;
	
	@Column(name = "proposal_id")
	private Integer proposalId;
	
	@Column(name = "ss_eng_visit_details_id")
	private Integer ssEngVisitDetailsId;
	
	@Column(name = "site_survey_cost_id")
	private Integer siteSurveyCostId;
	
	@Column(name = "brf_id")
	private Integer brfId;
	
	@Column(name = "is_delete")
	private String isDelete = "N";
	
	@Column(name = "child_contract_id")
	private Integer childContractId;
	
	@Column(name = "fa_eng_visit_details_id")
	private Integer faEngVisitDetailsId;
	
	@Column(name = "franchise_inv_req_id")
	private Integer franchiseInvReqId;
	
	@Column(name = "reminder_id")
	private String reminderId;
	
	@Column(name = "submitted_by_frc")
	private String submittedByFrc="N";
	
	@Column(name = "received_by_cs")
	private String receivedByCs="N";
	
	@Column(name = "frc_updated_time")
	private String frcUpdatedTime;
	
	@Column(name = "cs_updated_time")
	private String csUpdatedTime;
	
	@Column(name = "spares_so_id")
	private Integer sparesSoId;
	
	@Column(name = "sales_return_id")
	private Integer salesReturnId;
	
	@Column(name = "spares_so_delivery_id")
	private Integer sparesSoDeliveryId;
	
	@Column(name = "relocation_so_id")
	private Integer relocationSoId;
	
	@Column(name = "invoice_submission_id")
	private String invoiceSubmissionId;
	
	@Transient
	private String invoiceNo;
	
	public String getInvoiceSubmissionId() {
		return invoiceSubmissionId;
	}

	public void setInvoiceSubmissionId(String invoiceSubmissionId) {
		this.invoiceSubmissionId = invoiceSubmissionId;
	}

	public Integer getRelocationSoId() {
		return relocationSoId;
	}

	public void setRelocationSoId(Integer relocationSoId) {
		this.relocationSoId = relocationSoId;
	}

	public Integer getSparesSoDeliveryId() {
		return sparesSoDeliveryId;
	}

	public void setSparesSoDeliveryId(Integer sparesSoDeliveryId) {
		this.sparesSoDeliveryId = sparesSoDeliveryId;
	}

	public Integer getSalesReturnId() {
		return salesReturnId;
	}

	public void setSalesReturnId(Integer salesReturnId) {
		this.salesReturnId = salesReturnId;
	}

	public Integer getSparesSoId() {
		return sparesSoId;
	}

	public void setSparesSoId(Integer sparesSoId) {
		this.sparesSoId = sparesSoId;
	}

	public String getFrcUpdatedTime() {
		return frcUpdatedTime;
	}

	public void setFrcUpdatedTime(String frcUpdatedTime) {
		this.frcUpdatedTime = frcUpdatedTime;
	}

	public String getCsUpdatedTime() {
		return csUpdatedTime;
	}

	public void setCsUpdatedTime(String csUpdatedTime) {
		this.csUpdatedTime = csUpdatedTime;
	}

	public String getSubmittedByFrc() {
		return submittedByFrc;
	}

	public void setSubmittedByFrc(String submittedByFrc) {
		this.submittedByFrc = submittedByFrc;
	}

	public String getReceivedByCs() {
		return receivedByCs;
	}

	public void setReceivedByCs(String receivedByCs) {
		this.receivedByCs = receivedByCs;
	}

	public String getReminderId() {
		return reminderId;
	}

	public void setReminderId(String reminderId) {
		this.reminderId = reminderId;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public Integer getFranchiseInvReqId() {
		return franchiseInvReqId;
	}

	public void setFranchiseInvReqId(Integer franchiseInvReqId) {
		this.franchiseInvReqId = franchiseInvReqId;
	}

	public Integer getFaEngVisitDetailsId() {
		return faEngVisitDetailsId;
	}

	public void setFaEngVisitDetailsId(Integer faEngVisitDetailsId) {
		this.faEngVisitDetailsId = faEngVisitDetailsId;
	}

	public Integer getChildContractId() {
		return childContractId;
	}

	public void setChildContractId(Integer childContractId) {
		this.childContractId = childContractId;
	}

	public Integer getBrfId() {
		return brfId;
	}

	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}

	public Integer getSsEngVisitDetailsId() {
		return ssEngVisitDetailsId;
	}

	public void setSsEngVisitDetailsId(Integer ssEngVisitDetailsId) {
		this.ssEngVisitDetailsId = ssEngVisitDetailsId;
	}

	public Integer getSiteSurveyCostId() {
		return siteSurveyCostId;
	}

	public void setSiteSurveyCostId(Integer siteSurveyCostId) {
		this.siteSurveyCostId = siteSurveyCostId;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "file_type_mst_id", referencedColumnName = "file_type_mst_id", insertable = false, updatable = false)
	private FileTypeMst fileTypeMst;

	public Integer getProposalId() {
		return proposalId;
	}

	public void setProposalId(Integer proposalId) {
		this.proposalId = proposalId;
	}

	public Integer getRespMatrixDetailsId() {
		return respMatrixDetailsId;
	}

	public void setRespMatrixDetailsId(Integer respMatrixDetailsId) {
		this.respMatrixDetailsId = respMatrixDetailsId;
	}

	public FileTypeMst getFileTypeMst() {
		return fileTypeMst;
	}

	public void setFileTypeMst(FileTypeMst fileTypeMst) {
		this.fileTypeMst = fileTypeMst;
	}

	public String getUploadTime() {
		return uploadTime;
	}

	public void setUploadTime(String uploadTime) {
		this.uploadTime = uploadTime;
	}

	public Integer getFileTypeMstId() {
		return fileTypeMstId;
	}

	public void setFileTypeMstId(Integer fileTypeMstId) {
		this.fileTypeMstId = fileTypeMstId;
	}

	public Integer getOppUploadDetailsId() {
		return oppUploadDetailsId;
	}

	public void setOppUploadDetailsId(Integer oppUploadDetailsId) {
		this.oppUploadDetailsId = oppUploadDetailsId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getUpFileName() {
		return upFileName;
	}

	public void setUpFileName(String upFileName) {
		this.upFileName = upFileName;
	}

	public String getUploadUrl() {
		return uploadUrl;
	}

	public void setUploadUrl(String uploadUrl) {
		this.uploadUrl = uploadUrl;
	}

	public String getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(String isDelete) {
		this.isDelete = isDelete;
	}
	
	
}