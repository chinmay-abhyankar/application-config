/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.OrderTypeMst;
import com.nelco.o2c.model.PoApprovalDetail;
import com.nelco.o2c.model.ProductTypeMst;
import com.nelco.o2c.model.Proposal;
import com.nelco.o2c.model.ServiceOrderMst;
import com.nelco.o2c.model.StatusMst;
import com.nelco.o2c.model.UserMst;

/**
 * @author Jayashankar.r
 *
 */
@Component
/*
 * @Scope(value=WebApplicationContext.SCOPE_REQUEST,proxyMode=ScopedProxyMode.
 * TARGET_CLASS)
 */
public class PoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String fromDate;
	private String toDate;
	private Integer userMstId;
	private String roleCode;
	private List<PotentialInfoDTO> potentialInfoDTOList = new ArrayList<PotentialInfoDTO>();
	private Integer proposalId;
	private Integer opportunityId;
	private Proposal proposal;
	private List<ProductTypeMst> productTypeList;
	private List<ServiceOrderMst> serviceOrderList;
	private List<OppUploadDetail> oppUploadDetails = new ArrayList<OppUploadDetail>();
	private StatusMst statusMst;
	private List<FileTypeMst> fileList;
	private PoApprovalDetail poApprovalDetail;
	private List<UserMst> pmList;
	private List<HubMst> hubList;
	private Boolean isSaved = false;
	private String smOwnerId;
	private String remarks;
	private List<PoApprovalDetail> poApproverDetailList;
	private List<OrderTypeMst> orderTypeList;
	private List<UserMst> financeNelcoList;
	private List<UserMst> financeTnslList;
	private String orgCode;
	private List<PoPendingDTO> pendingPoList;
	

	public List<PoPendingDTO> getPendingPoList() {
		return pendingPoList;
	}

	public void setPendingPoList(List<PoPendingDTO> pendingPoList) {
		this.pendingPoList = pendingPoList;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public List<UserMst> getFinanceNelcoList() {
		return financeNelcoList;
	}

	public void setFinanceNelcoList(List<UserMst> financeNelcoList) {
		this.financeNelcoList = financeNelcoList;
	}

	public List<UserMst> getFinanceTnslList() {
		return financeTnslList;
	}

	public void setFinanceTnslList(List<UserMst> financeTnslList) {
		this.financeTnslList = financeTnslList;
	}

	public List<OrderTypeMst> getOrderTypeList() {
		return orderTypeList;
	}

	public void setOrderTypeList(List<OrderTypeMst> orderTypeList) {
		this.orderTypeList = orderTypeList;
	}

	public List<PoApprovalDetail> getPoApproverDetailList() {
		return poApproverDetailList;
	}

	public void setPoApproverDetailList(List<PoApprovalDetail> poApproverDetailList) {
		this.poApproverDetailList = poApproverDetailList;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getSmOwnerId() {
		return smOwnerId;
	}

	public void setSmOwnerId(String smOwnerId) {
		this.smOwnerId = smOwnerId;
	}

	public Boolean getIsSaved() {
		return isSaved;
	}

	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}

	public List<HubMst> getHubList() {
		return hubList;
	}

	public void setHubList(List<HubMst> hubList) {
		this.hubList = hubList;
	}

	public List<UserMst> getPmList() {
		return pmList;
	}

	public void setPmList(List<UserMst> pmList) {
		this.pmList = pmList;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public Integer getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public List<PotentialInfoDTO> getPotentialInfoDTOList() {
		return potentialInfoDTOList;
	}

	public void setPotentialInfoDTOList(List<PotentialInfoDTO> potentialInfoDTOList) {
		this.potentialInfoDTOList = potentialInfoDTOList;
	}

	public Integer getProposalId() {
		return proposalId;
	}

	public void setProposalId(Integer proposalId) {
		this.proposalId = proposalId;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public Proposal getProposal() {
		return proposal;
	}

	public void setProposal(Proposal proposal) {
		this.proposal = proposal;
	}

	public List<ProductTypeMst> getProductTypeList() {
		return productTypeList;
	}

	public void setProductTypeList(List<ProductTypeMst> productTypeList) {
		this.productTypeList = productTypeList;
	}

	public List<ServiceOrderMst> getServiceOrderList() {
		return serviceOrderList;
	}

	public void setServiceOrderList(List<ServiceOrderMst> serviceOrderList) {
		this.serviceOrderList = serviceOrderList;
	}

	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}

	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}

	public StatusMst getStatusMst() {
		return statusMst;
	}

	public void setStatusMst(StatusMst statusMst) {
		this.statusMst = statusMst;
	}

	public List<FileTypeMst> getFileList() {
		return fileList;
	}

	public void setFileList(List<FileTypeMst> fileList) {
		this.fileList = fileList;
	}

	public PoApprovalDetail getPoApprovalDetail() {
		return poApprovalDetail;
	}

	public void setPoApprovalDetail(PoApprovalDetail poApprovalDetail) {
		this.poApprovalDetail = poApprovalDetail;
	}

}
