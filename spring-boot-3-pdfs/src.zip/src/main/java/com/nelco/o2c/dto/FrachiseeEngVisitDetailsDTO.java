package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;

import com.nelco.o2c.model.OppUploadDetail;

public class FrachiseeEngVisitDetailsDTO {
	
	private Integer id;
	
	private Integer franchiseeAllocId;
	
	private Integer engineerId;

	private String iduRoomReady;
	private String upsAvail;
	//private String remarks;
	private String customerName;
	private String custAddress;
	private String contact;
	private Integer technology;
	private Integer antennaSizeId;
	private Integer hubDetails;
	private String cableLen;
	private String buildingHeight;
	private String platformReq;
	private String monkeyProtectionReq;
	private String ladderReq;
	private String ladderHeight;
    private String additionalRemarks;	
	private Integer workCompletionStatusId;
	private String workCompletionStatusUpdateTime;
	private Integer kmApplMstId;
	private String visit;
	private String createdDate;
	private String isSubmit;
	private Integer nonFeasibleOptionId;
	private String remarks;
	private String abortReason;
	private String actualPersonName;
	private String actualPersonContact;
	
	private String visitDate;
	private String visitTime;	
	private Integer antennaTypeMstId;
	private String siteClearForWmNow;
	private String mastHeight;	
	private Integer antennaLocationMstId;	
	private String earthing;	
	private String lanCable;	
	private String nocFromBuilding;	
	private String earthingWire;	
	
	private String powerSocketAvail;	
	
	private String monkeyMenace;
	
	private Integer userMstId;
	private String tsoNumber;
	private String tsoApprovedDate;
	private Integer installationStatusMstId;
	private Integer incAttributionMstId;
	private Integer activityType;
	
	
	
	public Integer getActivityType() {
		return activityType;
	}

	public void setActivityType(Integer activityType) {
		this.activityType = activityType;
	}

	public String getTsoApprovedDate() {
		return tsoApprovedDate;
	}

	public void setTsoApprovedDate(String tsoApprovedDate) {
		this.tsoApprovedDate = tsoApprovedDate;
	}

	public Integer getInstallationStatusMstId() {
		return installationStatusMstId;
	}

	public void setInstallationStatusMstId(Integer installationStatusMstId) {
		this.installationStatusMstId = installationStatusMstId;
	}

	public Integer getIncAttributionMstId() {
		return incAttributionMstId;
	}

	public void setIncAttributionMstId(Integer incAttributionMstId) {
		this.incAttributionMstId = incAttributionMstId;
	}

	public String getTsoNumber() {
		return tsoNumber;
	}

	public void setTsoNumber(String tsoNumber) {
		this.tsoNumber = tsoNumber;
	}

	public Integer getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

	private List<OppUploadDetail> oppUploadDetails = new ArrayList<OppUploadDetail>();
	
	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}

	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}

	public String getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}

	public String getVisitTime() {
		return visitTime;
	}

	public void setVisitTime(String visitTime) {
		this.visitTime = visitTime;
	}

	public Integer getAntennaTypeMstId() {
		return antennaTypeMstId;
	}

	public void setAntennaTypeMstId(Integer antennaTypeMstId) {
		this.antennaTypeMstId = antennaTypeMstId;
	}

	public String getSiteClearForWmNow() {
		return siteClearForWmNow;
	}

	public void setSiteClearForWmNow(String siteClearForWmNow) {
		this.siteClearForWmNow = siteClearForWmNow;
	}

	public String getMastHeight() {
		return mastHeight;
	}

	public void setMastHeight(String mastHeight) {
		this.mastHeight = mastHeight;
	}

	public Integer getAntennaLocationMstId() {
		return antennaLocationMstId;
	}

	public void setAntennaLocationMstId(Integer antennaLocationMstId) {
		this.antennaLocationMstId = antennaLocationMstId;
	}

	public String getEarthing() {
		return earthing;
	}

	public void setEarthing(String earthing) {
		this.earthing = earthing;
	}

	public String getLanCable() {
		return lanCable;
	}

	public void setLanCable(String lanCable) {
		this.lanCable = lanCable;
	}

	public String getNocFromBuilding() {
		return nocFromBuilding;
	}

	public void setNocFromBuilding(String nocFromBuilding) {
		this.nocFromBuilding = nocFromBuilding;
	}

	public String getEarthingWire() {
		return earthingWire;
	}

	public void setEarthingWire(String earthingWire) {
		this.earthingWire = earthingWire;
	}

	public String getPowerSocketAvail() {
		return powerSocketAvail;
	}

	public void setPowerSocketAvail(String powerSocketAvail) {
		this.powerSocketAvail = powerSocketAvail;
	}

	public String getMonkeyMenace() {
		return monkeyMenace;
	}

	public void setMonkeyMenace(String monkeyMenace) {
		this.monkeyMenace = monkeyMenace;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getFranchiseeAllocId() {
		return franchiseeAllocId;
	}

	public void setFranchiseeAllocId(Integer franchiseeAllocId) {
		this.franchiseeAllocId = franchiseeAllocId;
	}	

	public Integer getEngineerId() {
		return engineerId;
	}

	public void setEngineerId(Integer engineerId) {
		this.engineerId = engineerId;
	}

	public String getIduRoomReady() {
		return iduRoomReady;
	}

	public void setIduRoomReady(String iduRoomReady) {
		this.iduRoomReady = iduRoomReady;
	}

	public String getUpsAvail() {
		return upsAvail;
	}

	public void setUpsAvail(String upsAvail) {
		this.upsAvail = upsAvail;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public Integer getTechnology() {
		return technology;
	}

	public void setTechnology(Integer technology) {
		this.technology = technology;
	}

	public Integer getAntennaSizeId() {
		return antennaSizeId;
	}

	public void setAntennaSizeId(Integer antennaSizeId) {
		this.antennaSizeId = antennaSizeId;
	}

	public Integer getHubDetails() {
		return hubDetails;
	}

	public void setHubDetails(Integer hubDetails) {
		this.hubDetails = hubDetails;
	}

	public String getCableLen() {
		return cableLen;
	}

	public void setCableLen(String cableLen) {
		this.cableLen = cableLen;
	}

	public String getBuildingHeight() {
		return buildingHeight;
	}

	public void setBuildingHeight(String buildingHeight) {
		this.buildingHeight = buildingHeight;
	}

	public String getPlatformReq() {
		return platformReq;
	}

	public void setPlatformReq(String platformReq) {
		this.platformReq = platformReq;
	}

	public String getMonkeyProtectionReq() {
		return monkeyProtectionReq;
	}

	public void setMonkeyProtectionReq(String monkeyProtectionReq) {
		this.monkeyProtectionReq = monkeyProtectionReq;
	}

	public String getLadderReq() {
		return ladderReq;
	}

	public void setLadderReq(String ladderReq) {
		this.ladderReq = ladderReq;
	}

	public String getLadderHeight() {
		return ladderHeight;
	}

	public void setLadderHeight(String ladderHeight) {
		this.ladderHeight = ladderHeight;
	}

	public String getAdditionalRemarks() {
		return additionalRemarks;
	}

	public void setAdditionalRemarks(String additionalRemarks) {
		this.additionalRemarks = additionalRemarks;
	}	

	public Integer getWorkCompletionStatusId() {
		return workCompletionStatusId;
	}

	public void setWorkCompletionStatusId(Integer workCompletionStatusId) {
		this.workCompletionStatusId = workCompletionStatusId;
	}

	public String getWorkCompletionStatusUpdateTime() {
		return workCompletionStatusUpdateTime;
	}

	public void setWorkCompletionStatusUpdateTime(String workCompletionStatusUpdateTime) {
		this.workCompletionStatusUpdateTime = workCompletionStatusUpdateTime;
	}

	public Integer getKmApplMstId() {
		return kmApplMstId;
	}

	public void setKmApplMstId(Integer kmApplMstId) {
		this.kmApplMstId = kmApplMstId;
	}

	public String getVisit() {
		return visit;
	}

	public void setVisit(String visit) {
		this.visit = visit;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getIsSubmit() {
		return isSubmit;
	}

	public void setIsSubmit(String isSubmit) {
		this.isSubmit = isSubmit;
	}

	

	public Integer getNonFeasibleOptionId() {
		return nonFeasibleOptionId;
	}

	public void setNonFeasibleOptionId(Integer nonFeasibleOptionId) {
		this.nonFeasibleOptionId = nonFeasibleOptionId;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getAbortReason() {
		return abortReason;
	}

	public void setAbortReason(String abortReason) {
		this.abortReason = abortReason;
	}

	public String getActualPersonName() {
		return actualPersonName;
	}

	public void setActualPersonName(String actualPersonName) {
		this.actualPersonName = actualPersonName;
	}

	public String getActualPersonContact() {
		return actualPersonContact;
	}

	public void setActualPersonContact(String actualPersonContact) {
		this.actualPersonContact = actualPersonContact;
	}
	
	
}
