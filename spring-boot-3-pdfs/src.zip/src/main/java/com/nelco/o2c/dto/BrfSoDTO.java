/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

/**
 * @author Amol.l
 *
 */
public class BrfSoDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer brfId;
	private Integer accoMgr;
	private String bandwidth;
	private String brfPlan;
	private String bwAllocation;
	private String contractNum;
	private String createdDate;
	private String existingSite;
	private String product;
	private String oldSoNum;
	private String poNum;
	private Integer progMgr;
	private String siteName;
	private String soldToParty;
	private Integer statusMstId;
	private String technology;
	private String tentActDate;
	private Integer childContractId;
	private Integer financeId;
	private Integer nocMgrId;
	private String customerName;
	private String statusName;
	private String statusCode;
	private String financeRemark;
	private String nocRemark;
	private String salesOrg;
	private String distChannel;
	private String division;
	private Integer regulatoryId;
	private String item;
	private String billingEndDate;
	private String modifiedDate;
	private Integer soOrdersId;
	private String materialNum;
	
	private Integer brfSoDetailsId;
	private String bsoBandwidth;
	private Integer bsoBrfId;
	private String bsoBrfPlan;
	private String bsoCreatedDate;
	private String bsoExistingSite;
	private String bsoItem;
	private String bsoMaterialNum;
	private String bsoModifiedDate;
	private String bsoNewSoActDate;
	private String bsoNewSoNum;
	private String bsoOldSoNum;
	private Integer bsoSoOrdersId;
	private String bsoTechnology;
	private String bsoTentActDate;
	
	public Integer getBrfId() {
		return brfId;
	}
	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}
	public Integer getAccoMgr() {
		return accoMgr;
	}
	public void setAccoMgr(Integer accoMgr) {
		this.accoMgr = accoMgr;
	}
	public String getBandwidth() {
		return bandwidth;
	}
	public void setBandwidth(String bandwidth) {
		this.bandwidth = bandwidth;
	}
	public String getBrfPlan() {
		return brfPlan;
	}
	public void setBrfPlan(String brfPlan) {
		this.brfPlan = brfPlan;
	}
	public String getBwAllocation() {
		return bwAllocation;
	}
	public void setBwAllocation(String bwAllocation) {
		this.bwAllocation = bwAllocation;
	}
	public String getContractNum() {
		return contractNum;
	}
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getExistingSite() {
		return existingSite;
	}
	public void setExistingSite(String existingSite) {
		this.existingSite = existingSite;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getOldSoNum() {
		return oldSoNum;
	}
	public void setOldSoNum(String oldSoNum) {
		this.oldSoNum = oldSoNum;
	}
	public String getPoNum() {
		return poNum;
	}
	public void setPoNum(String poNum) {
		this.poNum = poNum;
	}
	public Integer getProgMgr() {
		return progMgr;
	}
	public void setProgMgr(Integer progMgr) {
		this.progMgr = progMgr;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getSoldToParty() {
		return soldToParty;
	}
	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}
	public Integer getStatusMstId() {
		return statusMstId;
	}
	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getTentActDate() {
		return tentActDate;
	}
	public void setTentActDate(String tentActDate) {
		this.tentActDate = tentActDate;
	}
	public Integer getChildContractId() {
		return childContractId;
	}
	public void setChildContractId(Integer childContractId) {
		this.childContractId = childContractId;
	}
	public Integer getFinanceId() {
		return financeId;
	}
	public void setFinanceId(Integer financeId) {
		this.financeId = financeId;
	}
	public Integer getNocMgrId() {
		return nocMgrId;
	}
	public void setNocMgrId(Integer nocMgrId) {
		this.nocMgrId = nocMgrId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getFinanceRemark() {
		return financeRemark;
	}
	public void setFinanceRemark(String financeRemark) {
		this.financeRemark = financeRemark;
	}
	public String getNocRemark() {
		return nocRemark;
	}
	public void setNocRemark(String nocRemark) {
		this.nocRemark = nocRemark;
	}
	public String getSalesOrg() {
		return salesOrg;
	}
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	public String getDistChannel() {
		return distChannel;
	}
	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public Integer getRegulatoryId() {
		return regulatoryId;
	}
	public void setRegulatoryId(Integer regulatoryId) {
		this.regulatoryId = regulatoryId;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public String getBillingEndDate() {
		return billingEndDate;
	}
	public void setBillingEndDate(String billingEndDate) {
		this.billingEndDate = billingEndDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Integer getSoOrdersId() {
		return soOrdersId;
	}
	public void setSoOrdersId(Integer soOrdersId) {
		this.soOrdersId = soOrdersId;
	}
	public String getMaterialNum() {
		return materialNum;
	}
	public void setMaterialNum(String materialNum) {
		this.materialNum = materialNum;
	}
	public Integer getBrfSoDetailsId() {
		return brfSoDetailsId;
	}
	public void setBrfSoDetailsId(Integer brfSoDetailsId) {
		this.brfSoDetailsId = brfSoDetailsId;
	}
	public String getBsoBandwidth() {
		return bsoBandwidth;
	}
	public void setBsoBandwidth(String bsoBandwidth) {
		this.bsoBandwidth = bsoBandwidth;
	}
	public Integer getBsoBrfId() {
		return bsoBrfId;
	}
	public void setBsoBrfId(Integer bsoBrfId) {
		this.bsoBrfId = bsoBrfId;
	}
	public String getBsoBrfPlan() {
		return bsoBrfPlan;
	}
	public void setBsoBrfPlan(String bsoBrfPlan) {
		this.bsoBrfPlan = bsoBrfPlan;
	}
	public String getBsoCreatedDate() {
		return bsoCreatedDate;
	}
	public void setBsoCreatedDate(String bsoCreatedDate) {
		this.bsoCreatedDate = bsoCreatedDate;
	}
	public String getBsoExistingSite() {
		return bsoExistingSite;
	}
	public void setBsoExistingSite(String bsoExistingSite) {
		this.bsoExistingSite = bsoExistingSite;
	}
	public String getBsoItem() {
		return bsoItem;
	}
	public void setBsoItem(String bsoItem) {
		this.bsoItem = bsoItem;
	}
	public String getBsoMaterialNum() {
		return bsoMaterialNum;
	}
	public void setBsoMaterialNum(String bsoMaterialNum) {
		this.bsoMaterialNum = bsoMaterialNum;
	}
	public String getBsoModifiedDate() {
		return bsoModifiedDate;
	}
	public void setBsoModifiedDate(String bsoModifiedDate) {
		this.bsoModifiedDate = bsoModifiedDate;
	}
	public String getBsoNewSoActDate() {
		return bsoNewSoActDate;
	}
	public void setBsoNewSoActDate(String bsoNewSoActDate) {
		this.bsoNewSoActDate = bsoNewSoActDate;
	}
	public String getBsoNewSoNum() {
		return bsoNewSoNum;
	}
	public void setBsoNewSoNum(String bsoNewSoNum) {
		this.bsoNewSoNum = bsoNewSoNum;
	}
	public String getBsoOldSoNum() {
		return bsoOldSoNum;
	}
	public void setBsoOldSoNum(String bsoOldSoNum) {
		this.bsoOldSoNum = bsoOldSoNum;
	}
	public Integer getBsoSoOrdersId() {
		return bsoSoOrdersId;
	}
	public void setBsoSoOrdersId(Integer bsoSoOrdersId) {
		this.bsoSoOrdersId = bsoSoOrdersId;
	}
	public String getBsoTechnology() {
		return bsoTechnology;
	}
	public void setBsoTechnology(String bsoTechnology) {
		this.bsoTechnology = bsoTechnology;
	}
	public String getBsoTentActDate() {
		return bsoTentActDate;
	}
	public void setBsoTentActDate(String bsoTentActDate) {
		this.bsoTentActDate = bsoTentActDate;
	}
	
}
