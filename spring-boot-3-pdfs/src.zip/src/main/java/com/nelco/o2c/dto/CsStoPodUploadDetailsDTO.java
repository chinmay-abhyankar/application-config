/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

import com.nelco.o2c.model.CsStoPodUploadDetail;

/**
 * @author Jayashankar.r
 *
 */
public class CsStoPodUploadDetailsDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer stoCsDeliveryId;
	private CsStoPodUploadDetail csStoPodUploadDetail;

	public Integer getStoCsDeliveryId() {
		return stoCsDeliveryId;
	}

	public void setStoCsDeliveryId(Integer stoCsDeliveryId) {
		this.stoCsDeliveryId = stoCsDeliveryId;
	}

	public CsStoPodUploadDetail getCsStoPodUploadDetail() {
		return csStoPodUploadDetail;
	}

	public void setCsStoPodUploadDetail(CsStoPodUploadDetail csStoPodUploadDetail) {
		this.csStoPodUploadDetail = csStoPodUploadDetail;
	}

}
