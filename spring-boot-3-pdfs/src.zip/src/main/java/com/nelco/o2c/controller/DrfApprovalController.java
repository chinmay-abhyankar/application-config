/**
 * 
 */
package com.nelco.o2c.controller;

import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dao.CallSpDao;
import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.DrfApprDetailsDTO;
import com.nelco.o2c.dto.DrfExtListDTO;
import com.nelco.o2c.dto.ExtendDemoDTO;
import com.nelco.o2c.service.DrfApprovalService;

/**
 * @author Jayashankar.r
 *
 */
@RestController
public class DrfApprovalController {
	
	@Autowired
	DrfApprovalService drfApprovalService;
	
	@Autowired
	CallSpDao callSpDao;
	
	/*@RequestMapping(value = "/testMail.do", method = RequestMethod.POST)
	public void testMail(@RequestBody EmailBean emailBean) {
		callSpDao.sendEmail(emailBean);
	}*/
	
	@RequestMapping(value = "/apprRej.do", method = RequestMethod.POST)
	public DrfApprDetailsDTO apprRej(@RequestBody CommonDTO commonDTO,HttpServletRequest request) throws ParseException {
		
		return drfApprovalService.apprRejDrfDetails(commonDTO,request);
	}
	
	@RequestMapping(value = "/getApprRejDrfDetails.do", method = RequestMethod.POST)
	public DrfApprDetailsDTO getApprRejDrfDetails(@RequestBody CommonDTO commonDTO,HttpServletRequest request) {
		return drfApprovalService.getApprRejDrfDetails(commonDTO,request);
	}
	
	
	@RequestMapping(value = "/extendDemo.do", method = RequestMethod.POST)
	public ExtendDemoDTO extendDemo(@RequestBody ExtendDemoDTO extendDemoInputDTO) {
		
		return drfApprovalService.extendDemo(extendDemoInputDTO);
	}
	
	@RequestMapping(value = "/getExtensionComments.do", method = RequestMethod.POST)
	public ExtendDemoDTO getExtensionComments(@RequestBody ExtendDemoDTO extendDemoInputDTO) {
		
		return drfApprovalService.getExtensionComments(extendDemoInputDTO);
	}
	
	
	@RequestMapping(value = "/closeDemo.do", method = RequestMethod.POST)
	public ExtendDemoDTO closeDemo(@RequestBody ExtendDemoDTO extendDemoInputDTO) {
		
		return drfApprovalService.closeDemo(extendDemoInputDTO);
	}
	
	@RequestMapping(value = "/getDrfExtensionList.do",method = RequestMethod.POST)
	public DrfExtListDTO getDrfExtensionList(@RequestBody DrfExtListDTO drfExtListInputDTO) {
		return drfApprovalService.getDrfExtensionList(drfExtListInputDTO);
	}
	
}
