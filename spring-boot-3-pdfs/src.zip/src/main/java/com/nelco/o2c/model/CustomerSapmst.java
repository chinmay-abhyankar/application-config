package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the customer_sapmst database table.
 * 
 */
@Entity
@Table(name="customer_sapmst")
@NamedQueries({
@NamedQuery(name="CustomerSapmst.findAll", query="SELECT cm FROM CustomerSapmst cm"),
@NamedQuery(name = "CustomerSapmst.getCustomerdetailsByCustomerNum", query = "SELECT cm from CustomerSapmst cm where cm.soldToParty =?1 "),

@NamedQuery(name = "CustomerSapmst.searchSoldToParty", query = "SELECT cm from CustomerSapmst cm where cm.soldToParty  like ?1 or cm.customerName like ?2 and cm.accountGroup='Z001' "),
@NamedQuery(name = "CustomerSapmst.searchSoldToPartyReport", query = "SELECT cm from CustomerSapmst cm where cm.soldToParty  like ?1 or cm.customerName like ?2  "),
@NamedQuery(name = "CustomerSapmst.searchShipToParty", query = "SELECT cm from CustomerSapmst cm where cm.soldToParty  like ?1 or cm.customerName like ?2 and cm.accountGroup='ZSHT' "),
//@NamedQuery(name = "CustomerSapmst.searchCustomer", query = "SELECT cm from CustomerSapmst cm where cm.customer_num  like ?1 or cm.customerName like ?2 "),
@NamedQuery(name = "CustomerSapmst.searchAccountMgrCode", query = "SELECT distinct new CustomerSapmst(cm.accountGroup,cm.customerName,cm.soldToParty) from CustomerSapmst cm where cm.accountGroup = 'Z007' and  (cm.soldToParty  like ?1 or cm.customerName like ?2 ) "),
@NamedQuery(name = "CustomerSapmst.searchSoldToPartySparesSo", query = "SELECT distinct new CustomerSapmst(cm.accountGroup,cm.customerName,cm.soldToParty) from CustomerSapmst cm where cm.accountGroup = 'Z001' and  (cm.soldToParty  like ?1 or cm.customerName like ?2 ) "),
@NamedQuery(name = "CustomerSapmst.searchShipToPartySparesSo", query = "SELECT distinct new  CustomerSapmst(cm.accountGroup, "
		+ " cm.cityName, cm.customerName, cm.soldToParty, cm.pin," + 
		" cm.street1, cm.street2, cm.street3,"
		+ " cm.street4, cm.street5, cm.stateMst, " + 
		" cm.countryMst) from CustomerSapmst cm where cm.accountGroup = 'ZSHT' and  (cm.soldToParty  like ?1 or cm.customerName like ?2 ) ")
})
public class CustomerSapmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="customer_sapmst_id")
	private Integer customerSapmstId;

	@Column(name="acc_assign_group")
	private String accAssignGroup;

	@Column(name="account_group")
	private String accountGroup;

	@Column(name="city_name")
	private String cityName;

	@Column(name="company_code")
	private String companyCode;

	@Column(name="country_code")
	private String countryCode;

	@Column(name="created_date")
	private Timestamp createdDate;

	private String currency;

	@Column(name="customer_name")
	private String customerName;

	@Column(name="customer_num")
	private String soldToParty;

	@Column(name="delivery_plant")
	private String deliveryPlant;

	@Column(name="delivery_priority")
	private String deliveryPriority;

	@Column(name="dist_channel")
	private String distChannel;

	private String division;

	private String gstin;

	@Column(name="payment_terms")
	private String paymentTerms;

	private String pin;

	@Column(name="reco_account")
	private String recoAccount;

	@Column(name="region_code")
	private String regionCode;

	@Column(name="sales_office")
	private String salesOffice;

	@Column(name="sales_org")
	private String salesOrg;

	@Column(name="shipping_con")
	private String shippingCon;

	private String street1;

	private String street2;

	private String street3;

	private String street4;

	private String street5;
	
	@Column(name = "contact_number")
	private String contactNumber;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="region_code",referencedColumnName="state_code", insertable = false, updatable = false)
	private StateMst stateMst;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="country_code",referencedColumnName="country_code", insertable = false, updatable = false)
	private CountryMst countryMst;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="payment_terms",referencedColumnName="pay_terms_code", insertable = false, updatable = false)
	private PayTermsMst payTermsMst;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="dist_channel",referencedColumnName="dc_code", insertable = false, updatable = false)
	private DistChannelMst distChannelMst;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="division",referencedColumnName="division_code", insertable = false, updatable = false)
	private DivisionMst divisionMst;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="delivery_plant",referencedColumnName="plant_code", insertable = false, updatable = false)
	private PlantSapmst plantSapmst;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="sales_office",referencedColumnName="sales_office_code", insertable = false, updatable = false)
	private SalesOfficeMst salesOfficeMst;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="sales_org",referencedColumnName="sales_org_code", insertable = false, updatable = false)
	private SalesOrgMst salesOrgMst;
	
	@Transient
	private String separator = " - ";
	
	public CustomerSapmst(String accountGroup, String customerName, String soldToParty) {
		super();
		this.accountGroup = accountGroup;
		this.customerName = customerName;
		this.soldToParty = soldToParty;
	}
	
	

	public CustomerSapmst(String accountGroup, String cityName, String customerName, String soldToParty, String pin,
			String street1, String street2, String street3, String street4, String street5, StateMst stateMst,
			CountryMst countryMst) {
		super();
		this.accountGroup = accountGroup;
		this.cityName = cityName;
		this.customerName = customerName;
		this.soldToParty = soldToParty;
		this.pin = pin;
		this.street1 = street1;
		this.street2 = street2;
		this.street3 = street3;
		this.street4 = street4;
		this.street5 = street5;
		this.stateMst = stateMst;
		this.countryMst = countryMst;
	}


	
	
	public String getContactNumber() {
		return contactNumber;
	}



	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}



	public String getSeparator() {
		return separator;
	}

	public void setSeparator(String separator) {
		this.separator = separator;
	}

	public CustomerSapmst() {
	}
	
	public Integer getCustomerSapmstId() {
		return customerSapmstId;
	}

	public void setCustomerSapmstId(Integer customerSapmstId) {
		this.customerSapmstId = customerSapmstId;
	}

	public String getAccAssignGroup() {
		return this.accAssignGroup;
	}

	public void setAccAssignGroup(String accAssignGroup) {
		this.accAssignGroup = accAssignGroup;
	}

	public String getAccountGroup() {
		return this.accountGroup;
	}

	public void setAccountGroup(String accountGroup) {
		this.accountGroup = accountGroup;
	}

	public String getCityName() {
		return this.cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCountryCode() {
		return this.countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCustomerName() {
		return this.customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getSoldToParty() {
		return soldToParty;
	}

	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}

	public String getDeliveryPlant() {
		return this.deliveryPlant;
	}

	public void setDeliveryPlant(String deliveryPlant) {
		this.deliveryPlant = deliveryPlant;
	}

	public String getDeliveryPriority() {
		return this.deliveryPriority;
	}

	public void setDeliveryPriority(String deliveryPriority) {
		this.deliveryPriority = deliveryPriority;
	}

	public String getDistChannel() {
		return this.distChannel;
	}

	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}

	public String getDivision() {
		return this.division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getGstin() {
		return this.gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getPaymentTerms() {
		return this.paymentTerms;
	}

	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public String getPin() {
		return this.pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getRecoAccount() {
		return this.recoAccount;
	}

	public void setRecoAccount(String recoAccount) {
		this.recoAccount = recoAccount;
	}

	public String getRegionCode() {
		return this.regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getSalesOffice() {
		return this.salesOffice;
	}

	public void setSalesOffice(String salesOffice) {
		this.salesOffice = salesOffice;
	}

	public String getSalesOrg() {
		return this.salesOrg;
	}

	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

	public String getShippingCon() {
		return this.shippingCon;
	}

	public void setShippingCon(String shippingCon) {
		this.shippingCon = shippingCon;
	}

	public String getStreet1() {
		return this.street1;
	}

	public void setStreet1(String street1) {
		this.street1 = street1;
	}

	public String getStreet2() {
		return this.street2;
	}

	public void setStreet2(String street2) {
		this.street2 = street2;
	}

	public String getStreet3() {
		return this.street3;
	}

	public void setStreet3(String street3) {
		this.street3 = street3;
	}

	public String getStreet4() {
		return this.street4;
	}

	public void setStreet4(String street4) {
		this.street4 = street4;
	}

	public String getStreet5() {
		return this.street5;
	}

	public StateMst getStateMst() {
		return stateMst;
	}

	public void setStateMst(StateMst stateMst) {
		this.stateMst = stateMst;
	}

	public void setStreet5(String street5) {
		this.street5 = street5;
	}

	public CountryMst getCountryMst() {
		return countryMst;
	}

	public void setCountryMst(CountryMst countryMst) {
		this.countryMst = countryMst;
	}

	public PayTermsMst getPayTermsMst() {
		return payTermsMst;
	}

	public void setPayTermsMst(PayTermsMst payTermsMst) {
		this.payTermsMst = payTermsMst;
	}

	public DistChannelMst getDistChannelMst() {
		return distChannelMst;
	}

	public void setDistChannelMst(DistChannelMst distChannelMst) {
		this.distChannelMst = distChannelMst;
	}

	public DivisionMst getDivisionMst() {
		return divisionMst;
	}

	public void setDivisionMst(DivisionMst divisionMst) {
		this.divisionMst = divisionMst;
	}

	public PlantSapmst getPlantSapmst() {
		return plantSapmst;
	}

	public void setPlantSapmst(PlantSapmst plantSapmst) {
		this.plantSapmst = plantSapmst;
	}

	public SalesOrgMst getSalesOrgMst() {
		return salesOrgMst;
	}

	public void setSalesOrgMst(SalesOrgMst salesOrgMst) {
		this.salesOrgMst = salesOrgMst;
	}

	public SalesOfficeMst getSalesOfficeMst() {
		return salesOfficeMst;
	}

	public void setSalesOfficeMst(SalesOfficeMst salesOfficeMst) {
		this.salesOfficeMst = salesOfficeMst;
	}
	
	
}