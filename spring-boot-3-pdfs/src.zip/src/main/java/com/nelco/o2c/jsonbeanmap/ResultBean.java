/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Jayashankar.r
 *
 */
public class ResultBean {

	@JsonProperty("Potentials")
	private LeadsBean leads;

	public LeadsBean getLeads() {
		return leads;
	}

	public void setLeads(LeadsBean leads) {
		this.leads = leads;
	}

}
