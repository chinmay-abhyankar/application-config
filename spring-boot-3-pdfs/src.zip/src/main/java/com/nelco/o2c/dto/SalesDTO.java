package com.nelco.o2c.dto;

public class SalesDTO {
	private Integer id;	
	private String creditNoteNoEquipment;	
	private int customerId;	
	private String disconnectionDate;	
	private int hubId;	
	private String invoiceNoEquipment;
	private String matnr;	
	private String matnrReturnStatus;	
	private String nocRemarks;
	private String returnType;	
	private String salesOrderNoBw;	
	private String salesOrderNoEquipment;	
	private String uniqId;		
	private String invoiceNoBW;		
	private String creditNoteNoBW;	
	private String status;	
	private String distChannel;	
	private String plant;	
	private String salesOrg;	
	private Integer createdUserId;	
	private String mdApproved;
	private String invoiceDate;
	private String consumptionNo;
	
	public String getConsumptionNo() {
		return consumptionNo;
	}
	public void setConsumptionNo(String consumptionNo) {
		this.consumptionNo = consumptionNo;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCreditNoteNoEquipment() {
		return creditNoteNoEquipment;
	}
	public void setCreditNoteNoEquipment(String creditNoteNoEquipment) {
		this.creditNoteNoEquipment = creditNoteNoEquipment;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getDisconnectionDate() {
		return disconnectionDate;
	}
	public void setDisconnectionDate(String disconnectionDate) {
		this.disconnectionDate = disconnectionDate;
	}
	public int getHubId() {
		return hubId;
	}
	public void setHubId(int hubId) {
		this.hubId = hubId;
	}
	public String getInvoiceNoEquipment() {
		return invoiceNoEquipment;
	}
	public void setInvoiceNoEquipment(String invoiceNoEquipment) {
		this.invoiceNoEquipment = invoiceNoEquipment;
	}
	public String getMatnr() {
		return matnr;
	}
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	public String getMatnrReturnStatus() {
		return matnrReturnStatus;
	}
	public void setMatnrReturnStatus(String matnrReturnStatus) {
		this.matnrReturnStatus = matnrReturnStatus;
	}
	public String getNocRemarks() {
		return nocRemarks;
	}
	public void setNocRemarks(String nocRemarks) {
		this.nocRemarks = nocRemarks;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	public String getSalesOrderNoBw() {
		return salesOrderNoBw;
	}
	public void setSalesOrderNoBw(String salesOrderNoBw) {
		this.salesOrderNoBw = salesOrderNoBw;
	}
	public String getSalesOrderNoEquipment() {
		return salesOrderNoEquipment;
	}
	public void setSalesOrderNoEquipment(String salesOrderNoEquipment) {
		this.salesOrderNoEquipment = salesOrderNoEquipment;
	}
	public String getUniqId() {
		return uniqId;
	}
	public void setUniqId(String uniqId) {
		this.uniqId = uniqId;
	}
	public String getInvoiceNoBW() {
		return invoiceNoBW;
	}
	public void setInvoiceNoBW(String invoiceNoBW) {
		this.invoiceNoBW = invoiceNoBW;
	}
	public String getCreditNoteNoBW() {
		return creditNoteNoBW;
	}
	public void setCreditNoteNoBW(String creditNoteNoBW) {
		this.creditNoteNoBW = creditNoteNoBW;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDistChannel() {
		return distChannel;
	}
	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getSalesOrg() {
		return salesOrg;
	}
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	public Integer getCreatedUserId() {
		return createdUserId;
	}
	public void setCreatedUserId(Integer createdUserId) {
		this.createdUserId = createdUserId;
	}
	public String getMdApproved() {
		return mdApproved;
	}
	public void setMdApproved(String mdApproved) {
		this.mdApproved = mdApproved;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	
	
}
