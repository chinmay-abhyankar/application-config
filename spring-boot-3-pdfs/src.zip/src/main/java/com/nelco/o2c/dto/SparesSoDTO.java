/**
 * 
 */
package com.nelco.o2c.dto;

/**
 * @author Jayashankar.r
 *
 */
public class SparesSoDTO {
	private Integer soOrdersId;
	private String sparesSoNumber;
	private String comments;
	private Boolean isSaved = false;
	private String soNumber;
	
	

	public String getSoNumber() {
		return soNumber;
	}

	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}

	public Integer getSoOrdersId() {
		return soOrdersId;
	}

	public void setSoOrdersId(Integer soOrdersId) {
		this.soOrdersId = soOrdersId;
	}

	public String getSparesSoNumber() {
		return sparesSoNumber;
	}

	public void setSparesSoNumber(String sparesSoNumber) {
		this.sparesSoNumber = sparesSoNumber;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Boolean getIsSaved() {
		return isSaved;
	}

	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}

}
