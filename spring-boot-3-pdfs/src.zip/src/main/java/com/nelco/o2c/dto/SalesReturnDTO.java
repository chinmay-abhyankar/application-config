package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.HubMst;
import com.nelco.o2c.model.StateMst;

public class SalesReturnDTO {
	private List<HubMst> hubMst = new ArrayList<HubMst>();
	
	private List<FileTypeMst> fileList=new ArrayList<FileTypeMst>();
	
	private List<InvoiceDTO> lstInvoiceDTO=null;
	
	private List<MaterialDetailsDTO> lstMaterialDetailsDTO=null;	
	
	public List<FileTypeMst> getFileList() {
		return fileList;
	}

	public void setFileList(List<FileTypeMst> fileList) {
		this.fileList = fileList;
	}

	public List<MaterialDetailsDTO> getLstMaterialDetailsDTO() {
		return lstMaterialDetailsDTO;
	}

	public void setLstMaterialDetailsDTO(List<MaterialDetailsDTO> lstMaterialDetailsDTO) {
		this.lstMaterialDetailsDTO = lstMaterialDetailsDTO;
	}

	public List<InvoiceDTO> getLstInvoiceDTO() {
		return lstInvoiceDTO;
	}

	public void setLstInvoiceDTO(List<InvoiceDTO> lstInvoiceDTO) {
		this.lstInvoiceDTO = lstInvoiceDTO;
	}

	public List<HubMst> getHubMst() {
		return hubMst;
	}

	public void setHubMst(List<HubMst> hubMst) {
		this.hubMst = hubMst;
	} 
	
	
	
}
