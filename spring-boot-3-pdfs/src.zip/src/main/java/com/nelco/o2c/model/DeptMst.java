/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author Jayashankar.r
 *
 */
@Entity
@Table(name = "dept_mst")
@NamedQueries({
	@NamedQuery(name = "DeptMst.getAllDeptList", query = "select dp from DeptMst dp"),
	@NamedQuery(name = "DeptMst.getDeptBydeptMstId", query = "select dp from DeptMst dp where dp.deptMstId =?1 ")
	})
public class DeptMst implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "dept_mst_id")
	private Integer deptMstId;

	@Column(name = "dept_cd", length = 10)
	private String deptCd;

	@Column(name = "dept_desc", length = 50)
	private String deptDesc;
	
	@Transient
	private Integer userMstId;
	

	public Integer getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

	public Integer getDeptMstId() {
		return deptMstId;
	}

	public void setDeptMstId(Integer deptMstId) {
		this.deptMstId = deptMstId;
	}

	public String getDeptCd() {
		return deptCd;
	}

	public void setDeptCd(String deptCd) {
		this.deptCd = deptCd;
	}

	public String getDeptDesc() {
		return deptDesc;
	}

	public void setDeptDesc(String deptDesc) {
		this.deptDesc = deptDesc;
	}

}
