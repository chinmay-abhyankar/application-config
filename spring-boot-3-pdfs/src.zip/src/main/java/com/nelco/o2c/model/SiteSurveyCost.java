package com.nelco.o2c.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.utility.DateUtil;


/**
 * The persistent class for the site_survey_cost database table.
 * 
 */
@Entity
@Table(name="site_survey_cost")
@NamedQueries({@NamedQuery(name="SiteSurveyCost.findAll", query="SELECT s FROM SiteSurveyCost s"),
	@NamedQuery(name="SiteSurveyCost.findAllForHoCs", query="SELECT s FROM SiteSurveyCost s where s.hoCsId=?1 and s.createdDate between ?2 and ?3 "),
	@NamedQuery(name="SiteSurveyCost.findAllPmgtCSHead", query="SELECT s FROM SiteSurveyCost s where s.csHeadId=?1 and s.createdDate between ?2 and ?3 "),
	@NamedQuery(name="SiteSurveyCost.findAllWithDateFilter", query="SELECT s FROM SiteSurveyCost s where s.createdDate between ?1 and ?2 ")
	})
@NamedNativeQueries({
	@NamedNativeQuery(name="SiteSurveyCost.findAllForSuppExec", query=" select sc.site_survey_cost_id,sc.app_cost,convert(varchar, sc.created_date, 23) as date1,"
			+ " sc.cs_appr,convert(varchar, sc.cs_appr_date, 23) as date2, sc.cs_appr_remarks,sc.cs_head_appr,convert(varchar, sc.cs_head_appr_date, 23) as date3,sc.cs_head_appr_remarks,"
			+ " sc.cs_head_id, sc.cs_id,sc.default_cost,sc.franchise_mst_id,sc.ho_cs_appr,convert(varchar, sc.ho_cs_appr_date, 23) as date4, "
			+ " sc.ho_cs_appr_remarks,sc.ho_cs_id,sc.mannual_cost,sc.other_cost,sc.site_survey_mst_id ,sc.status_mst_id,"
			+ " sc.total_cost, sc.franchisee_allocation_mst_id,sc.franchise_inv_req_id,ssm.uniq_id,null,fm.franchise_name,stat.status_mst_id as statusId,stat.status_code,stat.status_name "
			+ " from site_survey_cost sc inner join site_survey_mst ssm on sc.site_survey_mst_id = ssm.id "
			+ " inner join state_mst sm on ssm.state_id = sm.state_mst_id inner join user_to_region_mst utrm "
			+ " on sm.state_mst_id = utrm.region_code "
			+ " inner join franchise_mst fm on sc.franchise_mst_id = fm.franchise_mst_id "
			+ " inner join status_mst stat on sc.status_mst_id = stat.status_mst_id "
			+ " where sc.franchise_inv_req_id is null and utrm.user_id = :userMstId and sc.created_date "
			+ " between :fromDate and :toDate "
			+ " union "
			+ " select sc.site_survey_cost_id,sc.app_cost,convert(varchar, sc.created_date, 23) as date1,sc.cs_appr,convert(varchar, sc.cs_appr_date, 23) as date2, "
			+ " sc.cs_appr_remarks,sc.cs_head_appr,convert(varchar, sc.cs_head_appr_date, 23) as date3,sc.cs_head_appr_remarks,sc.cs_head_id, "
			+ " sc.cs_id,sc.default_cost,sc.franchise_mst_id,sc.ho_cs_appr,convert(varchar, sc.ho_cs_appr_date, 23) as date4, sc.ho_cs_appr_remarks,"
			+ " sc.ho_cs_id,sc.mannual_cost,sc.other_cost,sc.site_survey_mst_id ,sc.status_mst_id,sc.total_cost, "
			+ " sc.franchisee_allocation_mst_id,sc.franchise_inv_req_id,null,fam.uniq_id,fm.franchise_name,stat.status_mst_id as statusId,stat.status_code,stat.status_name"
			+ " from site_survey_cost sc "
			+ " inner join franchisee_allocation_mst fam on sc.franchisee_allocation_mst_id = fam.id "
			+ " inner join so_orders so "
			+ " on fam.so_number = so.so_number and fam.item = so.item "
			+ " inner join customer_sapmst cs on so.ship_to_party = cs.customer_num and so.dist_channel = cs.dist_channel "
			+ " and so.sales_org = cs.sales_org and so.division = cs.division inner join state_mst sm "
			+ " on cs.region_code = sm.state_code inner join user_to_region_mst utrm on sm.state_mst_id = utrm.region_code "
			+ " inner join franchise_mst fm on sc.franchise_mst_id = fm.franchise_mst_id "
			+ " inner join status_mst stat on sc.status_mst_id = stat.status_mst_id "
			+ " left outer join delivery d on fam.delivery_id = d.delivery_id  "
			+ " where sc.franchise_inv_req_id is null and utrm.user_id = :userMstId and sc.created_date "
			+ " between :fromDate and :toDate "),//@NamedQuery(name="SiteSurveyCost.findAllForSuppExec", query="SELECT s FROM SiteSurveyCost s where s.csId=?1 and s.createdDate between ?2 and ?3 "),
	@NamedNativeQuery(name="SiteSurveyCost.findAllFranCoord",query = " select sc.site_survey_cost_id,sc.app_cost,convert(varchar, sc.created_date, 23) as date1,"
			+ " sc.cs_appr,convert(varchar, sc.cs_appr_date, 23) as date2, sc.cs_appr_remarks,sc.cs_head_appr,convert(varchar, sc.cs_head_appr_date, 23) as date3,"
			+ " sc.cs_head_appr_remarks,sc.cs_head_id, sc.cs_id,sc.default_cost,sc.franchise_mst_id,"
			+ " sc.ho_cs_appr,convert(varchar, sc.ho_cs_appr_date, 23) as date4, sc.ho_cs_appr_remarks,sc.ho_cs_id,sc.mannual_cost,"
			+ " sc.other_cost,sc.site_survey_mst_id ,sc.status_mst_id,sc.total_cost, "
			+ " sc.franchisee_allocation_mst_id,sc.franchise_inv_req_id,ssm.uniq_id,null,fm.franchise_name,stat.status_mst_id as statusId,stat.status_code,stat.status_name "
			+ " from site_survey_cost sc inner join user_to_franchisee_mst utf "
			+ " on sc.franchise_mst_id = utf.franchisee_id "
			+ " inner join site_survey_mst ssm on sc.site_survey_mst_id = ssm.id "
			+ " inner join franchise_mst fm on sc.franchise_mst_id = fm.franchise_mst_id "
			+ " inner join status_mst stat on sc.status_mst_id = stat.status_mst_id "
			+ " where sc.franchise_inv_req_id is null and utf.user_mst_id = :userMstId and sc.created_date "
			+ " between :fromDate and :toDate "
			+ " union "
			+ " select sc.site_survey_cost_id,sc.app_cost,convert(varchar, sc.created_date, 23) as date1,sc.cs_appr,convert(varchar, sc.cs_appr_date, 23) as date2,"
			+ " sc.cs_appr_remarks,sc.cs_head_appr,convert(varchar, sc.cs_head_appr_date, 23) as date3,sc.cs_head_appr_remarks,sc.cs_head_id,"
			+ " sc.cs_id,sc.default_cost,sc.franchise_mst_id,sc.ho_cs_appr,convert(varchar, sc.ho_cs_appr_date, 23) as date4,"
			+ " sc.ho_cs_appr_remarks,sc.ho_cs_id,sc.mannual_cost,sc.other_cost,sc.site_survey_mst_id ,"
			+ " sc.status_mst_id,sc.total_cost, sc.franchisee_allocation_mst_id,"
			+ " sc.franchise_inv_req_id,null,fam.uniq_id,fm.franchise_name,stat.status_mst_id as statusId,stat.status_code,stat.status_name "
			+ " from site_survey_cost sc inner join user_to_franchisee_mst utf on sc.franchise_mst_id = utf.franchisee_id "
			+ " inner join franchisee_allocation_mst fam on sc.franchisee_allocation_mst_id = fam.id "
			+ " inner join franchise_mst fm on sc.franchise_mst_id = fm.franchise_mst_id "
			+ " inner join status_mst stat on sc.status_mst_id = stat.status_mst_id "
			+ " where sc.franchise_inv_req_id is null and utf.user_mst_id = :userMstId and sc.created_date "
			+ " between :fromDate and :toDate "),//query="SELECT s FROM SiteSurveyCost s where s.franchiseMstId in ?1 and s.createdDate between ?2 and ?3 "
	@NamedNativeQuery(name="SiteSurveyCost.findAllFranCoordPaymentRaiseRequest",query = " select sc.site_survey_cost_id,sc.app_cost,convert(varchar, sc.created_date, 23) as date1,"
			+ " sc.cs_appr,convert(varchar, sc.cs_appr_date, 23) as date2, sc.cs_appr_remarks,sc.cs_head_appr,convert(varchar, sc.cs_head_appr_date, 23) as date3,"
			+ " sc.cs_head_appr_remarks,sc.cs_head_id, sc.cs_id,sc.default_cost,sc.franchise_mst_id,"
			+ " sc.ho_cs_appr,convert(varchar, sc.ho_cs_appr_date, 23) as date4, sc.ho_cs_appr_remarks,sc.ho_cs_id,sc.mannual_cost,"
			+ " sc.other_cost,sc.site_survey_mst_id ,sc.status_mst_id,sc.total_cost, "
			+ " sc.franchisee_allocation_mst_id,sc.franchise_inv_req_id,ssm.uniq_id,null,fm.franchise_name,stat.status_mst_id as statusId,stat.status_code,stat.status_name "
			+ " from site_survey_cost sc inner join user_to_franchisee_mst utf "
			+ " on sc.franchise_mst_id = utf.franchisee_id "
			+ " inner join site_survey_mst ssm on sc.site_survey_mst_id = ssm.id "
			+ " inner join franchise_mst fm on sc.franchise_mst_id = fm.franchise_mst_id "
			+ " inner join status_mst stat on sc.status_mst_id = stat.status_mst_id "
			+ " where sc.franchise_inv_req_id is null and utf.user_mst_id = :userMstId and sc.created_date "
			+ " between :fromDate and :toDate and stat.status_code in ('SCSTF','SCRBF') "
			+ " union "
			+ " select sc.site_survey_cost_id,sc.app_cost,convert(varchar, sc.created_date, 23) as date1,sc.cs_appr,convert(varchar, sc.cs_appr_date, 23) as date2,"
			+ " sc.cs_appr_remarks,sc.cs_head_appr,convert(varchar, sc.cs_head_appr_date, 23) as date3,sc.cs_head_appr_remarks,sc.cs_head_id,"
			+ " sc.cs_id,sc.default_cost,sc.franchise_mst_id,sc.ho_cs_appr,convert(varchar, sc.ho_cs_appr_date, 23) as date4,"
			+ " sc.ho_cs_appr_remarks,sc.ho_cs_id,sc.mannual_cost,sc.other_cost,sc.site_survey_mst_id ,"
			+ " sc.status_mst_id,sc.total_cost, sc.franchisee_allocation_mst_id,"
			+ " sc.franchise_inv_req_id,null,fam.uniq_id,fm.franchise_name,stat.status_mst_id as statusId,stat.status_code,stat.status_name "
			+ " from site_survey_cost sc inner join user_to_franchisee_mst utf on sc.franchise_mst_id = utf.franchisee_id "
			+ " inner join franchisee_allocation_mst fam on sc.franchisee_allocation_mst_id = fam.id "
			+ " inner join franchise_mst fm on sc.franchise_mst_id = fm.franchise_mst_id "
			+ " inner join status_mst stat on sc.status_mst_id = stat.status_mst_id "
			+ " where sc.franchise_inv_req_id is null and utf.user_mst_id = :userMstId and sc.created_date "
			+ " between :fromDate and :toDate and stat.status_code in ('SCSTF','SCRBF') "),
	@NamedNativeQuery(name="SiteSurveyCost.findAllByInvoiceRequest",query = " select sc.site_survey_cost_id,sc.app_cost,convert(varchar, sc.created_date, 23) as date1,"
			+ " sc.cs_appr,convert(varchar, sc.cs_appr_date, 23) as date2, sc.cs_appr_remarks,sc.cs_head_appr,convert(varchar, sc.cs_head_appr_date, 23) as date3,"
			+ " sc.cs_head_appr_remarks,sc.cs_head_id, sc.cs_id,sc.default_cost,sc.franchise_mst_id,"
			+ " sc.ho_cs_appr,convert(varchar, sc.ho_cs_appr_date, 23) as date4, sc.ho_cs_appr_remarks,sc.ho_cs_id,sc.mannual_cost,"
			+ " sc.other_cost,sc.site_survey_mst_id ,sc.status_mst_id,sc.total_cost, "
			+ " sc.franchisee_allocation_mst_id,sc.franchise_inv_req_id,ssm.uniq_id,null,fm.franchise_name,stat.status_mst_id as statusId,stat.status_code,stat.status_name "
			+ " from site_survey_cost sc inner join user_to_franchisee_mst utf "
			+ " on sc.franchise_mst_id = utf.franchisee_id "
			+ " inner join site_survey_mst ssm on sc.site_survey_mst_id = ssm.id "
			+ " inner join franchise_mst fm on sc.franchise_mst_id = fm.franchise_mst_id "
			+ " inner join status_mst stat on sc.status_mst_id = stat.status_mst_id "
			+ " where sc.franchise_inv_req_id = :franchiseInvReqId "
			+ " union "
			+ " select sc.site_survey_cost_id,sc.app_cost,convert(varchar, sc.created_date, 23) as date1,sc.cs_appr,convert(varchar, sc.cs_appr_date, 23) as date2,"
			+ " sc.cs_appr_remarks,sc.cs_head_appr,convert(varchar, sc.cs_head_appr_date, 23) as date3,sc.cs_head_appr_remarks,sc.cs_head_id,"
			+ " sc.cs_id,sc.default_cost,sc.franchise_mst_id,sc.ho_cs_appr,convert(varchar, sc.ho_cs_appr_date, 23) as date4,"
			+ " sc.ho_cs_appr_remarks,sc.ho_cs_id,sc.mannual_cost,sc.other_cost,sc.site_survey_mst_id ,"
			+ " sc.status_mst_id,sc.total_cost, sc.franchisee_allocation_mst_id,"
			+ " sc.franchise_inv_req_id,null,fam.uniq_id,fm.franchise_name,stat.status_mst_id as statusId,stat.status_code,stat.status_name "
			+ " from site_survey_cost sc inner join user_to_franchisee_mst utf on sc.franchise_mst_id = utf.franchisee_id "
			+ " inner join franchisee_allocation_mst fam on sc.franchisee_allocation_mst_id = fam.id "
			+ " inner join franchise_mst fm on sc.franchise_mst_id = fm.franchise_mst_id "
			+ " inner join status_mst stat on sc.status_mst_id = stat.status_mst_id "
			+ " where sc.franchise_inv_req_id = :franchiseInvReqId ")
})
public class SiteSurveyCost implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="site_survey_cost_id")
	private Integer siteSurveyCostId;
	
	

	@Column(name="app_cost")
	private String appCost;

	@Column(name="created_date", updatable = false)
	private String createdDate;

	@Column(name="cs_appr")
	private String csAppr="NA";

	@Column(name="cs_appr_date")
	private String csApprDate;

	@Column(name="cs_appr_remarks")
	private String csApprRemarks;

	@Column(name="cs_head_appr")
	private String csHeadAppr="NA";

	@Column(name="cs_head_appr_date")
	private String csHeadApprDate;

	@Column(name="cs_head_appr_remarks")
	private String csHeadApprRemarks;

	@Column(name="cs_head_id")
	private Integer csHeadId;

	@Column(name="cs_id")
	private Integer csId;

	@Column(name="default_cost")
	private BigDecimal defaultCost;

	@Column(name="franchise_mst_id")
	private Integer franchiseMstId;

	@Column(name="ho_cs_appr")
	private String hoCsAppr="NA";

	@Column(name="ho_cs_appr_date")
	private String hoCsApprDate;

	@Column(name="ho_cs_appr_remarks")
	private String hoCsApprRemarks;

	@Column(name="ho_cs_id")
	private Integer hoCsId;

	@Column(name="mannual_cost")
	private BigDecimal mannualCost;

	@Column(name="other_cost")
	private BigDecimal otherCost;

	@Column(name="site_survey_mst_id")
	private Integer siteSurveyMstId;

	@Column(name="status_mst_id")
	private Integer statusMstId = 39;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_mst_id", referencedColumnName = "status_mst_id", insertable = false, updatable = false)
	private StatusMst statusMst;

	@Column(name="total_cost")
	private BigDecimal totalCost;
	
	@Transient
	private String siteSurveyId;
	
	@Transient
	private String franchiseName;
	
	@Transient
	private String franchiseAllocUniqId;
	
	@Column(name = "franchisee_allocation_mst_id")
	private Integer franchiseeAllocationMstId; 
	
	@Column(name = "franchise_inv_req_id")
	private Integer franchiseInvReqId; 
	
	
	
	public String getFranchiseAllocUniqId() {
		return franchiseAllocUniqId;
	}

	public void setFranchiseAllocUniqId(String franchiseAllocUniqId) {
		this.franchiseAllocUniqId = franchiseAllocUniqId;
	}

	public Integer getFranchiseInvReqId() {
		return franchiseInvReqId;
	}

	public void setFranchiseInvReqId(Integer franchiseInvReqId) {
		this.franchiseInvReqId = franchiseInvReqId;
	}

	public Integer getFranchiseeAllocationMstId() {
		return franchiseeAllocationMstId;
	}

	public void setFranchiseeAllocationMstId(Integer franchiseeAllocationMstId) {
		this.franchiseeAllocationMstId = franchiseeAllocationMstId;
	}

	public String getFranchiseName() {
		return franchiseName;
	}

	public void setFranchiseName(String franchiseName) {
		this.franchiseName = franchiseName;
	}

	public String getSiteSurveyId() {
		return siteSurveyId;
	}

	public void setSiteSurveyId(String siteSurveyId) {
		this.siteSurveyId = siteSurveyId;
	}

	

	public StatusMst getStatusMst() {
		return statusMst;
	}

	public void setStatusMst(StatusMst statusMst) {
		this.statusMst = statusMst;
	}

	public SiteSurveyCost() {
	}

	public Integer getSiteSurveyCostId() {
		return this.siteSurveyCostId;
	}

	public void setSiteSurveyCostId(Integer siteSurveyCostId) {
		this.siteSurveyCostId = siteSurveyCostId;
	}

	public String getAppCost() {
		return this.appCost;
	}

	public void setAppCost(String appCost) {
		this.appCost = appCost;
	}

	public String getCreatedDate() {
		return DateUtil.getSimpleUIDateFromSqlDate(this.createdDate);
		//return this.createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCsAppr() {
		return this.csAppr;
	}

	public void setCsAppr(String csAppr) {
		this.csAppr = csAppr;
	}

	public String getCsApprDate() {
		return this.csApprDate;
	}

	public void setCsApprDate(String csApprDate) {
		this.csApprDate = csApprDate;
	}

	public String getCsApprRemarks() {
		return this.csApprRemarks;
	}

	public void setCsApprRemarks(String csApprRemarks) {
		this.csApprRemarks = csApprRemarks;
	}

	public String getCsHeadAppr() {
		return this.csHeadAppr;
	}

	public void setCsHeadAppr(String csHeadAppr) {
		this.csHeadAppr = csHeadAppr;
	}

	public String getCsHeadApprDate() {
		return this.csHeadApprDate;
	}

	public void setCsHeadApprDate(String csHeadApprDate) {
		this.csHeadApprDate = csHeadApprDate;
	}

	public String getCsHeadApprRemarks() {
		return this.csHeadApprRemarks;
	}

	public void setCsHeadApprRemarks(String csHeadApprRemarks) {
		this.csHeadApprRemarks = csHeadApprRemarks;
	}

	public Integer getCsHeadId() {
		return this.csHeadId;
	}

	public void setCsHeadId(Integer csHeadId) {
		this.csHeadId = csHeadId;
	}

	public Integer getCsId() {
		return this.csId;
	}

	public void setCsId(Integer csId) {
		this.csId = csId;
	}

	public BigDecimal getDefaultCost() {
		return this.defaultCost;
	}

	public void setDefaultCost(BigDecimal defaultCost) {
		this.defaultCost = defaultCost;
	}

	public Integer getFranchiseMstId() {
		return this.franchiseMstId;
	}

	public void setFranchiseMstId(Integer franchiseMstId) {
		this.franchiseMstId = franchiseMstId;
	}

	public String getHoCsAppr() {
		return this.hoCsAppr;
	}

	public void setHoCsAppr(String hoCsAppr) {
		this.hoCsAppr = hoCsAppr;
	}

	public String getHoCsApprDate() {
		return this.hoCsApprDate;
	}

	public void setHoCsApprDate(String hoCsApprDate) {
		this.hoCsApprDate = hoCsApprDate;
	}

	public String getHoCsApprRemarks() {
		return this.hoCsApprRemarks;
	}

	public void setHoCsApprRemarks(String hoCsApprRemarks) {
		this.hoCsApprRemarks = hoCsApprRemarks;
	}

	public Integer getHoCsId() {
		return this.hoCsId;
	}

	public void setHoCsId(Integer hoCsId) {
		this.hoCsId = hoCsId;
	}

	public BigDecimal getMannualCost() {
		return this.mannualCost;
	}

	public void setMannualCost(BigDecimal mannualCost) {
		this.mannualCost = mannualCost;
	}

	public BigDecimal getOtherCost() {
		return this.otherCost;
	}

	public void setOtherCost(BigDecimal otherCost) {
		this.otherCost = otherCost;
	}

	public Integer getSiteSurveyMstId() {
		return this.siteSurveyMstId;
	}

	public void setSiteSurveyMstId(Integer siteSurveyMstId) {
		this.siteSurveyMstId = siteSurveyMstId;
	}

	public Integer getStatusMstId() {
		return this.statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}

	public BigDecimal getTotalCost() {
		return this.totalCost;
	}

	public void setTotalCost(BigDecimal totalCost) {
		this.totalCost = totalCost;
	}

}