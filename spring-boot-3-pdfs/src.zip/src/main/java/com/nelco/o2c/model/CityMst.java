/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author Amol.l
 *
 */

@Entity
@Table(name = "city_mst")
@NamedQuery(name="CityMst.findAll", query="SELECT c FROM CityMst c")
public class CityMst implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "city_mst_id")
	private Integer cityMstId;
	
	@Column(name = "city_code", length = 10)
	private String cityCode;
	
	@Column(name = "city_val", length = 30)
	private String cityVal;

	public Integer getCityMstId() {
		return cityMstId;
	}

	public void setCityMstId(Integer cityMstId) {
		this.cityMstId = cityMstId;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getCityVal() {
		return cityVal;
	}

	public void setCityVal(String cityVal) {
		this.cityVal = cityVal;
	}
	
}
