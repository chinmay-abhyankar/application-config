/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.jsonbeanmap.DrfExtBean;

/**
 * @author Jayshankar.r
 *
 */
public class DrfExtListDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<DrfExtBean> drfExtList;
	private String roleCode;
	private Integer userMstId;
	public List<DrfExtBean> getDrfExtList() {
		return drfExtList;
	}
	public void setDrfExtList(List<DrfExtBean> drfExtList) {
		this.drfExtList = drfExtList;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	
	
}
