package com.nelco.o2c.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nelco.o2c.dto.ReportsDTO;
import com.nelco.o2c.dto.ReportsFilterDTO;
import com.nelco.o2c.service.SiteSurveyReportService;

@RestController
public class ReportsController {
	@Autowired
	DataSource ds;
	
	@Autowired
	private SiteSurveyReportService siteSurveyReportService;
	
	public ReportsDTO utility(@RequestParam("inputJson") String ipJson) throws SQLException, JsonParseException, JsonMappingException, IOException {
		
		 ObjectMapper mapper = new ObjectMapper();
		 ReportsDTO reportsDTO = mapper.readValue(ipJson, ReportsDTO.class);
	     return reportsDTO;
	}
	
	@RequestMapping(value="/siteSurveyReport.do",method = RequestMethod.GET)
	public void siteSurveyReport(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) {
		try {
			ReportsDTO reportsDTO = utility(ipJson);
			siteSurveyReportService.siteSurveryReport(request, response, reportsDTO);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value="/salesOrderReport.do",method = RequestMethod.GET)
	public void salesOrderReport(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) {
		try {
			ReportsDTO reportsDTO = utility(ipJson);
			siteSurveyReportService.salesOrderReport(request, response, reportsDTO);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value="/incReport.do",method = RequestMethod.GET)
	public void incReport(HttpServletRequest request, HttpServletResponse response,@RequestParam("inputJson") String ipJson) {
		try {
			ReportsDTO reportsDTO = utility(ipJson);
			siteSurveyReportService.incReport(request, response, reportsDTO);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

}