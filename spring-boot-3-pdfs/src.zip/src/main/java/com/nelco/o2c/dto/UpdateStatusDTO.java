/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.DrfStatusTracker;
import com.nelco.o2c.model.UserMst;

/**
 * @author Amol.l
 *
 */
public class UpdateStatusDTO extends CommonDTO implements Serializable {
	private static final long serialVersionUID = 22L;
	
	private Integer drfDetailsId;
	private String zohoId;

	private CommonDTO commonDTO = new  CommonDTO();
	private DrfStatusTracker drfStatusTracker = new DrfStatusTracker();
	private List<UserMst> opcApprovers;
	
	public List<UserMst> getOpcApprovers() {
		return opcApprovers;
	}
	public void setOpcApprovers(List<UserMst> opcApprovers) {
		this.opcApprovers = opcApprovers;
	}
	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}
	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}
	
	
	public String getZohoId() {
		return zohoId;
	}
	public void setZohoId(String zohoId) {
		this.zohoId = zohoId;
	}
	public CommonDTO getCommonDTO() {
		return commonDTO;
	}
	public void setCommonDTO(CommonDTO commonDTO) {
		this.commonDTO = commonDTO;
	}
	public DrfStatusTracker getDrfStatusTracker() {
		return drfStatusTracker;
	}
	public void setDrfStatusTracker(DrfStatusTracker drfStatusTracker) {
		this.drfStatusTracker = drfStatusTracker;
	}
		
}
