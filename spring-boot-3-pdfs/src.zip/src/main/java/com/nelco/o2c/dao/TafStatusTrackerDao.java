package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.TafStatusTrackerDTO;

public interface TafStatusTrackerDao {
	public List<TafStatusTrackerDTO> getTafStatusTracker(String commonDTO);
	
}
