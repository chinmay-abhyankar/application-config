/**
 * 
 */
package com.nelco.o2c.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.AutoCompleteDTO;
import com.nelco.o2c.dto.AutoPopulateDTO;
import com.nelco.o2c.service.AutoPopulateService;

/**
 * @author Jayashankar.r
 *
 */
@RestController
public class AutoPopulateController {

	@Autowired
	AutoPopulateService autoPopulateService;

	@GetMapping("/searchMaterial.do")
	public AutoPopulateDTO searchMaterial(@RequestParam String material) {

		return autoPopulateService.searchMaterial(material);
	}
	
	@GetMapping("/searchMaterialBySalesOrg.do")
	public AutoPopulateDTO searchMaterialBySalesOrg(@RequestParam String material,@RequestParam String salesOrg) {

		return autoPopulateService.searchMaterialBySalesOrg(material, salesOrg);
	}
	
	@GetMapping("/searchMaterialByPlant.do")
	public AutoPopulateDTO searchMaterialByPlant(@RequestParam String material,@RequestParam String plant) {

		return autoPopulateService.searchMaterialByPlant(material, plant);
	}

	@GetMapping("/searchSoldToParty.do")
	public AutoPopulateDTO searchSoldToParty(@RequestParam String soldToParty) {
		return autoPopulateService.searchSoldToParty(soldToParty);
	}
	
	@GetMapping("/searchPlant.do")
	public AutoPopulateDTO searchPlant(@RequestParam String plant) {
		return autoPopulateService.searchPlant(plant);
	}
	
	@GetMapping("/searchStorage.do")
	public AutoPopulateDTO searchStorage(@RequestParam String storage) {
		return autoPopulateService.searchStorage(storage);
	}
	
	@GetMapping("/searchMaterialMasterContract.do")
	public AutoPopulateDTO searchMaterialMasterContract(@RequestParam String material,@RequestParam Integer contractId) {

		return autoPopulateService.searchMaterialMasterContract(material,contractId);
	}
	
	@GetMapping("/searchAccountMgrCode.do")
	public AutoPopulateDTO searchAccountMgrCode(@RequestParam String accMgrCode) {

		return autoPopulateService.searchAccountMgrCode(accMgrCode);
	}
	
	@GetMapping("/searchPaymentTerms.do")
	public AutoPopulateDTO searchPaymentTerms(@RequestParam String payTermsCode) {

		return autoPopulateService.searchPaymentTerms(payTermsCode);
	}
	
	@GetMapping("/searchSObySoNumber.do")
	public AutoPopulateDTO searchSObySoNumber(@RequestParam String soNumber) {
		return autoPopulateService.searchSObySoNumber(soNumber);
	}
	
	@GetMapping("/searchSoldToPartySparesSo.do")
	public AutoPopulateDTO searchSoldToPartySparesSo(@RequestParam String soldToParty) {

		return autoPopulateService.searchSoldToPartySparesSo(soldToParty);
	}
	
	@GetMapping("/searchShipToPartySparesSo.do")
	public AutoPopulateDTO searchShipToPartySparesSo(@RequestParam String shipToParty) {

		return autoPopulateService.searchShipToPartySparesSo(shipToParty);
	}
	
	@GetMapping("/searchMaterialSparesSo.do")
	public AutoPopulateDTO searchMaterialSparesSo(@RequestParam String material) {

		return autoPopulateService.searchMaterialSparesSo(material);
	}
	
	@GetMapping("/searchSObySoNumberForRelocation.do")
	public AutoPopulateDTO searchSObySoNumberForRelocation(@RequestParam String soNumber) {
		return autoPopulateService.searchSObySoNumberForRelocation(soNumber);
	}
	
	@GetMapping("/searchIp.do")
	public AutoPopulateDTO searchIp(@RequestParam String ip) {
		return autoPopulateService.searchIp(ip);
	}
	
	@PostMapping("/getBillToParty.do")
	public AutoPopulateDTO getBillToParty(@RequestBody AutoCompleteDTO autoCompleteDTO) {
		return autoPopulateService.getBillToParty(autoCompleteDTO);
	}
}
