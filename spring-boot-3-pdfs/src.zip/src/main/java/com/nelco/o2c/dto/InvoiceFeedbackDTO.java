package com.nelco.o2c.dto;

public class InvoiceFeedbackDTO {
private String feedbackType="";
private String feedbackSubtype="";
private String feedback="";
private String feedbackDate="";
private String userId="";
public String getFeedbackType() {
	return feedbackType;
}
public void setFeedbackType(String feedbackType) {
	this.feedbackType = feedbackType;
}
public String getFeedbackSubtype() {
	return feedbackSubtype;
}
public void setFeedbackSubtype(String feedbackSubtype) {
	this.feedbackSubtype = feedbackSubtype;
}
public String getFeedback() {
	return feedback;
}
public void setFeedback(String feedback) {
	this.feedback = feedback;
}
public String getFeedbackDate() {
	return feedbackDate;
}
public void setFeedbackDate(String feedbackDate) {
	this.feedbackDate = feedbackDate;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}

}
