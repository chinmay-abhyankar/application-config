/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

/**
 * @author Amol.l
 *
 */
public class CommonMailDTO implements Serializable {
	private static final long serialVersionUID = 84L;

	private Integer salesCoordId;
	private Integer accountMgrId;
	private Integer programMgrId;
	private Integer financeId;
	private String conStartDate;
	private String conEndDate;
	private Integer contractId;
	private String sapContractNum;
	private Integer proposalId;
	private String proposalGenId;
	private Integer childContractId;
	private String finRemarks;
	private String soNumber;
	private String deliveryNum;
	private String receivName;
	private Integer deliveryId;
	private String receivContact;
	private String addate;
	private String eddate;
	private String contactPerson;
	private String contactPersMob;
	private String contactPersAddress;
	private String customerName;
	private String challanNum;
	private String taxInvoice;
	private String amName;
	private String amEmail;
	private String pmName;
	private String pmEmail;
	private String materialNo; 
	private String materialDesc; 
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Integer getSalesCoordId() {
		return salesCoordId;
	}
	public void setSalesCoordId(Integer salesCoordId) {
		this.salesCoordId = salesCoordId;
	}
	public Integer getAccountMgrId() {
		return accountMgrId;
	}
	public void setAccountMgrId(Integer accountMgrId) {
		this.accountMgrId = accountMgrId;
	}
	public Integer getProgramMgrId() {
		return programMgrId;
	}
	public void setProgramMgrId(Integer programMgrId) {
		this.programMgrId = programMgrId;
	}
	public Integer getFinanceId() {
		return financeId;
	}
	public void setFinanceId(Integer financeId) {
		this.financeId = financeId;
	}
	public String getConStartDate() {
		return conStartDate;
	}
	public void setConStartDate(String conStartDate) {
		this.conStartDate = conStartDate;
	}
	public String getConEndDate() {
		return conEndDate;
	}
	public void setConEndDate(String conEndDate) {
		this.conEndDate = conEndDate;
	}
	public Integer getContractId() {
		return contractId;
	}
	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}
	public String getSapContractNum() {
		return sapContractNum;
	}
	public void setSapContractNum(String sapContractNum) {
		this.sapContractNum = sapContractNum;
	}
	public Integer getProposalId() {
		return proposalId;
	}
	public void setProposalId(Integer proposalId) {
		this.proposalId = proposalId;
	}
	public String getProposalGenId() {
		return proposalGenId;
	}
	public void setProposalGenId(String proposalGenId) {
		this.proposalGenId = proposalGenId;
	}
	public Integer getChildContractId() {
		return childContractId;
	}
	public void setChildContractId(Integer childContractId) {
		this.childContractId = childContractId;
	}
	public String getFinRemarks() {
		return finRemarks;
	}
	public void setFinRemarks(String finRemarks) {
		this.finRemarks = finRemarks;
	}
	public String getSoNumber() {
		return soNumber;
	}
	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}
	public String getDeliveryNum() {
		return deliveryNum;
	}
	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}
	public String getReceivName() {
		return receivName;
	}
	public void setReceivName(String receivName) {
		this.receivName = receivName;
	}
	public Integer getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(Integer deliveryId) {
		this.deliveryId = deliveryId;
	}
	public String getReceivContact() {
		return receivContact;
	}
	public void setReceivContact(String receivContact) {
		this.receivContact = receivContact;
	}
	public String getAddate() {
		return addate;
	}
	public void setAddate(String addate) {
		this.addate = addate;
	}
	public String getEddate() {
		return eddate;
	}
	public void setEddate(String eddate) {
		this.eddate = eddate;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	public String getContactPersMob() {
		return contactPersMob;
	}
	public void setContactPersMob(String contactPersMob) {
		this.contactPersMob = contactPersMob;
	}
	public String getContactPersAddress() {
		return contactPersAddress;
	}
	public void setContactPersAddress(String contactPersAddress) {
		this.contactPersAddress = contactPersAddress;
	}
	public String getChallanNum() {
		return challanNum;
	}
	public void setChallanNum(String challanNum) {
		this.challanNum = challanNum;
	}
	public String getTaxInvoice() {
		return taxInvoice;
	}
	public void setTaxInvoice(String taxInvoice) {
		this.taxInvoice = taxInvoice;
	}
	public String getAmName() {
		return amName;
	}
	public void setAmName(String amName) {
		this.amName = amName;
	}
	public String getAmEmail() {
		return amEmail;
	}
	public void setAmEmail(String amEmail) {
		this.amEmail = amEmail;
	}
	public String getPmName() {
		return pmName;
	}
	public void setPmName(String pmName) {
		this.pmName = pmName;
	}
	public String getPmEmail() {
		return pmEmail;
	}
	public void setPmEmail(String pmEmail) {
		this.pmEmail = pmEmail;
	}
	public String getMaterialNo() {
		return materialNo;
	}
	public void setMaterialNo(String materialNo) {
		this.materialNo = materialNo;
	}
	public String getMaterialDesc() {
		return materialDesc;
	}
	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}
	
}
