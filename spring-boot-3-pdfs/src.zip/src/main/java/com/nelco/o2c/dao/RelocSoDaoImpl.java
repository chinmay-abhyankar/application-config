/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.RelocSoDTO;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.RelocationSo;
import com.nelco.o2c.model.RelocationSoUserMap;
import com.nelco.o2c.model.RelocationTypeMst;
import com.nelco.o2c.model.SiteTypeMst;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Jayshankar.r
 *
 */
@Repository
public class RelocSoDaoImpl implements RelocSoDao {

	@PersistenceContext
	private EntityManager em;
	
	Query query;

	@SuppressWarnings("unchecked")
	@Override
	public List<RelocationSo> getRolocationSoList(RelocSoDTO relocSoInputDTO) {
		// TODO Auto-generated method stub
		
		String fromDate = DateUtil.convertDateToSqlDate(relocSoInputDTO.getFromDate());
		String toDate = DateUtil.convertDateToSqlDate(relocSoInputDTO.getToDate()) + Constants.MAXDAYTIME;
		
		try {
			query = em.createNamedQuery("RelocationSo.findByCreatorIdAndDateRange");
			query.setParameter("fromDate", fromDate);
			query.setParameter("toDate", toDate);
			query.setParameter("userMstId", relocSoInputDTO.getUserMstId());
			
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			
			List<RelocationSo> relocationList = new ArrayList<RelocationSo>();
			
			for (Object[] objects : resultList) {
				RelocationSo relocationSo = new RelocationSo();
				relocationSo.setRelocationSoId((Integer)objects[0]);
				relocationSo.setUniqId((String)objects[1]);
				relocationSo.setOldEquipmentSo(objects[2]!=null?(String)objects[2]:"");
				relocationSo.setOldShipToParty(objects[3]!=null?(String)objects[3]:"");
				relocationSo.setOldShtpAddress(objects[4]!=null?(String)objects[4]:"");
				relocationSo.setNewShtpAddress(objects[5]!=null?(String)objects[5]:"");
				relocationSo.setRelocationTypeMstId(objects[6]!=null?(Integer)objects[6]:null);
				relocationSo.setRelocationCharges(objects[7]!=null?(String)objects[7]:"");
				relocationSo.setIsSubmit(objects[8]!=null?(String)objects[8]:"");
				relocationSo.setCreatedDate(objects[9]!=null?(String)objects[9]:"");
				//relocationSo.setModifiedDate(objects[10]!=null?(String)objects[10]:"");
				relocationSo.setCreatedBy(objects[11]!=null?(Integer)objects[11]:null);
				relocationSo.setSiteTypeMstId(objects[12]!=null?(Integer)objects[12]:null);
				relocationSo.setPoNumber(objects[13]!=null?(String)objects[13]:"");
				relocationSo.setSoFlag(objects[14]!=null?(String)objects[14]:"N");
				relocationSo.setRelocationTypeVal(objects[15]!=null?(String)objects[15]:"");
				
				relocationList.add(relocationSo);
				
			}
			
			
			return relocationList;
		} finally {
			// TODO: handle finally clause
			em.close();
			fromDate = null;
			toDate = null;
		}
	}

	@Override
	public RelocationSo getRolocationSoById(RelocSoDTO relocSoInputDTO) {
		try {
			// TODO Auto-generated method stub
			RelocationSo relocationSo = em.find(RelocationSo.class, relocSoInputDTO.getRelocationSoId());
			return relocationSo!=null?relocationSo:new RelocationSo();
		} catch(Exception ex){
			return new RelocationSo();
		}finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RelocationTypeMst> getRelocTypeList() {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("RelocationTypeMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			return (List<RelocationTypeMst>) query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppUploadDetail> getOppUploadByReloSoId(Integer relocationSoId) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("OppUploadDetail.getOppUploadDetailsByRelocationSoId");
			query.setParameter("relocationSoId", relocationSoId);
			return (List<OppUploadDetail>) query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public RelocationSo saveRelocationSo(RelocationSo relocationSo) {
		// TODO Auto-generated method stub
		String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
		try {
			String uniqId = "";
			if (relocationSo.getRelocationSoId() == null) {
				synchronized (this) {
					Integer maxProposalNumber = getCurrentDayCountRelocationSo();
					uniqId = "RELOCATION_" + (DateUtil.getCurrentISTDateAsString(DateUtil.SIMPLE_DATE_FORMAT)
							.replace("-", "_").concat("_").concat(maxProposalNumber.toString()));
				}
				relocationSo.setUniqId(uniqId);
				
			}
			
			relocationSo.setCreatedDate(currTime);
			relocationSo.setModifiedDate(currTime);
			return em.merge(relocationSo);
		} finally {
			// TODO: handle finally clause
			em.close();
			currTime = null;
		}
	}

	private Integer getCurrentDayCountRelocationSo() {
		try {
			String currentDate = DateUtil.getCurrentISTDateOnlyAsString(DateUtil.DATE_ONLY_FORMAT_MSSQL);
			query = em.createNamedQuery("RelocationSo.getCurrentDayMaxCount");
			query.setParameter(1, currentDate);
			query.setParameter(2, currentDate + " 23:59:59.999");
			Long maxNumber = (Long) query.getSingleResult();
			return maxNumber.intValue();
		} finally {
			em.close();
		}
	}

	@Override
	public RelocationSoUserMap saveRelocationSoUserMap(RelocationSoUserMap relocationSoUserMap) {
		String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
		try {
			// TODO Auto-generated method stub
			relocationSoUserMap.setCreatedDate(currTime);
			return em.merge(relocationSoUserMap);
		} finally {
			// TODO: handle finally clause
			em.close();
			currTime = null;
		}
	}

	@Override
	public boolean checkAlreadyUserEnteredRelocationSoMap(Integer relocationSoId, Integer userMstId) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("RelocationSoUserMap.countUserRelocationSo");
		query.setParameter("relocationSoId", relocationSoId);
		query.setParameter("userMstId", userMstId);
		
		Long maxNumber = (Long) query.getSingleResult();
		return maxNumber.intValue()>0?true:false;
	}

	@Override
	public RelocationTypeMst getRelocationTypeMstById(Integer relocationTypeMstId) {
		try {
			// TODO Auto-generated method stub
			return em.find(RelocationTypeMst.class, relocationTypeMstId);
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SiteTypeMst> getSiteTypeList() {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("SiteTypeMst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			return (List<SiteTypeMst>) query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public SiteTypeMst getSiteTypeMst(Integer siteTypeMstId) {
		try {
			// TODO Auto-generated method stub
			return em.find(SiteTypeMst.class, siteTypeMstId);
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}
}
