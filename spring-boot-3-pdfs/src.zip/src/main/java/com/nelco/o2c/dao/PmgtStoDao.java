/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.AllDeliveryListDTO;
import com.nelco.o2c.dto.PmgtStoDTO;
import com.nelco.o2c.dto.SparesSoDTO;
import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.PmgtStoPodUploadDetail;
import com.nelco.o2c.model.StoPmgt;
import com.nelco.o2c.model.StoPmgtDelivery;
import com.nelco.o2c.model.StoPmgtDeliveryTracker;
import com.nelco.o2c.model.StoPmgtPodTracker;
import com.nelco.o2c.model.StorageSapmst;
import com.nelco.o2c.model.UserMst;

/**
 * @author Jayashankar.r
 *
 */
public interface PmgtStoDao {

	List<StoPmgt> getStoPmgtList(PmgtStoDTO ipPmgtStoDTO);

	StoPmgt getStoPmgtById(PmgtStoDTO ipPmgtStoDTO);

	StoPmgt saveSto(StoPmgt stoPmgt, Integer userMstId, String roleCode);

	void saveStoMaterials(StoPmgt stoPmgt, String roleCode);

	void submitByPm(PmgtStoDTO ipPmgtStoDTO);

	void submitByStores(PmgtStoDTO ipPmgtStoDTO);

	List<UserMst> getUserByRoleCodeList(PmgtStoDTO ipPmgtStoDTO, List<String> roleCodes);

	Integer getCurrentDayCountStoPmgt();

	List<StoPmgtDelivery> getDeliveryTrackPmgtSto(PmgtStoDTO ipPmgtStoDTO);

	StoPmgtDelivery saveDeliveryPmgtSto(StoPmgtDelivery delivery);

	StoPmgtDeliveryTracker saveDeliveryStatusTrackerPmgtSto(StoPmgtDeliveryTracker deliveryStatusTracker);

	StoPmgtPodTracker savePodStatusTrackerPmgtSto(StoPmgtPodTracker podStatusTracker);

	PmgtStoPodUploadDetail savePmgtStoUpPodFile(PmgtStoPodUploadDetail podUploadDetails);

	void updatePmgtStoPodStatusByDelId(Integer stoPmgtDeliveryId);

	PmgtStoPodUploadDetail getUpPodFileDetPmgtSto(Integer stoPmgtDeliveryId);

	void updateSparesSO(SparesSoDTO ipsparesSoDTO);
	
	public StoPmgt getStoPmgtByStoPmgtId(Integer stoPmgtId);

	public List<PlantSapmst> getReceivingPlantListByCompanyCode(PmgtStoDTO ipPmgtStoDTO);

	public List<StorageSapmst> getStorageListByReceivingPlant(PmgtStoDTO ipPmgtStoDTO);

	public List<StoPmgtDelivery> getStoDelListByDateAndDelStatusCode(AllDeliveryListDTO allDeliveryListDTO);

	StoPmgt getPmgtStoByReqId(PmgtStoDTO ipPmgtStoDTO);

	List<StoPmgtDelivery> stoPmgtDelBydeliveryNum(PmgtStoDTO ipPmgtStoDTO);

}
