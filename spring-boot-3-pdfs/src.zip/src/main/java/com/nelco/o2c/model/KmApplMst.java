package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the km_appl_mst database table.
 * 
 */
@Entity
@Table(name="km_appl_mst")
@NamedQuery(name="KmApplMst.findAll", query="SELECT k FROM KmApplMst k")
public class KmApplMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="km_appl_mst_id")
	private Integer kmApplMstId;

	@Column(name="is_active")
	private String isActive;

	@Column(name="km_appl_value")
	private String kmApplValue;

	public KmApplMst() {
	}

	public Integer getKmApplMstId() {
		return this.kmApplMstId;
	}

	public void setKmApplMstId(Integer kmApplMstId) {
		this.kmApplMstId = kmApplMstId;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getKmApplValue() {
		return this.kmApplValue;
	}

	public void setKmApplValue(String kmApplValue) {
		this.kmApplValue = kmApplValue;
	}

}