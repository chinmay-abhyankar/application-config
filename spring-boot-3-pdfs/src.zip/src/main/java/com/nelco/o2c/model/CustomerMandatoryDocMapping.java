package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the customer_mandatory_doc_mapping database table.
 * 
 */
@Entity
@Table(name="customer_mandatory_doc_mapping")
@NamedQueries({
	@NamedQuery(name="CustomerMandatoryDocMapping.findAll", query="SELECT c FROM CustomerMandatoryDocMapping c"),
	@NamedQuery(name="CustomerMandatoryDocMapping.deleteDocument", query="DELETE FROM CustomerMandatoryDocMapping c WHERE customer=:customer AND documentCode=:documentCode")
})

public class CustomerMandatoryDocMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(insertable=false, updatable=false, unique=true, nullable=false)
	private int typeid;

	@Column(insertable=false, updatable=false, length=2)
	private String actflag;

	@Column(name="change_date", insertable=false, updatable=false)
	private Timestamp changeDate;

	@Column(length=50)
	private String customer;

	@Column(name="document_code", length=50)
	private String documentCode;

	@Column(length=50)
	private String updatedby;

	public CustomerMandatoryDocMapping() {
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public Timestamp getChangeDate() {
		return this.changeDate;
	}

	public void setChangeDate(Timestamp changeDate) {
		this.changeDate = changeDate;
	}

	public String getCustomer() {
		return this.customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getDocumentCode() {
		return this.documentCode;
	}

	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}

	public String getUpdatedby() {
		return this.updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

}