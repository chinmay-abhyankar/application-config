package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the delivery_det_sapmst database table.
 * 
 */
@Entity
@Table(name="delivery_det_sapmst")
@NamedQuery(name="DeliveryDetSapmst.findAll", query="SELECT d FROM DeliveryDetSapmst d")
public class DeliveryDetSapmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="delivery_det_sapmst_id")
	private int deliveryDetSapmstId;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="delivery_num")
	private String deliveryNum;

	@Column(name="sales_doc")
	private String salesDoc;

	@Column(name="wbs_element")
	private String wbsElement;

	public DeliveryDetSapmst() {
	}

	public int getDeliveryDetSapmstId() {
		return this.deliveryDetSapmstId;
	}

	public void setDeliveryDetSapmstId(int deliveryDetSapmstId) {
		this.deliveryDetSapmstId = deliveryDetSapmstId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDeliveryNum() {
		return this.deliveryNum;
	}

	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}

	public String getSalesDoc() {
		return this.salesDoc;
	}

	public void setSalesDoc(String salesDoc) {
		this.salesDoc = salesDoc;
	}

	public String getWbsElement() {
		return this.wbsElement;
	}

	public void setWbsElement(String wbsElement) {
		this.wbsElement = wbsElement;
	}

}