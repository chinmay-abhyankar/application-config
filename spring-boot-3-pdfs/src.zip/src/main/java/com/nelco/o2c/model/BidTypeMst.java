package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


@Entity
@Table(name = "bid_type_mst")
@NamedQuery(name="BidTypeMst.findAll",query="select b from BidTypeMst b")
public class BidTypeMst implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bid_type_mst_id")
	private Integer bidTypeMstId;
	
	@Column(name = "bid_type_code", length = 10)
	private String bidTypeCode;
	
	@Column(name = "bid_type_val", length = 200)
	private String bidTypeVal;

	public Integer getBidTypeMstId() {
		return bidTypeMstId;
	}

	public void setBidTypeMstId(Integer bidTypeMstId) {
		this.bidTypeMstId = bidTypeMstId;
	}

	public String getBidTypeCode() {
		return bidTypeCode;
	}

	public void setBidTypeCode(String bidTypeCode) {
		this.bidTypeCode = bidTypeCode;
	}

	public String getBidTypeVal() {
		return bidTypeVal;
	}

	public void setBidTypeVal(String bidTypeVal) {
		this.bidTypeVal = bidTypeVal;
	}
		
}
