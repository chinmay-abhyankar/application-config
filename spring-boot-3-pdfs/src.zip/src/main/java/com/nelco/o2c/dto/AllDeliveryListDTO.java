/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.Delivery;
import com.nelco.o2c.model.StoCsDelivery;
import com.nelco.o2c.model.StoPmgtDelivery;

/**
 * @author Amol.l
 *
 */
public class AllDeliveryListDTO implements Serializable {

	private static final long serialVersionUID = 80L;

	private String fromDate;
	private String toDate;
	private Integer userMstId;
	private String roleCode;
	private String delStatusCode;
	private String deliverytype;
	private List<Delivery> deliveryList = new ArrayList<Delivery>();
	private List<StoPmgtDelivery> stoPmgtDeliveryList = new ArrayList<StoPmgtDelivery>();
	private List<StoCsDelivery> stoCsDeliveryList = new ArrayList<StoCsDelivery>();
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getDelStatusCode() {
		return delStatusCode;
	}
	public void setDelStatusCode(String delStatusCode) {
		this.delStatusCode = delStatusCode;
	}
	public String getDeliverytype() {
		return deliverytype;
	}
	public void setDeliverytype(String deliverytype) {
		this.deliverytype = deliverytype;
	}
	public List<Delivery> getDeliveryList() {
		return deliveryList;
	}
	public void setDeliveryList(List<Delivery> deliveryList) {
		this.deliveryList = deliveryList;
	}
	public List<StoPmgtDelivery> getStoPmgtDeliveryList() {
		return stoPmgtDeliveryList;
	}
	public void setStoPmgtDeliveryList(List<StoPmgtDelivery> stoPmgtDeliveryList) {
		this.stoPmgtDeliveryList = stoPmgtDeliveryList;
	}
	public List<StoCsDelivery> getStoCsDeliveryList() {
		return stoCsDeliveryList;
	}
	public void setStoCsDeliveryList(List<StoCsDelivery> stoCsDeliveryList) {
		this.stoCsDeliveryList = stoCsDeliveryList;
	}
	
}
