package com.nelco.o2c.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.nelco.o2c.dto.ChildContractDTO;
import com.nelco.o2c.dto.ChildContractListDTO;
import com.nelco.o2c.dto.CommonMailDTO;
import com.nelco.o2c.dto.MaterialDTO;
import com.nelco.o2c.model.ChildContract;
import com.nelco.o2c.model.ContRelStatusSapmst;
import com.nelco.o2c.model.Contract;
import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.model.MaterialChildContract;
import com.nelco.o2c.model.MaterialContract;
import com.nelco.o2c.model.MaterialSapmst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Amol.l
 *
 */

@Repository
public class ChildContractDaoImpl implements ChildContractDao {

	@PersistenceContext
	private EntityManager em;

	Query query;

	@Autowired
	AutoPopulateDao autoPopulateDao;

	@Autowired
	ContractDao contractDao;

	@Autowired
	CommonPotentialsDao commonPotentialsDao;

	@SuppressWarnings("unchecked")
	@Override
	public ChildContract getChildConBychildConId(ChildContractDTO childContractDTO) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("ChildContract.getChildConBychildConId");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			query.setParameter(1, childContractDTO.getChildContractId());
			List<ChildContract> childContracts = (List<ChildContract>) query.getResultList();
			ChildContract childContract;
			if (childContracts != null && childContracts.size() > 0) {
				childContract = childContracts.get(0);
			} else {
				childContract = new ChildContract();
				List<MaterialChildContract> materialChildContractList = new ArrayList<MaterialChildContract>();
				List<MaterialContract> materialContractList = autoPopulateDao.searchMaterialMasterContract(null,
						childContractDTO.getContractId());
				for (MaterialContract materialContract : materialContractList) {
					if (materialContract.getOrderQty() != null && materialContract.getOrderQty() > 0) {
						MaterialChildContract materialChildContract = new MaterialChildContract();
						materialChildContract.setMaterialDesc(materialContract.getMaterialSapmst().getMaterialDesc());
						materialChildContract.setMaterialNo(materialContract.getMaterialSapmst().getMaterialNo());
						materialChildContract.setOrderQty(materialContract.getOrderQty());
						materialChildContract.setPlant(materialContract.getMaterialSapmst().getPlant());
						materialChildContract.setSalesUnit(materialContract.getMaterialSapmst().getSalesUnit());
						materialChildContract.setDisableMatNum(true);
						materialChildContract.setRate(materialContract.getRate());
						materialChildContract.setValue(materialContract.getValue());
						materialChildContract.setItemNum(materialContract.getItemNum());
						materialChildContract.setConditionTypeCode(materialContract.getConditionTypeCode());
						materialChildContract.setPricingGroupCode(materialContract.getPricingGroupCode());
						materialChildContractList.add(materialChildContract);
					}
				}

				childContract.setMaterialChildContractList(materialChildContractList);
			}
			return childContract;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ChildContract();
		} finally {
			em.close();
		}
	}

	@Override
	public ChildContract saveChildContract(ChildContract childContract) {
		// TODO Auto-generated method stub
		Contract contract = childContract.getContract();
		if (childContract.getChildContractId() == null && contract != null) {
			childContract.setDivision(contract.getDivision());
			childContract.setSalesOrg(contract.getSalesOrg());
			childContract.setDistChannel(contract.getDistChannel());
		}
		String conStartDate = DateUtil.convertDateToSqlDate(childContract.getConStartDate());
		String conEndDate = DateUtil.convertDateToSqlDate(childContract.getConEndDate());
		String poDate = DateUtil.convertDateToSqlDate(childContract.getPoDate());
		childContract.setConStartDate(conStartDate);
		childContract.setConEndDate(conEndDate);
		childContract.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		childContract.setPoDate(poDate);
		ChildContract childContractNew = em.merge(childContract);

		if (childContract.getChildContractId() == null) {
			em.refresh(childContractNew);
		}

		return childContractNew;
	}

	@Override
	public MaterialChildContract saveMatChildContract(MaterialChildContract matChildContract) {
		// TODO Auto-generated method stub
		matChildContract.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		MaterialChildContract matChildContractNew = em.merge(matChildContract);

		if (matChildContract.getMaterialChildContractId() == null) {
			em.refresh(matChildContractNew);
		}

		return matChildContractNew;
	}

	@Override
	public List<ChildContract> getChildConByConIdAndDate(ChildContractListDTO childContractListDTO) {
		// TODO Auto-generated method stub

		try {
			String fromDate = DateUtil.convertDateToSqlDate(childContractListDTO.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(childContractListDTO.getToDate());
			List<ChildContract> childContractList = new ArrayList<ChildContract>();

			if (childContractListDTO.getRoleCode().equals(Constants.FINANCEROLECODE)) {
				if (childContractListDTO.getContractId() != null) {
					query = em.createNamedQuery("ChildContract.getChildConByConIdAndDateFinance");
					query.setParameter(1, fromDate + Constants.MINDAYTIME);
					query.setParameter(2, toDate + Constants.MAXDAYTIME);
					query.setParameter(3, childContractListDTO.getContractId());
				} else {
					if (childContractListDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)) {
						query = em.createNamedQuery("ChildContract.getChildConByDatePM");
						query.setParameter(1, fromDate + Constants.MINDAYTIME);
						query.setParameter(2, toDate + Constants.MAXDAYTIME);
						query.setParameter(3, childContractListDTO.getUserMstId());
					} else {
						query = em.createNamedQuery("ChildContract.getChildConByDate");
						query.setParameter(1, fromDate + Constants.MINDAYTIME);
						query.setParameter(2, toDate + Constants.MAXDAYTIME);
					}

				}
			} else {
				if (childContractListDTO.getContractId() != null) {
					query = em.createNamedQuery("ChildContract.getChildConByConIdAndDate");
					query.setParameter(1, fromDate + Constants.MINDAYTIME);
					query.setParameter(2, toDate +  Constants.MAXDAYTIME);
					query.setParameter(3, childContractListDTO.getContractId());
				} else {
					if (childContractListDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)) {
						query = em.createNamedQuery("ChildContract.getChildConByDatePM");
						query.setParameter(1, fromDate + Constants.MINDAYTIME);
						query.setParameter(2, toDate +  Constants.MAXDAYTIME);
						query.setParameter(3, childContractListDTO.getUserMstId());
					} else {
						query = em.createNamedQuery("ChildContract.getChildConByDate");
						query.setParameter(1, fromDate+ Constants.MINDAYTIME);
						query.setParameter(2, toDate + Constants.MAXDAYTIME);
					}
				}

			}

			// childContractList = (List<ChildContract>) query.getResultList();
			@SuppressWarnings("unchecked")
			List<Object[]> result = (List<Object[]>) query.getResultList();
			for (Object[] objects : result) {
				ChildContract childContract = new ChildContract();
				childContract.setChildContractId((Integer) objects[0]);
				childContract.setSapContractNum(objects[1] != null ? (String) objects[1] : "");
				childContract.setPoNumber(objects[2] != null ? (String) objects[2] : "");
				if (objects[3] != null) {
					String startDate = (String) objects[3];
					childContract.setConStartDate(DateUtil.convertDateTimeToString(startDate));
				}

				if (objects[4] != null) {
					String endDate = (String) objects[4];
					childContract.setConEndDate(DateUtil.convertDateTimeToString(endDate));
				}

				childContract.setMarketSegment(objects[5] != null ? (String) objects[5] : "");

				childContract.setQuarter(objects[6] != null ? (String) objects[6] : "");
				ContRelStatusSapmst contRelStatusSapmst = new ContRelStatusSapmst();
				if (objects[7] != null) {
					contRelStatusSapmst.setContStatus((String) objects[7]);
				}
				childContract.setContRelStatusSapmst(contRelStatusSapmst);

				if (objects[8] != null) {
					String createdDate = (String) objects[8];
					childContract.setCreatedDate(DateUtil.convertDateWithTimeToString(createdDate));
				}
				CustomerSapmst custMst = new CustomerSapmst();
				Contract contract = new Contract();
				if (objects[9] != null) {
					custMst.setCustomerName((String) objects[9]);
					custMst.setCustomerSapmstId(((Integer) objects[12]));
					custMst.setSoldToParty((String) objects[13]);
				} else if (objects[10] != null) {
					custMst.setCustomerName((String) objects[10]);
					custMst.setCustomerSapmstId(((Integer) objects[14]));
					custMst.setSoldToParty((String) objects[15]);
				}
				contract.setContractId((Integer) objects[11]);
				contract.setCustomerSapmst(custMst);
				childContract.setCustomerSapmst(custMst);
				childContract.setContract(contract);
				childContract.setContractId((Integer) objects[11]);
				childContract.setIsSubmit(objects[16] != null ? (String) objects[16] : "");
				
				if(objects[17]!= null) {
				childContract.setSoldToParty((String)objects[17]);
				}
				List<OppUploadDetail> oppUploadDetails = this.getUploadListByChildContractId(childContract);
				if (oppUploadDetails != null && oppUploadDetails.size() > 0) {
					childContract.setIsDocUp("Yes");
				} else {
					childContract.setIsDocUp("No");
				}
				childContractList.add(childContract);
			}
			/*
			 * String createdDate = ""; for (ChildContract childContract :
			 * childContractList) { createdDate =
			 * DateUtil.getSimpleUIDateFromSqlDate(childContract.getCreatedDate());
			 * childContract.setCreatedDate(createdDate); }
			 */

			return childContractList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<ChildContract>();
		} finally {
			em.close();
		}

	}

	@Override
	public ChildContractListDTO updateContractRemarkFinance(ChildContractListDTO childContractListDTO) {
		// TODO Auto-generated method stub
		try {

			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);

			query = em.createNamedQuery("ChildContract.updateRemarksFinance");
			query.setParameter(1, childContractListDTO.getFinRemarks());
			query.setParameter(2, childContractListDTO.getUserMstId());
			query.setParameter(3, currTime);
			query.setParameter(4, childContractListDTO.getChildContractId());
			query.executeUpdate();
			childContractListDTO.setIsSaved(true);
			return childContractListDTO;
		} finally {
			em.close();
		}

	}

	@Override
	public CommonMailDTO getSentMailDet(Integer childContractId) {
		// TODO Auto-generated method stub
		try {

			query = em.createQuery(
					"Select c.pmId,c.financeId,p.salesCoordId,um.userMstId as amId,c.childContractId,c.contractId,c.conStartDate,c.conEndDate,p.proposalId,p.proposalGenId,c.sapContractNum,c.finRemarks from ChildContract c inner join Contract con on c.contractId = con.contractId inner join Proposal p on con.proposalId = p.proposalId inner join UserMst um on p.smownerId = um.smOwnerId where c.childContractId =?1 ");
			query.setParameter(1, childContractId);
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			CommonMailDTO commonMailDTO = null;
			for (Object[] objects : resultList) {
				commonMailDTO = new CommonMailDTO();
				commonMailDTO.setProgramMgrId(Integer.parseInt((String) objects[0]));
				commonMailDTO.setFinanceId(Integer.parseInt((String) objects[1]));
				commonMailDTO.setSalesCoordId((Integer) objects[2]);
				commonMailDTO.setAccountMgrId((Integer) objects[3]);
				commonMailDTO.setChildContractId((Integer) objects[4]);
				commonMailDTO.setContractId((Integer) objects[5]);
				commonMailDTO.setConStartDate((String) objects[6]);
				commonMailDTO.setConEndDate((String) objects[7]);
				commonMailDTO.setProposalId((Integer) objects[8]);
				commonMailDTO.setProposalGenId((String) objects[9]);
				commonMailDTO.setSapContractNum((String) objects[10]);
				commonMailDTO.setFinRemarks((String) objects[11]);
			}
			if (commonMailDTO != null) {
				return commonMailDTO;
			} else {
				return commonMailDTO = new CommonMailDTO();
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new CommonMailDTO();
		} finally {
			em.close();
		}
	}

	@Override
	public ChildContract getChildConBySapContNum(ChildContractDTO childContractDTO) {

		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("ChildContract.getChildConBySapContNum");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			query.setParameter(1, childContractDTO.getSapContractNum());
			List<ChildContract> childContracts = (List<ChildContract>) query.getResultList();
			ChildContract childContract = new ChildContract();
			if (childContracts != null && childContracts.size() > 0) {
				childContract = childContracts.get(0);
			}
			/*
			  else { childContract = new ChildContract(); List<MaterialChildContract>
			  materialChildContractList = new ArrayList<MaterialChildContract>();
			  List<MaterialContract> materialContractList =
			  autoPopulateDao.searchMaterialMasterContract(null,
			  childContractDTO.getContractId()); for (MaterialContract materialContract :
			  materialContractList) { if(materialContract.getOrderQty()!=null &&
			  materialContract.getOrderQty()>0) { MaterialChildContract
			  materialChildContract = new MaterialChildContract();
			  materialChildContract.setMaterialDesc(materialContract.getMaterialSapmst().
			  getMaterialDesc());
			  materialChildContract.setMaterialNo(materialContract.getMaterialSapmst().
			  getMaterialNo());
			  materialChildContract.setOrderQty(materialContract.getOrderQty());
			  materialChildContract.setPlant(materialContract.getMaterialSapmst().getPlant(
			  )); materialChildContract.setSalesUnit(materialContract.getMaterialSapmst().
			  getSalesUnit()); materialChildContract.setDisableMatNum(true);
			  materialChildContract.setRate(materialContract.getRate());
			  materialChildContract.setValue(materialContract.getValue());
			  materialChildContract.setItemNum(materialContract.getItemNum());
			  materialChildContract.setConditionTypeCode(materialContract.
			  getConditionTypeCode());
			  materialChildContract.setPricingGroupCode(materialContract.
			  getPricingGroupCode()); materialChildContractList.add(materialChildContract);
			  } }
			  
			  childContract.setMaterialChildContractList(materialChildContractList); }
			 */
			return childContract;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ChildContract();
		} finally {
			em.close();
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppUploadDetail> getUploadListByChildContractId(ChildContract childContract) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("OppUploadDetail.getUploadListByChildContractId");
			query.setParameter(1, childContract.getChildContractId());
			return (List<OppUploadDetail>) query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Transactional(rollbackFor = Exception.class)
	@Override
	public List<ChildContract> uploadFile(MultipartFile file, String userMstId, String contractId) throws Exception {
		HSSFWorkbook workbook = new HSSFWorkbook(file.getInputStream());
		HSSFRow row = null;
		int i = 1;
		Integer j = null;
		BigDecimal materialNo = null;
		Contract contract = new Contract();
		contract = contractDao.getContractByContractId(Integer.parseInt(contractId));
		List<ChildContract> childContList = new ArrayList<ChildContract>();
		ChildContract childContract = null;
		ChildContract childContractNew = null;
		MaterialDTO materialDTO = null;
		MaterialChildContract matChildContract = null;
		HSSFSheet worksheet = workbook.getSheetAt(0);
		while (i <= worksheet.getLastRowNum()) {
			row = worksheet.getRow(i++);
			if (!(String.valueOf(row.getCell(0)).equals("") || String.valueOf(row.getCell(0)).equals("null"))) {

				if (j == null || j != (int) Math.round(Double.parseDouble(String.valueOf(row.getCell(0))))) {
					childContract = new ChildContract();
					childContractNew = new ChildContract();
					childContract.setSalesOrg(contract.getSalesOrg());
					childContract.setDistChannel(contract.getDistChannel());
					childContract.setDivision(contract.getDivision());
					childContract.setContractId(contract.getContractId());
					childContract.setCreatedbyId(Integer.parseInt(userMstId));
					
					try {
						Double poNumber = Double.parseDouble(String.valueOf(row.getCell(1)));
						childContract.setPoNumber((String.valueOf((long) Math.round(poNumber))));
			        } catch (NumberFormatException e) {
			        	childContract.setPoNumber(String.valueOf(String.valueOf(row.getCell(1))));     
			        }
								
					String poDate = DateUtil.convertDateToSqlDate(String.valueOf(row.getCell(2)));
					childContract.setPoDate(poDate);
					Double soldToParty = Double.parseDouble(String.valueOf(row.getCell(3)));
					childContract.setSoldToParty((String.valueOf((long) Math.round(soldToParty))));
					if (!(String.valueOf(row.getCell(4)).trim().equals("")
							|| String.valueOf(row.getCell(4)).equals("null"))) {
						Double accMgrCode = Double.parseDouble(String.valueOf(row.getCell(4)));
						childContract.setAccMgrCode((String.valueOf((long) Math.round(accMgrCode))));
					} else {
						childContract.setAccMgrCode(null);
					}
					String conStartDate = DateUtil.convertDateToSqlDate(String.valueOf(row.getCell(5)));
					childContract.setConStartDate(conStartDate);
					String conEndDate = DateUtil.convertDateToSqlDate(String.valueOf(row.getCell(6)));
					childContract.setConEndDate(conEndDate);
					if (!(String.valueOf(row.getCell(13)).trim().equals("")
							|| String.valueOf(row.getCell(13)).equals("null"))) {
						Double warrentyPeriod = Double.parseDouble(String.valueOf(row.getCell(13)));
						childContract.setWarrentyPeriod(String.valueOf((long) Math.round(warrentyPeriod)));
					} else {
						childContract.setWarrentyPeriod(null);
					}
					childContract.setMarketSegment(String.valueOf(row.getCell(15)));
					childContract.setQuarter(String.valueOf(row.getCell(16)));
					childContract.setPayTermsCode(String.valueOf(row.getCell(17)));
					if (!(String.valueOf(row.getCell(19)).trim().equals("")
							|| String.valueOf(row.getCell(19)).equals("null"))) {
						childContract.setDescription(String.valueOf(row.getCell(19)));
					} else {
						childContract.setDescription(null);
					}
					if (!(String.valueOf(row.getCell(20)).trim().equals("")
							|| String.valueOf(row.getCell(20)).equals("null"))) {
						childContract.setSubsegment(String.valueOf(row.getCell(20)));
					} else {
						childContract.setSubsegment(null);
					}
					Double pmLoginId = Double.parseDouble(String.valueOf(row.getCell(21)));
//				pmLoginId = new BigDecimal(String.valueOf(row.getCell(21)));
					UserMst programMgr = commonPotentialsDao
							.getUserDetByLoginId(String.valueOf((int) Math.round(pmLoginId)));
					childContract.setPmId(programMgr.getUserMstId());
					Double financeLoginId = Double.parseDouble(String.valueOf(row.getCell(22)));
					UserMst finance = commonPotentialsDao
							.getUserDetByLoginId(String.valueOf((int) Math.round(financeLoginId)));
					childContract.setFinanceId(finance.getUserMstId().toString());
					Double noticePeriod = Double.parseDouble(String.valueOf(row.getCell(23)));
					childContract.setNoticePeriod(Integer.parseInt(String.valueOf((int) Math.round(noticePeriod))));
					childContract.setIsSubmit("Y");
					childContract.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
					childContractNew = em.merge(childContract);
					if (childContract.getChildContractId() == null) {
						em.refresh(childContractNew);
					}
					childContList.add(childContractNew);
					j = (int) Math.round(Double.parseDouble(String.valueOf(row.getCell(0))));
				}

				matChildContract = new MaterialChildContract();
				matChildContract.setChildContractId(childContractNew.getChildContractId());
				matChildContract.setSalesOrg(childContractNew.getSalesOrg());
				matChildContract.setDistChannel(childContractNew.getDistChannel());
				Double itemNum = Double.parseDouble(String.valueOf(row.getCell(7)));
				matChildContract.setItemNum(String.valueOf((int) Math.round(itemNum)));
				materialNo = new BigDecimal(String.valueOf(row.getCell(8)));
				matChildContract.setMaterialNo(materialNo.toPlainString());
				Double orderQty = Double.parseDouble(String.valueOf(row.getCell(9)));
				matChildContract.setOrderQty(new Integer((int) orderQty.intValue()));
				matChildContract.setPlant(String.valueOf(row.getCell(10)));
				matChildContract.setConditionTypeCode(String.valueOf(row.getCell(11)));
				if (matChildContract.getConditionTypeCode().equals(Constants.CONDITYPEPPSV)) {
					Double pricingGroupCode = Double.parseDouble(String.valueOf(row.getCell(18))); 
					matChildContract.setPricingGroupCode(String.valueOf((int) Math.round(pricingGroupCode)));
				}
				materialDTO = new MaterialDTO();
				materialDTO.setMaterialNo(matChildContract.getMaterialNo());
				materialDTO.setPlant(matChildContract.getPlant());
				materialDTO.setSalesOrg(matChildContract.getSalesOrg());
				materialDTO.setDistChannel(matChildContract.getDistChannel());
				MaterialSapmst materialSapmst = commonPotentialsDao.uniqueMaterial(materialDTO);
				matChildContract.setMaterialDesc(materialSapmst.getMaterialDesc());
				List<MaterialContract> materialContractList = autoPopulateDao
						.searchMaterialMasterContract(matChildContract.getMaterialNo(), contract.getContractId());
				for (MaterialContract materialContract : materialContractList) {
					if (materialContract.getOrderQty() != null && materialContract.getOrderQty() > 0) {
						if (materialContract.getOrderQty() >= matChildContract.getOrderQty()) {
							if (!(String.valueOf(row.getCell(12)).trim().equals("")
									|| String.valueOf(row.getCell(12)).equals("null"))) {
								Double rate = Double.parseDouble(String.valueOf(row.getCell(12)));
								matChildContract.setRate(String.valueOf(rate));
								matChildContract.setValue(Double.toString(matChildContract.getOrderQty()
										* Double.parseDouble(matChildContract.getRate())));
							} else {
								matChildContract.setRate("0");
								matChildContract.setValue("0");
							}

							matChildContract
									.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
							MaterialChildContract matChildContractNew = em.merge(matChildContract);
						} else {
							throw new Exception(
									"Error of Line No : " + i + " Invalid Order Quantity for Material Number : "
											+ matChildContract.getMaterialNo() + " Remaining Order quantity : "
											+ materialContract.getOrderQty());
						}
					}
				}

				if (childContract.getChildContractId() == null) {
					em.refresh(childContractNew);
				}

			}
		}
		return childContList;

	}

	@Override
	public String getAccountManger(String childContractId) {
		try {
			query = em.createNativeQuery("select distinct u.user_name from child_contract cc" + 
					"  left join [dbo].[contract] c on cc.contract_id = c.contract_id" + 
					"  left join [dbo].[proposal] p on c.proposal_id = p.proposal_id" + 
					"  left join [dbo].[user_mst] u on u.sm_owner_id = p.smowner_id" + 
					" where cc.contract_id=?1");
			
			query.setParameter(1, childContractId);
			
			String result = (String) query.getSingleResult();
			return result;
		}
		catch (Exception e) {
			e.printStackTrace();
			return "" ;
		}
	}

}
