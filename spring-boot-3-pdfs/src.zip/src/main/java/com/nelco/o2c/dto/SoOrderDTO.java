package com.nelco.o2c.dto;

import java.io.Serializable;

import com.nelco.o2c.model.SoOrders;

public class SoOrderDTO implements Serializable {
	private static final long serialVersionUID = 36L;
	
	private String soNumber;
	private String contractNum;
	private String materialNum;
	private String salesOrg;
	private SoOrders soorderSapmst = new SoOrders();
	
	public String getContractNum() {
		return contractNum;
	}
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}
	public String getMaterialNum() {
		return materialNum;
	}
	public void setMaterialNum(String materialNum) {
		this.materialNum = materialNum;
	}
	public String getSalesOrg() {
		return salesOrg;
	}
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	public String getSoNumber() {
		return soNumber;
	}
	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}
	public SoOrders getSoorderSapmst() {
		return soorderSapmst;
	}
	public void setSoorderSapmst(SoOrders soorderSapmst) {
		this.soorderSapmst = soorderSapmst;
	}
	
}
