package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.utility.DateUtil;

/**
 * The persistent class for the ss_eng_visit_details database table.
 * 
 */
@Entity
@Table(name = "ss_eng_visit_details")
@NamedQueries({ @NamedQuery(name = "SsEngVisitDetail.findAll", query = "SELECT s FROM SsEngVisitDetail s"),
		@NamedQuery(name = "SsEngVisitDetail.findBySiteSurveyMstId", query = "SELECT s FROM SsEngVisitDetail s where s.siteSurveyMstId = ?1"),
		@NamedQuery(name = "SsEngVisitDetail.updateSubmitFlag", query = "update SsEngVisitDetail s set s.isSubmit = 'Y' where s.ssEngVisitDetailsId=?1")})
public class SsEngVisitDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ss_eng_visit_details_id")
	private Integer ssEngVisitDetailsId;

	@Column(name = "additional_remarks")
	private String additionalRemarks;

	@Column(name = "antenna_size_id")
	private Integer antennaSizeId;

	@Column(name = "building_height")
	private String buildingHeight;

	@Column(name = "cable_len")
	private String cableLen;

	private String contact;

	@Column(name = "cust_address")
	private String custAddress;

	@Column(name = "customer_name")
	private String customerName;

	@Column(name = "hub_details")
	private Integer hubDetails;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "hub_details", referencedColumnName = "hub_mst_id", insertable = false, updatable = false)
	private HubMst hubMst;

	@Column(name = "idu_room_ready")
	private String iduRoomReady;

	@Column(name = "km_appl_mst_id")
	private Integer kmApplMstId;

	@Column(name = "ladder_height")
	private String ladderHeight;

	@Column(name = "ladder_req")
	private String ladderReq;

	@Column(name = "monkey_protection_req")
	private String monkeyProtectionReq;

	@Column(name = "platform_req")
	private String platformReq;

	@Column(name = "site_survey_eng_mst_id")
	private Integer siteSurveyEngMstId;
	
	/*@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "site_survey_eng_mst_id", referencedColumnName = "id", insertable = false, updatable = false)
	private SiteSurveyEngineerMst siteSurveyEngineerMst;*/

	@Column(name = "site_survey_mst_id")
	private Integer siteSurveyMstId;

	private Integer technology;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "technology", referencedColumnName = "id", insertable = false, updatable = false)
	private TechnologyMaster technologyMaster;

	private String ups;

	@Column(name = "ups_avail")
	private String upsAvail;

	@Column(name = "work_completion_status_mst_id")
	private Integer workCompletionStatusId;

	@Column(name = "work_completion_status_update_time")
	private String workCompletionStatusUpdateTime;

	@Column(name = "visit")
	private String visit;

	@Column(name = "created_date",updatable = false)
	private String createdDate;
	
	@Column(name = "is_submit")
	private String isSubmit = "N";
	
	@Column(name = "non_feasible_option_mst_id")
	private Integer nonFeasibleOptionMstId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "non_feasible_option_mst_id", referencedColumnName = "non_feasible_option_mst_id", insertable = false, updatable = false)
	private NonFeasibleOptionMst nonFeasibleOptionMst;
	
	
	
	public NonFeasibleOptionMst getNonFeasibleOptionMst() {
		return nonFeasibleOptionMst;
	}

	public void setNonFeasibleOptionMst(NonFeasibleOptionMst nonFeasibleOptionMst) {
		this.nonFeasibleOptionMst = nonFeasibleOptionMst;
	}

	@Column(name = "remarks")
	private String remarks;
	
	@Column(name = "abort_reason")
	private String abortReason;
	
	@Column(name = "actual_person_name")
	private String actualPersonName;
	
	@Column(name = "actual_person_contact")
	private String actualPersonContact;
	
	@Column(name = "visit_date")
	private String visitDate;
	
	@Column(name = "visit_time")
	private String visitTime;
	
	@Column(name = "antenna_type_mst_id")
	private String antennaTypeMstId;
	
	@Column(name = "site_clear_for_wm_now")
	private String siteClearForWmNow;
	
	@Column(name = "mast_height")
	private String mastHeight;
	
	@Column(name = "antenna_location_mst_id")
	private String antennaLocationMstId;
	
	@Column(name = "earthing")
	private String earthing;
	
	@Column(name = "lan_cable")
	private String lanCable;
	
	@Column(name = "noc_from_building")
	private String nocFromBuilding;
	
	@Column(name = "earthing_wire")
	private String earthingWire;
	
	@Column(name = "power_socket_avail")
	private String powerSocketAvail;
	
	@Column(name = "monkey_menace")
	private String monkeyMenace;
	

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "antenna_type_mst_id", referencedColumnName = "antenna_type_mst_id", insertable = false, updatable = false)
	private AntennaTypeMst antennaTypeMst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "antenna_location_mst_id", referencedColumnName = "antenna_location_mst_id", insertable = false, updatable = false)
	private AntennaLocationMst antennaLocationMst;
	
	
	
	public AntennaTypeMst getAntennaTypeMst() {
		return antennaTypeMst;
	}

	public void setAntennaTypeMst(AntennaTypeMst antennaTypeMst) {
		this.antennaTypeMst = antennaTypeMst;
	}

	public AntennaLocationMst getAntennaLocationMst() {
		return antennaLocationMst;
	}

	public void setAntennaLocationMst(AntennaLocationMst antennaLocationMst) {
		this.antennaLocationMst = antennaLocationMst;
	}

	public String getVisitDate() {
		//return visitDate;
//		return DateUtil.getSimpleUIDateFromSqlDate(this.visitDate);
		return DateUtil.convertDateTimeToString(this.visitDate);
	}

	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}

	public String getVisitTime() {
		return visitTime;
	}

	public void setVisitTime(String visitTime) {
		this.visitTime = visitTime;
	}

	public String getAntennaTypeMstId() {
		return antennaTypeMstId;
	}

	public void setAntennaTypeMstId(String antennaTypeMstId) {
		this.antennaTypeMstId = antennaTypeMstId;
	}

	public String getSiteClearForWmNow() {
		return siteClearForWmNow;
	}

	public void setSiteClearForWmNow(String siteClearForWmNow) {
		this.siteClearForWmNow = siteClearForWmNow;
	}

	public String getMastHeight() {
		return mastHeight;
	}

	public void setMastHeight(String mastHeight) {
		this.mastHeight = mastHeight;
	}

	public String getAntennaLocationMstId() {
		return antennaLocationMstId;
	}

	public void setAntennaLocationMstId(String antennaLocationMstId) {
		this.antennaLocationMstId = antennaLocationMstId;
	}

	public String getEarthing() {
		return earthing;
	}

	public void setEarthing(String earthing) {
		this.earthing = earthing;
	}

	public String getLanCable() {
		return lanCable;
	}

	public void setLanCable(String lanCable) {
		this.lanCable = lanCable;
	}

	public String getNocFromBuilding() {
		return nocFromBuilding;
	}

	public void setNocFromBuilding(String nocFromBuilding) {
		this.nocFromBuilding = nocFromBuilding;
	}

	public String getEarthingWire() {
		return earthingWire;
	}

	public void setEarthingWire(String earthingWire) {
		this.earthingWire = earthingWire;
	}

	public String getPowerSocketAvail() {
		return powerSocketAvail;
	}

	public void setPowerSocketAvail(String powerSocketAvail) {
		this.powerSocketAvail = powerSocketAvail;
	}

	public String getMonkeyMenace() {
		return monkeyMenace;
	}

	public void setMonkeyMenace(String monkeyMenace) {
		this.monkeyMenace = monkeyMenace;
	}

	public String getActualPersonName() {
		return actualPersonName;
	}

	public void setActualPersonName(String actualPersonName) {
		this.actualPersonName = actualPersonName;
	}

	public String getActualPersonContact() {
		return actualPersonContact;
	}

	public void setActualPersonContact(String actualPersonContact) {
		this.actualPersonContact = actualPersonContact;
	}

	public Integer getNonFeasibleOptionMstId() {
		return nonFeasibleOptionMstId;
	}

	public void setNonFeasibleOptionMstId(Integer nonFeasibleOptionMstId) {
		this.nonFeasibleOptionMstId = nonFeasibleOptionMstId;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getAbortReason() {
		return abortReason;
	}

	public void setAbortReason(String abortReason) {
		this.abortReason = abortReason;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "work_completion_status_mst_id", referencedColumnName = "work_completion_status_mst_id", insertable = false, updatable = false)
	private WorkCompletionStatusMst workCompletionStatusMst;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "antenna_size_id", referencedColumnName = "id", insertable = false, updatable = false)
	private AntennaSizeMaster antennaSizeMaster;
	
	@Transient
	private String siteSurveyId;
	
	@Transient
	private String engName;
	
	@Transient
	private String franchiseName;
	
	
	
	
	
	

	/*@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "site_survey_mst_id", referencedColumnName = "id", insertable = false, updatable = false)
	private SiteSurveyMaster siteSurveyMaster;

	public SiteSurveyMaster getSiteSurveyMaster() {
		return siteSurveyMaster;
	}

	public void setSiteSurveyMaster(SiteSurveyMaster siteSurveyMaster) {
		this.siteSurveyMaster = siteSurveyMaster;
	}*/

	

	public String getFranchiseName() {
		return franchiseName;
	}

	public void setFranchiseName(String franchiseName) {
		this.franchiseName = franchiseName;
	}

	public String getEngName() {
		return engName;
	}

	public HubMst getHubMst() {
		return hubMst;
	}

	public void setHubMst(HubMst hubMst) {
		this.hubMst = hubMst;
	}

	public TechnologyMaster getTechnologyMaster() {
		return technologyMaster;
	}

	public void setTechnologyMaster(TechnologyMaster technologyMaster) {
		this.technologyMaster = technologyMaster;
	}

	public void setEngName(String engName) {
		this.engName = engName;
	}

	public String getSiteSurveyId() {
		return siteSurveyId;
	}

	public void setSiteSurveyId(String siteSurveyId) {
		this.siteSurveyId = siteSurveyId;
	}

	public String getIsSubmit() {
		return isSubmit;
	}

	/*public SiteSurveyEngineerMst getSiteSurveyEngineerMst() {
		return siteSurveyEngineerMst;
	}

	public void setSiteSurveyEngineerMst(SiteSurveyEngineerMst siteSurveyEngineerMst) {
		this.siteSurveyEngineerMst = siteSurveyEngineerMst;
	}*/

	public void setIsSubmit(String isSubmit) {
		this.isSubmit = isSubmit;
	}

	public WorkCompletionStatusMst getWorkCompletionStatusMst() {
		return workCompletionStatusMst;
	}

	public void setWorkCompletionStatusMst(WorkCompletionStatusMst workCompletionStatusMst) {
		this.workCompletionStatusMst = workCompletionStatusMst;
	}

	public AntennaSizeMaster getAntennaSizeMaster() {
		return antennaSizeMaster;
	}

	public void setAntennaSizeMaster(AntennaSizeMaster antennaSizeMaster) {
		this.antennaSizeMaster = antennaSizeMaster;
	}

	public String getCreatedDate() {
		// return createdDate;
		return DateUtil.getSimpleUIDateFromSqlDate(this.createdDate);
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public SsEngVisitDetail() {
	}

	public String getVisit() {
		return visit;
	}

	public void setVisit(String visit) {
		this.visit = visit;
	}

	public Integer getSsEngVisitDetailsId() {
		return this.ssEngVisitDetailsId;
	}

	public void setSsEngVisitDetailsId(Integer ssEngVisitDetailsId) {
		this.ssEngVisitDetailsId = ssEngVisitDetailsId;
	}

	public String getAdditionalRemarks() {
		return this.additionalRemarks;
	}

	public void setAdditionalRemarks(String additionalRemarks) {
		this.additionalRemarks = additionalRemarks;
	}

	public Integer getAntennaSizeId() {
		return this.antennaSizeId;
	}

	public void setAntennaSizeId(Integer antennaSizeId) {
		this.antennaSizeId = antennaSizeId;
	}

	public String getBuildingHeight() {
		return this.buildingHeight;
	}

	public void setBuildingHeight(String buildingHeight) {
		this.buildingHeight = buildingHeight;
	}

	

	public String getCableLen() {
		return cableLen;
	}

	public void setCableLen(String cableLen) {
		this.cableLen = cableLen;
	}

	public String getContact() {
		return this.contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getCustAddress() {
		return this.custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	public String getCustomerName() {
		return this.customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	

	public Integer getHubDetails() {
		return hubDetails;
	}

	public void setHubDetails(Integer hubDetails) {
		this.hubDetails = hubDetails;
	}

	public String getIduRoomReady() {
		return this.iduRoomReady;
	}

	public void setIduRoomReady(String iduRoomReady) {
		this.iduRoomReady = iduRoomReady;
	}

	public Integer getKmApplMstId() {
		return this.kmApplMstId;
	}

	public void setKmApplMstId(Integer kmApplMstId) {
		this.kmApplMstId = kmApplMstId;
	}

	public String getLadderHeight() {
		return this.ladderHeight;
	}

	public void setLadderHeight(String ladderHeight) {
		this.ladderHeight = ladderHeight;
	}

	public String getLadderReq() {
		return this.ladderReq;
	}

	public void setLadderReq(String ladderReq) {
		this.ladderReq = ladderReq;
	}

	public String getMonkeyProtectionReq() {
		return this.monkeyProtectionReq;
	}

	public void setMonkeyProtectionReq(String monkeyProtectionReq) {
		this.monkeyProtectionReq = monkeyProtectionReq;
	}

	public String getPlatformReq() {
		return this.platformReq;
	}

	public void setPlatformReq(String platformReq) {
		this.platformReq = platformReq;
	}

	public Integer getSiteSurveyEngMstId() {
		return this.siteSurveyEngMstId;
	}

	public void setSiteSurveyEngMstId(Integer siteSurveyEngMstId) {
		this.siteSurveyEngMstId = siteSurveyEngMstId;
	}

	public Integer getSiteSurveyMstId() {
		return this.siteSurveyMstId;
	}

	public void setSiteSurveyMstId(Integer siteSurveyMstId) {
		this.siteSurveyMstId = siteSurveyMstId;
	}

	
	public Integer getTechnology() {
		return technology;
	}

	public void setTechnology(Integer technology) {
		this.technology = technology;
	}

	public String getUps() {
		return this.ups;
	}

	public void setUps(String ups) {
		this.ups = ups;
	}

	public String getUpsAvail() {
		return this.upsAvail;
	}

	public void setUpsAvail(String upsAvail) {
		this.upsAvail = upsAvail;
	}

	public Integer getWorkCompletionStatusId() {
		return this.workCompletionStatusId;
	}

	public void setWorkCompletionStatusId(Integer workCompletionStatusId) {
		this.workCompletionStatusId = workCompletionStatusId;
	}

	public String getWorkCompletionStatusUpdateTime() {
		// return this.workCompletionStatusUpdateTime;
		return DateUtil.getSimpleUIDateFromSqlDate(this.workCompletionStatusUpdateTime);
	}

	public void setWorkCompletionStatusUpdateTime(String workCompletionStatusUpdateTime) {
		this.workCompletionStatusUpdateTime = workCompletionStatusUpdateTime;
	}

}