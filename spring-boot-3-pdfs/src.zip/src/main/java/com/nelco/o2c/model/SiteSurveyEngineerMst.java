package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;

@Entity
@Table(name="site_survey_eng_mst")
@NamedQueries({@NamedQuery(name="SiteSurveyEngineerMst.findAll", query="SELECT h FROM SiteSurveyEngineerMst h ")
,@NamedQuery(name="SiteSurveyEngineerMst.findById",query="select h from SiteSurveyEngineerMst h where h.id=?1")
,@NamedQuery(name="SiteSurveyEngineerMst.findBySiteSurveyId",query="select h from SiteSurveyEngineerMst h where h.site_survey_id=?1")
})

public class SiteSurveyEngineerMst implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	@Column(name="site_survey_id")
	private Integer site_survey_id;
	
	@Column(name="franchisee_id")
	private Integer franchisee_id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="mobile_no")
	private String mobile_no;
	
	@Column(name="email_id")
	private String email_id;
	
	@Column(name="creation_date")
	private String creation_date;
	
	@Column(name = "eng_visit_date")
	private String engVisitDate;
	
	@Column(name = "eng_visit_timing")
	private String engVisitTiming;
	
	public String getEngVisitDate() {
		//return engVisitDate;
		return DateUtil.getSimpleUIDateFromSqlDate(this.engVisitDate);
	}
	public void setEngVisitDate(String engVisitDate) {
		this.engVisitDate = engVisitDate;
	}
	public String getEngVisitTiming() {
		return engVisitTiming;
	}
	public void setEngVisitTiming(String engVisitTiming) {
		this.engVisitTiming = engVisitTiming;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "franchisee_id", referencedColumnName = "franchise_mst_id", insertable = false, updatable = false)
	private FranchiseeMaster franchiseeMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "site_survey_id", referencedColumnName = "id", insertable = false, updatable = false)
	private SiteSurveyMaster siteSurveyMaster;
	public FranchiseeMaster getFranchiseeMaster() {
		return franchiseeMaster;
	}
	public void setFranchiseeMaster(FranchiseeMaster franchiseeMaster) {
		this.franchiseeMaster = franchiseeMaster;
	}
	public SiteSurveyMaster getSiteSurveyMaster() {
		return siteSurveyMaster;
	}
	public void setSiteSurveyMaster(SiteSurveyMaster siteSurveyMaster) {
		this.siteSurveyMaster = siteSurveyMaster;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getSite_survey_id() {
		return site_survey_id;
	}

	public void setSite_survey_id(Integer site_survey_id) {
		this.site_survey_id = site_survey_id;
	}

	public Integer getFranchisee_id() {
		return franchisee_id;
	}

	public void setFranchisee_id(Integer franchisee_id) {
		this.franchisee_id = franchisee_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(String creation_date) {
		this.creation_date = creation_date;
	}
	
	
}
