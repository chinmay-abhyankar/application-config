/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.AllDeliveryListDTO;
import com.nelco.o2c.dto.CommonMailDTO;
import com.nelco.o2c.dto.DeliveryDTO;
import com.nelco.o2c.dto.DeliveryListDTO;
import com.nelco.o2c.dto.FileUploadDTO;
import com.nelco.o2c.model.AddressTracker;
import com.nelco.o2c.model.Delivery;
import com.nelco.o2c.model.DeliveryStatusTracker;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.PodStatusTracker;
import com.nelco.o2c.model.PodUploadDetails;

/**
 * @author Amol.l
 *
 */
public interface DeliveryDao {

	public Delivery getDelByDelId(Integer deliveryId);

	public List<Delivery> getDelListByDate(DeliveryListDTO deliveryListDTO);

	public Delivery saveDelivery(Delivery delivery);

	public List<FileTypeMst> getPODfileList(FileUploadDTO fileUploadDTO);

	public PodUploadDetails saveUpPodFile(PodUploadDetails podUploadDetails);

	public PodUploadDetails getUpPodFileDet(Integer deliveryId);

	public void updatePodStatusByDelId(Integer deliveryId);

	public PodStatusTracker savePodStatusTracker(PodStatusTracker podStatusTracker);
	
	public DeliveryStatusTracker saveDeliveryStatusTracker(DeliveryStatusTracker deliveryStatusTracker);

	public List<Delivery> getWrongAddressList(DeliveryListDTO deliveryListDTO);

	public AddressTracker saveAddressTracker(AddressTracker addressTracker);

	public CommonMailDTO getDeliveryMail(Integer deliveryId);

	public List<Delivery> getDelListByDateAndDelStatusCode(AllDeliveryListDTO allDeliveryListDTO);

	public Delivery getDelByDelNum(String deliveryNum);
	
	public DeliveryDTO mailForSalesReturn(DeliveryDTO deliveryDTO);
	
	public void updateDelSalesReturn(Integer deliveryId);

}
