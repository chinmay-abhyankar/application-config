package com.nelco.o2c.dto;

public class PaymentCollectionBreakupDTO {
private String paymentNo="";
private String invoiceNo="";
private String collectedAmt="";
private String outstandingAmt="";
private String paymentDate="";
private String userId="";
private String creditNoteNo="";
private String creditAmt="";
private String uniqueId="";
private String tds;

public PaymentCollectionBreakupDTO(String paymentNo,String invoiceNo,String collectedAmt,String outstandingAmt,String paymentDate,String userId,String creditNoteNo,String creditAmt,String uniqueId,String tds){
	this.paymentNo=paymentNo;
	this.invoiceNo=invoiceNo;
	this.collectedAmt=collectedAmt;
	this.outstandingAmt=outstandingAmt;
	this.paymentDate=paymentDate;
	this.userId=userId;
	this.creditNoteNo=creditNoteNo;
	this.creditAmt=creditAmt;
	this.uniqueId=uniqueId;
	this.tds=tds;
}


public String getTds() {
	return tds;
}


public void setTds(String tds) {
	this.tds = tds;
}


public String getUniqueId() {
	return uniqueId;
}


public void setUniqueId(String uniqueId) {
	this.uniqueId = uniqueId;
}


public String getCreditNoteNo() {
	return creditNoteNo;
}


public void setCreditNoteNo(String creditNoteNo) {
	this.creditNoteNo = creditNoteNo;
}


public String getCreditAmt() {
	return creditAmt;
}


public void setCreditAmt(String creditAmt) {
	this.creditAmt = creditAmt;
}


public String getPaymentNo() {
	return paymentNo;
}
public void setPaymentNo(String paymentNo) {
	this.paymentNo = paymentNo;
}
public String getInvoiceNo() {
	return invoiceNo;
}
public void setInvoiceNo(String invoiceNo) {
	this.invoiceNo = invoiceNo;
}
public String getCollectedAmt() {
	return collectedAmt;
}
public void setCollectedAmt(String collectedAmt) {
	this.collectedAmt = collectedAmt;
}

public String getOutstandingAmt() {
	return outstandingAmt;
}
public void setOutstandingAmt(String outstandingAmt) {
	this.outstandingAmt = outstandingAmt;
}
public String getPaymentDate() {
	return paymentDate;
}
public void setPaymentDate(String paymentDate) {
	this.paymentDate = paymentDate;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}

}
