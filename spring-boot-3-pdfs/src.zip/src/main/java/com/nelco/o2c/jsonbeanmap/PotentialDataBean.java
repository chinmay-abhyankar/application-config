/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Amol.l
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PotentialDataBean {

	@JsonProperty("Opportunity_Size_Value_TNSL_Annuity_Rs_in_Lac")
	private String opportunitySizeValueTnslAnnuityRsInLac;
	
	@JsonProperty("Owner")
	private IDName owner = new IDName();
	
	@JsonProperty("$currency_symbol")
	private String currencySymbol;
	
	@JsonProperty("Business_Line")
	private String businessLine;
	
	@JsonProperty("AMC_MS")
	private String amcMS;
	
	@JsonProperty("Pre_Sales_Resource")
	private String preSalesResource;
	
	@JsonProperty("$followers")
	private String followers;
	
	@JsonProperty("Bid_Submission_Date")
	private String bidSubmissionDate;
	
	@JsonProperty("Last_Activity_Time")
	private String lastActivityTime;
	
	@JsonProperty("$state")
	private String state;
	
	@JsonProperty("$process_flow")
	private String processFlow;
	
	@JsonProperty("Deal_Name")
	private String dealName;
	
	@JsonProperty("Solution_Description")
	private String solutionDescription;
	
	@JsonProperty("Stage")
	private String stage;
	
	@JsonProperty("Dropped_Remarks")
	private String droppedRemarks;
	
	@JsonProperty("id")
	private String zohoId;
	
	
	@JsonProperty("BW_MS")
	private String bwMS;
	
	@JsonProperty("$approved")
	private String approved;
	
	@JsonProperty("$approval")
	private Approval approval = new Approval();
	
	@JsonProperty("Probability_of_getting_decided_Cust_End")
	private String probabilityOfGettingDecidedCustEnd;
	
	@JsonProperty("Potential_Ageing")
	private String potentialAgeing;
	
	@JsonProperty("Created_Time")
	private String createdTime;
	
	@JsonProperty("$followed")
	private String followed;
	
	
	@JsonProperty("$editable")
	private String editable;
	
	@JsonProperty("Go_to_Market_Channel")
	private String goToMarketChannel;
	
	@JsonProperty("Bandwidth_Short_Term_Rs_in_Lac")
	private String bandwidthShortTermRsInLac;
	
	@JsonProperty("Number_3")
	private String number3;
	
	@JsonProperty("$Contract_Duration_in_Years")
	private String contractDurationInYears;
	
	@JsonProperty("Region")
	private String region;
	
	@JsonProperty("Created_By")
	private IDName createdBy = new IDName();
	
	@JsonProperty("SAP_Contract_No")
	private String sapContractNo;
	
	@JsonProperty("Short_Term_BW_MS")
	private String shortTermBwMs;
	
	@JsonProperty("Sites_MS1")
	private String sitesMS1;
	
	@JsonProperty("Equip_MS")
	private String equipMs;
	
	@JsonProperty("Market_Share_Expected")
	private String marketShareExpected;
	
	@JsonProperty("Remarks_Comments_Any_other_Details")
	private String remarksCommentsAnyOtherDetails;
	
	@JsonProperty("Opportunity_Size_No_of_Sites")
	private String opportunitySizeNoOfSites;
	
	@JsonProperty("Market_Segment")
	private String marketSegment;
	
	@JsonProperty("Opportunity_Size_Value_One_Time_Rs_in_Lac")
	private String opportunitySizeValueOneTimeRsInLac;
	
	@JsonProperty("$review_process")
	private String reviewProcess;
	
	@JsonProperty("Our_Addressability_with_present_services")
	private String ourAddressabilityWithPresentServices;
	
	@JsonProperty("Funnel_Segment")
	private String funnelSegment;
	
	@JsonProperty("Closing_Date")
	private String closingDate;
	
	@JsonProperty("Modified_By")
	private IDName modifiedBy = new IDName();
	
	@JsonProperty("$review")
	private String review;
	
	@JsonProperty("Lead_Conversion_Time")
	private String leadConversionTime;
	
	@JsonProperty("Current_Status")
	private String currentStatus;
	
	@JsonProperty("Overall_Sales_Duration")
	private String overallSalesDuration;
	
	@JsonProperty("Account_Name")
	private IDName accountName = new IDName();
	
	@JsonProperty("Probability_to_Win")
	private String probabilityToWin;
	
	@JsonProperty("Date_of_Opportunity_Creation")
	private String dateOfOpportunityCreation;
	
	@JsonProperty("Opportunity_Size_Value_Nelco_Annuity_Rs_in_Lac1")
	private String opportunitySizeValueNelcoAnnuityRsInLac1;
	
	@JsonProperty("Funnel_Status")
	private String funnelStatus;
	
	@JsonProperty("Modified_Time")
	private String modifiedTime;
	
	@JsonProperty("Nature_of_opportunity_Opex_Capex")
	private String natureOfOpportunityOpexCapex;
	
	@JsonProperty("Nelco_Rental_Rs_in_Lac")
	private String nelcoRentalRsInLac;
	
	@JsonProperty("Segment_1")
	private String segment1;
	
	@JsonProperty("$orchestration")
	private String orchestration;
	
	@JsonProperty("Contact_Name")
	private IDName contactName = new IDName();
	
	@JsonProperty("Sales_Cycle_Duration")
	private String salesCycleDuration;
	
	@JsonProperty("RENTAL_MS")
	private String rentalMs;

	public String getOpportunitySizeValueTnslAnnuityRsInLac() {
		return opportunitySizeValueTnslAnnuityRsInLac;
	}

	public void setOpportunitySizeValueTnslAnnuityRsInLac(String opportunitySizeValueTnslAnnuityRsInLac) {
		this.opportunitySizeValueTnslAnnuityRsInLac = opportunitySizeValueTnslAnnuityRsInLac;
	}

	public IDName getOwner() {
		return owner;
	}

	public void setOwner(IDName owner) {
		this.owner = owner;
	}

	public String getCurrencySymbol() {
		return currencySymbol;
	}

	public void setCurrencySymbol(String currencySymbol) {
		this.currencySymbol = currencySymbol;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getAmcMS() {
		return amcMS;
	}

	public void setAmcMS(String amcMS) {
		this.amcMS = amcMS;
	}

	public String getPreSalesResource() {
		return preSalesResource;
	}

	public void setPreSalesResource(String preSalesResource) {
		this.preSalesResource = preSalesResource;
	}

	public String getFollowers() {
		return followers;
	}

	public void setFollowers(String followers) {
		this.followers = followers;
	}

	public String getBidSubmissionDate() {
		return bidSubmissionDate;
	}

	public void setBidSubmissionDate(String bidSubmissionDate) {
		this.bidSubmissionDate = bidSubmissionDate;
	}

	public String getLastActivityTime() {
		return lastActivityTime;
	}

	public void setLastActivityTime(String lastActivityTime) {
		this.lastActivityTime = lastActivityTime;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getProcessFlow() {
		return processFlow;
	}

	public void setProcessFlow(String processFlow) {
		this.processFlow = processFlow;
	}

	public String getDealName() {
		return dealName;
	}

	public void setDealName(String dealName) {
		this.dealName = dealName;
	}

	public String getSolutionDescription() {
		return solutionDescription;
	}

	public void setSolutionDescription(String solutionDescription) {
		this.solutionDescription = solutionDescription;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public String getDroppedRemarks() {
		return droppedRemarks;
	}

	public void setDroppedRemarks(String droppedRemarks) {
		this.droppedRemarks = droppedRemarks;
	}

	public String getZohoId() {
		return zohoId;
	}

	public void setZohoId(String zohoId) {
		this.zohoId = zohoId;
	}

	public String getBwMS() {
		return bwMS;
	}

	public void setBwMS(String bwMS) {
		this.bwMS = bwMS;
	}

	public String getApproved() {
		return approved;
	}

	public void setApproved(String approved) {
		this.approved = approved;
	}

	public Approval getApproval() {
		return approval;
	}

	public void setApproval(Approval approval) {
		this.approval = approval;
	}

	public String getProbabilityOfGettingDecidedCustEnd() {
		return probabilityOfGettingDecidedCustEnd;
	}

	public void setProbabilityOfGettingDecidedCustEnd(String probabilityOfGettingDecidedCustEnd) {
		this.probabilityOfGettingDecidedCustEnd = probabilityOfGettingDecidedCustEnd;
	}

	public String getPotentialAgeing() {
		return potentialAgeing;
	}

	public void setPotentialAgeing(String potentialAgeing) {
		this.potentialAgeing = potentialAgeing;
	}

	public String getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}

	public String getFollowed() {
		return followed;
	}

	public void setFollowed(String followed) {
		this.followed = followed;
	}

	public String getEditable() {
		return editable;
	}

	public void setEditable(String editable) {
		this.editable = editable;
	}

	public String getGoToMarketChannel() {
		return goToMarketChannel;
	}

	public void setGoToMarketChannel(String goToMarketChannel) {
		this.goToMarketChannel = goToMarketChannel;
	}

	public String getBandwidthShortTermRsInLac() {
		return bandwidthShortTermRsInLac;
	}

	public void setBandwidthShortTermRsInLac(String bandwidthShortTermRsInLac) {
		this.bandwidthShortTermRsInLac = bandwidthShortTermRsInLac;
	}

	public String getNumber3() {
		return number3;
	}

	public void setNumber3(String number3) {
		this.number3 = number3;
	}

	public String getContractDurationInYears() {
		return contractDurationInYears;
	}

	public void setContractDurationInYears(String contractDurationInYears) {
		this.contractDurationInYears = contractDurationInYears;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public IDName getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(IDName createdBy) {
		this.createdBy = createdBy;
	}

	public String getSapContractNo() {
		return sapContractNo;
	}

	public void setSapContractNo(String sapContractNo) {
		this.sapContractNo = sapContractNo;
	}

	public String getShortTermBwMs() {
		return shortTermBwMs;
	}

	public void setShortTermBwMs(String shortTermBwMs) {
		this.shortTermBwMs = shortTermBwMs;
	}

	public String getSitesMS1() {
		return sitesMS1;
	}

	public void setSitesMS1(String sitesMS1) {
		this.sitesMS1 = sitesMS1;
	}

	public String getEquipMs() {
		return equipMs;
	}

	public void setEquipMs(String equipMs) {
		this.equipMs = equipMs;
	}

	public String getMarketShareExpected() {
		return marketShareExpected;
	}

	public void setMarketShareExpected(String marketShareExpected) {
		this.marketShareExpected = marketShareExpected;
	}

	public String getRemarksCommentsAnyOtherDetails() {
		return remarksCommentsAnyOtherDetails;
	}

	public void setRemarksCommentsAnyOtherDetails(String remarksCommentsAnyOtherDetails) {
		this.remarksCommentsAnyOtherDetails = remarksCommentsAnyOtherDetails;
	}

	public String getOpportunitySizeNoOfSites() {
		return opportunitySizeNoOfSites;
	}

	public void setOpportunitySizeNoOfSites(String opportunitySizeNoOfSites) {
		this.opportunitySizeNoOfSites = opportunitySizeNoOfSites;
	}

	public String getMarketSegment() {
		return marketSegment;
	}

	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}

	public String getOpportunitySizeValueOneTimeRsInLac() {
		return opportunitySizeValueOneTimeRsInLac;
	}

	public void setOpportunitySizeValueOneTimeRsInLac(String opportunitySizeValueOneTimeRsInLac) {
		this.opportunitySizeValueOneTimeRsInLac = opportunitySizeValueOneTimeRsInLac;
	}

	public String getReviewProcess() {
		return reviewProcess;
	}

	public void setReviewProcess(String reviewProcess) {
		this.reviewProcess = reviewProcess;
	}

	public String getOurAddressabilityWithPresentServices() {
		return ourAddressabilityWithPresentServices;
	}

	public void setOurAddressabilityWithPresentServices(String ourAddressabilityWithPresentServices) {
		this.ourAddressabilityWithPresentServices = ourAddressabilityWithPresentServices;
	}

	public String getFunnelSegment() {
		return funnelSegment;
	}

	public void setFunnelSegment(String funnelSegment) {
		this.funnelSegment = funnelSegment;
	}

	public String getClosingDate() {
		return closingDate;
	}

	public void setClosingDate(String closingDate) {
		this.closingDate = closingDate;
	}

	public IDName getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(IDName modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public String getLeadConversionTime() {
		return leadConversionTime;
	}

	public void setLeadConversionTime(String leadConversionTime) {
		this.leadConversionTime = leadConversionTime;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public String getOverallSalesDuration() {
		return overallSalesDuration;
	}

	public void setOverallSalesDuration(String overallSalesDuration) {
		this.overallSalesDuration = overallSalesDuration;
	}

	public IDName getAccountName() {
		return accountName;
	}

	public void setAccountName(IDName accountName) {
		this.accountName = accountName;
	}

	public String getProbabilityToWin() {
		return probabilityToWin;
	}

	public void setProbabilityToWin(String probabilityToWin) {
		this.probabilityToWin = probabilityToWin;
	}

	public String getDateOfOpportunityCreation() {
		return dateOfOpportunityCreation;
	}

	public void setDateOfOpportunityCreation(String dateOfOpportunityCreation) {
		this.dateOfOpportunityCreation = dateOfOpportunityCreation;
	}

	public String getOpportunitySizeValueNelcoAnnuityRsInLac1() {
		return opportunitySizeValueNelcoAnnuityRsInLac1;
	}

	public void setOpportunitySizeValueNelcoAnnuityRsInLac1(String opportunitySizeValueNelcoAnnuityRsInLac1) {
		this.opportunitySizeValueNelcoAnnuityRsInLac1 = opportunitySizeValueNelcoAnnuityRsInLac1;
	}

	public String getFunnelStatus() {
		return funnelStatus;
	}

	public void setFunnelStatus(String funnelStatus) {
		this.funnelStatus = funnelStatus;
	}

	public String getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(String modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	public String getNatureOfOpportunityOpexCapex() {
		return natureOfOpportunityOpexCapex;
	}

	public void setNatureOfOpportunityOpexCapex(String natureOfOpportunityOpexCapex) {
		this.natureOfOpportunityOpexCapex = natureOfOpportunityOpexCapex;
	}

	public String getNelcoRentalRsInLac() {
		return nelcoRentalRsInLac;
	}

	public void setNelcoRentalRsInLac(String nelcoRentalRsInLac) {
		this.nelcoRentalRsInLac = nelcoRentalRsInLac;
	}

	public String getSegment1() {
		return segment1;
	}

	public void setSegment1(String segment1) {
		this.segment1 = segment1;
	}

	public String getOrchestration() {
		return orchestration;
	}

	public void setOrchestration(String orchestration) {
		this.orchestration = orchestration;
	}

	public String getSalesCycleDuration() {
		return salesCycleDuration;
	}

	public void setSalesCycleDuration(String salesCycleDuration) {
		this.salesCycleDuration = salesCycleDuration;
	}

	public String getRentalMs() {
		return rentalMs;
	}

	public void setRentalMs(String rentalMs) {
		this.rentalMs = rentalMs;
	}

	public IDName getContactName() {
		return contactName;
	}

	public void setContactName(IDName contactName) {
		this.contactName = contactName;
	}

	@Override
	public String toString() {
		return "PotentialDataBean [opportunitySizeValueTnslAnnuityRsInLac=" + opportunitySizeValueTnslAnnuityRsInLac
				+ ", owner=" + owner + ", currencySymbol=" + currencySymbol + ", businessLine=" + businessLine
				+ ", amcMS=" + amcMS + ", preSalesResource=" + preSalesResource + ", followers=" + followers
				+ ", bidSubmissionDate=" + bidSubmissionDate + ", lastActivityTime=" + lastActivityTime + ", state="
				+ state + ", processFlow=" + processFlow + ", dealName=" + dealName + ", solutionDescription="
				+ solutionDescription + ", stage=" + stage + ", droppedRemarks=" + droppedRemarks + ", zohoId=" + zohoId
				+ ", bwMS=" + bwMS + ", approved=" + approved + ", approval=" + approval
				+ ", probabilityOfGettingDecidedCustEnd=" + probabilityOfGettingDecidedCustEnd + ", potentialAgeing="
				+ potentialAgeing + ", createdTime=" + createdTime + ", followed=" + followed + ", editable=" + editable
				+ ", goToMarketChannel=" + goToMarketChannel + ", bandwidthShortTermRsInLac="
				+ bandwidthShortTermRsInLac + ", number3=" + number3 + ", contractDurationInYears="
				+ contractDurationInYears + ", region=" + region + ", createdBy=" + createdBy + ", sapContractNo="
				+ sapContractNo + ", shortTermBwMs=" + shortTermBwMs + ", sitesMS1=" + sitesMS1 + ", equipMs=" + equipMs
				+ ", marketShareExpected=" + marketShareExpected + ", remarksCommentsAnyOtherDetails="
				+ remarksCommentsAnyOtherDetails + ", opportunitySizeNoOfSites=" + opportunitySizeNoOfSites
				+ ", marketSegment=" + marketSegment + ", opportunitySizeValueOneTimeRsInLac="
				+ opportunitySizeValueOneTimeRsInLac + ", reviewProcess=" + reviewProcess
				+ ", ourAddressabilityWithPresentServices=" + ourAddressabilityWithPresentServices + ", funnelSegment="
				+ funnelSegment + ", closingDate=" + closingDate + ", modifiedBy=" + modifiedBy + ", review=" + review
				+ ", leadConversionTime=" + leadConversionTime + ", currentStatus=" + currentStatus
				+ ", overallSalesDuration=" + overallSalesDuration + ", accountName=" + accountName
				+ ", probabilityToWin=" + probabilityToWin + ", dateOfOpportunityCreation=" + dateOfOpportunityCreation
				+ ", opportunitySizeValueNelcoAnnuityRsInLac1=" + opportunitySizeValueNelcoAnnuityRsInLac1
				+ ", funnelStatus=" + funnelStatus + ", modifiedTime=" + modifiedTime
				+ ", natureOfOpportunityOpexCapex=" + natureOfOpportunityOpexCapex + ", nelcoRentalRsInLac="
				+ nelcoRentalRsInLac + ", segment1=" + segment1 + ", orchestration=" + orchestration + ", contactName="
				+ contactName + ", salesCycleDuration=" + salesCycleDuration + ", rentalMs=" + rentalMs + "]";
	}

}
