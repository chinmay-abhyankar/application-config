package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the installation_type_mst database table.
 * 
 */
@Entity
@Table(name="installation_type_mst")
@NamedQueries({
@NamedQuery(name="InstallationTypeMst.findAll", query="SELECT i FROM InstallationTypeMst i"),
@NamedQuery(name="InstallationTypeMst.InstallTypeMstByDesc", query="SELECT i FROM InstallationTypeMst i where i.installationTypeVal=?1 ")
})
public class InstallationTypeMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="installation_type_mst_id")
	private Integer installationTypeMstId;

	@Column(name="installation_type_val")
	private String installationTypeVal;

	public InstallationTypeMst() {
	}

	public int getInstallationTypeMstId() {
		return this.installationTypeMstId;
	}

	public void setInstallationTypeMstId(int installationTypeMstId) {
		this.installationTypeMstId = installationTypeMstId;
	}

	public String getInstallationTypeVal() {
		return this.installationTypeVal;
	}

	public void setInstallationTypeVal(String installationTypeVal) {
		this.installationTypeVal = installationTypeVal;
	}

}