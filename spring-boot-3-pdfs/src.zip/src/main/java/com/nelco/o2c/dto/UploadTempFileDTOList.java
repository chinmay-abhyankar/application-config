package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class UploadTempFileDTOList implements Serializable {
	/**
	 * @author Amol.l
	 *
	 */
	private static final long serialVersionUID = 10L;
	private Integer opportunityId;
	private Integer userMstId;
	private List<UploadTempFileDTO> uploadTempFileDTOList = new ArrayList<UploadTempFileDTO>();
	private Integer respMatrixDetailsId;
	
	public Integer getRespMatrixDetailsId() {
		return respMatrixDetailsId;
	}
	public void setRespMatrixDetailsId(Integer respMatrixDetailsId) {
		this.respMatrixDetailsId = respMatrixDetailsId;
	}
	public Integer getOpportunityId() {
		return opportunityId;
	}
	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public List<UploadTempFileDTO> getUploadTempFileDTOList() {
		return uploadTempFileDTOList;
	}
	public void setUploadTempFileDTOList(List<UploadTempFileDTO> uploadTempFileDTOList) {
		this.uploadTempFileDTOList = uploadTempFileDTOList;
	}
	
	
		
}
