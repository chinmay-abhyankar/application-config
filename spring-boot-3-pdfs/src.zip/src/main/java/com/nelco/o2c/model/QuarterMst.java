package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the quarter_mst database table.
 * 
 */
@Entity
@Table(name="quarter_mst")
@NamedQuery(name="QuarterMst.findAll", query="SELECT q FROM QuarterMst q")
public class QuarterMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="quarter_mst_id")
	private int quarterMstId;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="is_active")
	private String isActive;

	@Column(name="quarter_desc")
	private String quarterDesc;

	private String sequence;

	public QuarterMst() {
	}

	public int getQuarterMstId() {
		return this.quarterMstId;
	}

	public void setQuarterMstId(int quarterMstId) {
		this.quarterMstId = quarterMstId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getQuarterDesc() {
		return this.quarterDesc;
	}

	public void setQuarterDesc(String quarterDesc) {
		this.quarterDesc = quarterDesc;
	}

	public String getSequence() {
		return this.sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

}