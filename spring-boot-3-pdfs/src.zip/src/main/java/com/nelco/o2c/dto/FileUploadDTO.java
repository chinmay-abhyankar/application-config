/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.FileTypeMst;

/**
 * @author Amol.l
 *
 */
public class FileUploadDTO  implements Serializable {
	
	private static final long serialVersionUID = 13L;
	
	private String username;
	private Integer statusMstId;
	private List<FileTypeMst> fileTypeMsts;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Integer getStatusMstId() {
		return statusMstId;
	}
	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}
	public List<FileTypeMst> getFileTypeMsts() {
		return fileTypeMsts;
	}
	public void setFileTypeMsts(List<FileTypeMst> fileTypeMsts) {
		this.fileTypeMsts = fileTypeMsts;
	}
	
}
