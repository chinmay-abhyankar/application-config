package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the location_mst database table.
 * 
 */
@Entity
@Table(name="location_mst")
@NamedQuery(name="LocationMst.findAll", query="SELECT l FROM LocationMst l")
public class LocationMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="location_mst_id")
	private Integer locationMstId;

	@Column(name="location_code")
	private String locationCode;

	@Column(name="location_val")
	private String locationVal;

	public Integer getLocationMstId() {
		return locationMstId;
	}

	public void setLocationMstId(Integer locationMstId) {
		this.locationMstId = locationMstId;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getLocationVal() {
		return locationVal;
	}

	public void setLocationVal(String locationVal) {
		this.locationVal = locationVal;
	}

	

}