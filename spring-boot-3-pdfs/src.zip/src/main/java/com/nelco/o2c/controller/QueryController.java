/**
 * 
 */
package com.nelco.o2c.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.QueryDetailsDTO;
import com.nelco.o2c.service.QueryService;

/**
 * @author Jayashankar.r
 *
 */
@RestController
public class QueryController {
	
	@Autowired
	QueryService queryService;
	
	@RequestMapping(value = "/getQueryDetails.do", method = RequestMethod.POST)
	public QueryDetailsDTO getQueryDetails(@RequestBody CommonDTO commonDTO) {
		
		return queryService.getQueryDetails(commonDTO);
	}
	
	@RequestMapping(value = "/postQuery.do", method = RequestMethod.POST)
	public QueryDetailsDTO postQuery(@RequestBody CommonDTO commonDTO,HttpServletRequest request) {
		
		return queryService.postQuery(commonDTO,request);
	}
	
	@RequestMapping(value = "/postResponse.do", method = RequestMethod.POST)
	public QueryDetailsDTO postResponse(@RequestBody CommonDTO commonDTO,HttpServletRequest request) {
		
		return queryService.postResponse(commonDTO,request);
	}
}
