/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.PreSalesRespMatrix;
import com.nelco.o2c.model.RespMatrixDetails;

/**
 * @author Amol.l
 *
 */
public interface RespMatrixDetailsDao {
	
	public List<RespMatrixDetails> getRespMatrixDetailsByUserMstIdAndOpId(Integer userMstId, Integer opportunityId);

	public RespMatrixDetails saveRespMatrixDetails(RespMatrixDetails respMatrixDetails);

	public List<PreSalesRespMatrix> getPSMRespMatrixByUserMstIdAndOpId(Integer userMstId, Integer opportunityId,Integer respMatrixDetailsId);

	public PreSalesRespMatrix savePSMRespMatrixDetails(PreSalesRespMatrix preSalesRespMatrix);

	public List<OppDetails> getOppDetailsbyOpId(Integer opportunityId);
	
	public List<RespMatrixDetails> PSMgrRespMatrixDetByUserId(CommonDTO commonDTO);

	public List<OppUploadDetail> getRiskDocumentsbyOppId(Integer opportunityId);
	
	public RespMatrixDetails getRMDByRespMatrixDetailsId(Integer respMatrixDetailsId);
	
}
