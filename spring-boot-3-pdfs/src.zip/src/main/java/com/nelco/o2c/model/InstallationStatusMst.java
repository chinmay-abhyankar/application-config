package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the installation_status_mst database table.
 * 
 */
@Entity
@Table(name="installation_status_mst")
@NamedQuery(name="InstallationStatusMst.findAll", query="SELECT i FROM InstallationStatusMst i where i.isActive = 'Y' ")
public class InstallationStatusMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="installation_status_mst_id")
	private Integer installationStatusMstId;

	@Column(name="installation_status_code")
	private String installationStatusCode;

	@Column(name="installation_status_val")
	private String installationStatusVal;
	
	@Column(name = "is_active")
	private String isActive;

	public InstallationStatusMst() {
	}

	public Integer getInstallationStatusMstId() {
		return installationStatusMstId;
	}

	public void setInstallationStatusMstId(Integer installationStatusMstId) {
		this.installationStatusMstId = installationStatusMstId;
	}

	public String getInstallationStatusCode() {
		return installationStatusCode;
	}

	public void setInstallationStatusCode(String installationStatusCode) {
		this.installationStatusCode = installationStatusCode;
	}

	public String getInstallationStatusVal() {
		return installationStatusVal;
	}

	public void setInstallationStatusVal(String installationStatusVal) {
		this.installationStatusVal = installationStatusVal;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
}