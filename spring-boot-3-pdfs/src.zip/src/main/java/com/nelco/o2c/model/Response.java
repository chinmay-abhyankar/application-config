package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the response database table.
 * 
 */
@Entity
@Table(name = "response")
@NamedQuery(name = "Response.findAll", query = "SELECT r FROM Response r")
public class Response implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "response_id")
	private Integer responseId;

	@Column(name = "created_date",insertable = false)
	private String createdDate;

	@Column(name = "query_id")
	private Integer queryId;

	@Column(name = "response")
	private String response;

	@Column(name = "user_mst_id")
	private Integer userMstId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_mst_id", referencedColumnName = "user_mst_id", insertable = false, updatable = false)
	private UserMst userMst;

	public UserMst getUserMst() {
		return userMst;
	}

	public void setUserMst(UserMst userMst) {
		this.userMst = userMst;
	}

	public Integer getResponseId() {
		return responseId;
	}

	public void setResponseId(Integer responseId) {
		this.responseId = responseId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getQueryId() {
		return queryId;
	}

	public void setQueryId(Integer queryId) {
		this.queryId = queryId;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public Integer getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

}