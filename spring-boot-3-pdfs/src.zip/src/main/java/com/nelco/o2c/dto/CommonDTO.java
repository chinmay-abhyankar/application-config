/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.jsonbeanmap.TafApprovalBean;
import com.nelco.o2c.model.BrfSoDetails;
import com.nelco.o2c.model.BrfStatusTracker;
import com.nelco.o2c.model.DrfApproverDetail;
import com.nelco.o2c.model.Query;
import com.nelco.o2c.model.Response;
import com.nelco.o2c.model.StatusMst;

/**
 * @author Jayashankar.r
 *
 */
public class CommonDTO implements Serializable {
	private static final long serialVersionUID = 50L;
	private String loginId;
	private String roleCode;
	private String userName;
	private Integer drfDetailsId;
	private Integer userMstId;
	private Query query;
	private Response response;
	private DrfApproverDetail drfApproverDetail;
	private BrfStatusTracker brfStatusTracker;
	private Integer oppId;
	private String zohoStatus;
	private Integer tafId;
	private Integer tafStatusId;
	private Boolean isSubmit = false;
	private Integer preBidId;
	private String opportunityName;
	private StatusMst status;
	private String tafStatusCode;
	private List<TafApprovalBean> tafApprBeans;
	private String fromDate;
	private String toDate;
	private Integer brfId;
	private String financeRemark;
	private String nocRemark;
	private Integer proposalId;
	private String bwAllocation;
	private String existingSite;
	private String oldSoNum;
	private String item;
	private String materialNum;
	private Integer soOrdersId;
	private String newSoActDate;
	private List<BrfSoDetails> brfSoDetailsList = new ArrayList<BrfSoDetails>();
	private Integer franchiseeAllocEngMstId;
	private Boolean accepted = false;
	private Integer franchiseAllocId;
	private String flag;
	private String bidManagerComments;
	private String statusCode;
	private String demoStart;
	private String demoEnd;
	
	public String getDemoStart() {
		return demoStart;
	}
	public void setDemoStart(String demoStart) {
		this.demoStart = demoStart;
	}
	public String getDemoEnd() {
		return demoEnd;
	}
	public void setDemoEnd(String demoEnd) {
		this.demoEnd = demoEnd;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public Integer getFranchiseAllocId() {
		return franchiseAllocId;
	}
	public void setFranchiseAllocId(Integer franchiseAllocId) {
		this.franchiseAllocId = franchiseAllocId;
	}
	public Boolean getAccepted() {
		return accepted;
	}
	public void setAccepted(Boolean accepted) {
		this.accepted = accepted;
	}
	public Integer getFranchiseeAllocEngMstId() {
		return franchiseeAllocEngMstId;
	}
	public void setFranchiseeAllocEngMstId(Integer franchiseeAllocEngMstId) {
		this.franchiseeAllocEngMstId = franchiseeAllocEngMstId;
	}
	public List<BrfSoDetails> getBrfSoDetailsList() {
		return brfSoDetailsList;
	}
	public void setBrfSoDetailsList(List<BrfSoDetails> brfSoDetailsList) {
		this.brfSoDetailsList = brfSoDetailsList;
	}
	public String getNewSoActDate() {
		return newSoActDate;
	}
	public void setNewSoActDate(String newSoActDate) {
		this.newSoActDate = newSoActDate;
	}
	public Integer getProposalId() {
		return proposalId;
	}
	public void setProposalId(Integer proposalId) {
		this.proposalId = proposalId;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public List<TafApprovalBean> getTafApprBeans() {
		return tafApprBeans;
	}
	public void setTafApprBeans(List<TafApprovalBean> tafApprBeans) {
		this.tafApprBeans = tafApprBeans;
	}
	public String getTafStatusCode() {
		return tafStatusCode;
	}
	public void setTafStatusCode(String tafStatusCode) {
		this.tafStatusCode = tafStatusCode;
	}
	public StatusMst getStatus() {
		return status;
	}
	public void setStatus(StatusMst status) {
		this.status = status;
	}
	public String getOpportunityName() {
		return opportunityName;
	}
	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}
	public Integer getPreBidId() {
		return preBidId;
	}
	public void setPreBidId(Integer preBidId) {
		this.preBidId = preBidId;
	}
	public Boolean getIsSubmit() {
		return isSubmit;
	}
	public void setIsSubmit(Boolean isSubmit) {
		this.isSubmit = isSubmit;
	}
	public Integer getTafId() {
		return tafId;
	}
	public void setTafId(Integer tafId) {
		this.tafId = tafId;
	}
	public Integer getTafStatusId() {
		return tafStatusId;
	}
	public void setTafStatusId(Integer tafStatusId) {
		this.tafStatusId = tafStatusId;
	}
	public String getZohoStatus() {
		return zohoStatus;
	}
	public void setZohoStatus(String zohoStatus) {
		this.zohoStatus = zohoStatus;
	}
	public Integer getOppId() {
		return oppId;
	}
	public void setOppId(Integer oppId) {
		this.oppId = oppId;
	}
	public DrfApproverDetail getDrfApproverDetail() {
		return drfApproverDetail;
	}
	public void setDrfApproverDetail(DrfApproverDetail drfApproverDetail) {
		this.drfApproverDetail = drfApproverDetail;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public Query getQuery() {
		return query;
	}
	public void setQuery(Query query) {
		this.query = query;
	}
	public Response getResponse() {
		return response;
	}
	public void setResponse(Response response) {
		this.response = response;
	}
	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}
	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public BrfStatusTracker getBrfStatusTracker() {
		return brfStatusTracker;
	}
	public void setBrfStatusTracker(BrfStatusTracker brfStatusTracker) {
		this.brfStatusTracker = brfStatusTracker;
	}
	public Integer getBrfId() {
		return brfId;
	}
	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}
	public String getFinanceRemark() {
		return financeRemark;
	}
	public void setFinanceRemark(String financeRemark) {
		this.financeRemark = financeRemark;
	}
	public String getNocRemark() {
		return nocRemark;
	}
	public void setNocRemark(String nocRemark) {
		this.nocRemark = nocRemark;
	}
	public String getBwAllocation() {
		return bwAllocation;
	}
	public void setBwAllocation(String bwAllocation) {
		this.bwAllocation = bwAllocation;
	}
	public String getExistingSite() {
		return existingSite;
	}
	public void setExistingSite(String existingSite) {
		this.existingSite = existingSite;
	}
	public String getOldSoNum() {
		return oldSoNum;
	}
	public void setOldSoNum(String oldSoNum) {
		this.oldSoNum = oldSoNum;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public String getMaterialNum() {
		return materialNum;
	}
	public void setMaterialNum(String materialNum) {
		this.materialNum = materialNum;
	}
	public Integer getSoOrdersId() {
		return soOrdersId;
	}
	public void setSoOrdersId(Integer soOrdersId) {
		this.soOrdersId = soOrdersId;
	}
	public String getBidManagerComments() {
		return bidManagerComments;
	}
	public void setBidManagerComments(String bidManagerComments) {
		this.bidManagerComments = bidManagerComments;
	}
	
}
