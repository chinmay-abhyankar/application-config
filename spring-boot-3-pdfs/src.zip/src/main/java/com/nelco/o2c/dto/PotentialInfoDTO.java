package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.TafStatusTracker;
import com.nelco.o2c.utility.DateUtil;

public class PotentialInfoDTO  implements Serializable {
	/**
	 * @author Amol.l
	 *
	 */
	private static final long serialVersionUID = 10L;
	
	/*private Opportunity opportunity;
	private OppDetails oppDetails;
	private List<Opportunity> opportunityList = new ArrayList<>();
	private List<Opportunity> OppDetailsList = new ArrayList<>();*/

	private Integer opportunityId;
	private String zohoId;
	private String potentialName;
	private String businessLine;
	private String potentialOwner;
	private String createdDate;
	private String closingDate;
	private String zohoStatus;
	private String tafStatus="NA";
	private String tafStatusCode = "NA";
	private String ceoStatusCode="NA";
	private String emdStatusCode;
	private String emdStatusVal;
	private String tenderStatusCode;
	private String tenderStatusVal;
	private String smOwnerId;
	private Integer tafId;
	private Integer respMatrixDetailsId;
	private String topicsDel;
	private String statusFlag;
	private String targetDate;
	private String fromDate;
	private String toDate;
	private String modifiedDate;
	private String showDrfButton = "N";
	private String custName;
	private String marketSegment;
	private String tenderNo;
	private String poStatus;
	private String proposalGenId;
	private Integer proposalId;
	private String poStatusCode;
	private String poNumber;
	private String poDate;
	private List<TafStatusTrackerDTO> tafstatusTrackerDto;
	
	public String getPoDate() {
		return poDate;
	}
	public void setPoDate(String poDate) {
		this.poDate = poDate;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public String getPoStatusCode() {
		return poStatusCode;
	}
	public void setPoStatusCode(String poStatusCode) {
		this.poStatusCode = poStatusCode;
	}
	public String getProposalGenId() {
		return proposalGenId;
	}
	public void setProposalGenId(String proposalGenId) {
		this.proposalGenId = proposalGenId;
	}
	public Integer getProposalId() {
		return proposalId;
	}
	public void setProposalId(Integer proposalId) {
		this.proposalId = proposalId;
	}
	public String getPoStatus() {
		return poStatus;
	}
	public void setPoStatus(String poStatus) {
		this.poStatus = poStatus;
	}
	public String getTenderNo() {
		return tenderNo;
	}
	public void setTenderNo(String tenderNo) {
		this.tenderNo = tenderNo;
	}
	public String getShowDrfButton() {
		return showDrfButton;
	}
	public void setShowDrfButton(String showDrfButton) {
		this.showDrfButton = showDrfButton;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = DateUtil.convertDateToSqlDate(fromDate);
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = DateUtil.convertDateToSqlDate(toDate);
	}
	public Integer getRespMatrixDetailsId() {
		return respMatrixDetailsId;
	}
	public void setRespMatrixDetailsId(Integer respMatrixDetailsId) {
		this.respMatrixDetailsId = respMatrixDetailsId;
	}
	public String getTopicsDel() {
		return topicsDel;
	}
	public void setTopicsDel(String topicsDel) {
		this.topicsDel = topicsDel;
	}
	public String getStatusFlag() {
		return statusFlag;
	}
	public void setStatusFlag(String statusFlag) {
		this.statusFlag = statusFlag;
	}
	public String getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(String targetDate) {
		this.targetDate = targetDate;
	}
	public Integer getTafId() {
		return tafId;
	}
	public void setTafId(Integer tafId) {
		this.tafId = tafId;
	}
	public String getSmOwnerId() {
		return smOwnerId;
	}
	public void setSmOwnerId(String smOwnerId) {
		this.smOwnerId = smOwnerId;
	}
	public String getCeoStatusCode() {
		return ceoStatusCode;
	}
	public void setCeoStatusCode(String ceoStatusCode) {
		this.ceoStatusCode = ceoStatusCode;
	}
	public String getEmdStatusCode() {
		return emdStatusCode;
	}
	public void setEmdStatusCode(String emdStatusCode) {
		this.emdStatusCode = emdStatusCode;
	}
	public String getEmdStatusVal() {
		return emdStatusVal;
	}
	public void setEmdStatusVal(String emdStatusVal) {
		this.emdStatusVal = emdStatusVal;
	}
	public String getTenderStatusCode() {
		return tenderStatusCode;
	}
	public void setTenderStatusCode(String tenderStatusCode) {
		this.tenderStatusCode = tenderStatusCode;
	}
	public String getTenderStatusVal() {
		return tenderStatusVal;
	}
	public void setTenderStatusVal(String tenderStatusVal) {
		this.tenderStatusVal = tenderStatusVal;
	}
	public String getTafStatusCode() {
		return tafStatusCode;
	}
	public void setTafStatusCode(String tafStatusCode) {
		this.tafStatusCode = tafStatusCode;
	}
	public Integer getOpportunityId() {
		return opportunityId;
	}
	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}
	public String getZohoId() {
		return zohoId;
	}
	public void setZohoId(String zohoId) {
		this.zohoId = zohoId;
	}
	public String getPotentialName() {
		return potentialName;
	}
	public void setPotentialName(String potentialName) {
		this.potentialName = potentialName;
	}
	public String getBusinessLine() {
		return businessLine;
	}
	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}
	public String getPotentialOwner() {
		return potentialOwner;
	}
	public void setPotentialOwner(String potentialOwner) {
		this.potentialOwner = potentialOwner;
	}
	
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getClosingDate() {
		return closingDate;
	}
	public void setClosingDate(String closingDate) {
		this.closingDate = closingDate;
	}
	public String getZohoStatus() {
		return zohoStatus;
	}
	public void setZohoStatus(String zohoStatus) {
		this.zohoStatus = zohoStatus;
	}
	public String getTafStatus() {
		return tafStatus;
	}
	public void setTafStatus(String tafStatus) {
		this.tafStatus = tafStatus;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getMarketSegment() {
		return marketSegment;
	}
	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}
	public List<TafStatusTrackerDTO> getTafstatusTrackerDto() {
		return tafstatusTrackerDto;
	}
	public void setTafstatusTrackerDto(List<TafStatusTrackerDTO> tafstatusTrackerDto) {
		this.tafstatusTrackerDto = tafstatusTrackerDto;
	}
	
	
	
}
