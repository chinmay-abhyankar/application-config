package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;


/**
 * The persistent class for the spares_so_delivery database table.
 * 
 */
@Entity
@Table(name="spares_so_delivery")
@NamedQueries({
	@NamedQuery(name="SparesSoDelivery.findAll", query="SELECT s FROM SparesSoDelivery s"),
	@NamedQuery(name="SparesSoDelivery.findByDeliveryCreationDateGreaterThan", query="SELECT s FROM SparesSoDelivery s "
			+ " inner join fetch s.deliveryStatusMst dm inner join fetch s.podStatusMst psm "
			+ " where s.delCreationDate between :fromDate and :toDate and s.sparesSoDeliveryId > :sparesSoDeliveryId and s.deliveryStatusMstId = :deliveryStatusMstId "),
	@NamedQuery(name="SparesSoDelivery.findByDeliveryCreationDateLessThan", query="SELECT s FROM SparesSoDelivery s "
			+ " inner join fetch s.deliveryStatusMst dm inner join fetch s.podStatusMst psm "
			+ " where s.delCreationDate between :fromDate and :toDate and s.sparesSoDeliveryId < :sparesSoDeliveryId and s.deliveryStatusMstId = :deliveryStatusMstId "),
	@NamedQuery(name = "SparesSoDelivery.updatePodStatusByDeliveryId", query = "update SparesSoDelivery s set s.podStatusMstId = :podStatusMstId where s.sparesSoDeliveryId = :sparesSoDeliveryId ")
})
public class SparesSoDelivery implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="spares_so_delivery_id")
	private Integer sparesSoDeliveryId;

	@Column(name="billing_type")
	private String billingType;

	@Column(name="created_date",updatable = false)
	private String createdDate;

	@Column(name="customer_name")
	private String customerName;

	@Column(name="del_creation_date",updatable = false)
	private String delCreationDate;

	@Column(name="del_no")
	private String delNo;

	@Column(name="del_type")
	private String delType;

	@Column(name="delivery_status_mst_id")
	private Integer deliveryStatusMstId;

	@Column(name="inv_date",updatable = false)
	private String invDate;

	@Column(name="inv_no")
	private String invNo;

	@Column(name="inv_type")
	private String invType;

	private String item;

	@Column(name="material_desc")
	private String materialDesc;

	@Column(name="material_num")
	private String materialNum;

	@Column(name="modified_date")
	private String modifiedDate;

	@Column(name="order_quantity")
	private String orderQuantity;

	@Column(name="pgi_num")
	private String pgiNum;

	private String plant;

	@Column(name="pod_status_mst_id")
	private Integer podStatusMstId;

	@Column(name="posting_date",updatable = false)
	private String postingDate;

	private String proforma;

	@Column(name="proforma_date",updatable = false)
	private String proformaDate;

	@Column(name="ship_to_party")
	private String shipToParty;

	@Column(name="shtp_address")
	private String shtpAddress;

	@Column(name="so_number")
	private String soNumber;

	@Column(name="sold_to_party")
	private String soldToParty;

	@Column(name="spares_req_id")
	private String sparesReqId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "delivery_status_mst_id", referencedColumnName = "delivery_status_mst_id", insertable = false, updatable = false)
	private DeliveryStatusMst deliveryStatusMst;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "pod_status_mst_id", referencedColumnName = "pod_status_mst_id", insertable = false, updatable = false)
	private PodStatusMst podStatusMst;
	
	@Column(name = "dispatch_date")
	private String dispatchDate;
	
	@Column(name = "docket_num")
	private String docketNum;
	
	@Column(name = "courier_name")
	private String courierName;
	
	@Column(name = "eddate")
	private String eddate;
	
	@Column(name = "addate")
	private String addate;
	
	@Column(name = "boxes")
	private String boxes;
	
	@Column(name = "state_mst_id")
	private Integer stateMstId;
	
	
	
	public Integer getStateMstId() {
		return stateMstId;
	}

	public void setStateMstId(Integer stateMstId) {
		this.stateMstId = stateMstId;
	}

	public String getDispatchDate() {
		//return dispatchDate;
		return DateUtil.convertDateTimeToString(this.dispatchDate);
	}

	public void setDispatchDate(String dispatchDate) {
		this.dispatchDate = dispatchDate;
	}

	public String getDocketNum() {
		return docketNum;
	}

	public void setDocketNum(String docketNum) {
		this.docketNum = docketNum;
	}

	public String getCourierName() {
		return courierName;
	}

	public void setCourierName(String courierName) {
		this.courierName = courierName;
	}

	public String getEddate() {
		//return eddate;
		return DateUtil.convertDateTimeToString(this.eddate);
	}

	public void setEddate(String eddate) {
		this.eddate = eddate;
	}

	public String getAddate() {
		//return addate;
		return DateUtil.convertDateTimeToString(this.addate);
	}

	public void setAddate(String addate) {
		this.addate = addate;
	}

	public String getBoxes() {
		return boxes;
	}

	public void setBoxes(String boxes) {
		this.boxes = boxes;
	}

	public DeliveryStatusMst getDeliveryStatusMst() {
		return deliveryStatusMst;
	}

	public void setDeliveryStatusMst(DeliveryStatusMst deliveryStatusMst) {
		this.deliveryStatusMst = deliveryStatusMst;
	}

	public PodStatusMst getPodStatusMst() {
		return podStatusMst;
	}

	public void setPodStatusMst(PodStatusMst podStatusMst) {
		this.podStatusMst = podStatusMst;
	}

	public SparesSoDelivery() {
	}

	public Integer getSparesSoDeliveryId() {
		return this.sparesSoDeliveryId;
	}

	public void setSparesSoDeliveryId(Integer sparesSoDeliveryId) {
		this.sparesSoDeliveryId = sparesSoDeliveryId;
	}

	public String getBillingType() {
		return this.billingType;
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

	public String getCreatedDate() {
		//return this.createdDate;
		return DateUtil.convertDateTimeToString(this.createdDate);
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCustomerName() {
		return this.customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getDelCreationDate() {
		//return this.delCreationDate;
		return DateUtil.convertDateTimeToString(this.delCreationDate);
	}

	public void setDelCreationDate(String delCreationDate) {
		this.delCreationDate = delCreationDate;
	}

	public String getDelNo() {
		return this.delNo;
	}

	public void setDelNo(String delNo) {
		this.delNo = delNo;
	}

	public String getDelType() {
		return this.delType;
	}

	public void setDelType(String delType) {
		this.delType = delType;
	}

	public Integer getDeliveryStatusMstId() {
		return this.deliveryStatusMstId;
	}

	public void setDeliveryStatusMstId(Integer deliveryStatusMstId) {
		this.deliveryStatusMstId = deliveryStatusMstId;
	}

	public String getInvDate() {
		//return this.invDate;
		return DateUtil.convertDateTimeToString(this.invDate);
	}

	public void setInvDate(String invDate) {
		this.invDate = invDate;
	}

	public String getInvNo() {
		return this.invNo;
	}

	public void setInvNo(String invNo) {
		this.invNo = invNo;
	}

	public String getInvType() {
		return this.invType;
	}

	public void setInvType(String invType) {
		this.invType = invType;
	}

	public String getItem() {
		return this.item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getMaterialDesc() {
		return this.materialDesc;
	}

	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}

	public String getMaterialNum() {
		return this.materialNum;
	}

	public void setMaterialNum(String materialNum) {
		this.materialNum = materialNum;
	}

	public String getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getOrderQuantity() {
		return this.orderQuantity;
	}

	public void setOrderQuantity(String orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public String getPgiNum() {
		return this.pgiNum;
	}

	public void setPgiNum(String pgiNum) {
		this.pgiNum = pgiNum;
	}

	public String getPlant() {
		return this.plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public Integer getPodStatusMstId() {
		return this.podStatusMstId;
	}

	public void setPodStatusMstId(Integer podStatusMstId) {
		this.podStatusMstId = podStatusMstId;
	}

	public String getPostingDate() {
		//return this.postingDate;
		return DateUtil.convertDateTimeToString(this.postingDate);
	}

	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}

	public String getProforma() {
		return this.proforma;
	}

	public void setProforma(String proforma) {
		this.proforma = proforma;
	}

	public String getProformaDate() {
		//return this.proformaDate;
		return DateUtil.convertDateTimeToString(this.proformaDate);
	}

	public void setProformaDate(String proformaDate) {
		this.proformaDate = proformaDate;
	}

	public String getShipToParty() {
		return this.shipToParty;
	}

	public void setShipToParty(String shipToParty) {
		this.shipToParty = shipToParty;
	}

	public String getShtpAddress() {
		return this.shtpAddress;
	}

	public void setShtpAddress(String shtpAddress) {
		this.shtpAddress = shtpAddress;
	}

	public String getSoNumber() {
		return this.soNumber;
	}

	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}

	public String getSoldToParty() {
		return this.soldToParty;
	}

	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}

	public String getSparesReqId() {
		return this.sparesReqId;
	}

	public void setSparesReqId(String sparesReqId) {
		this.sparesReqId = sparesReqId;
	}

	

}