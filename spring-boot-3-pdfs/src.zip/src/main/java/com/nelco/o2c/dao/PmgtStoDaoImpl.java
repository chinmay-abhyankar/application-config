/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.AllDeliveryListDTO;
import com.nelco.o2c.dto.PmgtStoDTO;
import com.nelco.o2c.dto.SparesSoDTO;
import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.PmgtStoPodUploadDetail;
import com.nelco.o2c.model.StoPmgt;
import com.nelco.o2c.model.StoPmgtDelivery;
import com.nelco.o2c.model.StoPmgtDeliveryTracker;
import com.nelco.o2c.model.StoPmgtMaterial;
import com.nelco.o2c.model.StoPmgtPodTracker;
import com.nelco.o2c.model.StoPmgtStatusTracker;
import com.nelco.o2c.model.StorageSapmst;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class PmgtStoDaoImpl implements PmgtStoDao {

	@PersistenceContext
	private EntityManager em;

	Query query;

	private String pmgtStoGenId;

	@SuppressWarnings("unchecked")
	@Override
	public List<StoPmgt> getStoPmgtList(PmgtStoDTO ipPmgtStoDTO) {
		// TODO Auto-generated method stub
		try {
			String fromDate = DateUtil.convertDateToSqlDate(ipPmgtStoDTO.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(ipPmgtStoDTO.getToDate());
			if (ipPmgtStoDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)) {
				query = em.createNamedQuery("StoPmgt.getStoPmgtListPm");
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, ipPmgtStoDTO.getUserMstId());
			} else if (ipPmgtStoDTO.getRoleCode().equals(Constants.STOREEXECUTIVECODE)
					|| ipPmgtStoDTO.getRoleCode().equals(Constants.STOREASSOCIATECODE)) {
				query = em.createNamedQuery("StoPmgt.getStoPmgtListStores");
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, ipPmgtStoDTO.getUserMstId());
			} else if (ipPmgtStoDTO.getRoleCode().equals(Constants.PMGTCOORDCODE)) {
				query = em.createNamedQuery("StoPmgt.getStoPmgtListPmgtCoord");
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, ipPmgtStoDTO.getUserMstId());
			} else {
				query = em.createNamedQuery("StoPmgt.findByCreatedDate");
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
			}

			return (List<StoPmgt>) query.getResultList();
		} finally {
			em.close();
		}
	}

	@Override
	public StoPmgt getStoPmgtById(PmgtStoDTO ipPmgtStoDTO) {
		// TODO Auto-generated method stub
		try {
			return em.find(StoPmgt.class, ipPmgtStoDTO.getStoPmgtId());
		} catch (Exception e) {
			return new StoPmgt();
		} finally {
			em.close();
		}
	}

	@Override
	public StoPmgt saveSto(StoPmgt stoPmgt, Integer userMstId,String roleCode) {
		// TODO Auto-generated method stub
		String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
		if (stoPmgt.getStoPmgtId() == null) {
			stoPmgt.setStatusMstId(Constants.PMGTSTONSID);
			synchronized (this) {
				Integer maxProposalNumber = getCurrentDayCountStoPmgt();
				this.pmgtStoGenId = "PMGTSTO_" + (DateUtil.getCurrentISTDateAsString(DateUtil.SIMPLE_DATE_FORMAT)
						.replace("-", "_").concat("_").concat(maxProposalNumber.toString()));

			}
			stoPmgt.setStoPmgtGenId(this.pmgtStoGenId);
		}
		stoPmgt.setCreatedDate(currTime);

		StoPmgt savedStoPmgt = em.merge(stoPmgt);
		stoPmgt.setStoPmgtId(savedStoPmgt.getStoPmgtId());
		saveStoMaterials(stoPmgt,roleCode);
		if (stoPmgt.getStoPmgtId() == null) {
			//em.refresh(savedStoPmgt);
			StoPmgtStatusTracker stoPmgtStatusTracker = new StoPmgtStatusTracker();
			stoPmgtStatusTracker.setReqById(userMstId);
			stoPmgtStatusTracker.setReqDate(currTime);
			stoPmgtStatusTracker.setStatusMstId(Constants.PMGTSTONSID);
			stoPmgtStatusTracker.setStoPmgtId(savedStoPmgt.getStoPmgtId());
			em.merge(stoPmgtStatusTracker);
		}
		return savedStoPmgt;
	}

	@Override
	public void saveStoMaterials(StoPmgt stoPmgt,String roleCode) {
		// TODO Auto-generated method stub
		List<StoPmgtMaterial> stoPmgtMaterialList = stoPmgt.getStoPmgtMaterialList();
		for (StoPmgtMaterial stoPmgtMaterial : stoPmgtMaterialList) {
			stoPmgtMaterial.setPlantSapmst(null);
			stoPmgtMaterial.setStorageSapmst(null);
			stoPmgtMaterial.setStoPmgtId(stoPmgt.getStoPmgtId());
			if(roleCode.equals(Constants.PROGRAMMGRCODE)) {
				stoPmgtMaterial.setAvailMaterialNum(stoPmgtMaterial.getReqMaterialNum());
				stoPmgtMaterial.setAvailQuantity(stoPmgtMaterial.getReqQuantity());	
			}
			em.merge(stoPmgtMaterial);
		}
	}

	@Override
	public void submitByPm(PmgtStoDTO ipPmgtStoDTO) {
		try {
			// TODO Auto-generated method stub
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			query = em.createNamedQuery("StoPmgt.updatePmSubmit");
			query.setParameter(1, currTime);
			query.setParameter(2, Constants.PMGTSTOSTSID);
			query.setParameter(3, ipPmgtStoDTO.getStoPmgtId());
			query.executeUpdate();
			StoPmgtStatusTracker stoPmgtStatusTracker = new StoPmgtStatusTracker();
			stoPmgtStatusTracker.setReqById(ipPmgtStoDTO.getUserMstId());
			stoPmgtStatusTracker.setReqDate(currTime);
			stoPmgtStatusTracker.setStatusMstId(Constants.PMGTSTOSTSID);
			stoPmgtStatusTracker.setStoPmgtId(ipPmgtStoDTO.getStoPmgtId());
			em.merge(stoPmgtStatusTracker);
		} finally {
			// TODO: handle finally clause
			em.close();
		}

	}

	@Override
	public void submitByStores(PmgtStoDTO ipPmgtStoDTO) {
		try {
			// TODO Auto-generated method stub
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			query = em.createNamedQuery("StoPmgt.updateStoresSubmit");
			query.setParameter(1, currTime);
			query.setParameter(2, Constants.PMGTSTOSBSID);
			query.setParameter(3, ipPmgtStoDTO.getStoPmgtId());
			query.executeUpdate();
			StoPmgtStatusTracker stoPmgtStatusTracker = new StoPmgtStatusTracker();
			stoPmgtStatusTracker.setReqById(ipPmgtStoDTO.getUserMstId());
			stoPmgtStatusTracker.setReqDate(currTime);
			stoPmgtStatusTracker.setStatusMstId(Constants.PMGTSTOSBSID);
			stoPmgtStatusTracker.setStoPmgtId(ipPmgtStoDTO.getStoPmgtId());
			em.merge(stoPmgtStatusTracker);
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserMst> getUserByRoleCodeList(PmgtStoDTO ipPmgtStoDTO, List<String> roleCodes) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("UserMst.getUserListByRoleCodeList");
			query.setParameter(1, roleCodes);
			// query.setParameter(2, ipPmgtStoDTO.getUserMstId());
			return (List<UserMst>) query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public Integer getCurrentDayCountStoPmgt() {
		try {
			String currentDate = DateUtil.getCurrentISTDateOnlyAsString(DateUtil.DATE_ONLY_FORMAT_MSSQL);
			query = em.createNamedQuery("StoPmgt.getCurrentDayMaxCount");
			query.setParameter(1, currentDate);
			query.setParameter(2, currentDate + " 23:59:59.999");
			Long maxNumber = (Long) query.getSingleResult();
			return maxNumber.intValue();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StoPmgtDelivery> getDeliveryTrackPmgtSto(PmgtStoDTO ipPmgtStoDTO) {
		// TODO Auto-generated method stub
		String fromDate = DateUtil.convertDateToSqlDate(ipPmgtStoDTO.getFromDate());
		String toDate = DateUtil.convertDateToSqlDate(ipPmgtStoDTO.getToDate());
		if (ipPmgtStoDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)) {
			if("".equalsIgnoreCase(ipPmgtStoDTO.getPlant()) || (null==ipPmgtStoDTO.getPlant()) || ipPmgtStoDTO.getPlant().isEmpty() || ("ALL".equalsIgnoreCase(ipPmgtStoDTO.getPlant()))){
			query = em.createNamedQuery("StoPmgtDelivery.getStoDeliveryListPm");
			query.setParameter(1, ipPmgtStoDTO.getUserMstId());
			query.setParameter(2, fromDate + Constants.MINDAYTIME);
			query.setParameter(3, toDate + Constants.MAXDAYTIME);
			query.setParameter(4, null);
		}
		else {
			query = em.createNativeQuery("select plant_sapmst_id from plant_sapmst where plant_code = ?1");
			query.setParameter(1, ipPmgtStoDTO.getPlant());
			int plantId = (int) query.getSingleResult();
			
			query = em.createNamedQuery("StoPmgtDelivery.getStoDeliveryListPm");
			query.setParameter(1, ipPmgtStoDTO.getUserMstId());
			query.setParameter(2, fromDate + Constants.MINDAYTIME);
			query.setParameter(3, toDate + Constants.MAXDAYTIME);
			query.setParameter(4,  plantId);
		}
		} else if (ipPmgtStoDTO.getRoleCode().equals(Constants.STOREEXECUTIVECODE)
				|| ipPmgtStoDTO.getRoleCode().equals(Constants.STOREASSOCIATECODE)) {
			if("".equalsIgnoreCase(ipPmgtStoDTO.getPlant()) || (null==ipPmgtStoDTO.getPlant()) || ipPmgtStoDTO.getPlant().isEmpty() || ("ALL".equalsIgnoreCase(ipPmgtStoDTO.getPlant()))) {
				query = em.createNamedQuery("StoPmgtDelivery.getStoDeliveryListStores");
				query.setParameter(1, ipPmgtStoDTO.getUserMstId());
				query.setParameter(2, fromDate + Constants.MINDAYTIME);
				query.setParameter(3, toDate + Constants.MAXDAYTIME);
				query.setParameter(4, null);
			}
			else {
				query = em.createNativeQuery("select plant_sapmst_id from plant_sapmst where plant_code = ?1");
				query.setParameter(1, ipPmgtStoDTO.getPlant());
				int plantId = (int) query.getSingleResult();
				
				query = em.createNamedQuery("StoPmgtDelivery.getStoDeliveryListStores");
				query.setParameter(1, ipPmgtStoDTO.getUserMstId());
				query.setParameter(2, fromDate + Constants.MINDAYTIME);
				query.setParameter(3, toDate + Constants.MAXDAYTIME);
				query.setParameter(4, plantId);
			}
			
		} else if (ipPmgtStoDTO.getRoleCode().equals(Constants.PMGTCOORDCODE)) {
			if("".equalsIgnoreCase(ipPmgtStoDTO.getPlant()) || (null==ipPmgtStoDTO.getPlant()) || ipPmgtStoDTO.getPlant().isEmpty() || ("ALL".equalsIgnoreCase(ipPmgtStoDTO.getPlant()))) {
				query = em.createNamedQuery("StoPmgtDelivery.getStoDeliveryListPmgtCoord");
				query.setParameter(1, ipPmgtStoDTO.getUserMstId());
				query.setParameter(2, fromDate + Constants.MINDAYTIME);
				query.setParameter(3, toDate + Constants.MAXDAYTIME);
				query.setParameter(4, null);
			}
			else {
				query = em.createNativeQuery("select plant_sapmst_id from plant_sapmst where plant_code = ?1");
				query.setParameter(1, ipPmgtStoDTO.getPlant());
				int plantId = (int) query.getSingleResult();
				
				query = em.createNamedQuery("StoPmgtDelivery.getStoDeliveryListStores");
				query.setParameter(1, ipPmgtStoDTO.getUserMstId());
				query.setParameter(2, fromDate + Constants.MINDAYTIME);
				query.setParameter(3, toDate + Constants.MAXDAYTIME);
				query.setParameter(4, plantId);
			}
			
			
		} else {
			query = em.createNamedQuery("StoPmgtDelivery.findAll");
		}

		List<StoPmgtDelivery> delList = (List<StoPmgtDelivery>) query.getResultList();

		return delList;
	}

	@Override
	public StoPmgtDelivery saveDeliveryPmgtSto(StoPmgtDelivery delivery) {
		// TODO Auto-generated method stub

		delivery.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		String dispatchDate = DateUtil.convertDateToSqlDate(delivery.getDispatchDate());
		//String addate = DateUtil.convertDateToSqlDate(delivery.getAddate());
		String eddate = DateUtil.convertDateToSqlDate(delivery.getEddate());
		delivery.setDispatchDate(dispatchDate);
		//delivery.setAddate(addate);
		delivery.setEddate(eddate);

		StoPmgtDelivery deliveryNew = em.merge(delivery);

		if (delivery.getStoPmgtDeliveryId() == null) {
			em.refresh(deliveryNew);
		}
		return deliveryNew;
	}

	@Override
	public StoPmgtDeliveryTracker saveDeliveryStatusTrackerPmgtSto(StoPmgtDeliveryTracker deliveryStatusTracker) {
		// TODO Auto-generated method stub

		deliveryStatusTracker.setStatusReqDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));

		StoPmgtDeliveryTracker deliveryStatusTrackerNew = em.merge(deliveryStatusTracker);
		if (deliveryStatusTracker.getStoPmgtDeliveryTrackerId() == null) {
			em.refresh(deliveryStatusTrackerNew);
		}
		return deliveryStatusTrackerNew;

	}

	@Override
	public StoPmgtPodTracker savePodStatusTrackerPmgtSto(StoPmgtPodTracker podStatusTracker) {
		// TODO Auto-generated method stub
		podStatusTracker.setStatusReqDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));

		StoPmgtPodTracker podStatusTrackerNew = em.merge(podStatusTracker);
		if (podStatusTracker.getStoPmgtPodTrackerId() == null) {
			em.refresh(podStatusTrackerNew);
		}
		return podStatusTrackerNew;
	}

	@Override
	public PmgtStoPodUploadDetail savePmgtStoUpPodFile(PmgtStoPodUploadDetail podUploadDetails) {
		// TODO Auto-generated method stub
		return em.merge(podUploadDetails);
	}

	@Override
	public void updatePmgtStoPodStatusByDelId(Integer stoPmgtDeliveryId) {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			if (stoPmgtDeliveryId != null) {
				query = em.createNamedQuery("StoPmgtDelivery.updatePmgtStoPodStatusByDelId");
				query.setParameter(1, Constants.PODUPLOADEDSTATUSID);
				query.setParameter(2, stoPmgtDeliveryId);
			}
			query.executeUpdate();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public PmgtStoPodUploadDetail getUpPodFileDetPmgtSto(Integer stoPmgtDeliveryId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("PmgtStoPodUploadDetail.getPodByStoPmgtDeliveryId");
			query.setParameter(1, stoPmgtDeliveryId);
			PmgtStoPodUploadDetail pmgtStoPodUploadDetail = (PmgtStoPodUploadDetail) query.getSingleResult();
			return pmgtStoPodUploadDetail;
		} catch(Exception e) {
			return new PmgtStoPodUploadDetail();
		}finally {
			em.close();
		}
		
	}

	@Override
	public void updateSparesSO(SparesSoDTO ipsparesSoDTO) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("SoOrders.updateSparesSo");
			query.setParameter(1, ipsparesSoDTO.getSparesSoNumber());
			query.setParameter(2, ipsparesSoDTO.getComments());
			query.setParameter(3, ipsparesSoDTO.getSoNumber());
			query.executeUpdate();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public StoPmgt getStoPmgtByStoPmgtId(Integer stoPmgtId) {
		// TODO Auto-generated method stub
		try {
            
//			query = em.createQuery("Select c.pmId,c.financeId,p.salesCoordId,um.userMstId as amId,c.childContractId,c.contractId,c.conStartDate,c.conEndDate,p.proposalId,p.proposalGenId,c.sapContractNum,c.finRemarks from ChildContract c inner join Contract con on c.contractId = con.contractId inner join Proposal p on con.proposalId = p.proposalId inner join UserMst um on p.smownerId = um.smOwnerId where c.childContractId =?1 ");
			query = em.createQuery("Select sp.stoPmgtId ,sp.pmgtCoordId, sp.reqById,sp.stoPmgtGenId,sp.stoReqTime,sp.storeUserId,sp.storesUpdateTime,sp.supplyPlantId,sp.stoPmSubmit,sp.stoStoresSubmit,sp.createdDate,sp.financeId,sp.statusMstId from StoPmgt sp where sp.stoPmgtId = ?1 ");
			query.setParameter(1, stoPmgtId);
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			StoPmgt stoPmgt=null;
			for (Object[] objects : resultList) {
				stoPmgt = new StoPmgt();
				
				stoPmgt.setStoPmgtId(Integer.parseInt((String) objects[0]));
				stoPmgt.setPmgtCoordId(Integer.parseInt((String) objects[1]));
				stoPmgt.setReqById(Integer.parseInt((String) objects[2]));
				stoPmgt.setStoPmgtGenId((String) objects[3]);
				stoPmgt.setStoReqTime((String) objects[4]);
				stoPmgt.setStoreUserId(Integer.parseInt((String) objects[5]));
				stoPmgt.setStoresUpdateTime((String) objects[6]);
				stoPmgt.setSupplyPlantId(Integer.parseInt((String) objects[7]));
				stoPmgt.setStoPmSubmit((String) objects[8]);
				stoPmgt.setStoStoresSubmit((String) objects[9]);
				stoPmgt.setCreatedDate((String) objects[10]);
				stoPmgt.setFinanceId(Integer.parseInt((String) objects[11]));
				stoPmgt.setStatusMstId(Integer.parseInt((String) objects[12]));
				
				/*commonMailDTO.setProgramMgrId(Integer.parseInt((String) objects[0]));
				commonMailDTO.setFinanceId(Integer.parseInt((String) objects[1]));
				commonMailDTO.setSalesCoordId((Integer) objects[2]);
				commonMailDTO.setAccountMgrId((Integer) objects[3]);
				commonMailDTO.setChildContractId((Integer) objects[4]);
				commonMailDTO.setContractId((Integer) objects[5]);
				commonMailDTO.setConStartDate((String) objects[6]);
				commonMailDTO.setConEndDate((String) objects[7]);
				commonMailDTO.setProposalId((Integer) objects[8]);
				commonMailDTO.setProposalGenId((String) objects[9]);
				commonMailDTO.setSapContractNum((String) objects[10]);
				commonMailDTO.setFinRemarks((String) objects[11]);*/	
				
				
			}
			if(stoPmgt != null) {
			return stoPmgt;
			}else {
				return stoPmgt = new StoPmgt();
			}
						
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new StoPmgt(); 
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PlantSapmst> getReceivingPlantListByCompanyCode(PmgtStoDTO ipPmgtStoDTO) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("PlantSapmst.getReceivingPlantListByCompanyCode");
			//query.setParameter(1, ipPmgtStoDTO.getPlantCode());
			query.setParameter(1, ipPmgtStoDTO.getCompanyCode());
			return (List<PlantSapmst>) query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StorageSapmst> getStorageListByReceivingPlant(PmgtStoDTO ipPmgtStoDTO) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("StorageSapmst.getStorageListByReceivingPlant");
			query.setParameter(1, ipPmgtStoDTO.getPlantCode());
			return (List<StorageSapmst>) query.getResultList();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public List<StoPmgtDelivery> getStoDelListByDateAndDelStatusCode(AllDeliveryListDTO allDeliveryListDTO) {
		try {
			String fromDate = DateUtil.convertDateToSqlDate(allDeliveryListDTO.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(allDeliveryListDTO.getToDate());

			query = em.createNamedQuery("StoPmgtDelivery.getStoDelListByDateAndDelStatusCode");

			query.setParameter(1, fromDate + Constants.MINDAYTIME);
			query.setParameter(2, toDate + Constants.MAXDAYTIME);
			if("All".equalsIgnoreCase(allDeliveryListDTO.getDelStatusCode())) {
				List<String> status = Arrays.asList("ITR","NA","DLV","WDA");
				query.setParameter("status", status);
			}else {
				query.setParameter("status", allDeliveryListDTO.getDelStatusCode());
			}
			@SuppressWarnings("unchecked")
			List<StoPmgtDelivery> stoPmgtDeliveryList = (List<StoPmgtDelivery>) query.getResultList();

			return stoPmgtDeliveryList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<StoPmgtDelivery>();
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public StoPmgt getPmgtStoByReqId(PmgtStoDTO ipPmgtStoDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("StoPmgt.getPmgtStoByReqId");
			query.setParameter(1, ipPmgtStoDTO.getStoPmgtGenId());
			List<StoPmgt> stoPmgtList = (List<StoPmgt>) query.getResultList();
			return stoPmgtList!=null && stoPmgtList.size()>0?stoPmgtList.get(0):new StoPmgt();
		} catch (Exception e) {
			return new StoPmgt();
		} finally {
			em.close();
		}
	}

	@Override
	public List<StoPmgtDelivery> stoPmgtDelBydeliveryNum(PmgtStoDTO ipPmgtStoDTO) {
		try {
			query = em.createNamedQuery("StoPmgtDelivery.stoPmgtDelBydeliveryNum");
			query.setParameter(1, ipPmgtStoDTO.getDeliveryNum());
			
			@SuppressWarnings("unchecked")
			List<StoPmgtDelivery> stoPmgtDelList = (List<StoPmgtDelivery>) query.getResultList();

			return stoPmgtDelList!=null && stoPmgtDelList.size()>0?stoPmgtDelList:new ArrayList<StoPmgtDelivery>();
		} catch (Exception e) {
			return new ArrayList<StoPmgtDelivery>();
		} finally {
			em.close();
		}
	}

}
