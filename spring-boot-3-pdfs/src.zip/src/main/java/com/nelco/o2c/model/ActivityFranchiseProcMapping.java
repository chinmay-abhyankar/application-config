package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the activity_franchise_proc_mapping database table.
 * 
 */
@Entity
@Table(name="activity_franchise_proc_mapping")
@NamedQueries({@NamedQuery(name="ActivityFranchiseProcMapping.findAll", query="SELECT a FROM ActivityFranchiseProcMapping a"),
	@NamedQuery(name="ActivityFranchiseProcMapping.findFranchiseDropDown", query="SELECT atm FROM ActivityFranchiseProcMapping a inner join a.activityTypeMst atm where a.franchiseProcTypeMstId = 2 and atm.isActive = 'Y'")})
public class ActivityFranchiseProcMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="activity_franchise_proc_mapping_id")
	private Integer activityFranchiseProcMappingId;

	@Column(name="activity_type_mst_id")
	private Integer activityTypeMstId;

	@Column(name="franchise_proc_type_mst_id")
	private Integer franchiseProcTypeMstId;
	
	@ManyToOne
	@JoinColumn(name = "activity_type_mst_id", referencedColumnName = "activity_type_mst_id", insertable = false, updatable = false)
	private ActivityTypeMst activityTypeMst;

	public ActivityTypeMst getActivityTypeMst() {
		return activityTypeMst;
	}

	public void setActivityTypeMst(ActivityTypeMst activityTypeMst) {
		this.activityTypeMst = activityTypeMst;
	}

	public ActivityFranchiseProcMapping() {
	}

	public Integer getActivityFranchiseProcMappingId() {
		return activityFranchiseProcMappingId;
	}

	public void setActivityFranchiseProcMappingId(Integer activityFranchiseProcMappingId) {
		this.activityFranchiseProcMappingId = activityFranchiseProcMappingId;
	}

	public Integer getActivityTypeMstId() {
		return activityTypeMstId;
	}

	public void setActivityTypeMstId(Integer activityTypeMstId) {
		this.activityTypeMstId = activityTypeMstId;
	}

	public Integer getFranchiseProcTypeMstId() {
		return franchiseProcTypeMstId;
	}

	public void setFranchiseProcTypeMstId(Integer franchiseProcTypeMstId) {
		this.franchiseProcTypeMstId = franchiseProcTypeMstId;
	}

	

}