package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the drf_query_user_map database table.
 * 
 */
@Entity
@Table(name="drf_query_user_map")
@NamedQuery(name="DrfQueryUserMap.findAll", query="SELECT d FROM DrfQueryUserMap d")
public class DrfQueryUserMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="drf_query_user_map_id")
	private Integer drfQueryUserMapId;

	@Column(name="is_active")
	private String isActive;

	@Column(name="query_id")
	private Integer queryId;

	@Column(name="query_user_id")
	private Integer queryUserId;

	public DrfQueryUserMap() {
	}

	public Integer getDrfQueryUserMapId() {
		return drfQueryUserMapId;
	}

	public void setDrfQueryUserMapId(Integer drfQueryUserMapId) {
		this.drfQueryUserMapId = drfQueryUserMapId;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public Integer getQueryId() {
		return queryId;
	}

	public void setQueryId(Integer queryId) {
		this.queryId = queryId;
	}

	public Integer getQueryUserId() {
		return queryUserId;
	}

	public void setQueryUserId(Integer queryUserId) {
		this.queryUserId = queryUserId;
	}

	

}