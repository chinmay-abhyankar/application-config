/**
 * 
 */
package com.nelco.o2c.dao;

import java.text.ParseException;
import java.util.List;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.DrfExtListDTO;
import com.nelco.o2c.dto.ExtendDemoDTO;
import com.nelco.o2c.jsonbeanmap.DrfApprDetailBean;
import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.DrfApproverDetail;
import com.nelco.o2c.model.DrfExtComment;
import com.nelco.o2c.model.DrfStatusTracker;

/**
 * @author Jayashankar.r
 *
 */
public interface DrfApprovalDao {

	public void saveDrfApprovals(List<DrfApproverDetail> drfApproverDetails);

	public DrfApproverDetail saveSingleDrfApprovals(DrfApproverDetail drfApproverDetail);

	public DrfApproverDetail getDrfApprovals(CommonDTO commonDTO);

	public boolean checkAllApproved(DrfApproverDetail drfApproverDetail);
	
	public boolean checkDrfRejectStatus(DrfApproverDetail drfApproverDetail);

	public void insertStatusTracker(DrfStatusTracker drfStatusTracker);

	public DrfApprDetailBean getDrfPeopleDetails(CommonDTO commonDTO);

	public UserEmailDetailsBean getUserEmailDetails(UserEmailDetailsBean bean);
	
	public UserEmailDetailsBean getUserEmailDetailsByOpportunity(UserEmailDetailsBean bean);

	public DrfExtComment saveDrfExtComment(DrfExtComment drfExtComment);

	public DrfExtComment getDrfCommentByDrfAndUserId(Integer userMstId, Integer drfDetailsId);
	
	public void updateVpsInDrf(Integer userMstId,Integer drfDetailsId);
	
	public void updateEboSalesHeadInDrf(Integer userMstId,Integer drfDetailsId);
	
	public void updateMdInDrf(Integer userMstId,Integer drfDetailsId);

	public List<DrfExtComment> getExtensionComments(ExtendDemoDTO extendDemoInputDTO);
	
	public void updateDrfStatus(Integer drfDetailsId, Integer statusMstId);

	public void updateDrfDemoDates(Integer drfDetailsId) throws ParseException;

	public void updateDrfApprovalFlag(Integer drfDetailsId, String flag);

	public List<Object[]> getDrfExtensionList(DrfExtListDTO drfExtListInputDTO);

}
