package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="report_mst")
public class ReportMst implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "report_id")
	private Integer reportMstId;
	
	
	@Column(name="reportCode")
	private String reportCode;
	
	@Column(name="report_name")
	private String reportName;
	
	@Column(name="report_file_name")
	private String reportFileName;
	
	@Column(name="is_active")
	private String isActive;

	public ReportMst() {}
	
	
	public ReportMst(String reportCode, String reportName, String reportFileName, String isActive) {
		this.reportCode = reportCode;
		this.reportName = reportName;
		this.reportFileName = reportFileName;
		this.isActive = isActive;
	}


	public Integer getReportMstId() {
		return reportMstId;
	}


	public void setReportMstId(Integer reportMstId) {
		this.reportMstId = reportMstId;
	}


	public String getReportCode() {
		return reportCode;
	}


	public void setReportCode(String reportCode) {
		this.reportCode = reportCode;
	}


	public String getReportName() {
		return reportName;
	}


	public void setReportName(String reportName) {
		this.reportName = reportName;
	}


	public String getReportFileName() {
		return reportFileName;
	}


	public void setReportFileName(String reportFileName) {
		this.reportFileName = reportFileName;
	}


	public String getIsActive() {
		return isActive;
	}


	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}


	@Override
	public String toString() {
		return "ReportMst [reportMstId=" + reportMstId + ", reportCode=" + reportCode + ", reportName=" + reportName
				+ ", reportFileName=" + reportFileName + ", isActive=" + isActive + "]";
	}
	
	
	
	
	
}
