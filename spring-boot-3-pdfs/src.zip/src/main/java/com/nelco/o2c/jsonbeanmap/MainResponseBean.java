/**
 * 
 */
package com.nelco.o2c.jsonbeanmap;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Jayashankar.r
 *
 */
public class MainResponseBean {

	@JsonProperty("response")
	private ResponseBean responseBean;

	public ResponseBean getResponseBean() {
		return responseBean;
	}

	public void setResponseBean(ResponseBean responseBean) {
		this.responseBean = responseBean;
	}
	
	
}
