package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.model.MaterialChildContract;

/**
 * @author Amol.lR
 *
 */
public class BrfDetailsDTO implements Serializable {
	private static final long serialVersionUID = 92L;

	private String marketSegment;
	private String conEndDate;
	private String conStartDate;
	private String quarter;
	private String sapContractNum;
	private Integer brfId;
	private Integer accoMgr;
	private String accoMgrName;
	private String bandwidth;
	private String brfPlan;
	private String bwAllocation;
	private String contractNum;
	private String createdDate;
	private String existingSite;
	private String product;
	private String oldSoNum;
	private String poNum;
	private Integer progMgr;
	private String siteName;
	private String soldToParty;
	private Integer statusMstId;
	private String technology;
	private String tentActDate;
	private Integer childContractId;
	private Integer financeId;
	private Integer nocMgrId;
	private String customerName;
	private String statusName;
	private String statusCode;
	private String financeRemark;
	private String nocRemark;
	private String salesOrg;
	private String distChannel;
	private String division;
	private Integer regulatoryId;
	private String item;
	private String billingEndDate;
	private String modifiedDate;
	private Integer soOrdersId;
	private String materialNum;
	private Integer numOfBrf;
	private String materialDesc;
	private Integer orderQty;
	private List<MaterialChildContract> materialChildContractList = new ArrayList<MaterialChildContract>();
	private Integer brfNumOfSiteCreated;
	private String pmRemark;
	private Integer hubMstId;
	private String hubDesc;
	private String updatedDate;
	private String demoStart;
	private String demoEnd;
	private Integer drfDetailsId;
	private String soNumber;
	
	public List<MaterialChildContract> getMaterialChildContractList() {
		return materialChildContractList;
	}
	public void setMaterialChildContractList(List<MaterialChildContract> materialChildContractList) {
		this.materialChildContractList = materialChildContractList;
	}
	public String getPmRemark() {
		return pmRemark;
	}
	public void setPmRemark(String pmRemark) {
		this.pmRemark = pmRemark;
	}
	public Integer getBrfNumOfSiteCreated() {
		return brfNumOfSiteCreated;
	}
	public void setBrfNumOfSiteCreated(Integer brfNumOfSiteCreated) {
		this.brfNumOfSiteCreated = brfNumOfSiteCreated;
	}
	private CustomerSapmst customerSapmst = new CustomerSapmst();
	
	
	public CustomerSapmst getCustomerSapmst() {
		return customerSapmst;
	}
	public void setCustomerSapmst(CustomerSapmst customerSapmst) {
		this.customerSapmst = customerSapmst;
	}
	public String getAccoMgrName() {
		return accoMgrName;
	}
	public void setAccoMgrName(String accoMgrName) {
		this.accoMgrName = accoMgrName;
	}
	public String getMaterialDesc() {
		return materialDesc;
	}
	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}
	public Integer getOrderQty() {
		return orderQty;
	}
	public void setOrderQty(Integer orderQty) {
		this.orderQty = orderQty;
	}
	public Integer getNumOfBrf() {
		return numOfBrf;
	}
	public void setNumOfBrf(Integer numOfBrf) {
		this.numOfBrf = numOfBrf;
	}
	public String getMarketSegment() {
		return marketSegment;
	}
	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}
	public String getConEndDate() {
		return conEndDate;
	}
	public void setConEndDate(String conEndDate) {
		this.conEndDate = conEndDate;
	}
	public String getConStartDate() {
		return conStartDate;
	}
	public void setConStartDate(String conStartDate) {
		this.conStartDate = conStartDate;
	}
	public String getQuarter() {
		return quarter;
	}
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}
	public String getSapContractNum() {
		return sapContractNum;
	}
	public void setSapContractNum(String sapContractNum) {
		this.sapContractNum = sapContractNum;
	}
	public Integer getBrfId() {
		return brfId;
	}
	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}
	public Integer getAccoMgr() {
		return accoMgr;
	}
	public void setAccoMgr(Integer accoMgr) {
		this.accoMgr = accoMgr;
	}
	public String getBandwidth() {
		return bandwidth;
	}
	public void setBandwidth(String bandwidth) {
		this.bandwidth = bandwidth;
	}
	public String getBrfPlan() {
		return brfPlan;
	}
	public void setBrfPlan(String brfPlan) {
		this.brfPlan = brfPlan;
	}
	public String getBwAllocation() {
		return bwAllocation;
	}
	public void setBwAllocation(String bwAllocation) {
		this.bwAllocation = bwAllocation;
	}
	public String getContractNum() {
		return contractNum;
	}
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getExistingSite() {
		return existingSite;
	}
	public void setExistingSite(String existingSite) {
		this.existingSite = existingSite;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getOldSoNum() {
		return oldSoNum;
	}
	public void setOldSoNum(String oldSoNum) {
		this.oldSoNum = oldSoNum;
	}
	public String getPoNum() {
		return poNum;
	}
	public void setPoNum(String poNum) {
		this.poNum = poNum;
	}
	public Integer getProgMgr() {
		return progMgr;
	}
	public void setProgMgr(Integer progMgr) {
		this.progMgr = progMgr;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getSoldToParty() {
		return soldToParty;
	}
	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}
	public Integer getStatusMstId() {
		return statusMstId;
	}
	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getTentActDate() {
		return tentActDate;
	}
	public void setTentActDate(String tentActDate) {
		this.tentActDate = tentActDate;
	}
	public Integer getChildContractId() {
		return childContractId;
	}
	public void setChildContractId(Integer childContractId) {
		this.childContractId = childContractId;
	}
	public Integer getFinanceId() {
		return financeId;
	}
	public void setFinanceId(Integer financeId) {
		this.financeId = financeId;
	}
	public Integer getNocMgrId() {
		return nocMgrId;
	}
	public void setNocMgrId(Integer nocMgrId) {
		this.nocMgrId = nocMgrId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getFinanceRemark() {
		return financeRemark;
	}
	public void setFinanceRemark(String financeRemark) {
		this.financeRemark = financeRemark;
	}
	public String getNocRemark() {
		return nocRemark;
	}
	public void setNocRemark(String nocRemark) {
		this.nocRemark = nocRemark;
	}
	public String getSalesOrg() {
		return salesOrg;
	}
	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}
	public String getDistChannel() {
		return distChannel;
	}
	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public Integer getRegulatoryId() {
		return regulatoryId;
	}
	public void setRegulatoryId(Integer regulatoryId) {
		this.regulatoryId = regulatoryId;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public String getBillingEndDate() {
		return billingEndDate;
	}
	public void setBillingEndDate(String billingEndDate) {
		this.billingEndDate = billingEndDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Integer getSoOrdersId() {
		return soOrdersId;
	}
	public void setSoOrdersId(Integer soOrdersId) {
		this.soOrdersId = soOrdersId;
	}
	public String getMaterialNum() {
		return materialNum;
	}
	public void setMaterialNum(String materialNum) {
		this.materialNum = materialNum;
	}
	public Integer getHubMstId() {
		return hubMstId;
	}
	public void setHubMstId(Integer hubMstId) {
		this.hubMstId = hubMstId;
	}
	public String getHubDesc() {
		return hubDesc;
	}
	public void setHubDesc(String hubDesc) {
		this.hubDesc = hubDesc;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getDemoStart() {
		return demoStart;
	}
	public void setDemoStart(String demoStart) {
		this.demoStart = demoStart;
	}
	public String getDemoEnd() {
		return demoEnd;
	}
	public void setDemoEnd(String demoEnd) {
		this.demoEnd = demoEnd;
	}
	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}
	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}
	public String getSoNumber() {
		return soNumber;
	}
	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}
	
}
