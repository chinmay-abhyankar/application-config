/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.RelocationSo;
import com.nelco.o2c.model.RelocationTypeMst;
import com.nelco.o2c.model.SiteTypeMst;

/**
 * @author Jayshankar.r
 *
 */
public class RelocSoDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Integer userMstId;
	private String roleCode;
	private String fromDate;
	private String toDate;
	private RelocationSo relocationSo;
	private Integer relocationSoId;
	private List<RelocationSo> rolocationSoList;
	private List<RelocationTypeMst> relocTypeList;
	private Boolean isSaved = false;
	private List<OppUploadDetail> oppUploadDetails = new ArrayList<OppUploadDetail>();
	private List<FileTypeMst> fileList;
	private String isSubmit;
	private List<SiteTypeMst> siteTypeList;
	
	
	public List<SiteTypeMst> getSiteTypeList() {
		return siteTypeList;
	}
	public void setSiteTypeList(List<SiteTypeMst> siteTypeList) {
		this.siteTypeList = siteTypeList;
	}
	public String getIsSubmit() {
		return isSubmit;
	}
	public void setIsSubmit(String isSubmit) {
		this.isSubmit = isSubmit;
	}
	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}
	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}
	public List<FileTypeMst> getFileList() {
		return fileList;
	}
	public void setFileList(List<FileTypeMst> fileList) {
		this.fileList = fileList;
	}
	public Boolean getIsSaved() {
		return isSaved;
	}
	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}
	public List<RelocationTypeMst> getRelocTypeList() {
		return relocTypeList;
	}
	public void setRelocTypeList(List<RelocationTypeMst> relocTypeList) {
		this.relocTypeList = relocTypeList;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public RelocationSo getRelocationSo() {
		return relocationSo;
	}
	public void setRelocationSo(RelocationSo relocationSo) {
		this.relocationSo = relocationSo;
	}
	public Integer getRelocationSoId() {
		return relocationSoId;
	}
	public void setRelocationSoId(Integer relocationSoId) {
		this.relocationSoId = relocationSoId;
	}
	public List<RelocationSo> getRolocationSoList() {
		return rolocationSoList;
	}
	public void setRolocationSoList(List<RelocationSo> rolocationSoList) {
		this.rolocationSoList = rolocationSoList;
	}
	
	
}
