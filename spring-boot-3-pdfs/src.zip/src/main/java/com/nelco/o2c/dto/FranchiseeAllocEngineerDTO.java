package com.nelco.o2c.dto;

public class FranchiseeAllocEngineerDTO {
	private Integer id;
	private Integer franchisee_alloc_id;
	private Integer franchisee_id;
	private String name;
	private String mobile_no;
	private String email_id;
	private String engVisitDate;
	private String engVisitTiming;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}	

	public Integer getFranchisee_alloc_id() {
		return franchisee_alloc_id;
	}

	public void setFranchisee_alloc_id(Integer franchisee_alloc_id) {
		this.franchisee_alloc_id = franchisee_alloc_id;
	}

	public Integer getFranchisee_id() {
		return franchisee_id;
	}

	public void setFranchisee_id(Integer franchisee_id) {
		this.franchisee_id = franchisee_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getEngVisitDate() {
		return engVisitDate;
	}

	public void setEngVisitDate(String engVisitDate) {
		this.engVisitDate = engVisitDate;
	}

	public String getEngVisitTiming() {
		return engVisitTiming;
	}

	public void setEngVisitTiming(String engVisitTiming) {
		this.engVisitTiming = engVisitTiming;
	}

}
