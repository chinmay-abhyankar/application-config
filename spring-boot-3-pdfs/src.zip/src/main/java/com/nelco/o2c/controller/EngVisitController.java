/**
 * 
 */
package com.nelco.o2c.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dao.CallSpDao;
import com.nelco.o2c.dto.HubSignOffDTO;
import com.nelco.o2c.dto.PaymentRequestDTO;
import com.nelco.o2c.dto.VisitCommonDTO;
import com.nelco.o2c.service.EngVisitService;

import net.sf.jasperreports.engine.JRException;

/**
 * @author Jayashankar.r
 *
 */
@RestController
public class EngVisitController {
	
	@Autowired
	EngVisitService engVisitService;
	
	@Autowired
	CallSpDao callSpDao;

	@RequestMapping(value = "/getVisitDetails.do", method = RequestMethod.POST)
	public VisitCommonDTO getVisitDetails(@RequestBody VisitCommonDTO visitCommonDTOInput) {
		return engVisitService.getVisitDetails(visitCommonDTOInput);
	}
	
	@RequestMapping(value = "/getVisitListBySurveyMstId.do", method = RequestMethod.POST)
	public VisitCommonDTO getVisitListBySurveyMstId(@RequestBody VisitCommonDTO visitCommonDTOInput) {
		return engVisitService.getVisitListBySurveyMstId(visitCommonDTOInput);
	}
	
	@RequestMapping(value = "/getVisitDetailsDropDowns.do", method = RequestMethod.POST)
	public VisitCommonDTO getVisitDetailsDropDowns(@RequestBody VisitCommonDTO visitCommonDTOInput) {
		return engVisitService.getVisitDetailsDropDowns(visitCommonDTOInput);
	}
	
	@RequestMapping(value = "/saveVisitDetails.do", method = RequestMethod.POST)
	public VisitCommonDTO saveVisitDetails(@RequestBody VisitCommonDTO visitCommonDTOInput) {
		return engVisitService.saveVisitDetails(visitCommonDTOInput);
	}
	
	@RequestMapping(value = "/submitVisitDetails.do", method = RequestMethod.POST)
	public VisitCommonDTO submitVisitDetails(@RequestBody VisitCommonDTO visitCommonDTOInput) throws JRException, IOException, SQLException, NamingException {
		VisitCommonDTO visitCommonDTO = engVisitService.submitVisitDetails(visitCommonDTOInput);
		Boolean isMailSent = true;
	    try {
	        VisitCommonDTO visitCommonAfterJasperDTO = this.engVisitService.generateJasperReport(visitCommonDTO);
	        this.engVisitService.sendAttachmentMail(visitCommonDTO.getEmailBean());
	        isMailSent = false;
	      } catch (Exception e) {
	    	  isMailSent = true;
	        e.printStackTrace();
	      }
	    
	    if(isMailSent) {
	      try
	      {
	        this.engVisitService.sendAttachmentMail(visitCommonDTO.getEmailBean());
	      } catch (Exception e) {
	        e.printStackTrace();
	      }
	    }
		return visitCommonDTO;
	}
	
	@RequestMapping(value = "/getCostList.do", method = RequestMethod.POST)
	public VisitCommonDTO getCostList(@RequestBody VisitCommonDTO visitCommonDTOInput) {
		return engVisitService.getCostList(visitCommonDTOInput);
	}
	
	@RequestMapping(value = "/saveCost.do", method = RequestMethod.POST)
	public VisitCommonDTO saveCost(@RequestBody VisitCommonDTO visitCommonDTOInput) {
		return engVisitService.saveCost(visitCommonDTOInput);
	}
	
	@RequestMapping(value = "/apprRejRequest.do", method = RequestMethod.POST)
	public VisitCommonDTO apprRejRequest(@RequestBody VisitCommonDTO visitCommonDTOInput) {
		return engVisitService.apprRejRequest(visitCommonDTOInput);
	}	
	
	@RequestMapping(value = "/getUploadDetailsByCostId.do", method = RequestMethod.POST)
	public VisitCommonDTO getUploadDetailsByCostId(@RequestBody VisitCommonDTO visitCommonDTOInput) {
		return engVisitService.getUploadDetailsByCostId(visitCommonDTOInput);
	}
	
	@RequestMapping(value = "/saveCostUploadDetails.do", method = RequestMethod.POST)
	public VisitCommonDTO saveCostUploadDetails(@RequestBody VisitCommonDTO visitCommonDTOInput) {
		return engVisitService.saveCostUploadDetails(visitCommonDTOInput);
	}
	
	@RequestMapping(value = "/apprRejRequestList.do", method = RequestMethod.POST)
	public VisitCommonDTO apprRejRequestList(@RequestBody VisitCommonDTO visitCommonDTOInput) {
		return engVisitService.apprRejRequestList(visitCommonDTOInput);
	}
	
	@RequestMapping(value = "/downloadJaperReport.do", method = {RequestMethod.POST,RequestMethod.GET})
	@CrossOrigin
	public void downloadJaperReport(HttpServletRequest request, HttpServletResponse resp,@RequestParam String siteSurveyIds) throws SQLException, JRException, NamingException, IOException {
		engVisitService.downloadJaperReport(request,resp,siteSurveyIds);
	}
	
	@RequestMapping(value = "/getCostListReadOnly.do", method = RequestMethod.POST)
	public VisitCommonDTO getCostListReadOnly(@RequestBody VisitCommonDTO visitCommonDTOInput) {
		return engVisitService.getCostListReadOnly(visitCommonDTOInput);
	}
	
	@RequestMapping(value = "/raisePaymentRequest.do",method = RequestMethod.POST)
	public PaymentRequestDTO raisePaymentRequest(@RequestBody PaymentRequestDTO paymentRequestDTOInput) {
		
		return engVisitService.raisePaymentRequest(paymentRequestDTOInput);
	}
	
	@RequestMapping(value = "/getPaymentRequests.do",method = RequestMethod.POST)
	public PaymentRequestDTO getPaymentRequests(@RequestBody PaymentRequestDTO paymentRequestDTOInput) {
		
		return engVisitService.getPaymentRequests(paymentRequestDTOInput);
	}
	
	@RequestMapping(value = "/getPaymentRequestDropDowns.do",method = RequestMethod.POST)
	public PaymentRequestDTO getPaymentRequestDropDowns(@RequestBody PaymentRequestDTO paymentRequestDTOInput) {
		
		return engVisitService.getPaymentRequestDropDowns(paymentRequestDTOInput);
	}
	
	@RequestMapping(value = "/getUploadListByFranchiseInvReqId.do",method = RequestMethod.POST)
	public PaymentRequestDTO getUploadListByFranchiseInvReqId(@RequestBody PaymentRequestDTO paymentRequestDTOInput) {
		
		return engVisitService.getUploadListByFranchiseInvReqId(paymentRequestDTOInput);
	}
	
	@RequestMapping(value = "/apprRejIncPayRequest.do",method = RequestMethod.POST)
	public PaymentRequestDTO apprRejIncPayRequest(@RequestBody PaymentRequestDTO paymentRequestDTOInput) {
		
		return engVisitService.apprRejIncPayRequest(paymentRequestDTOInput);
	}
	
	@RequestMapping(value = "/getIncInvoiceList.do",method = RequestMethod.POST)
	public PaymentRequestDTO getIncInvoiceList(@RequestBody PaymentRequestDTO paymentRequestDTOInput) {
		
		return engVisitService.getIncInvoiceList(paymentRequestDTOInput);
	}
	
	
	@RequestMapping(value = "/gethubSignOffList.do",method = RequestMethod.POST)
	public HubSignOffDTO gethubSignOffList(@RequestBody HubSignOffDTO hubSignOffDTOInput) {
		
		return engVisitService.gethubSignOffList(hubSignOffDTOInput);
	}
	
	@RequestMapping(value = "/savehubSignOffList.do",method = RequestMethod.POST)
	public HubSignOffDTO savehubSignOffList(@RequestBody HubSignOffDTO hubSignOffDTOInput) {
		
		return engVisitService.savehubSignOffList(hubSignOffDTOInput);
	}
	
	@RequestMapping(value = "/submithubSignOffList.do",method = RequestMethod.POST)
	public HubSignOffDTO submitHubSignOffList(@RequestBody HubSignOffDTO hubSignOffDTOInput) {
		HubSignOffDTO hubSignOffOutDTO = engVisitService.submitHubSignOffList(hubSignOffDTOInput);
		 //callSpDao.callIspGenerateMaterialConfirmationCsv(hubSignOffOutDTO.getFileName());
		 return hubSignOffOutDTO;
				
	}
	
	@RequestMapping(value = "/downloadFranchiseVisitReport.do", method = {RequestMethod.POST,RequestMethod.GET})
	@CrossOrigin
	public void downloadFranchiseVisitReport(HttpServletRequest request, HttpServletResponse resp,@RequestParam String franchiseIds) throws SQLException, JRException, NamingException, IOException {
		engVisitService.downloadFranchiseVisitReport(request,resp,franchiseIds);
	}
	
	@RequestMapping(value = "/updateOppUploadDetails.do",method = RequestMethod.POST)
	public PaymentRequestDTO updateOppUploadDetails(@RequestBody PaymentRequestDTO paymentRequestDTOInput) {
		
		return engVisitService.updateOppUploadDetails(paymentRequestDTOInput);
	}
	
	@RequestMapping(value = "/downloadHsoExcelReport.do", method = {RequestMethod.POST,RequestMethod.GET})
	@CrossOrigin
	public void downloadHsoExcelReport(HttpServletRequest request, HttpServletResponse resp,@RequestParam String fromDate,@RequestParam String toDate,@RequestParam String userMstId) throws SQLException, JRException, NamingException, IOException {
		engVisitService.downloadHsoExcelReport(request,resp,fromDate,toDate,userMstId);
	}
	
	@RequestMapping(value = "/downloadHSOReportById.do", method = {RequestMethod.POST,RequestMethod.GET})
	@CrossOrigin
	public void downloadHSOReportById(HttpServletRequest request, HttpServletResponse resp,@RequestParam String hsoTransactionId) throws SQLException, JRException, NamingException, IOException {
		engVisitService.downloadHsoReportById(request,resp,hsoTransactionId);
	}
	
	
}
