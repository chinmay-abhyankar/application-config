/**
 * 
 */
package com.nelco.o2c.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.model.UserMst;

/**
 * @author Chinmay A
 *
 */
@Repository 
public interface UserManagementRepository extends JpaRepository<UserMst, Integer> {

}
