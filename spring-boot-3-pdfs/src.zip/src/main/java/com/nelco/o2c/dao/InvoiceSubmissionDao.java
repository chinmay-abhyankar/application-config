package com.nelco.o2c.dao;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.nelco.o2c.dto.InvoiceFeedbackDTO;
import com.nelco.o2c.dto.InvoiceListDTO;
import com.nelco.o2c.dto.InvoiceSubmissionActionsTrackerDTO;
import com.nelco.o2c.dto.InvoiceSubmissionDTO;
import com.nelco.o2c.dto.InvoiceSubmissionFormDTO;
import com.nelco.o2c.dto.InvoiceSubmissionRequestDetailsDTO;
import com.nelco.o2c.dto.OppUploadDetailDTO;
import com.nelco.o2c.model.InvoiceSubmissionFeedbackMst;
import com.nelco.o2c.model.InvoiceSubmissionMst;

public interface InvoiceSubmissionDao {

	List<InvoiceSubmissionDTO> getOutstandingInvoicesList(HttpServletRequest request);

	List<InvoiceSubmissionRequestDetailsDTO> getSubmissionRequestDetailsFromInvoiceNo(String parameter);

	List<InvoiceFeedbackDTO> getFeedbackDetailsFromInvoiceNo(String parameter);

	List<OppUploadDetailDTO> getInvoiceDocumentsDetails(String parameter);

	String getSubmissionDueStatus(String parameter);

	InvoiceSubmissionMst submitInvoiceDetails(InvoiceSubmissionMst tobeSavedRequest);

	InvoiceSubmissionFeedbackMst submitFeedback(InvoiceSubmissionFeedbackMst tobeSavedFeedback);

	InvoiceSubmissionFormDTO getInvoiceSubmissionMasters(InvoiceSubmissionFormDTO invoiceSubmissionFormDTO);

	InvoiceSubmissionMst updateDocumentCheckForInvoiceSubmission(InvoiceSubmissionMst tobeSavedRequest);

	List<InvoiceSubmissionActionsTrackerDTO> getInvoiceSubmissionActionsTracker(String parameter);

	List<InvoiceSubmissionDTO> getOutstandingInvoicesList_Paginated(HttpServletRequest request);

}
