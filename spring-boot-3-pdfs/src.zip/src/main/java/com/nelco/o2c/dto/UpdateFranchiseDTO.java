/**
 * 
 */
package com.nelco.o2c.dto;

/**
 * @author Jayashankar.r
 *
 */
public class UpdateFranchiseDTO {

	private Integer franchiseId;
	private Integer siteSurveyId;
	private Integer franchiseeAllocId;
	
	public Integer getFranchiseeAllocId() {
		return franchiseeAllocId;
	}
	public void setFranchiseeAllocId(Integer franchiseeAllocId) {
		this.franchiseeAllocId = franchiseeAllocId;
	}
	public Integer getFranchiseId() {
		return franchiseId;
	}
	public void setFranchiseId(Integer franchiseId) {
		this.franchiseId = franchiseId;
	}
	public Integer getSiteSurveyId() {
		return siteSurveyId;
	}
	public void setSiteSurveyId(Integer siteSurveyId) {
		this.siteSurveyId = siteSurveyId;
	}
	
	
}
