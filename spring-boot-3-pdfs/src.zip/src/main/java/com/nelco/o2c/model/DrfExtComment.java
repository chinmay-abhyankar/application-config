package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the drf_ext_comments database table.
 * 
 */
@Entity
@Table(name="drf_ext_comments")
@NamedQueries({
	@NamedQuery(name="DrfExtComment.findAll", query="SELECT new DrfExtComment(d.drfExtCommentsId, d.comment, d.drfDetailsId, d.reqDate, " + 
			" d.userMstId, u.userName) FROM DrfExtComment d inner join d.userMst u "),
	@NamedQuery(name="DrfExtComment.getByDrfAndUserMstId", query="SELECT new DrfExtComment(d.drfExtCommentsId, d.comment, d.drfDetailsId, d.reqDate, " + 
					" d.userMstId, u.userName) "
			+ " FROM DrfExtComment d inner join d.userMst u "
			+ " where d.drfDetailsId = :drfDetailsId and d.userMstId = :userMstId order by d.drfExtCommentsId desc "),
	@NamedQuery(name="DrfExtComment.getByDrfId", query="SELECT new DrfExtComment(d.drfExtCommentsId, d.comment, d.drfDetailsId, d.reqDate, " + 
			" d.userMstId, u.userName) "
			+ " FROM DrfExtComment d inner join d.userMst u "
			+ " where d.drfDetailsId = :drfDetailsId order by d.drfExtCommentsId desc ")
})

public class DrfExtComment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="drf_ext_comments_id")
	private Integer drfExtCommentsId;

	private String comment;

	@Column(name="drf_details_id")
	private Integer drfDetailsId;

	@Column(name="req_date")
	private String reqDate;

	@Column(name="user_mst_id")
	private Integer userMstId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_mst_id", referencedColumnName = "user_mst_id", insertable = false, updatable = false)
	private UserMst userMst;
	
	@Transient
	private String userName;
	
	public DrfExtComment() {
	}

	
	
	

	public DrfExtComment(Integer drfExtCommentsId, String comment, Integer drfDetailsId, String reqDate,
			Integer userMstId, String userName) {
		super();
		this.drfExtCommentsId = drfExtCommentsId;
		this.comment = comment;
		this.drfDetailsId = drfDetailsId;
		this.reqDate = reqDate;
		this.userMstId = userMstId;
		this.userName = userName;
	}





	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public UserMst getUserMst() {
		return userMst;
	}

	public void setUserMst(UserMst userMst) {
		this.userMst = userMst;
	}

	
	public Integer getDrfExtCommentsId() {
		return drfExtCommentsId;
	}

	public void setDrfExtCommentsId(Integer drfExtCommentsId) {
		this.drfExtCommentsId = drfExtCommentsId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}

	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}

	public String getReqDate() {
		return reqDate;
	}

	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}

	public Integer getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

	

}