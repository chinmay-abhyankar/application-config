package com.nelco.o2c.dto;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class CustomerInfoDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8627788779251786669L;
	private String customerNo="";
	private String customerName="";
	private String customerCity="";
	private String customerRegion="";
	private String customerCountry="";
	private String customerSalesOrg="";
	
	public CustomerInfoDTO(){
		
	}
	public CustomerInfoDTO(String customerNo,String customerName,String customerCity,String customerRegion,String customerCountry,String customerSalesOrg){
		this.customerNo=customerNo;
		this.customerName=customerName;
		this.customerCity=customerCity;
		this.customerRegion=customerRegion;
		this.customerCountry=customerCountry;
		this.customerSalesOrg=customerSalesOrg;
	}
	
	public String getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerCity() {
		return customerCity;
	}
	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}
	public String getCustomerRegion() {
		return customerRegion;
	}
	public void setCustomerRegion(String customerRegion) {
		this.customerRegion = customerRegion;
	}
	public String getCustomerCountry() {
		return customerCountry;
	}
	public void setCustomerCountry(String customerCountry) {
		this.customerCountry = customerCountry;
	}
	public String getCustomerSalesOrg() {
		return customerSalesOrg;
	}
	public void setCustomerSalesOrg(String customerSalesOrg) {
		this.customerSalesOrg = customerSalesOrg;
	}
	
}
