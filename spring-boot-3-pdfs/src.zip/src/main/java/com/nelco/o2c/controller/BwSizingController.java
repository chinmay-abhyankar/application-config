/**
 * 
 */
package com.nelco.o2c.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.BwSizingDTO;
import com.nelco.o2c.dto.CustomerInputDTO;
import com.nelco.o2c.dto.SapResponseDTO;
import com.nelco.o2c.service.BwSizingService;

/**
 * @author Jayashankar.r
 *
 */
@RestController
public class BwSizingController {

	@Autowired
	BwSizingService bwSizingService;

	@GetMapping("/searchCustomer.do")
	public BwSizingDTO searchCustomerMaster(@RequestParam String custSearchStr) {

		return bwSizingService.getCustomerDetails(custSearchStr);
	}

	@PostMapping("/getBwSizingDetails.do")
	public BwSizingDTO getBwSizingDetails(@RequestBody BwSizingDTO bwSizingDTO) {
		return bwSizingService.getBwSizingDetails(bwSizingDTO);
	}
	
	@PostMapping("/saveBwSizingDetails.do")
	public BwSizingDTO saveBwSizingDetails(@RequestBody BwSizingDTO bwSizingDTO) {
		return bwSizingService.saveBwSizingDetails(bwSizingDTO);
	}
	
	@PostMapping("/submitBandwidthSizing.do")
	public BwSizingDTO submitBandwidthSizing(@RequestBody BwSizingDTO bwSizingDTO) {
		return bwSizingService.submitBandwidthSizing(bwSizingDTO);
	}
	
	@PostMapping("/addCustomerMaster.do")
	public SapResponseDTO addCustomerMaster(@RequestBody CustomerInputDTO input) {
		return bwSizingService.saveCustomer(input);
	}
	
	@PostMapping("/getErrorLogs.do")
	public BwSizingDTO getErrorLogs(@RequestBody BwSizingDTO input) {
		return bwSizingService.getErrorLogs(input);
	}

}
