package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the activity_type_mst database table.
 * 
 */
@Entity
@Table(name="activity_type_mst")
@NamedQueries({@NamedQuery(name="ActivityTypeMst.findAll", query="SELECT a FROM ActivityTypeMst a where a.isActive = 'Y'")})
public class ActivityTypeMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="activity_type_mst_id")
	private Integer activityTypeMstId;

	@Column(name="activity_type_val")
	private String activityTypeVal;

	@Column(name="is_active")
	private String isActive;

	public ActivityTypeMst() {
	}

	public Integer getActivityTypeMstId() {
		return this.activityTypeMstId;
	}

	public void setActivityTypeMstId(Integer activityTypeMstId) {
		this.activityTypeMstId = activityTypeMstId;
	}

	public String getActivityTypeVal() {
		return this.activityTypeVal;
	}

	public void setActivityTypeVal(String activityTypeVal) {
		this.activityTypeVal = activityTypeVal;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

}