package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the storage_sapmst database table.
 * 
 */
@Entity
@Table(name = "storage_sapmst")
@NamedQueries({
		@NamedQuery(name = "StorageSapmst.searchStorage", query = " SELECT s FROM StorageSapmst s where s.storageCode  like ?1 or s.storageDesc like ?2 "),
		@NamedQuery(name = "StorageSapmst.findAll", query = "SELECT s FROM StorageSapmst s"),
		@NamedQuery(name = "StorageSapmst.getStorageListByReceivingPlant", query = " SELECT s FROM StorageSapmst s where s.plantCode=?1 ")})
public class StorageSapmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "storage_sapmst_id")
	private Integer storageSapmstId;

	@Column(name = "storage_code")
	private String storageCode;

	@Column(name = "storage_desc")
	private String storageDesc;
	
	@Column(name = "plant_code")
	private String plantCode;
	
	@Transient
	private String separator = " - ";

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	public String getSeparator() {
		return separator;
	}

	public void setSeparator(String separator) {
		this.separator = separator;
	}

	public Integer getStorageSapmstId() {
		return storageSapmstId;
	}

	public void setStorageSapmstId(Integer storageSapmstId) {
		this.storageSapmstId = storageSapmstId;
	}

	public String getStorageCode() {
		return storageCode;
	}

	public void setStorageCode(String storageCode) {
		this.storageCode = storageCode;
	}

	public String getStorageDesc() {
		return storageDesc;
	}

	public void setStorageDesc(String storageDesc) {
		this.storageDesc = storageDesc;
	}

}