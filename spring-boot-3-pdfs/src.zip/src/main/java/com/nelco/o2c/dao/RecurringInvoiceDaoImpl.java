package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.RecurringInvoiceReportDTO;
import com.nelco.o2c.dto.SalesOrderReportDTO;
import com.nelco.o2c.dto.SalesReturnListDTO;
import com.nelco.o2c.model.CustomerSapmst;
import com.nelco.o2c.utility.DateUtil;
import com.nelco.o2c.utility.SDCommonUtil;
@Repository
public class RecurringInvoiceDaoImpl implements RecurringInvoiceDao {
	@PersistenceContext
	EntityManager em;
	Query query;
	@Autowired
	HttpSession session;
	 
	@Override
	public List<SalesOrderReportDTO> getSalesOrderReport(HttpServletRequest request) {
		List<SalesOrderReportDTO> lst = new ArrayList<SalesOrderReportDTO>();
		SalesOrderReportDTO bean = null;
		String lQuery = "SELECT distinct so_number,convert(varchar,s.creation_date, 105) as so_date,c.customer_name,'01-01-2019' as "
						+" i_c_conf_date,cc.warrenty_period,cc.clause_id,cl.value as clause_value,s.cont_sales_doc_type,st.value as doc_type"
						+" ,case when s.cont_sales_doc_type !='ZRNH' then"
						+" convert(varchar,(DATEADD(day, cast(warrenty_period as int), '2019-01-01')),105) "
						+" when s.cont_sales_doc_type='ZRNH' then"
						+" case when cc.clause_id=1 then "
						+" convert(varchar,(DATEADD(day, cast(warrenty_period as int), '2019-01-01')),105) "
						+" when cc.clause_id =2 then"
						+" convert(varchar,(DATEADD(week, cast(warrenty_period as int), '2019-01-01')),105) "
						+" when cc.clause_id =3 then"
						+" convert(varchar,(DATEADD(day, cast(warrenty_period as int), "
							+" 	convert(date,Dateadd(month, Datediff(month, 0,cast(DATEADD(month, 1, '01-01-2019') as date)), 0))"
								+" )),105) "
						+" end"
						+" end as due_date"
						+" FROM so_orders s inner join sales_doc_type_mst st on s.cont_sales_doc_type=st.code"
						+" inner join customer_sapmst c on s.sold_to_party=c.customer_num and s.sales_org=c.sales_org"
						+" and s.dist_channel=c.dist_channel and s.division=c.division"
						+" inner join child_contract cc on s.contract_num=cc.sap_contract_num"
						+" left join clause_contract_mst cl on cc.clause_id=cl.id"
						+ " where s.creation_date between :start_date and :end_date";
		query = em.createNativeQuery(lQuery);
		query.setParameter("start_date", DateUtil.convertDateToSqlDate(request.getParameter("start_date")));
		query.setParameter("end_date",
				DateUtil.convertDateToSqlDate(request.getParameter("end_date")) + " 23:59:59.999");
		int flag = 0;
		
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			flag++;
			bean = new SalesOrderReportDTO();
			bean.setSoNumber(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setSoDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[1]), false));
			bean.setCustomerName(SDCommonUtil.convertNullToBlank(String.valueOf(o[2]), false));
			bean.setiCConfirmationDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[3]), false));
			bean.setWarranty(SDCommonUtil.convertNullToBlank(String.valueOf(o[4]), false));
			bean.setClause(SDCommonUtil.convertNullToBlank(String.valueOf(o[5]), false));
			bean.setClause(SDCommonUtil.convertNullToBlank(String.valueOf(o[6]), false));
			bean.setContSalesDocTypeId(SDCommonUtil.convertNullToBlank(String.valueOf(o[7]), false));
			bean.setContSalesDocType(SDCommonUtil.convertNullToBlank(String.valueOf(o[8]), false));
			bean.setDueDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[9]), false));
			lst.add(bean);
		}
		if (flag > 0) {
			return lst;
		} else {
			lst.add(new SalesOrderReportDTO());
			return lst;
		}

		
	}

	@Override
	public List<CustomerSapmst> getListCustomerAutoComplete(HttpServletRequest request) {
		return null;
	}

	@Override
	public List<RecurringInvoiceReportDTO> getRecurringInvoiceReport(HttpServletRequest request) {
		List<RecurringInvoiceReportDTO> lst = new ArrayList<RecurringInvoiceReportDTO>();
		RecurringInvoiceReportDTO bean = null;
		String lQuery = "SELECT distinct r.sold_to_party,r.name_of_sold_to_party,'' as bank_name,so.so_number"
					+",u.user_name,ct.cont_desc as contract_type,c.po_number,r.so_no,convert(varchar,h.verified_date,104)"
					+"as installation_date,r.billing_type1 as billing_type,h.technology,'' as billing_plant,"
					+"'' as shipping_plant,cs.street1+','+cs.street2+','+cs.street3 as address,s.state_val"
					+",h.hub_name,net_value,convert(varchar,billing_date,104) as billing_date"
					+" FROM recurring_invoice_mst r inner join so_orders so on r.so_no=so.so_number"
					+" inner join child_contract cc on so.contract_num=cc.sap_contract_num "
					+" inner join user_mst u on u.user_mst_id=cc.pm_id"
					+" inner join contract c on c.contract_id=cc.contract_id"
					+" inner join contract_doc_type_sapmst ct on c.cont_sales_doc_type=ct.cont_sales_doc_type"
					+" left join hso_details h on r.so_no=h.so_number"
					+" inner join customer_sapmst cs on r.sold_to_party=cs.customer_num and so.dist_channel=cs.dist_channel"
					+" and so.sales_org=cs.sales_org and so.division=cs.division"
					+" inner join state_mst s on cs.region_code=s.state_code";
		query = em.createNativeQuery(lQuery);
		//query.setParameter("start_date", DateUtil.convertDateToSqlDate(request.getParameter("start_date")));
		//query.setParameter("end_date",
				//DateUtil.convertDateToSqlDate(request.getParameter("end_date")) + " 23:59:59.999");
		int flag = 0;
		List<Object[]> objList = query.getResultList();
		for (Object[] o : objList) {
			flag++;
			bean = new RecurringInvoiceReportDTO();
			bean.setSoldToParty(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setNameOfSoldToParty(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setBankName(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setSoNo(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setInstallationDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setBillingType(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setTechnology(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setBillingPlant(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setShippingPlant(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setAddress(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setState(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setHubName(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setNetValue(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			bean.setBillingDate(SDCommonUtil.convertNullToBlank(String.valueOf(o[0]), false));
			lst.add(bean);
		}
		if (flag > 0) {
			return lst;
		} else {
			lst.add(new RecurringInvoiceReportDTO());
			return lst;
		}

	}

}
