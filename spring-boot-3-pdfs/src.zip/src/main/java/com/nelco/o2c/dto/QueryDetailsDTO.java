/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nelco.o2c.model.Query;

/**
 * @author Jayashankar.r
 *
 */
@Component
public class QueryDetailsDTO  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<Query> queries;

	public List<Query> getQueries() {
		return queries;
	}

	public void setQueries(List<Query> queries) {
		this.queries = queries;
	}
}
