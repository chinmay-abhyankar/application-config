/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.DrfApprovalDTO;
import com.nelco.o2c.dto.DrfInfoDTO;
import com.nelco.o2c.dto.MaterialDTO;
import com.nelco.o2c.dto.PlantSapmstDTO;
import com.nelco.o2c.dto.UserDTO;
import com.nelco.o2c.model.ClauseContractMst;
import com.nelco.o2c.model.DeptMst;
import com.nelco.o2c.model.DrfApproverDetail;
import com.nelco.o2c.model.DrfTypeMst;
import com.nelco.o2c.model.MaterialSapmst;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.PlantSapmst;
import com.nelco.o2c.model.PreBidRespMatrix;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.utility.Constants;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class CommonPotentialsDaoImpl implements CommonPotentialsDao {

	@PersistenceContext
	private EntityManager em;

	Query query;

	@SuppressWarnings("unchecked")
	@Override
	public List<OppDetails> getPreSalesPotentialList(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("OppDetails.preSalesPotentialInfo");
		query.setParameter(1, commonDTO.getUserMstId().toString());
		List<OppDetails> opportunityDetObjs = (List<OppDetails>) query.getResultList();
		return opportunityDetObjs;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppDetails> getSalesCoordPotentialList(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("OppDetails.salesCoordPotentialInfo");
		List<OppDetails> opportunityDetObjs = (List<OppDetails>) query.getResultList();
		return opportunityDetObjs;
	}

	@Override
	public UserMst getUserDetailsById(Integer userMstId) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("UserMst.getUserDetailsById");
			query.setParameter(1, userMstId);
			UserMst userMstObj = (UserMst) query.getSingleResult();
			return userMstObj;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new UserMst();
		} finally {
			em.close();
		}

	}

	@Override
	public List<UserMst> getUserListByJobCode(String roleCd) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("UserMst.getUserListByJobCode");
			query.setParameter(1, roleCd);
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<UserMst> userMstList = (List<UserMst>) query.getResultList();
			return userMstList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<UserMst>();
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppDetails> getHeadPotentialList(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		if (commonDTO.getRoleCode().equalsIgnoreCase(Constants.OPERATIONSHEADCODE)) {
			query = em.createNamedQuery("OppDetails.NOCheadPotentialInfo");
			query.setParameter(1, commonDTO.getUserMstId().toString());
			List<OppDetails> opportunityDetObjs = (List<OppDetails>) query.getResultList();
			return opportunityDetObjs;
		} else if (commonDTO.getRoleCode().equalsIgnoreCase(Constants.PMGTHEADCODE)) {
			query = em.createNamedQuery("OppDetails.PMGTheadPotentialInfo");
			query.setParameter(1, commonDTO.getUserMstId().toString());
			List<OppDetails> opportunityDetObjs = (List<OppDetails>) query.getResultList();
			return opportunityDetObjs;
		} else {
			query = em.createNamedQuery("OppDetails.PREheadPotentialInfo");
			query.setParameter(1, commonDTO.getUserMstId().toString());
			List<OppDetails> opportunityDetObjs = (List<OppDetails>) query.getResultList();
			return opportunityDetObjs;
		}

	}

	@Override
	public List<OppDetails> preBidResponsibilityMatrix(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("OppDetails.preBidRespMatrixForBidMgr");
		query.setParameter(1, commonDTO.getUserMstId());
		@SuppressWarnings("unchecked")
		List<OppDetails> opportunityDetObjs = (List<OppDetails>) query.getResultList();
		return opportunityDetObjs;
	}

	@Override
	public List<DeptMst> getAllDeptList(DeptMst deptMst) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("DeptMst.getAllDeptList");
		@SuppressWarnings("unchecked")
		List<DeptMst> deptMstList = (List<DeptMst>) query.getResultList();
		return deptMstList;
	}

	@Override
	public List<UserDTO> getUserListDeptwise(DeptMst deptMst) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("UserMst.getUserListDeptwise");
			query.setParameter(1, deptMst.getDeptMstId());
			query.setParameter(2, deptMst.getUserMstId());

			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			@SuppressWarnings("unchecked")
			List<Object[]> userRes = (List<Object[]>) query.getResultList();
			List<UserDTO> userDTOList = new ArrayList<UserDTO>();
			for (Object[] objects : userRes) {
				UserDTO userDTO = new UserDTO();
				userDTO.setUserMstId((Integer) objects[0]);
				userDTO.setUserName((String) objects[1]);
				userDTO.setRoleCode((String) objects[2]);
				userDTO.setLoginId((String) objects[3]);
				userDTOList.add(userDTO);
			}

			return userDTOList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<UserDTO>();
		} finally {
			em.close();
		}
	}

	@Override
	public DeptMst getDeptBydeptMstId(Integer deptMstId) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("DeptMst.getDeptBydeptMstId");
			query.setParameter(1, deptMstId);
			DeptMst deptMstObj = (DeptMst) query.getSingleResult();
			return deptMstObj;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new DeptMst();
		} finally {
			em.close();
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OppDetails> commonPreBidTasks(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("PreBidRespMatrix.findByOppId");
		query.setParameter(1, commonDTO.getUserMstId());
		List<PreBidRespMatrix> preBidRespMatrixObjs = (List<PreBidRespMatrix>) query.getResultList();
		List<Integer> oppIds = new ArrayList<Integer>();
		for (PreBidRespMatrix preBidRespMatrix : preBidRespMatrixObjs) {
			oppIds.add(preBidRespMatrix.getOpportunityId());
		}

		List<OppDetails> oppDetailsList = new ArrayList<OppDetails>();
		if (oppIds.size() > 0) {
			query = em.createNamedQuery("OppDetails.preBidTaskDetailsbyOppId");
			query.setParameter(1, oppIds);
			oppDetailsList = (List<OppDetails>) query.getResultList();
		}

		return oppDetailsList;
	}

	@Override
	public List<OppDetails> getRespMatrix(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("OppDetails.RespMatrixForBidMgr");
		query.setParameter(1, commonDTO.getUserMstId());
		@SuppressWarnings("unchecked")
		List<OppDetails> opportunityDetObjs = (List<OppDetails>) query.getResultList();
		return opportunityDetObjs;
	}

	@Override
	public String getPotentialNameByOppId(Integer oppId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("OppDetails.getPotentialNameByOppId");
			query.setParameter(1, oppId);
			return (String) query.getSingleResult();
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		} finally {
			em.close();
		}
		
	}

	@Override
	public String getCustomerNameByOppId(Integer oppId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("OppDetails.getCustomerNameByOppId");
			query.setParameter(1, oppId);
			return (String) query.getSingleResult();
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		} finally {
			em.close();
		}
		
	}
	
	@Override
	public String getNatureByOppId(Integer oppId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("OppDetails.getNatureByOppId");
			query.setParameter(1, oppId);
			String res = (String) query.getSingleResult();
			return res.toUpperCase();
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			em.close();
		}
		
	}
	
	@Override
	public List<DrfTypeMst> getAllDrfTypeList(DrfTypeMst drfTypeMst) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("DrfTypeMst.getAllDrfTypeList");
		@SuppressWarnings("unchecked")
		List<DrfTypeMst> drfTypeMstList = (List<DrfTypeMst>) query.getResultList();
		return drfTypeMstList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public DrfApprovalDTO getDrfApprovalInfo(DrfInfoDTO drfInfoDTO) {
		DrfApprovalDTO drfApprovalDTO = new DrfApprovalDTO();
		try {
			// TODO Auto-generated method stub

			query = em.createNamedQuery("DrfDetails.getDrfApprovalInfoList");
			query.setParameter(1, drfInfoDTO.getUserMstId() != null ? drfInfoDTO.getUserMstId().toString() : "");
			query.setParameter(2, drfInfoDTO.getOpportunityId());
			List<DrfInfoDTO> apprViewList = new ArrayList<DrfInfoDTO>();
			List<Object[]> resultList = (List<Object[]>) query.getResultList();
			List<Integer> drfIds = new ArrayList<Integer>();
			
			for (Object[] objects : resultList) {
				DrfInfoDTO drfInfo = new DrfInfoDTO();
				drfInfo.setDrfDetailsId(objects[0] != null ? (Integer) objects[0] : null);
				drfInfo.setOpportunityId(objects[1] != null ? (Integer) objects[1] : null);
				drfInfo.setCustName(objects[2] != null ? (String) objects[2] : null);
				drfInfo.setMarketSegment(objects[3] != null ? (String) objects[3] : null);
				drfInfo.setPotentialName(objects[4] != null ? (String) objects[4] : null);
				drfInfo.setOpHead(objects[5] != null ? (String) objects[5] : null);
				drfInfo.setPmgtHead(objects[6] != null ? (String) objects[6] : null);
				drfInfo.setPreSalesHead(objects[7] != null ? (String) objects[7] : null);
				if(drfInfo.getDrfDetailsId()!=null) {
					drfIds.add(drfInfo.getDrfDetailsId());
				}
				apprViewList.add(drfInfo);
			}
			drfApprovalDTO.setApprViewList(apprViewList);
			drfApprovalDTO.setDrfId(drfIds);
			return drfApprovalDTO;
		} catch (Exception e) {
			e.printStackTrace();
			return drfApprovalDTO;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DrfApproverDetail> headApprovalInfo(List<Integer> drfIds) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("DrfApproverDetail.getApprDetailsbyDrfIds");
			query.setParameter(1, drfIds);
			return (List<DrfApproverDetail>) query.getResultList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} finally {
			em.close();
		}
	}

	@Override
	public UserMst getUserDetByLoginId(String loginId) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("UserMst.getUserDetByLoginId");
			query.setParameter(1, loginId);
			UserMst userMstObj = (UserMst) query.getSingleResult();
			return userMstObj;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new UserMst();
		} finally {
			em.close();
		}
	}

	@Override
	public MaterialSapmst uniqueMaterial(MaterialDTO materialDTO) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("MaterialSapmst.uniqueMaterial");
			query.setParameter(1, materialDTO.getMaterialNo());
			query.setParameter(2, materialDTO.getPlant());
			query.setParameter(3, materialDTO.getSalesOrg());
			query.setParameter(4, materialDTO.getDistChannel());
			MaterialSapmst materialSapmst = (MaterialSapmst) query.getSingleResult();
			return materialSapmst;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new MaterialSapmst();
		} finally {
			em.close();
		}
	}

	@Override
	public List<ClauseContractMst> allClauseContList(ClauseContractMst clauseContractMst) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("ClauseContractMst.allClauseContList");
		@SuppressWarnings("unchecked")
		List<ClauseContractMst> clauseContMstList = (List<ClauseContractMst>) query.getResultList();
		return clauseContMstList;
	}

	@Override
	public List<PlantSapmst> allPlantList(PlantSapmstDTO plantSapmstDTO) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("PlantSapmst.findAll");
			query.setHint("org.hibernate.cacheable", Boolean.TRUE);
			List<PlantSapmst> resultList = (List<PlantSapmst>) query.getResultList();
			return resultList;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ArrayList<PlantSapmst>();
		}  finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public List<OppDetails> getVpsPotentialList(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("OppDetails.vpsPotentialInfo");
		query.setParameter(1, commonDTO.getUserMstId());
		List<OppDetails> opportunityDetObjs = (List<OppDetails>) query.getResultList();
		return opportunityDetObjs;
	}

	@Override
	public List<OppDetails> getEboHeadPotentialList(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("OppDetails.eboHeadPotentialInfo");
		query.setParameter(1, commonDTO.getUserMstId());
		List<OppDetails> opportunityDetObjs = (List<OppDetails>) query.getResultList();
		return opportunityDetObjs;
	}

	@Override
	public List<OppDetails> getMdPotentialList(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("OppDetails.mdPotentialInfo");
		query.setParameter(1, commonDTO.getUserMstId());
		List<OppDetails> opportunityDetObjs = (List<OppDetails>) query.getResultList();
		return opportunityDetObjs;
	}

	@Override
	public UserMst getUserByBusinessLine(String businessline) {
		try{
			UserMst user = null;
			query = em.createNativeQuery("select user_login_id from user_to_businessline where business_line=?1");
			query.setParameter(1, businessline);
			String loginId = (String) query.getSingleResult();
			
			user = getUserDetByLoginId(loginId);
			
			return user!=null?user:new UserMst();
		}catch (Exception e) {
			e.printStackTrace();
			return new UserMst();
		}
		finally {
			em.close();
		}
	}

	
}
