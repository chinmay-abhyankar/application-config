package com.nelco.o2c.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.FranchiseDropDownDTO;
import com.nelco.o2c.dto.FranchiseeAllocEngineerDTO;
import com.nelco.o2c.dto.FranchiseeAllocFormDTO;
import com.nelco.o2c.dto.FranchiseeDTO;
import com.nelco.o2c.dto.FranchiseeListFormDTO;
import com.nelco.o2c.dto.UpdateFranchiseDTO;
import com.nelco.o2c.model.Delivery;
import com.nelco.o2c.model.FranchiseeAllocEngMst;
import com.nelco.o2c.model.FranchiseeAllocationMst;
import com.nelco.o2c.model.SiteSurveyMaster;
import com.nelco.o2c.model.StateMst;
import com.nelco.o2c.model.StatusMst;

public interface FranchiseeAllocDao {
	public List<SiteSurveyMaster> getListSiteSurveyMaster(HttpServletRequest request);
	
	public FranchiseeAllocFormDTO getFranchiseeFormMasters(FranchiseeAllocFormDTO franchiseeAllocFormDTO);
	
	public List<FranchiseeListFormDTO> getDeliveryListForPMGT(FranchiseeAllocFormDTO franchiseeAllocFormDTO,HttpServletRequest request);
	
	public List<FranchiseeListFormDTO> getDeliveryById(HttpServletRequest request);
	
	public FranchiseeAllocationMst saveFranchiseeAllocation(FranchiseeDTO franchiseeDTO);
	
	public FranchiseeAllocationMst submitFranchiseeAllocation(FranchiseeDTO franchiseeDTO);
	
	public List<FranchiseeListFormDTO> getFranchiseeAllocListForCS(HttpServletRequest request);
	
	public FranchiseeAllocationMst updateFranchiseeAllocFranchisee(UpdateFranchiseDTO updateFranchiseDTO);
	
	public List<FranchiseeListFormDTO> getFranchiseeAllocListForFranhisee(HttpServletRequest request);
	
	public FranchiseeAllocEngMst saveFranchiseeAllocSurveyEngineer(FranchiseeAllocEngineerDTO franchiseeAllocEngineerDTO);
	
	public FranchiseeAllocEngMst getEngineerById(HttpServletRequest request);
	
	public List<FranchiseeAllocEngMst> getEngineerListBySiteIdFrachiseeId(HttpServletRequest request);
	
	public List<Delivery> getDeliveryList();

	public void acceptFranchiseEngineer(CommonDTO commonDTOInput);

	public List<StatusMst> getFranchiseStatusList(List<String> statusList);

	public List<StateMst> getStateListByRoleCode(FranchiseDropDownDTO inputFranchiseDropDownDTO);

	public List<FranchiseeAllocationMst> uploadINCRequest(MultipartFile file, String userMstId) throws Exception;
}
