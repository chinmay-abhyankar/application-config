/**
 * 
 */
package com.nelco.o2c.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.LoginDTO;
import com.nelco.o2c.model.LoginLog;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class LoginDaoImpl implements LoginDao {

	@PersistenceContext
	EntityManager em;

	Query query;
	
	@Autowired 
	HttpSession session;

	@Override
	public LoginDTO authenticateUser(LoginDTO loginDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("UserMst.authenticate");
			query.setParameter(1, loginDTO.getLoginId());
			query.setParameter(2, loginDTO.getPassword());
			UserMst userMst = (UserMst) query.getSingleResult();
			loginDTO.setAuthFailed(false);
			loginDTO.setUserMst(userMst);
			
			//insertion of entry in login log table and updation in user table begins
			
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			
			query = em.createNamedQuery("UserMst.updateLastLogin");
			query.setParameter("lastLoginTime", currTime);
			query.setParameter("userMstId", userMst.getUserMstId());
			
			query.executeUpdate();
			
			LoginLog loginLog = new LoginLog();
			
			
			loginLog.setActTime(currTime);
			loginLog.setActType("LOGIN");
			loginLog.setLoginId(userMst.getLoginId());
			loginLog.setUserMstId(userMst.getUserMstId());
			
			em.merge(loginLog);
			
			//insertion of entry in login log table and updation in user table ends
			
			session.setAttribute("workArea", loginDTO);
			return loginDTO;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			session.setAttribute("workArea", null);
			return new LoginDTO();
		} finally {
			em.close();
		}
	}

	@Override
	public UserMst saveUser(UserMst userMst) {
		// TODO Auto-generated method stub
		UserMst userMstNew = em.merge(userMst);
		if(userMst.getUserMstId() == null) {
		em.refresh(userMstNew);
		}
		return userMstNew;
	}

	@Override
	public void logoutActionUpdate(LoginDTO loginDTO) {
		// TODO Auto-generated method stub
		//insertion of entry in login log table and updation in user table begins
		
		try {
			String currTime = DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS);
			UserMst userMst = loginDTO.getUserMst();
			if (userMst != null) {
				query = em.createNamedQuery("UserMst.updateLastLogout");
				query.setParameter("lastLogoutTime", currTime);
				query.setParameter("userMstId", userMst.getUserMstId());

				query.executeUpdate();

				LoginLog loginLog = new LoginLog();

				loginLog.setActTime(currTime);
				loginLog.setActType("LOGOUT");
				loginLog.setLoginId(userMst.getLoginId());
				loginLog.setUserMstId(userMst.getUserMstId());

				em.merge(loginLog);
			} 
		} finally {
			// TODO: handle finally clause
			em.close();
		}
		
		//insertion of entry in login log table and updation in user table ends
	}


}
