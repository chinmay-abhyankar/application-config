/**
 * 
 */
package com.nelco.o2c.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.nelco.o2c.dto.AllDeliveryListDTO;
import com.nelco.o2c.dto.DeliveryDTO;
import com.nelco.o2c.dto.DeliveryDropDownDTO;
import com.nelco.o2c.dto.DeliveryListDTO;
import com.nelco.o2c.dto.FileUploadDTO;
import com.nelco.o2c.dto.PodUploadDetailsDTO;
import com.nelco.o2c.model.Delivery;
import com.nelco.o2c.service.DeliveryService;

/**
 * @author Amol.l
 *
 */
@RestController
public class DeliveryController {

	@Autowired
	DeliveryService deliveryService;

	@RequestMapping(value = "/getDelByDelId.do", method = RequestMethod.POST)
	public DeliveryDTO getDelByDelId(@RequestBody DeliveryDTO deliveryDTO) {
		DeliveryDTO deliveryDTONew = new DeliveryDTO();
		Delivery delivery = new Delivery();
		delivery = deliveryService.getDelByDelId(deliveryDTO.getDeliveryId());
		deliveryDTONew.setDeliveryId(deliveryDTO.getDeliveryId());
		deliveryDTONew.setDelivery(delivery);
		return deliveryDTONew;
	}

	@RequestMapping(value = "/getDelByDelNum.do", method = RequestMethod.POST)
	public DeliveryListDTO getDelByDelNum(@RequestBody DeliveryListDTO deliveryListDTO) {
		
		DeliveryListDTO deliveryListDTONew = new DeliveryListDTO();
		List<Delivery> deliveryList = new ArrayList<Delivery>();
		Delivery delivery = deliveryService.getDelByDelNum(deliveryListDTO.getDeliveryNum());
		deliveryList.add(delivery);
		deliveryListDTONew.setDeliveryNum(deliveryListDTO.getDeliveryNum());
		deliveryListDTONew.setDeliveryList(deliveryList);
		return deliveryListDTONew;
	}
	
	@RequestMapping(value = "/getDeliveryDropDowns.do", method = RequestMethod.POST)
	public DeliveryDropDownDTO getDeliveryDropDowns(@RequestBody DeliveryDropDownDTO deliveryDropDownDTO) {
		return deliveryService.getDeliveryDropDowns(deliveryDropDownDTO);
	}

	@RequestMapping(value = "/getDelListByDate.do", method = RequestMethod.POST)
	public DeliveryListDTO getDelListByDate(@RequestBody DeliveryListDTO deliveryListDTO) {
		DeliveryListDTO deliveryListDTONew = new DeliveryListDTO();
		List<Delivery> deliveryList = new ArrayList<Delivery>();
		deliveryList = deliveryService.getDelListByDate(deliveryListDTO);
		deliveryListDTONew.setToDate(deliveryListDTO.getToDate());
		deliveryListDTONew.setFromDate(deliveryListDTO.getFromDate());
		deliveryListDTONew.setDeliveryList(deliveryList);
		return deliveryListDTONew;
	}
	
	@RequestMapping(value = "/getTypeAndStatuswiseDelList.do", method = RequestMethod.POST)
	public AllDeliveryListDTO getDelListByDateAndDelStatusCode(@RequestBody AllDeliveryListDTO allDeliveryListDTO) {
		AllDeliveryListDTO allDeliveryListDTONew = new AllDeliveryListDTO();
		allDeliveryListDTONew = deliveryService.getTypeAndStatuswiseDelList(allDeliveryListDTO);
		allDeliveryListDTONew.setToDate(allDeliveryListDTO.getToDate());
		allDeliveryListDTONew.setFromDate(allDeliveryListDTO.getFromDate());
		allDeliveryListDTONew.setDeliverytype(allDeliveryListDTO.getDeliverytype());
		return allDeliveryListDTONew;
	}

	@RequestMapping(value = "/getWrongAddressList.do", method = RequestMethod.POST)
	public DeliveryListDTO getWrongAddressList(@RequestBody DeliveryListDTO deliveryListDTO) {
		DeliveryListDTO deliveryListDTONew = new DeliveryListDTO();
		List<Delivery> deliveryList = new ArrayList<Delivery>();
		deliveryList = deliveryService.getWrongAddressList(deliveryListDTO);
//		deliveryListDTONew.setToDate(deliveryListDTO.getToDate());
//		deliveryListDTONew.setFromDate(deliveryListDTO.getFromDate());
		deliveryListDTONew.setDeliveryList(deliveryList);
		return deliveryListDTONew;
	}

	@RequestMapping(value = "/saveAllDeliveryDetList.do", method = RequestMethod.POST)
	public DeliveryListDTO saveAllDeliveryDetList(@RequestBody DeliveryListDTO deliveryListDTO) {
		DeliveryListDTO deliveryListDTONew = new DeliveryListDTO();
		return deliveryListDTONew = deliveryService.saveAllDeliveryDetList(deliveryListDTO);
	}

	@RequestMapping(value = "/updateWrongAddressByDelId.do", method = RequestMethod.POST)
	public DeliveryDTO updateWrongAddressByDelId(@RequestBody DeliveryDTO deliveryDTO) {
		DeliveryDTO deliveryDTONew = new DeliveryDTO();
		return deliveryDTONew = deliveryService.updateWrongAddressByDelId(deliveryDTO);
	}

	@RequestMapping(value = "/getPODfileList.do", method = RequestMethod.POST)
	public FileUploadDTO getPODfileList(@RequestBody FileUploadDTO fileUploadDTO) {
		return deliveryService.getPODfileList(fileUploadDTO);
	}

	@RequestMapping(value = "/uploadPodFile.do", method = RequestMethod.POST)
	public PodUploadDetailsDTO uploadfile(MultipartHttpServletRequest request, @RequestParam String fileTypeMstId,
			@RequestParam String deliveryId, @RequestParam String createdBy) {
		Iterator<String> fileNames = request.getFileNames();
		//request.get
		PodUploadDetailsDTO podUploadDetailsDTO = null;
		if (fileNames.hasNext()) {
			MultipartFile file = request.getFile(fileNames.next());
			podUploadDetailsDTO = deliveryService.uploadPodFile(file, fileTypeMstId, deliveryId, createdBy);
		}

		return podUploadDetailsDTO;

	}

	@RequestMapping(value = "/getUpPodFileDet.do", method = RequestMethod.POST)
	public PodUploadDetailsDTO getUpPodFileDet(@RequestBody PodUploadDetailsDTO podUploadDetailsDTO) {

		podUploadDetailsDTO = deliveryService.getUpPodFileDet(podUploadDetailsDTO.getDeliveryId());

		return podUploadDetailsDTO;

	}
	
	@RequestMapping(value = "/mailForSalesReturn.do", method = RequestMethod.POST)
	public DeliveryDTO mailForSalesReturn(@RequestBody DeliveryDTO deliveryDTO) {
		DeliveryDTO deliveryDTONew = new DeliveryDTO();
		deliveryDTONew = deliveryService.mailForSalesReturn(deliveryDTO);
		return deliveryDTONew;
	}
}
