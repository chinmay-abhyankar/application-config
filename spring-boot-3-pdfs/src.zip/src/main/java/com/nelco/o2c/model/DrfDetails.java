/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Amol.l
 *
 */

@Entity
@Table(name = "drf_details")
@NamedQueries({
		@NamedQuery(name = "DrfDetails.accountManagerDrfInfo", query = "select dd from DrfDetails dd inner join dd.opportunity where dd.opportunityId =?1"),
		@NamedQuery(name = "DrfDetails.getDrfInfoByDrfId", query = " select dd from DrfDetails dd where dd.drfDetailsId =?1"),
		@NamedQuery(name = "DrfDetails.drfInfoforHeadlogins", query = " select distinct new DrfDetails(dd.drfDetailsId,dd.opportunityId) from DrfDetails dd inner join dd.drfStatusTrackerList stl inner join stl.statusMst sm where dd.opportunityId =?1 and sm.statusCode in ('DRFSTSA','DRFSTSEA') "),
		@NamedQuery(name = "DrfDetails.drfInfoforHeadloginsWithoutOppId", query = " select distinct new DrfDetails(dd.drfDetailsId,dd.opportunityId) from DrfDetails dd inner join dd.drfStatusTrackerList stl inner join stl.statusMst sm where sm.statusCode in ('DRFSTSA','DRFSTSEA')"),
		@NamedQuery(name = "DrfDetails.getDrfPeopleDetails", query = " select dd.preSalesResName, dd.accMgr,dd.prgMgr, dd.techAppr, dd.opHead, dd.pmgtHead, dd.preSalesHead, dd.custName, dd.eboSalesHeadId, dd.vpSalesId, dd.ceoId from DrfDetails dd where dd.drfDetailsId=?1"),
		@NamedQuery(name = "DrfDetails.getDrfApprovalInfoList", query = " select drf.drfDetailsId, drf.opportunityId, drf.custName, "
				+ " drf.marketSegment, drf.potentialName, drf.opHead, drf.pmgtHead, drf.preSalesHead "
				+ " from DrfDetails drf inner join drf.drfStatusTrackerList tracker "
				+ " where tracker.statusMstId=3 and drf.preSalesResName = ?1 and drf.opportunityId=?2 ")})
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "drfDetailsId")
public class DrfDetails implements Serializable {

	private static final long serialVersionUID = 10L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "drf_details_id")
	private Integer drfDetailsId;

	@Column(name = "opportunity_id")
	private Integer opportunityId;

	@Column(name = "process_mst_id")
	private Integer process_mstId;

	@Column(name = "cust_name", length = 200)
	private String custName;

	@Column(name = "business_seg", length = 200)
	private String businessSeg;

	@Column(name = "writ_demo_req")
	private String writDemoReq;

	@Column(name = "obj_desc")
	private String objDesc;

	@Column(name = "exp_reports")
	private String expReports;

	@Column(name = "cust_def_success")
	private String custDefSuccess;

	@Column(name = "qty_req")
	private String qtyReq;

	@Column(name = "bandwidth")
	private String bandwidth;

	@Column(name = "share_ratio", length = 300)
	private String shareRatio;

	@Column(name = "backhaul", length = 300)
	private String backhaul;

	@Column(name = "link_frm_rem", length = 200)
	private String linkFrmRem;

	@Column(name = "link_to_cen", length = 200)
	private String linkToCen;

	@Column(name = "demo_start")
	private String demoStart;

	@Column(name = "demo_end")
	private String demoEnd;

	@Column(name = "init_by", length = 100)
	private String initBy;

	@Column(name = "pre_sales_res_name", length = 100)
	private String preSalesResName;

	@Column(name = "acc_mgr", length = 100)
	private String accMgr;

	@Column(name = "prg_mgr", length = 100)
	private String prgMgr;

	@Column(name = "tech_appr", length = 100)
	private String techAppr;

	@Column(name = "op_head", length = 100)
	private String opHead;

	@Column(name = "pmgt_head", length = 100)
	private String pmgtHead;

	@Column(name = "pre_sales_head", length = 100)
	private String preSalesHead;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "pan_no")
	private String panNo;
	
	@Column(name = "gstin_no")
	private String gstinNo;
	
	@Column(name = "potential_name")
	private String potentialName;

	@Column(name = "market_segment")
	private String marketSegment;
	
	@Column(name = "pre_sales_demo_init_rem")
	private String preSalesDemoInitRem;
	
	@Column(name = "drf_type_mst_id")
	private String drfTypeMstId;
	
	@Column(name = "hardware_desc")
	private String hardwareDesc;
	
	@Column(name = "ebo_sales_head_id")
	private Integer eboSalesHeadId;
	
	@Column(name = "vp_sales_id")
	private Integer vpSalesId;
	
	@Column(name = "ceo_id")
	private Integer ceoId;
	
	@Column(name = "status_mst_id")
	private Integer statusMstId;
	
	public DrfDetails() {
		
	}

	public DrfDetails(Integer drfDetailsId, Integer opportunityId) {
		super();
		this.drfDetailsId = drfDetailsId;
		this.opportunityId = opportunityId;
	}
	
	

	public Integer getStatusMstId() {
		return statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}

	public Integer getEboSalesHeadId() {
		return eboSalesHeadId;
	}

	public void setEboSalesHeadId(Integer eboSalesHeadId) {
		this.eboSalesHeadId = eboSalesHeadId;
	}

	public Integer getVpSalesId() {
		return vpSalesId;
	}

	public void setVpSalesId(Integer vpSalesId) {
		this.vpSalesId = vpSalesId;
	}

	public Integer getCeoId() {
		return ceoId;
	}

	public void setCeoId(Integer ceoId) {
		this.ceoId = ceoId;
	}

	@Transient
	private String zohoId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "opportunity_id", referencedColumnName = "opportunity_id", insertable = false, updatable = false)
	@JsonBackReference
	private Opportunity opportunity;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "drf_details_id", referencedColumnName = "drf_details_id", insertable = false, updatable = false)
	private List<DrfUploadDetail> drfUploadDetailList;
	
	@OneToMany(fetch = FetchType.LAZY,mappedBy="drfDetails")
	/*
	 * @JoinColumn(name = "drf_details_id", referencedColumnName = "drf_details_id",
	 * insertable = false, updatable = false)
	 */
	private List<DrfStatusTracker> drfStatusTrackerList;
	
	public String getZohoId() {
		return zohoId;
	}

	public void setZohoId(String zohoId) {
		this.zohoId = zohoId;
	}

	public List<DrfStatusTracker> getDrfStatusTrackerList() {
		return drfStatusTrackerList;
	}

	public void setDrfStatusTrackerList(List<DrfStatusTracker> drfStatusTrackerList) {
		this.drfStatusTrackerList = drfStatusTrackerList;
	}

	public List<DrfUploadDetail> getDrfUploadDetailList() {
		return drfUploadDetailList;
	}

	public void setDrfUploadDetailList(List<DrfUploadDetail> drfUploadDetailList) {
		this.drfUploadDetailList = drfUploadDetailList;
	}

	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}

	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public Integer getProcess_mstId() {
		return process_mstId;
	}

	public void setProcess_mstId(Integer process_mstId) {
		this.process_mstId = process_mstId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getBusinessSeg() {
		return businessSeg;
	}

	public void setBusinessSeg(String businessSeg) {
		this.businessSeg = businessSeg;
	}

	public String getWritDemoReq() {
		return writDemoReq;
	}

	public void setWritDemoReq(String writDemoReq) {
		this.writDemoReq = writDemoReq;
	}

	public String getObjDesc() {
		return objDesc;
	}

	public void setObjDesc(String objDesc) {
		this.objDesc = objDesc;
	}

	public String getExpReports() {
		return expReports;
	}

	public void setExpReports(String expReports) {
		this.expReports = expReports;
	}

	public String getCustDefSuccess() {
		return custDefSuccess;
	}

	public void setCustDefSuccess(String custDefSuccess) {
		this.custDefSuccess = custDefSuccess;
	}

	public String getQtyReq() {
		return qtyReq;
	}

	public void setQtyReq(String qtyReq) {
		this.qtyReq = qtyReq;
	}

	public String getBandwidth() {
		return bandwidth;
	}

	public void setBandwidth(String bandwidth) {
		this.bandwidth = bandwidth;
	}

	public String getShareRatio() {
		return shareRatio;
	}

	public void setShareRatio(String shareRatio) {
		this.shareRatio = shareRatio;
	}

	public String getBackhaul() {
		return backhaul;
	}

	public void setBackhaul(String backhaul) {
		this.backhaul = backhaul;
	}

	public String getLinkFrmRem() {
		return linkFrmRem;
	}

	public void setLinkFrmRem(String linkFrmRem) {
		this.linkFrmRem = linkFrmRem;
	}

	public String getLinkToCen() {
		return linkToCen;
	}

	public void setLinkToCen(String linkToCen) {
		this.linkToCen = linkToCen;
	}

	public String getInitBy() {
		return initBy;
	}

	public void setInitBy(String initBy) {
		this.initBy = initBy;
	}

	public String getPreSalesResName() {
		return preSalesResName;
	}

	public void setPreSalesResName(String preSalesResName) {
		this.preSalesResName = preSalesResName;
	}

	public String getAccMgr() {
		return accMgr;
	}

	public void setAccMgr(String accMgr) {
		this.accMgr = accMgr;
	}

	public String getPrgMgr() {
		return prgMgr;
	}

	public void setPrgMgr(String prgMgr) {
		this.prgMgr = prgMgr;
	}

	public String getTechAppr() {
		return techAppr;
	}

	public void setTechAppr(String techAppr) {
		this.techAppr = techAppr;
	}

	public String getOpHead() {
		return opHead;
	}

	public void setOpHead(String opHead) {
		this.opHead = opHead;
	}

	public String getPmgtHead() {
		return pmgtHead;
	}

	public void setPmgtHead(String pmgtHead) {
		this.pmgtHead = pmgtHead;
	}

	public String getPreSalesHead() {
		return preSalesHead;
	}

	public void setPreSalesHead(String preSalesHead) {
		this.preSalesHead = preSalesHead;
	}

	
	public Opportunity getOpportunity() {
		return opportunity;
	}

	public void setOpportunity(Opportunity opportunity) {
		this.opportunity = opportunity;
	}

	public String getDemoStart() {
		return DateUtil.convertDateTimeToString(demoStart);
		//return demoStart;
	}

	public void setDemoStart(String demoStart) {
		this.demoStart = DateUtil.convertDateToSqlDate(demoStart);
	}

	public String getDemoEnd() {
		return DateUtil.convertDateTimeToString(demoEnd);
		//return demoEnd;
	}

	public void setDemoEnd(String demoEnd) {
		this.demoEnd = DateUtil.convertDateToSqlDate(demoEnd);
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getGstinNo() {
		return gstinNo;
	}

	public void setGstinNo(String gstinNo) {
		this.gstinNo = gstinNo;
	}

	public String getPotentialName() {
		return potentialName;
	}

	public void setPotentialName(String potentialName) {
		this.potentialName = potentialName;
	}

	public String getMarketSegment() {
		return marketSegment;
	}

	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}

	public String getPreSalesDemoInitRem() {
		return preSalesDemoInitRem;
	}

	public void setPreSalesDemoInitRem(String preSalesDemoInitRem) {
		this.preSalesDemoInitRem = preSalesDemoInitRem;
	}


	public String getDrfTypeMstId() {
		return drfTypeMstId;
	}

	public void setDrfTypeMstId(String drfTypeMstId) {
		this.drfTypeMstId = drfTypeMstId;
	}

	public String getHardwareDesc() {
		return hardwareDesc;
	}

	public void setHardwareDesc(String hardwareDesc) {
		this.hardwareDesc = hardwareDesc;
	}
	

}
