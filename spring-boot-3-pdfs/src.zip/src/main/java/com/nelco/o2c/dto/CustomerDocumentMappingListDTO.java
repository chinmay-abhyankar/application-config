package com.nelco.o2c.dto;

public class CustomerDocumentMappingListDTO {

	private String customerCode="";
	private String customerName="";
	private String documentCode="";
	private String documentName="";
	private String typeId="";
	
	public CustomerDocumentMappingListDTO(String customerCode,String customerName,String documentCode,String documentName,String typeId){
		this.customerCode=customerCode;
		this.customerName=customerName;
		this.documentCode=documentCode;
		this.documentName=documentName;
		this.typeId=typeId;
	}
	
	public String getTypeId() {
		return typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDocumentCode() {
		return documentCode;
	}
	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	
}
