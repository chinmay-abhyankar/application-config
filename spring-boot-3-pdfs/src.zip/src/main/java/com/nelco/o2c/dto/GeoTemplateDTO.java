/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.GeoTemplate;

/**
 * @author Amol.l
 *
 */
public class GeoTemplateDTO implements Serializable {
	private static final long serialVersionUID = 88L;

	private Integer geoTemplateId;
	private GeoTemplate geoTemplate = new GeoTemplate();
	private Boolean isSaved = false;
	private Integer userMstId;
	private String selectedBtn;
	private String roleCode;
	private List<GeoTemplate> geoTemplateList = new ArrayList<GeoTemplate>();
	private List<GeoTempDTO> geoTempDTOList = new ArrayList<GeoTempDTO>();
	private Integer brfId;
	private String fromDate;
	private String toDate;
	private Integer contractId;
	
	public Integer getContractId() {
		return contractId;
	}
	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}
	public Integer getBrfId() {
		return brfId;
	}
	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}
	public Integer getGeoTemplateId() {
		return geoTemplateId;
	}
	public void setGeoTemplateId(Integer geoTemplateId) {
		this.geoTemplateId = geoTemplateId;
	}
	public GeoTemplate getGeoTemplate() {
		return geoTemplate;
	}
	public void setGeoTemplate(GeoTemplate geoTemplate) {
		this.geoTemplate = geoTemplate;
	}
	public Boolean getIsSaved() {
		return isSaved;
	}
	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getSelectedBtn() {
		return selectedBtn;
	}
	public void setSelectedBtn(String selectedBtn) {
		this.selectedBtn = selectedBtn;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public List<GeoTemplate> getGeoTemplateList() {
		return geoTemplateList;
	}
	public void setGeoTemplateList(List<GeoTemplate> geoTemplateList) {
		this.geoTemplateList = geoTemplateList;
	}
	public List<GeoTempDTO> getGeoTempDTOList() {
		return geoTempDTOList;
	}
	public void setGeoTempDTOList(List<GeoTempDTO> geoTempDTOList) {
		this.geoTempDTOList = geoTempDTOList;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	
}
