package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import com.nelco.o2c.model.StatusMst;

public class ReportsDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String field;
	private String type;
	private String fromDate;
	private String toDate;
	private String status;
	private String hub;
	private String sapContractNum;
	private String soldToParty;
	private String loginId;

	private String franchiseName;
	private String sscustomerName;
	private String feasible;
	
	private String soType;
	private String stateCode;
	
	private String billingType;
	private String billingPlant;
	
	public String getBillingType() {
		return billingType;
	}
	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}
	public String getBillingPlant() {
		return billingPlant;
	}
	public void setBillingPlant(String billingPlant) {
		this.billingPlant = billingPlant;
	}
	public String getFranchiseName() {
		return franchiseName;
	}
	public void setFranchiseName(String franchiseName) {
		this.franchiseName = franchiseName;
	}
	public String getSscustomerName() {
		return sscustomerName;
	}
	public void setSscustomerName(String sscustomerName) {
		this.sscustomerName = sscustomerName;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getHub() {
		return hub;
	}
	public void setHub(String hub) {
		this.hub = hub;
	}
	public String getField() {
		return field;
	}
	public void setField(String contractNumber) {
		this.field = contractNumber;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getSapContractNum() {
		return sapContractNum;
	}
	public void setSapContractNum(String sapContractNum) {
		this.sapContractNum = sapContractNum;
	}
	public String getSoldToParty() {
		return soldToParty;
	}
	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}
	public String getFeasible() {
		return feasible;
	}
	public void setFeasible(String feasible) {
		this.feasible = feasible;
	}
	public String getSoType() {
		return soType;
	}
	public void setSoType(String soType) {
		this.soType = soType;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	
	
}
