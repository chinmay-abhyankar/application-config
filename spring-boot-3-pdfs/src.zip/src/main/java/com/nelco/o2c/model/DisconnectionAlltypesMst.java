package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the disconnection_alltypes_mst database table.
 * 
 */
@Entity
@Table(name="disconnection_alltypes_mst")
@NamedQueries({
@NamedQuery(name="DisconnectionAlltypesMst.findAll", query="SELECT d FROM DisconnectionAlltypesMst d"),
@NamedQuery(name="DisconnectionAlltypesMst.findDisconnectionStatus", query="SELECT d FROM DisconnectionAlltypesMst d WHERE d.type='status'"),
@NamedQuery(name="DisconnectionAlltypesMst.findDisconnectionActions", query="SELECT d FROM DisconnectionAlltypesMst d WHERE d.type='action'"),
@NamedQuery(name="DisconnectionAlltypesMst.findDisconnectionSeverity", query="SELECT d FROM DisconnectionAlltypesMst d WHERE d.type='severity'")
})
public class DisconnectionAlltypesMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int typeid;

	private String actflag;

	private Timestamp changedate;

	private String label;

	private String type;

	private String value;

	public DisconnectionAlltypesMst() {
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public Timestamp getChangedate() {
		return this.changedate;
	}

	public void setChangedate(Timestamp changedate) {
		this.changedate = changedate;
	}

	public String getLabel() {
		return this.label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}