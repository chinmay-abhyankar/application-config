/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author Amol.l
 *
 */

@Entity
@Table(name="drf_type_mst")
@NamedQueries({
	@NamedQuery(name = "DrfTypeMst.getAllDrfTypeList", query = "select dtm from DrfTypeMst dtm ")
	})
public class DrfTypeMst implements Serializable {

	private static final long serialVersionUID = 10L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "drf_type_mst_id")
	private Integer drfTypeMstId;
	
	@Column(name = "drf_type_name")
	private String drfTypeName;

	public Integer getDrfTypeMstId() {
		return drfTypeMstId;
	}

	public void setDrfTypeMstId(Integer drfTypeMstId) {
		this.drfTypeMstId = drfTypeMstId;
	}

	public String getDrfTypeName() {
		return drfTypeName;
	}

	public void setDrfTypeName(String drfTypeName) {
		this.drfTypeName = drfTypeName;
	}
	
}
