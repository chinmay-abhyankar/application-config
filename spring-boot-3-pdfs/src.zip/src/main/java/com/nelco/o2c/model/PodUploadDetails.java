/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author Amol.l
 *
 */
@Entity
@Table(name = "pod_upload_details")
@NamedQueries({ 
		@NamedQuery(name = "PodUploadDetails.findAll", query = "SELECT pod FROM PodUploadDetails pod "),
		@NamedQuery(name = "PodUploadDetails.getUpPodFileDetByDeliveryId", query = "SELECT pod FROM PodUploadDetails pod where pod.deliveryId =?1 ")
	})
public class PodUploadDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pod_upload_details_id")
	private Integer podUploadDetailsId;

	@Column(name = "created_by")
	private Integer createdBy;

	@Column(name = "delivery_id")
	private Integer deliveryId;

	@Column(name = "up_file_name")
	private String upFileName;

	@Column(name = "upload_url")
	private String uploadUrl;

	@Column(name = "file_type_mst_id")
	private Integer fileTypeMstId;

	@Column(name = "upload_time")
	private String uploadTime;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "file_type_mst_id", referencedColumnName = "file_type_mst_id", insertable = false, updatable = false)
	private FileTypeMst fileTypeMst;

	public Integer getPodUploadDetailsId() {
		return podUploadDetailsId;
	}

	public void setPodUploadDetailsId(Integer podUploadDetailsId) {
		this.podUploadDetailsId = podUploadDetailsId;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(Integer deliveryId) {
		this.deliveryId = deliveryId;
	}

	public String getUpFileName() {
		return upFileName;
	}

	public void setUpFileName(String upFileName) {
		this.upFileName = upFileName;
	}

	public String getUploadUrl() {
		return uploadUrl;
	}

	public void setUploadUrl(String uploadUrl) {
		this.uploadUrl = uploadUrl;
	}

	public Integer getFileTypeMstId() {
		return fileTypeMstId;
	}

	public void setFileTypeMstId(Integer fileTypeMstId) {
		this.fileTypeMstId = fileTypeMstId;
	}

	public String getUploadTime() {
		return uploadTime;
	}

	public void setUploadTime(String uploadTime) {
		this.uploadTime = uploadTime;
	}

	public FileTypeMst getFileTypeMst() {
		return fileTypeMst;
	}

	public void setFileTypeMst(FileTypeMst fileTypeMst) {
		this.fileTypeMst = fileTypeMst;
	}

}
