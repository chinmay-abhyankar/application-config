/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Amol.l
 *
 */
public class PotentialInfoListDTO implements Serializable {

	private static final long serialVersionUID = 11L;

	private List<PotentialInfoDTO> potentialInfoDTOList = new ArrayList<PotentialInfoDTO>();

	public List<PotentialInfoDTO> getPotentialInfoDTOList() {
		return potentialInfoDTOList;
	}

	public void setPotentialInfoDTOList(List<PotentialInfoDTO> potentialInfoDTOList) {
		this.potentialInfoDTOList = potentialInfoDTOList;
	}

}
