/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.EmdRequestDetails;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.OppDetails;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.TenderFeeRequestDetails;
import com.nelco.o2c.model.TenderTypeMst;

/**
 * @author Jayashankar.r
 *
 */
public interface EmdTenderFeeDao {

	void saveTafCeoStatus(CommonDTO commonDTO);

	List<UserEmailDetailsBean> getFinanceList();

	List<TenderTypeMst> getTenderTypeList();

	List<FileTypeMst> getFileTypes(Integer processId);

	EmdRequestDetails getEmdRequestData(CommonDTO commonDTO);

	List<OppUploadDetail> getOppUploadsByOppId(CommonDTO commonDTO);

	void saveEmdDetails(EmdRequestDetails emdRequestDetails, HttpServletRequest request);

	List<EmdRequestDetails> getEmdRequestDataByRequestTo(CommonDTO commonDTO);

	List<OppDetails> getOppDetailsByOppId(Integer opportunityId);

	TenderFeeRequestDetails getTenderFeeData(CommonDTO commonDTO);

	void saveTenderFeeDetails(TenderFeeRequestDetails tenderFeeRequestDetails, HttpServletRequest request);

	List<TenderFeeRequestDetails> getTenderFeeDataByRequestTo(CommonDTO commonDTO);

	OppUploadDetail saveOppUploadDetails(OppUploadDetail oppUploadDetail);

}
