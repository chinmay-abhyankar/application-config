/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author Amol.l
 *
 */



@Entity
@Table(name="clause_contract_mst")
@NamedQueries({
	@NamedQuery(name = "ClauseContractMst.allClauseContList", query = "select ccm from ClauseContractMst ccm"),
	@NamedQuery(name = "ClauseContractMst.getClauseContMstId", query = "select ccm from ClauseContractMst ccm where ccm.clauseContractMstId =?1 ")
	})


public class ClauseContractMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Integer clauseContractMstId;

	@Column(name="value")
	private String value;

	public Integer getClauseContractMstId() {
		return clauseContractMstId;
	}

	public void setClauseContractMstId(Integer clauseContractMstId) {
		this.clauseContractMstId = clauseContractMstId;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
