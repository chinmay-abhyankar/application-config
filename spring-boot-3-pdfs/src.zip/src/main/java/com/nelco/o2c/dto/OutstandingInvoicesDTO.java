package com.nelco.o2c.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import org.springframework.stereotype.Component;

@Component
public class OutstandingInvoicesDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1065265900184778094L;
	private String customerNo = "";
	private String customerName = "";
	private String invoiceNo = "";
	private String invoiceDate = "";
	private BigDecimal outstandingAmt;
	private String dueDate = "";
	private String requestCount = "";
	private String requestStatus = "";
	private String lastReminderDate = "";
	private String noticeFlag = "";
	private String requestStatusCode= "";
	private String requestId="";
	private String salesHeadAppStatus="";
	private String financeHeadAppStatus="";
	private String requestType="";
	private String requestTypeCode="";
	private String creditNoteNo="";
	private String creditNoteAmt="";
	private String overallStatus="";
	private String disconnectionStatus="";
	private String paymentTerms="";
	
	
	public String getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public String getDisconnectionStatus() {
		return disconnectionStatus;
	}

	public void setDisconnectionStatus(String disconnectionStatus) {
		this.disconnectionStatus = disconnectionStatus;
	}

	public String getCreditNoteNo() {
		return creditNoteNo;
	}

	public void setCreditNoteNo(String creditNoteNo) {
		this.creditNoteNo = creditNoteNo;
	}

	public String getCreditNoteAmt() {
		return creditNoteAmt;
	}

	public void setCreditNoteAmt(String creditNoteAmt) {
		this.creditNoteAmt = creditNoteAmt;
	}

	public String getOverallStatus() {
		return overallStatus;
	}

	public void setOverallStatus(String overallStatus) {
		this.overallStatus = overallStatus;
	}

	public OutstandingInvoicesDTO(String customerNo, String customerName, String invoiceNo, String invoiceDate,
			BigDecimal outstandingAmt, String dueDate, String requestCount, String requestStatus,String lastReminderDate
			,String noticeFlag,String requestStatusCode,String requestId,String salesHeadAppStatus,String financeHeadAppStatus
			,String requestType,String requestTypeCode,String creditNoteNo,String creditNoteAmt,String overallStatus,String paymentTerms) {
		this.customerNo = customerNo;
		this.customerName = customerName;
		this.invoiceNo = invoiceNo;
		this.invoiceDate = invoiceDate;
		this.outstandingAmt = outstandingAmt;
		this.dueDate = dueDate;
		this.requestCount = requestCount;
		this.requestStatus = requestStatus;
		this.lastReminderDate=lastReminderDate;
		this.noticeFlag=noticeFlag;
		this.requestStatusCode=requestStatusCode;
		this.requestId=requestId;
		this.salesHeadAppStatus=salesHeadAppStatus;
		this.financeHeadAppStatus=financeHeadAppStatus;
		this.requestType=requestType;
		this.requestTypeCode=requestTypeCode;
		this.creditNoteNo=creditNoteNo;
		this.creditNoteAmt=creditNoteAmt;
		this.overallStatus=overallStatus;
		this.paymentTerms=paymentTerms;
	}
	
	public OutstandingInvoicesDTO(String customerNo, String customerName, String invoiceNo, String invoiceDate,
			BigDecimal outstandingAmt, String dueDate,String creditNoteNo,String creditNoteAmt,String overallStatus
			,String disconnectionStatus) {
		this.customerNo = customerNo;
		this.customerName = customerName;
		this.invoiceNo = invoiceNo;
		this.invoiceDate = invoiceDate;
		this.outstandingAmt = outstandingAmt;
		this.dueDate = dueDate;
		this.creditNoteNo=creditNoteNo;
		this.creditNoteAmt=creditNoteAmt;
		this.overallStatus=overallStatus;
		this.disconnectionStatus=disconnectionStatus;
	}
		
	public String getRequestTypeCode() {
		return requestTypeCode;
	}

	public void setRequestTypeCode(String requestTypeCode) {
		this.requestTypeCode = requestTypeCode;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getSalesHeadAppStatus() {
		return salesHeadAppStatus;
	}

	public void setSalesHeadAppStatus(String salesHeadAppStatus) {
		this.salesHeadAppStatus = salesHeadAppStatus;
	}

	public String getFinanceHeadAppStatus() {
		return financeHeadAppStatus;
	}

	public void setFinanceHeadAppStatus(String financeHeadAppStatus) {
		this.financeHeadAppStatus = financeHeadAppStatus;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getNoticeFlag() {
		return noticeFlag;
	}

	public void setNoticeFlag(String noticeFlag) {
		this.noticeFlag = noticeFlag;
	}

	public String getRequestStatusCode() {
		return requestStatusCode;
	}

	public void setRequestStatusCode(String requestStatusCode) {
		this.requestStatusCode = requestStatusCode;
	}

	public String getLastReminderDate() {
		return lastReminderDate;
	}

	public void setLastReminderDate(String lastReminderDate) {
		this.lastReminderDate = lastReminderDate;
	}

	public String getCustomerNo() {
		return customerNo;
	}

	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public BigDecimal getOutstandingAmt() {
		return outstandingAmt;
	}

	public void setOutstandingAmt(BigDecimal outstandingAmt) {
		this.outstandingAmt = outstandingAmt;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getRequestCount() {
		return requestCount;
	}

	public void setRequestCount(String requestCount) {
		this.requestCount = requestCount;
	}

	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	
	
	public OutstandingInvoicesDTO(){
		
	}
}
