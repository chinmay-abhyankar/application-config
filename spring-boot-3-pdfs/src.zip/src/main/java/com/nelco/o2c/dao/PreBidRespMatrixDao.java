/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.PreBidRespMatrix;
import com.nelco.o2c.model.PreBidTaskResponse;
import com.nelco.o2c.model.RespMatrixDetails;

/**
 * @author Amol.l
 *
 */
public interface PreBidRespMatrixDao {

	public PreBidRespMatrix savePreBidRespMatrixDetails(PreBidRespMatrix preBidRespMatrix);

	public List<PreBidRespMatrix> getPreBidRespMatrixByUserMstIdAndOpId(Integer userMstId, Integer opportunityId);

	public PreBidTaskResponse savePreBidResponse(PreBidTaskResponse preBidTaskResponse);

	public List<PreBidRespMatrix> getPreBidResponsesByUserMstIdAndOpId(Integer userMstId, Integer opportunityId);

	public List<PreBidRespMatrix> getFinalPBResponseByUserMstIdAndOpId(Integer userMstId, Integer opportunityId);

	public PreBidRespMatrix getByPreBidRespMatrixId(Integer preBidRespMatrixId);

	public List<OppUploadDetail> getFileUpDetForPre(Integer opportunityId,Integer respMatrixDetailsId);
}
