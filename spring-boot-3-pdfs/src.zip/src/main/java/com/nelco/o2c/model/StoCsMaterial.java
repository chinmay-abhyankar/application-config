package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the sto_cs_material database table.
 * 
 */
@Entity
@Table(name = "sto_cs_material")
@NamedQuery(name = "StoCsMaterial.findAll", query = "SELECT s FROM StoCsMaterial s")
public class StoCsMaterial implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sto_cs_material_id")
	private Integer stoCsMaterialId;

	@Column(name = "avail_material_num")
	private String availMaterialNum;

	@Column(name = "avail_quantity")
	private String availQuantity;

	@Column(name = "rec_plant_id")
	private Integer recPlantId;

	@Column(name = "req_material_desc")
	private String reqMaterialDesc;

	@Column(name = "req_material_num")
	private String reqMaterialNum;

	@Column(name = "req_quantity")
	private String reqQuantity;

	@Column(name = "sto_cs_id")
	private Integer stoCsId;

	@Column(name = "storage_sapmst_id")
	private Integer storageSapmstId;

	public StoCsMaterial() {
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "rec_plant_id", referencedColumnName = "plant_sapmst_id", insertable = false, updatable = false)
	private PlantSapmst plantSapmst;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "storage_sapmst_id", referencedColumnName = "storage_sapmst_id", insertable = false, updatable = false)
	private StorageSapmst storageSapmst;
	
	

	
	
	public StorageSapmst getStorageSapmst() {
		return storageSapmst;
	}

	public void setStorageSapmst(StorageSapmst storageSapmst) {
		this.storageSapmst = storageSapmst;
	}

	public PlantSapmst getPlantSapmst() {
		return plantSapmst;
	}

	public void setPlantSapmst(PlantSapmst plantSapmst) {
		this.plantSapmst = plantSapmst;
	}

	public Integer getStoCsMaterialId() {
		return stoCsMaterialId;
	}

	public void setStoCsMaterialId(Integer stoCsMaterialId) {
		this.stoCsMaterialId = stoCsMaterialId;
	}

	public String getAvailMaterialNum() {
		return availMaterialNum;
	}

	public void setAvailMaterialNum(String availMaterialNum) {
		this.availMaterialNum = availMaterialNum;
	}

	public String getAvailQuantity() {
		return availQuantity;
	}

	public void setAvailQuantity(String availQuantity) {
		this.availQuantity = availQuantity;
	}

	public Integer getRecPlantId() {
		return recPlantId;
	}

	public void setRecPlantId(Integer recPlantId) {
		this.recPlantId = recPlantId;
	}

	public String getReqMaterialDesc() {
		return reqMaterialDesc;
	}

	public void setReqMaterialDesc(String reqMaterialDesc) {
		this.reqMaterialDesc = reqMaterialDesc;
	}

	public String getReqMaterialNum() {
		return reqMaterialNum;
	}

	public void setReqMaterialNum(String reqMaterialNum) {
		this.reqMaterialNum = reqMaterialNum;
	}

	public String getReqQuantity() {
		return reqQuantity;
	}

	public void setReqQuantity(String reqQuantity) {
		this.reqQuantity = reqQuantity;
	}

	public Integer getStoCsId() {
		return stoCsId;
	}

	public void setStoCsId(Integer stoCsId) {
		this.stoCsId = stoCsId;
	}

	public Integer getStorageSapmstId() {
		return storageSapmstId;
	}

	public void setStorageSapmstId(Integer storageSapmstId) {
		this.storageSapmstId = storageSapmstId;
	}

}