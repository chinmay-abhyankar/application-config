package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;


/**
 * @author Amol.lR
 *
 */
@Entity
@Table(name="geo_template")
@NamedQueries({
		@NamedQuery(name="GeoTemplate.findAll", query="SELECT g FROM GeoTemplate g"),
		@NamedQuery(name="GeoTemplate.getGeoTempByGeoTempId", query="SELECT g FROM GeoTemplate g where g.geoTemplateId =?1")})
public class GeoTemplate implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="geo_template_id")
	private Integer geoTemplateId;

	private String amsl;

	@Column(name="antenna_make")
	private String antennaMake;

	@Column(name="antenna_size")
	private String antennaSize;

	private String band;

	@Column(name="brf_id")
	private Integer brfId ;

	@Column(name="buc_serial_num")
	private String bucSerialNum;

	@Column(name="bw_satellite_det")
	private String bwSatelliteDet;

	@Column(name="cable_length")
	private String cableLength;

	@Column(name="created_date")
	private String createdDate;

	@Column(name="franchise_mst_id")
	private String franchiseMstId;

	@Column(name="height_of_antenna")
	private String heightOfAntenna;

	@Column(name="height_of_building")
	private String heightOfBuilding;

	@Column(name="height_of_mast")
	private String heightOfMast;

	@Column(name="hsn_num")
	private String hsnNum;

	private String hub;

	@Column(name="idu_serial")
	private String iduSerial;

	@Column(name="install_date")
	private String installDate;

	@Column(name="ladder_lenght")
	private String ladderLenght;

	@Column(name="lan_ip")
	private String lanIp;

	@Column(name="lan_subnet_mask")
	private String lanSubnetMask;

	private String latitude;

	@Column(name="lnbc_serial_num")
	private String lnbcSerialNum;

	private String longitude;

	@Column(name="monkey_cage")
	private String monkeyCage;

	@Column(name="new_vsat_ip")
	private String newVsatIp;

	@Column(name="po_num")
	private String poNum;

	@Column(name="rac_code")
	private String racCode;

	@Column(name="request_date")
	private String requestDate;

	@Column(name="request_type")
	private String requestType;

	private String sacfa;

	@Column(name="so_num")
	private String soNum;

	@Column(name="sold_to_party")
	private String soldToParty;

	@Column(name="sub_sold_to_party")
	private String subSoldToParty;

	private String technology;

	@Column(name="tramsmitter_op_power")
	private String tramsmitterOpPower;

	private String ups;

	@Column(name="vsat_id")
	private String vsatId;

	@Column(name="vsat_ip")
	private String vsatIp;

	@Column(name="vsat_subnet_mask")
	private String vsatSubnetMask;
	
	@Column(name = "status_mst_id")
	private Integer statusMstId;
	
	@Column(name="new_postal_address")
	private String newPostalAddress;
	
	@Column(name="region")
	private String region;
	
	@Column(name="location")
	private String location;
	
	@Column(name="ic_invoice")
	private String icInvoice;
	
	@Column(name="serial_num")
	private String serialNum;
	
	@Column(name="sales_org")
	private String salesOrg;
	
	@Column(name="dist_channel")
	private String distChannel;

	@Column(name="division")
	private String division;
	
//	@Column(name="acc_reg_mail_sent")
//	private String accRegMailSent;
//	
//	@Column(name="noc_mail_sent")
//	private String nocMailSent;
	
//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "brf_id", referencedColumnName = "brf_id", insertable = false, updatable = false)
//	private Brf brf;
	
	@ManyToOne
	@JoinColumns({@JoinColumn(name = "sold_to_party", referencedColumnName = "customer_num", insertable = false, updatable = false),
			@JoinColumn(name = "dist_channel", referencedColumnName = "dist_channel", insertable = false, updatable = false),
			@JoinColumn(name = "division", referencedColumnName = "division", insertable = false, updatable = false),
			@JoinColumn(name = "sales_org", referencedColumnName = "sales_org", insertable = false, updatable = false)})
	private CustomerSapmst customerSapmst;
	
	@ManyToOne
	@JoinColumn(name = "status_mst_id", referencedColumnName = "status_mst_id", insertable = false, updatable = false)
	private StatusMst statusMst;
	
	@ManyToOne
	@JoinColumn(name = "franchise_mst_id", referencedColumnName = "franchise_mst_id", insertable = false, updatable = false)
	private FranchiseeMaster franchiseeMaster;

	public GeoTemplate() {
	}

	public Integer getGeoTemplateId() {
		return geoTemplateId;
	}

	public void setGeoTemplateId(Integer geoTemplateId) {
		this.geoTemplateId = geoTemplateId;
	}

	public String getAmsl() {
		return amsl;
	}

	public void setAmsl(String amsl) {
		this.amsl = amsl;
	}

	public String getAntennaMake() {
		return antennaMake;
	}

	public void setAntennaMake(String antennaMake) {
		this.antennaMake = antennaMake;
	}

	public String getAntennaSize() {
		return antennaSize;
	}

	public void setAntennaSize(String antennaSize) {
		this.antennaSize = antennaSize;
	}

	public String getBand() {
		return band;
	}

	public void setBand(String band) {
		this.band = band;
	}

	public Integer getBrfId() {
		return brfId;
	}

	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}

	public String getBucSerialNum() {
		return bucSerialNum;
	}

	public void setBucSerialNum(String bucSerialNum) {
		this.bucSerialNum = bucSerialNum;
	}

	public String getBwSatelliteDet() {
		return bwSatelliteDet;
	}

	public void setBwSatelliteDet(String bwSatelliteDet) {
		this.bwSatelliteDet = bwSatelliteDet;
	}

	public String getCableLength() {
		return cableLength;
	}

	public void setCableLength(String cableLength) {
		this.cableLength = cableLength;
	}

	public String getCreatedDate() {
//		return createdDate;
		return DateUtil.convertDateTimeToString(this.createdDate);
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}


	public String getHeightOfAntenna() {
		return heightOfAntenna;
	}

	public void setHeightOfAntenna(String heightOfAntenna) {
		this.heightOfAntenna = heightOfAntenna;
	}

	public String getHeightOfBuilding() {
		return heightOfBuilding;
	}

	public void setHeightOfBuilding(String heightOfBuilding) {
		this.heightOfBuilding = heightOfBuilding;
	}

	public String getHeightOfMast() {
		return heightOfMast;
	}

	public void setHeightOfMast(String heightOfMast) {
		this.heightOfMast = heightOfMast;
	}

	public String getHsnNum() {
		return hsnNum;
	}

	public void setHsnNum(String hsnNum) {
		this.hsnNum = hsnNum;
	}

	public String getHub() {
		return hub;
	}

	public void setHub(String hub) {
		this.hub = hub;
	}

	public String getIduSerial() {
		return iduSerial;
	}

	public void setIduSerial(String iduSerial) {
		this.iduSerial = iduSerial;
	}

	public String getInstallDate() {
//		return installDate;
		return DateUtil.convertDateTimeToString(this.installDate);
	}

	public void setInstallDate(String installDate) {
		this.installDate = installDate;
	}

	public String getLadderLenght() {
		return ladderLenght;
	}

	public void setLadderLenght(String ladderLenght) {
		this.ladderLenght = ladderLenght;
	}

	public String getLanIp() {
		return lanIp;
	}

	public void setLanIp(String lanIp) {
		this.lanIp = lanIp;
	}

	public String getLanSubnetMask() {
		return lanSubnetMask;
	}

	public void setLanSubnetMask(String lanSubnetMask) {
		this.lanSubnetMask = lanSubnetMask;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLnbcSerialNum() {
		return lnbcSerialNum;
	}

	public void setLnbcSerialNum(String lnbcSerialNum) {
		this.lnbcSerialNum = lnbcSerialNum;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getMonkeyCage() {
		return monkeyCage;
	}

	public void setMonkeyCage(String monkeyCage) {
		this.monkeyCage = monkeyCage;
	}

	public String getNewVsatIp() {
		return newVsatIp;
	}

	public void setNewVsatIp(String newVsatIp) {
		this.newVsatIp = newVsatIp;
	}

	public String getPoNum() {
		return poNum;
	}

	public void setPoNum(String poNum) {
		this.poNum = poNum;
	}

	public String getRacCode() {
		return racCode;
	}

	public void setRacCode(String racCode) {
		this.racCode = racCode;
	}

	public String getRequestDate() {
//		return requestDate;
		return DateUtil.convertDateTimeToString(this.requestDate);
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getSacfa() {
		return sacfa;
	}

	public void setSacfa(String sacfa) {
		this.sacfa = sacfa;
	}

	public String getSoNum() {
		return soNum;
	}

	public void setSoNum(String soNum) {
		this.soNum = soNum;
	}

	public String getSoldToParty() {
		return soldToParty;
	}

	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}

	public String getSubSoldToParty() {
		return subSoldToParty;
	}

	public void setSubSoldToParty(String subSoldToParty) {
		this.subSoldToParty = subSoldToParty;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getTramsmitterOpPower() {
		return tramsmitterOpPower;
	}

	public void setTramsmitterOpPower(String tramsmitterOpPower) {
		this.tramsmitterOpPower = tramsmitterOpPower;
	}

	public String getUps() {
		return ups;
	}

	public void setUps(String ups) {
		this.ups = ups;
	}

	public String getVsatId() {
		return vsatId;
	}

	public void setVsatId(String vsatId) {
		this.vsatId = vsatId;
	}

	public String getVsatIp() {
		return vsatIp;
	}

	public void setVsatIp(String vsatIp) {
		this.vsatIp = vsatIp;
	}

	public String getVsatSubnetMask() {
		return vsatSubnetMask;
	}

	public void setVsatSubnetMask(String vsatSubnetMask) {
		this.vsatSubnetMask = vsatSubnetMask;
	}


	public CustomerSapmst getCustomerSapmst() {
		return customerSapmst;
	}

	public void setCustomerSapmst(CustomerSapmst customerSapmst) {
		this.customerSapmst = customerSapmst;
	}

	public Integer getStatusMstId() {
		return statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}

	public String getNewPostalAddress() {
		return newPostalAddress;
	}

	public void setNewPostalAddress(String newPostalAddress) {
		this.newPostalAddress = newPostalAddress;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public StatusMst getStatusMst() {
		return statusMst;
	}

	public void setStatusMst(StatusMst statusMst) {
		this.statusMst = statusMst;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getIcInvoice() {
		return icInvoice;
	}

	public void setIcInvoice(String icInvoice) {
		this.icInvoice = icInvoice;
	}

	public String getSerialNum() {
		return serialNum;
	}

	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}

	public String getSalesOrg() {
		return salesOrg;
	}

	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

	public String getDistChannel() {
		return distChannel;
	}

	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getFranchiseMstId() {
		return franchiseMstId;
	}

	public void setFranchiseMstId(String franchiseMstId) {
		this.franchiseMstId = franchiseMstId;
	}

	public FranchiseeMaster getFranchiseeMaster() {
		return franchiseeMaster;
	}

	public void setFranchiseeMaster(FranchiseeMaster franchiseeMaster) {
		this.franchiseeMaster = franchiseeMaster;
	}
	
}