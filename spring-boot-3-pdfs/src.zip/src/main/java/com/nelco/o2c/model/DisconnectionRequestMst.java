package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the disconnection_request_mst database table.
 * 
 */
@Entity
@Table(name="disconnection_request_mst")
@NamedQueries({
@NamedQuery(name="DisconnectionRequestMst.findAll", query="SELECT d FROM DisconnectionRequestMst d"),
@NamedQuery(name="DisconnectionRequestMst.updateBusinessHeadAppStatus",query="UPDATE DisconnectionRequestMst d SET d.businessheadAppStatus=:requestStatus,disconnectionDate=CASE WHEN :requestStatus='2' AND mdAppStatus='2' THEN GETDATE() ELSE disconnectionDate END  WHERE d.requestId=:requestId"),
@NamedQuery(name="DisconnectionRequestMst.updateMDAppStatus",query="UPDATE DisconnectionRequestMst d SET d.mdAppStatus=:requestStatus,disconnectionDate=CASE WHEN :requestStatus='2' AND businessheadAppStatus='2' THEN GETDATE() ELSE disconnectionDate END WHERE d.requestId=:requestId"),
@NamedQuery(name="DisconnectionRequestMst.updateDisconnectionStatus",query="UPDATE DisconnectionRequestMst d SET d.disconnectionStatus=:requestStatus WHERE d.requestId=:requestId")
})
@NamedNativeQueries({
	@NamedNativeQuery(name="DisconnectionRequestMst.updateDisconnectionRequestStatus", query="update disconnection_request_mst SET request_status=CASE :requestStatus WHEN '3' THEN '5'"
			+ " ELSE CASE"
			+ " WHEN severity='1' AND request_status='0' THEN '2'"
			+ " WHEN severity='2' AND request_status='0' THEN '1'"
			+ " WHEN severity='2' AND request_status='1' THEN '2'"
			+ " WHEN severity='3' AND request_status='0' THEN '1'"
			+ " WHEN severity='3' AND request_status='1' THEN '2' END END"
			+ " WHERE request_id=:requestId")
})
public class DisconnectionRequestMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private int typeid;

	@Column(length=2)
	private String actflag;

	@Column(name="businesshead_app_status", length=2)
	private String businessheadAppStatus;

	@Column(name="disconnection_date")
	private String disconnectionDate;

	@Column(name="disconnection_status", length=2)
	private String disconnectionStatus;

	@Column(name="md_app_status", length=2)
	private String mdAppStatus;

	@Column(name="notice_id", length=20)
	private String noticeId;

	@Column(name="request_date")
	private Timestamp requestDate;

	@Column(name="request_id", length=20)
	private String requestId;

	@Transient
	private String userRole="";
	
	@Transient
	private String userId="";
	
	@Column(name="request_status")
	private String requestStatus="";
	
	@Transient
	private String appRemark="";
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "request_id", referencedColumnName = "request_id", insertable=false, updatable = false)
	private DisconnectionRequestDetail disconnectionRequestDetail;
	
	
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public DisconnectionRequestDetail getDisconnectionRequestDetail() {
		return disconnectionRequestDetail;
	}

	public void setDisconnectionRequestDetail(DisconnectionRequestDetail disconnectionRequestDetail) {
		this.disconnectionRequestDetail = disconnectionRequestDetail;
	}

	public String getAppRemark() {
		return appRemark;
	}

	public void setAppRemark(String appRemark) {
		this.appRemark = appRemark;
	}

	public DisconnectionRequestMst() {
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public String getBusinessheadAppStatus() {
		return this.businessheadAppStatus;
	}

	public void setBusinessheadAppStatus(String businessheadAppStatus) {
		this.businessheadAppStatus = businessheadAppStatus;
	}

	

	public String getDisconnectionDate() {
		return disconnectionDate;
	}

	public void setDisconnectionDate(String disconnectionDate) {
		this.disconnectionDate = disconnectionDate;
	}

	public String getDisconnectionStatus() {
		return this.disconnectionStatus;
	}

	public void setDisconnectionStatus(String disconnectionStatus) {
		this.disconnectionStatus = disconnectionStatus;
	}

	public String getMdAppStatus() {
		return this.mdAppStatus;
	}

	public void setMdAppStatus(String mdAppStatus) {
		this.mdAppStatus = mdAppStatus;
	}

	public String getNoticeId() {
		return this.noticeId;
	}

	public void setNoticeId(String noticeId) {
		this.noticeId = noticeId;
	}

	public Timestamp getRequestDate() {
		return this.requestDate;
	}

	public void setRequestDate(Timestamp requestDate) {
		this.requestDate = requestDate;
	}

	public String getRequestId() {
		return this.requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

}