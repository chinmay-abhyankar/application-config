package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the plant_sapmst database table.
 * 
 */
@Entity
@Table(name = "plant_sapmst")
@NamedQueries({
		@NamedQuery(name = "PlantSapmst.searchPlant", query = " SELECT p FROM PlantSapmst p where p.plantCode  like ?1 or p.plantName like ?2 "),
		@NamedQuery(name = "PlantSapmst.findAll", query = "SELECT p FROM PlantSapmst p"),
		@NamedQuery(name = "PlantSapmst.getReceivingPlantListByCompanyCode", query = " SELECT p FROM PlantSapmst p where p.companyCode = ?1 "),
		@NamedQuery(name = "PlantSapmst.plantByPlantCode", query = " SELECT p FROM PlantSapmst p where p.plantCode = ?1 ")
		})
public class PlantSapmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "plant_sapmst_id")
	private Integer plantSapmstId;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "plant_code")
	private String plantCode;

	@Column(name = "plant_name")
	private String plantName;

	@Column(name = "region_code")
	private String regionCode;
	
	@Column(name = "company_code")
	private String companyCode;

	@Transient
	private String separator = " - ";
	
	

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getSeparator() {
		return separator;
	}

	public void setSeparator(String separator) {
		this.separator = separator;
	}

	public Integer getPlantSapmstId() {
		return plantSapmstId;
	}

	public void setPlantSapmstId(Integer plantSapmstId) {
		this.plantSapmstId = plantSapmstId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	public String getPlantName() {
		return plantName;
	}

	public void setPlantName(String plantName) {
		this.plantName = plantName;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

}