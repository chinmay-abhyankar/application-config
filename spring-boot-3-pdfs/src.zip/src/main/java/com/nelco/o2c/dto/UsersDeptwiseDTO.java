/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Amol.l
 *
 */
public class UsersDeptwiseDTO implements Serializable {
	
	private static final long serialVersionUID = 19L;
	private List<UserDTO> userList = new ArrayList<UserDTO>();
	public List<UserDTO> getUserList() {
		return userList;
	}
	public void setUserList(List<UserDTO> userList) {
		this.userList = userList;
	}
	
}
