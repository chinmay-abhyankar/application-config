/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.Brf;
import com.nelco.o2c.model.BrfSoDetails;
import com.nelco.o2c.model.BrfStatusTracker;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.OppUploadDetail;

/**
 * @author Amol.l
 *
 */

public class BrfDTO implements Serializable {
	
	private static final long serialVersionUID = 81L;
	
	private Integer brfId;
	private Brf brf = new Brf();
	private Boolean isSaved = false;
	private Integer userMstId;
	private String selectedBtn;
	private String roleCode;
	private List<Brf> brfList = new ArrayList<Brf>();
	private List<FileTypeMst> brfFileList = new ArrayList<FileTypeMst>();
	private List<OppUploadDetail> oppUploadDetails = new ArrayList<OppUploadDetail>();
	private List<BrfStatusTracker> brfStatusTrackerList = new ArrayList<BrfStatusTracker>();
	private List<BrfSoDetails> brfSoDetailsList = new ArrayList<BrfSoDetails>();
	private Integer brfSoDetailsId;
	private String isNext;
	private Integer rowNumber;
	
	public Integer getBrfId() {
		return brfId;
	}
	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}
	public Brf getBrf() {
		return brf;
	}
	public void setBrf(Brf brf) {
		this.brf = brf;
	}

	public Boolean getIsSaved() {
		return isSaved;
	}
	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public List<Brf> getBrfList() {
		return brfList;
	}
	public void setBrfList(List<Brf> brfList) {
		this.brfList = brfList;
	}
	public String getSelectedBtn() {
		return selectedBtn;
	}
	public void setSelectedBtn(String selectedBtn) {
		this.selectedBtn = selectedBtn;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public List<FileTypeMst> getBrfFileList() {
		return brfFileList;
	}
	public void setBrfFileList(List<FileTypeMst> brfFileList) {
		this.brfFileList = brfFileList;
	}
	public List<OppUploadDetail> getOppUploadDetails() {
		return oppUploadDetails;
	}
	public void setOppUploadDetails(List<OppUploadDetail> oppUploadDetails) {
		this.oppUploadDetails = oppUploadDetails;
	}
	public List<BrfStatusTracker> getBrfStatusTrackerList() {
		return brfStatusTrackerList;
	}
	public void setBrfStatusTrackerList(List<BrfStatusTracker> brfStatusTrackerList) {
		this.brfStatusTrackerList = brfStatusTrackerList;
	}
	public List<BrfSoDetails> getBrfSoDetailsList() {
		return brfSoDetailsList;
	}
	public void setBrfSoDetailsList(List<BrfSoDetails> brfSoDetailsList) {
		this.brfSoDetailsList = brfSoDetailsList;
	}
	public String getIsNext() {
		return isNext;
	}
	public void setIsNext(String isNext) {
		this.isNext = isNext;
	}
	public Integer getBrfSoDetailsId() {
		return brfSoDetailsId;
	}
	public void setBrfSoDetailsId(Integer brfSoDetailsId) {
		this.brfSoDetailsId = brfSoDetailsId;
	}
	public Integer getRowNumber() {
		return rowNumber;
	}
	public void setRowNumber(Integer rowNumber) {
		this.rowNumber = rowNumber;
	}
	
}
