package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the relocation_so_user_map database table.
 * 
 */
@Entity
@Table(name="relocation_so_user_map")
@NamedQueries({
	@NamedQuery(name="RelocationSoUserMap.findAll", query="SELECT r FROM RelocationSoUserMap r"),
	@NamedQuery(name="RelocationSoUserMap.countUserRelocationSo", query = "select count(r) FROM RelocationSoUserMap r where r.relocationSoId = :relocationSoId and r.userMstId = :userMstId ")
})
public class RelocationSoUserMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="relocation_so_user_map_id")
	private Integer relocationSoUserMapId;

	@Column(name="created_date")
	private String createdDate;

	@Column(name="relocation_so_id")
	private Integer relocationSoId;

	@Column(name="user_mst_id")
	private Integer userMstId;
	
	@Column(name = "role_code")
	private String roleCode;

	public RelocationSoUserMap() {
	}

	
	
	public String getRoleCode() {
		return roleCode;
	}



	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}



	public Integer getRelocationSoUserMapId() {
		return this.relocationSoUserMapId;
	}

	public void setRelocationSoUserMapId(Integer relocationSoUserMapId) {
		this.relocationSoUserMapId = relocationSoUserMapId;
	}

	public String getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getRelocationSoId() {
		return this.relocationSoId;
	}

	public void setRelocationSoId(Integer relocationSoId) {
		this.relocationSoId = relocationSoId;
	}

	public Integer getUserMstId() {
		return this.userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

}