package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the po_status_tracker database table.
 * 
 */
@Entity
@Table(name = "po_status_tracker")
@NamedQueries({
		@NamedQuery(name = "PoStatusTracker.findByProposalId", query = "SELECT p FROM PoStatusTracker p where p.proposalId=?1 order by p.poStatusTrackerId desc"),
		@NamedQuery(name = "PoStatusTracker.findAll", query = "SELECT p FROM PoStatusTracker p") })
public class PoStatusTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "po_status_tracker_id")
	private Integer poStatusTrackerId;

	@Column(name = "created_by_id")
	private Integer createdById;

	@Column(name = "proposal_id")
	private Integer proposalId;

	@Column(name = "req_date")
	private String reqDate;

	@Column(name = "status_mst_id")
	private Integer statusMstId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "proposal_id", referencedColumnName = "proposal_id", insertable = false, updatable = false)
	private Proposal proposal;

	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="status_mst_id",referencedColumnName="status_mst_id", insertable = false, updatable = false)
	private StatusMst statusMst;
	
	
	public Proposal getProposal() {
		return proposal;
	}

	public void setProposal(Proposal proposal) {
		this.proposal = proposal;
	}

	public StatusMst getStatusMst() {
		return statusMst;
	}

	public void setStatusMst(StatusMst statusMst) {
		this.statusMst = statusMst;
	}

	public Integer getPoStatusTrackerId() {
		return poStatusTrackerId;
	}

	public void setPoStatusTrackerId(Integer poStatusTrackerId) {
		this.poStatusTrackerId = poStatusTrackerId;
	}

	public Integer getCreatedById() {
		return createdById;
	}

	public void setCreatedById(Integer createdById) {
		this.createdById = createdById;
	}

	public Integer getProposalId() {
		return proposalId;
	}

	public void setProposalId(Integer proposalId) {
		this.proposalId = proposalId;
	}

	public String getReqDate() {
		return reqDate;
	}

	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}

	public Integer getStatusMstId() {
		return statusMstId;
	}

	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}
}