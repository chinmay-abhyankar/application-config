package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the mat_consum_sapmst database table.
 * 
 */
@Entity
@Table(name="mat_consum_sapmst")
@NamedQuery(name="MatConsumSapmst.findAll", query="SELECT m FROM MatConsumSapmst m")
public class MatConsumSapmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="mat_consum_sapmst_id")
	private int matConsumSapmstId;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="mat_doc_item")
	private String matDocItem;

	@Column(name="mat_doc_num")
	private String matDocNum;

	@Column(name="mat_doc_year")
	private String matDocYear;

	@Column(name="reser_num")
	private String reserNum;

	public MatConsumSapmst() {
	}

	public int getMatConsumSapmstId() {
		return this.matConsumSapmstId;
	}

	public void setMatConsumSapmstId(int matConsumSapmstId) {
		this.matConsumSapmstId = matConsumSapmstId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getMatDocItem() {
		return this.matDocItem;
	}

	public void setMatDocItem(String matDocItem) {
		this.matDocItem = matDocItem;
	}

	public String getMatDocNum() {
		return this.matDocNum;
	}

	public void setMatDocNum(String matDocNum) {
		this.matDocNum = matDocNum;
	}

	public String getMatDocYear() {
		return this.matDocYear;
	}

	public void setMatDocYear(String matDocYear) {
		this.matDocYear = matDocYear;
	}

	public String getReserNum() {
		return this.reserNum;
	}

	public void setReserNum(String reserNum) {
		this.reserNum = reserNum;
	}

}