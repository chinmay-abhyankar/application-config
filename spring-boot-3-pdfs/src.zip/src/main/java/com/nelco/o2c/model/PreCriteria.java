package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the pre_criteria database table.
 * 
 */
@Entity
@Table(name = "pre_criteria")
@NamedQueries({ @NamedQuery(name = "PreCriteria.findAll", query = "SELECT p FROM PreCriteria p"),
		@NamedQuery(name = "PreCriteria.findByOppId", query = "SELECT p FROM PreCriteria p where p.opportunityId = ?1 ") })
public class PreCriteria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pre_criteria_id")
	private Integer preCriteriaId;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "criteria")
	private String criteria;

	@Column(name = "criteria_by")
	private Integer criteriaBy;

	@Column(name = "meeting_crit")
	private String meetingCrit;

	@Column(name = "opportunity_id")
	private Integer opportunityId;

	@Column(name = "tend_bid_det_id")
	private Integer tendBidDetId;

	public Integer getPreCriteriaId() {
		return preCriteriaId;
	}

	public void setPreCriteriaId(Integer preCriteriaId) {
		this.preCriteriaId = preCriteriaId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}

	public Integer getCriteriaBy() {
		return criteriaBy;
	}

	public void setCriteriaBy(Integer criteriaBy) {
		this.criteriaBy = criteriaBy;
	}

	public String getMeetingCrit() {
		return meetingCrit;
	}

	public void setMeetingCrit(String meetingCrit) {
		this.meetingCrit = meetingCrit;
	}

	public Integer getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Integer opportunityId) {
		this.opportunityId = opportunityId;
	}

	public Integer getTendBidDetId() {
		return tendBidDetId;
	}

	public void setTendBidDetId(Integer tendBidDetId) {
		this.tendBidDetId = tendBidDetId;
	}

}