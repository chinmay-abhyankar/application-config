/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

/**
 * @author Amol.l
 *
 */
public class PmgtMailDTO implements Serializable {
	private static final long serialVersionUID = 85L;
	
	private Integer stoPmgtId;
	private Integer pmgtCoordId;
	private Integer reqById;
	private String stoPmgtGenId;
	private String stoReqTime;
	private Integer storeUserId;
	private String storesUpdateTime;
	private Integer supplyPlantId;
	private String stoPmSubmit = "N";
	private String stoStoresSubmit = "N";
	private String createdDate;
	private Integer financeId;
	private Integer statusMstId;
	
	public Integer getStoPmgtId() {
		return stoPmgtId;
	}
	public void setStoPmgtId(Integer stoPmgtId) {
		this.stoPmgtId = stoPmgtId;
	}
	public Integer getPmgtCoordId() {
		return pmgtCoordId;
	}
	public void setPmgtCoordId(Integer pmgtCoordId) {
		this.pmgtCoordId = pmgtCoordId;
	}
	public Integer getReqById() {
		return reqById;
	}
	public void setReqById(Integer reqById) {
		this.reqById = reqById;
	}
	public String getStoPmgtGenId() {
		return stoPmgtGenId;
	}
	public void setStoPmgtGenId(String stoPmgtGenId) {
		this.stoPmgtGenId = stoPmgtGenId;
	}
	public String getStoReqTime() {
		return stoReqTime;
	}
	public void setStoReqTime(String stoReqTime) {
		this.stoReqTime = stoReqTime;
	}
	public Integer getStoreUserId() {
		return storeUserId;
	}
	public void setStoreUserId(Integer storeUserId) {
		this.storeUserId = storeUserId;
	}
	public String getStoresUpdateTime() {
		return storesUpdateTime;
	}
	public void setStoresUpdateTime(String storesUpdateTime) {
		this.storesUpdateTime = storesUpdateTime;
	}
	public Integer getSupplyPlantId() {
		return supplyPlantId;
	}
	public void setSupplyPlantId(Integer supplyPlantId) {
		this.supplyPlantId = supplyPlantId;
	}
	public String getStoPmSubmit() {
		return stoPmSubmit;
	}
	public void setStoPmSubmit(String stoPmSubmit) {
		this.stoPmSubmit = stoPmSubmit;
	}
	public String getStoStoresSubmit() {
		return stoStoresSubmit;
	}
	public void setStoStoresSubmit(String stoStoresSubmit) {
		this.stoStoresSubmit = stoStoresSubmit;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getFinanceId() {
		return financeId;
	}
	public void setFinanceId(Integer financeId) {
		this.financeId = financeId;
	}
	public Integer getStatusMstId() {
		return statusMstId;
	}
	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}
	
	
}
