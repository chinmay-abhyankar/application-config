/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.SoOrderDTO;
import com.nelco.o2c.dto.SoOrdersListDTO;
import com.nelco.o2c.model.SoOrders;

/**
 * @author Amol.l
 *
 */

public interface SalesOrderDao {

	public List<SoOrders> getSoDetailsBySoNumber(SoOrderDTO soOrderDTO);
	
	public List<SoOrders> getSOListByContractNum(String contractNum);

	public List<SoOrders> getSOListBySparesSoUniqId(SoOrdersListDTO soOrdersListDTO);

	public List<SoOrders> getSOListByRelocationSoUniqId(SoOrdersListDTO soOrdersListDTO);

	public List<SoOrders> getSOListByDemoId(SoOrdersListDTO soOrdersListDTO);

}
