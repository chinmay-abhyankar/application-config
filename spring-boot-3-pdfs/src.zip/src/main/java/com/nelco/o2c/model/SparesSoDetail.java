package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the spares_so_details database table.
 * 
 */
@Entity
@Table(name="spares_so_details")
@NamedQueries({
	@NamedQuery(name="SparesSoDetail.findAll", query="SELECT s FROM SparesSoDetail s"),
	@NamedQuery(name="SparesSoDetail.updateDelFlag", query="update SparesSoDetail s set s.delFlg = 'Y' where s.sparesSoDetailsId = :sparesSoDetailsId ")
})
public class SparesSoDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="spares_so_details_id")
	private Integer sparesSoDetailsId;

	@Column(name="del_flg")
	private String delFlg="N";

	@Column(name="item_no")
	private String itemNo;

	@Column(name="material_code")
	private String materialCode;

	@Column(name="material_desc")
	private String materialDesc;

	private String quantity;

	@Column(name="spares_so_id")
	private Integer sparesSoId;
	
	@Column(name = "created_date",updatable = false)
	private String createdDate;
	
	@Column(name = "modified_date")
	private String modifiedDate;

	public SparesSoDetail() {
	}

	
	
	public String getCreatedDate() {
		return createdDate;
	}



	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}



	public String getModifiedDate() {
		return modifiedDate;
	}



	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}



	public Integer getSparesSoDetailsId() {
		return this.sparesSoDetailsId;
	}

	public void setSparesSoDetailsId(Integer sparesSoDetailsId) {
		this.sparesSoDetailsId = sparesSoDetailsId;
	}

	public String getDelFlg() {
		return this.delFlg;
	}

	public void setDelFlg(String delFlg) {
		this.delFlg = delFlg;
	}

	public String getItemNo() {
		return this.itemNo;
	}

	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public String getMaterialCode() {
		return this.materialCode;
	}

	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	public String getMaterialDesc() {
		return this.materialDesc;
	}

	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}

	public String getQuantity() {
		return this.quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public Integer getSparesSoId() {
		return this.sparesSoId;
	}

	public void setSparesSoId(Integer sparesSoId) {
		this.sparesSoId = sparesSoId;
	}

}