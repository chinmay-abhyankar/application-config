package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the cs_sto_pod_upload_details database table.
 * 
 */
@Entity
@Table(name = "cs_sto_pod_upload_details")
@NamedQueries({
		@NamedQuery(name = "CsStoPodUploadDetail.getPodByStoCsDeliveryId", query = "SELECT c FROM CsStoPodUploadDetail c where c.stoCsDeliveryId=?1"),
		@NamedQuery(name = "CsStoPodUploadDetail.findAll", query = "SELECT c FROM CsStoPodUploadDetail c") })

public class CsStoPodUploadDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cs_sto_pod_upload_details_id")
	private Integer csStoPodUploadDetailsId;

	@Column(name = "created_by")
	private Integer createdBy;

	@Column(name = "file_type_mst_id")
	private Integer fileTypeMstId;

	@Column(name = "sto_cs_delivery_id")
	private Integer stoCsDeliveryId;

	@Column(name = "up_file_name")
	private String upFileName;

	@Column(name = "upload_time")
	private String uploadTime;

	@Column(name = "upload_url")
	private String uploadUrl;

	public CsStoPodUploadDetail() {
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "file_type_mst_id", referencedColumnName = "file_type_mst_id", insertable = false, updatable = false)
	private FileTypeMst fileTypeMst;

	public FileTypeMst getFileTypeMst() {
		return fileTypeMst;
	}

	public void setFileTypeMst(FileTypeMst fileTypeMst) {
		this.fileTypeMst = fileTypeMst;
	}

	public Integer getCsStoPodUploadDetailsId() {
		return csStoPodUploadDetailsId;
	}

	public void setCsStoPodUploadDetailsId(Integer csStoPodUploadDetailsId) {
		this.csStoPodUploadDetailsId = csStoPodUploadDetailsId;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getFileTypeMstId() {
		return fileTypeMstId;
	}

	public void setFileTypeMstId(Integer fileTypeMstId) {
		this.fileTypeMstId = fileTypeMstId;
	}

	public Integer getStoCsDeliveryId() {
		return stoCsDeliveryId;
	}

	public void setStoCsDeliveryId(Integer stoCsDeliveryId) {
		this.stoCsDeliveryId = stoCsDeliveryId;
	}

	public String getUpFileName() {
		return upFileName;
	}

	public void setUpFileName(String upFileName) {
		this.upFileName = upFileName;
	}

	public String getUploadTime() {
		return uploadTime;
	}

	public void setUploadTime(String uploadTime) {
		this.uploadTime = uploadTime;
	}

	public String getUploadUrl() {
		return uploadUrl;
	}

	public void setUploadUrl(String uploadUrl) {
		this.uploadUrl = uploadUrl;
	}

}