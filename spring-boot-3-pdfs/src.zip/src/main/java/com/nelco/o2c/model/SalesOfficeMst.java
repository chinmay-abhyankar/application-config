package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the sales_office_mst database table.
 * 
 */
@Entity
@Table(name="sales_office_mst")
@NamedQueries({
@NamedQuery(name="SalesOfficeMst.findAll", query="SELECT s FROM SalesOfficeMst s")

})
public class SalesOfficeMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="sales_office_mst_id")
	private int salesOfficeMstId;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="is_active")
	private String isActive;

	@Column(name="sales_office_code")
	private String salesOfficeCode;

	@Column(name="sales_office_desc")
	private String salesOfficeDesc;

	private String sequence;

	public SalesOfficeMst() {
	}

	public int getSalesOfficeMstId() {
		return this.salesOfficeMstId;
	}

	public void setSalesOfficeMstId(int salesOfficeMstId) {
		this.salesOfficeMstId = salesOfficeMstId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getSalesOfficeCode() {
		return this.salesOfficeCode;
	}

	public void setSalesOfficeCode(String salesOfficeCode) {
		this.salesOfficeCode = salesOfficeCode;
	}

	public String getSalesOfficeDesc() {
		return this.salesOfficeDesc;
	}

	public void setSalesOfficeDesc(String salesOfficeDesc) {
		this.salesOfficeDesc = salesOfficeDesc;
	}

	public String getSequence() {
		return this.sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

}