package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the pod_status_tracker database table.
 * 
 */
@Entity
@Table(name="pod_status_tracker")
@NamedQuery(name="PodStatusTracker.findAll", query="SELECT p FROM PodStatusTracker p")
public class PodStatusTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pod_status_tracker_id")
	private Integer podStatusTrackerId;

	@Column(name="delivery_id")
	private Integer deliveryId;

	@Column(name = "pod_status_mst_id")
	private Integer podStatusMstId;

	@Column(name="req_by")
	private Integer reqBy;

	@Column(name="status_req_date")
	private String statusReqDate;

	public PodStatusTracker() {
	}

	public Integer getPodStatusTrackerId() {
		return podStatusTrackerId;
	}

	public void setPodStatusTrackerId(Integer podStatusTrackerId) {
		this.podStatusTrackerId = podStatusTrackerId;
	}

	public Integer getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(Integer deliveryId) {
		this.deliveryId = deliveryId;
	}

	public Integer getReqBy() {
		return reqBy;
	}

	public void setReqBy(Integer reqBy) {
		this.reqBy = reqBy;
	}

	public String getStatusReqDate() {
		return statusReqDate;
	}

	public void setStatusReqDate(String statusReqDate) {
		this.statusReqDate = statusReqDate;
	}

	public Integer getPodStatusMstId() {
		return podStatusMstId;
	}

	public void setPodStatusMstId(Integer podStatusMstId) {
		this.podStatusMstId = podStatusMstId;
	}

}