/**
 * 
 */
package com.nelco.o2c.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.FileUploadDTO;
import com.nelco.o2c.dto.OppUploadDetailDTO;
import com.nelco.o2c.dto.PotentialInfoListDTO;
import com.nelco.o2c.dto.PreBidRespMatrixDTO;
import com.nelco.o2c.dto.PreBidTaskResponseDTO;
import com.nelco.o2c.dto.UploadTempFileDTOList;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.service.PotentialInfoService;
import com.nelco.o2c.service.PreBidRespMatrixService;

/**
 * @author Amol.l
 *
 */

@RestController
public class PreBidRespMatrixController {
	
	@Autowired
	PreBidRespMatrixService preBidRespMatrixService;
	
	@Autowired
	PotentialInfoService potentialInfoService;
	
	@RequestMapping(value = "/saveAllPreBidRespMatrixDetails.do", method = RequestMethod.POST)
	public PreBidRespMatrixDTO saveAllPreBidRespMatrixDetails(@RequestBody PreBidRespMatrixDTO preBidRespMatrixDTO,HttpServletRequest request) {
		 preBidRespMatrixService.saveAllPreBidRespMatrixDetails(preBidRespMatrixDTO,request);
		 
		 return preBidRespMatrixService.getPreBidRespMatrixByUserMstIdAndOpId(preBidRespMatrixDTO);
	}
	
	@RequestMapping(value = "/getPreBidRespMatrixByUserMstIdAndOpId.do", method = RequestMethod.POST)
	public PreBidRespMatrixDTO getPreBidRespMatrixByUserMstIdAndOpId(@RequestBody PreBidRespMatrixDTO preBidRespMatrixDTO) {
//		System.out.println(request.getRequestURL().toString().replace(request.getRequestURI(), "").concat(request.getContextPath()).concat("/"));
		return preBidRespMatrixService.getPreBidRespMatrixByUserMstIdAndOpId(preBidRespMatrixDTO);
	}
	
	@RequestMapping(value = "/commonPreBidTasks.do", method = RequestMethod.POST)
	public PotentialInfoListDTO commonPreBidTasks(@RequestBody CommonDTO commonDTO) {
		return preBidRespMatrixService.commonPreBidTasks(commonDTO);
	}
	
	@RequestMapping(value = "/getPreBidResponsesByUserMstIdAndOpId.do", method = RequestMethod.POST)
	public PreBidRespMatrixDTO getPreBidResponsesByUserMstIdAndOpId(@RequestBody PreBidRespMatrixDTO preBidRespMatrixDTO) {
		
		PreBidRespMatrixDTO preBidRespMatrixDTONew = new PreBidRespMatrixDTO();
		preBidRespMatrixDTONew = preBidRespMatrixService.getPreBidResponsesByUserMstIdAndOpId(preBidRespMatrixDTO.getUserMstId(),preBidRespMatrixDTO.getOpportunityId());
		preBidRespMatrixDTONew.setOpportunityName(preBidRespMatrixDTO.getOpportunityName());
		return preBidRespMatrixDTONew;
	}
	
	@RequestMapping(value = "/savePreBidResponses.do", method = RequestMethod.POST)
	public PreBidRespMatrixDTO savePreBidResponses(@RequestBody PreBidTaskResponseDTO preBidTaskResponseDTO,HttpServletRequest request) {
		preBidRespMatrixService.savePreBidResponses(preBidTaskResponseDTO,request);
		PreBidRespMatrixDTO preBidRespMatrixDTO = new PreBidRespMatrixDTO();
		preBidRespMatrixDTO = preBidRespMatrixService.getPreBidResponsesByUserMstIdAndOpId(preBidTaskResponseDTO.getUserMstId(),preBidTaskResponseDTO.getOpportunityId());
		preBidRespMatrixDTO.setOpportunityName(preBidTaskResponseDTO.getOpportunityName());
		return preBidRespMatrixDTO;
	}
	
	@RequestMapping(value = "/getFinalPBResponseByUserMstIdAndOpId.do", method = RequestMethod.POST)
	public PreBidRespMatrixDTO getFinalPBResponseByUserMstIdAndOpId(@RequestBody PreBidRespMatrixDTO preBidRespMatrixDTO) {
		return preBidRespMatrixService.getFinalPBResponseByUserMstIdAndOpId(preBidRespMatrixDTO);
	}
	
	@RequestMapping(value = "/getFileProcUploadDetForTAF.do", method = RequestMethod.POST)
	public FileUploadDTO getFileProcUploadDetForTAF(@RequestBody FileUploadDTO fileUploadDTO) {
		return preBidRespMatrixService.getFileProcUploadDetForTAF(fileUploadDTO);
	}
	
	@RequestMapping(value = "/getFileUpDetForTAFByOppId.do", method = RequestMethod.POST)
	public OppUploadDetailDTO getFileUpDetForTAFByOppId(@RequestBody UploadTempFileDTOList uploadTempFileDTOList) {
		
		OppUploadDetailDTO oppUploadDetailDTO = new OppUploadDetailDTO();
		List<OppUploadDetail> oppUploadDetailList = new ArrayList<OppUploadDetail>();
		 oppUploadDetailList = preBidRespMatrixService.getFileUpDetForTAFByOppId(uploadTempFileDTOList.getOpportunityId());
		 oppUploadDetailDTO.setOppUploadDetailList(oppUploadDetailList);
		 return oppUploadDetailDTO;
		
	}
	
	@RequestMapping(value = "/savePreBidResponseUpload.do", method = RequestMethod.POST)
	public OppUploadDetailDTO savePreBidResponseUpload(@RequestBody UploadTempFileDTOList uploadTempFileDTOList) {
		OppUploadDetailDTO oppUploadDetailDTO = new OppUploadDetailDTO();
		List<OppUploadDetail> oppUploadDetailList = new ArrayList<OppUploadDetail>();
		 preBidRespMatrixService.savePreBidResponseUpload(uploadTempFileDTOList);
		 oppUploadDetailList = preBidRespMatrixService.getFileUpDetForTAFByOppId(uploadTempFileDTOList.getOpportunityId());
		 oppUploadDetailDTO.setOppUploadDetailList(oppUploadDetailList);
		 return oppUploadDetailDTO;
	}
	
	@RequestMapping(value = "/getFileUploadPreDropdowns.do", method = RequestMethod.POST)
	public FileUploadDTO getFileUploadPreDropdowns(@RequestBody FileUploadDTO fileUploadDTO) {
		return preBidRespMatrixService.getFileUploadPreDropdowns(fileUploadDTO);
	}
	
	@RequestMapping(value = "/getFileUpDetForPre.do", method = RequestMethod.POST)
	public OppUploadDetailDTO getFileUpDetForPre(@RequestBody UploadTempFileDTOList uploadTempFileDTOList) {
		
		OppUploadDetailDTO oppUploadDetailDTO = new OppUploadDetailDTO();
		List<OppUploadDetail> oppUploadDetailList = new ArrayList<OppUploadDetail>();
		 oppUploadDetailList = preBidRespMatrixService.getFileUpDetForPre(uploadTempFileDTOList.getOpportunityId(),uploadTempFileDTOList.getRespMatrixDetailsId());
		 oppUploadDetailDTO.setOppUploadDetailList(oppUploadDetailList);
		 return oppUploadDetailDTO;
		
	}
	
	@RequestMapping(value = "/savePreSalesUpload.do", method = RequestMethod.POST)
	public OppUploadDetailDTO savePreSalesUpload(@RequestBody UploadTempFileDTOList uploadTempFileDTOList) {
		OppUploadDetailDTO oppUploadDetailDTO = new OppUploadDetailDTO();
		List<OppUploadDetail> oppUploadDetailList = new ArrayList<OppUploadDetail>();
		 preBidRespMatrixService.savePreSalesUpload(uploadTempFileDTOList);
		 oppUploadDetailList = preBidRespMatrixService.getFileUpDetForPre(uploadTempFileDTOList.getOpportunityId(),uploadTempFileDTOList.getRespMatrixDetailsId());
		 oppUploadDetailDTO.setOppUploadDetailList(oppUploadDetailList);
		 return oppUploadDetailDTO;
	}
	
}
