/**
 * 
 */
package com.nelco.o2c.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.RelocSoDTO;
import com.nelco.o2c.service.RelocSoService;

/**
 * @author Jayshankar.r
 *
 */
@RestController
public class RelocSoController {

	@Autowired
	RelocSoService relocSoService;
	
	@RequestMapping(value = "/getRelocSoList.do", method = RequestMethod.POST)
	public RelocSoDTO getRolocationSoList(@RequestBody RelocSoDTO relocSoInputDTO) {
		return relocSoService.getRolocationSoList(relocSoInputDTO);
	}
	
	@RequestMapping(value = "/getRelocSoById.do", method = RequestMethod.POST)
	public RelocSoDTO getRelocSoById(@RequestBody RelocSoDTO relocSoInputDTO) {
		return relocSoService.getRelocSoById(relocSoInputDTO);
	}
	
	@RequestMapping(value = "/saveRelocSo.do", method = RequestMethod.POST)
	public RelocSoDTO saveRelocSo(@RequestBody RelocSoDTO relocSoInputDTO) {
		return relocSoService.saveRelocSo(relocSoInputDTO);
	}
}
