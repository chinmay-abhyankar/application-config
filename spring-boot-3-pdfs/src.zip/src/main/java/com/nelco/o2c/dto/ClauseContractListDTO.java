/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.ClauseContractMst;

/**
 * @author Amol.l
 *
 */
public class ClauseContractListDTO implements Serializable  {

	private static final long serialVersionUID = 33L;
	
	private List<ClauseContractMst> clauseContMstList = new ArrayList<ClauseContractMst>();

	public List<ClauseContractMst> getClauseContMstList() {
		return clauseContMstList;
	}

	public void setClauseContMstList(List<ClauseContractMst> clauseContMstList) {
		this.clauseContMstList = clauseContMstList;
	}

}
