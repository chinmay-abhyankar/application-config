package com.nelco.o2c.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.nelco.o2c.dto.FrachiseeEngVisitDetailsDTO;
import com.nelco.o2c.model.FaEngVisitDetail;
import com.nelco.o2c.model.FranchiseeAllocationMst;

public interface FranchiseeAllocVisitDao {
	public FaEngVisitDetail saveFranchiseAllocVisitDetails(FrachiseeEngVisitDetailsDTO frachiseeEngVisitDetailsDTO);
	
	public List<FaEngVisitDetail> getEngineerVisitByFranchiseeAllocId(HttpServletRequest request);
	
	public FaEngVisitDetail getFranchiseeAllocEngineerById(HttpServletRequest request);
	
	public FaEngVisitDetail submitFranchiseAllocVisitDetails(FrachiseeEngVisitDetailsDTO dtoObject);

	public FranchiseeAllocationMst getFranchiseAllocationMstById(Integer franchiseAllocId);

	public void sendEmailOnCompletion(FranchiseeAllocationMst franchiseeAllocationMst,FaEngVisitDetail faEngVisitDetail);
}
