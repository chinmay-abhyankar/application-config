package com.nelco.o2c.dto;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nelco.o2c.model.SiteSurveyMaster;
@Service
public class FranchiseeAllocDTO {
	private List<SiteSurveyMaster> siteSurveyList;

	public List<SiteSurveyMaster> getSiteSurveyList() {
		return siteSurveyList;
	}

	public void setSiteSurveyList(List<SiteSurveyMaster> siteSurveyList) {
		this.siteSurveyList = siteSurveyList;
	}

}
