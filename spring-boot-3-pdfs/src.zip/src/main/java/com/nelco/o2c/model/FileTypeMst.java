package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the file_type_mst database table.
 * 
 */
@Entity
@Table(name="file_type_mst")
@NamedQueries({
				@NamedQuery(name="FileTypeMst.findAll", query="SELECT f FROM FileTypeMst f"),
				@NamedQuery(name="FileTypeMst.getPODfileList", query="SELECT f FROM FileTypeMst f where f.fileTypeMstId=29"),
				@NamedQuery(name="FileTypeMst.getFileIdIn", query="SELECT f FROM FileTypeMst f where f.fileTypeMstId in :fileIdList"),
				@NamedQuery(name="FileTypeMst.getFileListByCode", query="SELECT f FROM FileTypeMst f where f.fileTypeCode in :fileCodeList")
})
public class FileTypeMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="file_type_mst_id")
	private Integer fileTypeMstId;

	@Column(name="file_type_code")
	private String fileTypeCode;

	@Column(name="file_type_val")
	private String fileTypeVal;

	public Integer getFileTypeMstId() {
		return fileTypeMstId;
	}

	public void setFileTypeMstId(Integer fileTypeMstId) {
		this.fileTypeMstId = fileTypeMstId;
	}

	public String getFileTypeCode() {
		return fileTypeCode;
	}

	public void setFileTypeCode(String fileTypeCode) {
		this.fileTypeCode = fileTypeCode;
	}

	public String getFileTypeVal() {
		return fileTypeVal;
	}

	public void setFileTypeVal(String fileTypeVal) {
		this.fileTypeVal = fileTypeVal;
	}

	

}