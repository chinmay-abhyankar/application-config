package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.ReactivationRequestMst;

public class ReactivationOnCRFormDTO {
private List<ReactivationListDTO> reactivationRequestList=new ArrayList<ReactivationListDTO>();
private List<ReactivationRequestMst> reactivationRequestDetails=new ArrayList<ReactivationRequestMst>();
private List<ReactivationRequestMst> appRejList=new ArrayList<ReactivationRequestMst>();
List<ReactivationOnCRDTO> soList=new ArrayList<ReactivationOnCRDTO>();

public List<ReactivationRequestMst> getAppRejList() {
	return appRejList;
}

public void setAppRejList(List<ReactivationRequestMst> appRejList) {
	this.appRejList = appRejList;
}

public List<ReactivationRequestMst> getReactivationRequestDetails() {
	return reactivationRequestDetails;
}

public void setReactivationRequestDetails(List<ReactivationRequestMst> reactivationRequestDetails) {
	this.reactivationRequestDetails = reactivationRequestDetails;
}

public List<ReactivationListDTO> getReactivationRequestList() {
	return reactivationRequestList;
}

public void setReactivationRequestList(List<ReactivationListDTO> reactivationRequestList) {
	this.reactivationRequestList = reactivationRequestList;
}

public List<ReactivationOnCRDTO> getSoList() {
	return soList;
}

public void setSoList(List<ReactivationOnCRDTO> soList) {
	this.soList = soList;
}


}
