/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.BrfDetailsDTO;
import com.nelco.o2c.dto.BrfDetailsListDTO;
import com.nelco.o2c.model.Brf;
import com.nelco.o2c.model.DrfDemoDate;
import com.nelco.o2c.model.DrfDetails;

/**
 * @author Amol.l
 *
 */
public interface DrfBrfDao {

	public List<BrfDetailsDTO> getDrfBrfListByDate(BrfDetailsListDTO brfDetailsListDTO);

	public List<BrfDetailsDTO> brfListBySONumAndDate(BrfDetailsListDTO brfDetailsListDTO);

	public Brf drfBrfByBrfId(Integer brfId);

	public Integer getRemainNumSiteBySoNumber(String soNumber,Integer drfDetailsId);

	public void updateDRFDemoDates(DrfDetails drfDetails);

	public DrfDemoDate saveDrfDemoDate(DrfDemoDate drfDemoDate);

}
