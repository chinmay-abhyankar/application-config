/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nelco.o2c.jsonbeanmap.EmdTenderTasksBean;
import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.EmdRequestDetails;
import com.nelco.o2c.model.FileTypeMst;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.Taf;
import com.nelco.o2c.model.TenderFeeRequestDetails;
import com.nelco.o2c.model.TenderTypeMst;

/**
 * @author Jayashankar.r
 *
 */
@Component
public class EmdTenderFeeDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public List<TenderTypeMst> tenderTypeList;

	private List<UserEmailDetailsBean> financeList;

	private List<FileTypeMst> emdFileTypes;
	
	private List<FileTypeMst> tenderFeeFileTypes;
	
	private EmdRequestDetails emdRequestDetails;
	
	private List<OppUploadDetail> oppUploadList;
	
	private Integer oppId;
	
	private Integer userMstId;
	
	private List<EmdTenderTasksBean> tasksBean;
	
	private TenderFeeRequestDetails tenderFeeRequestDetails;
	
	private Taf tahHeader;

	public Taf getTahHeader() {
		return tahHeader;
	}

	public void setTahHeader(Taf tahHeader) {
		this.tahHeader = tahHeader;
	}

	public TenderFeeRequestDetails getTenderFeeRequestDetails() {
		return tenderFeeRequestDetails;
	}

	public void setTenderFeeRequestDetails(TenderFeeRequestDetails tenderFeeRequestDetails) {
		this.tenderFeeRequestDetails = tenderFeeRequestDetails;
	}

	public List<EmdTenderTasksBean> getTasksBean() {
		return tasksBean;
	}

	public void setTasksBean(List<EmdTenderTasksBean> tasksBean) {
		this.tasksBean = tasksBean;
	}

	public Integer getUserMstId() {
		return userMstId;
	}

	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}

	public Integer getOppId() {
		return oppId;
	}

	public void setOppId(Integer oppId) {
		this.oppId = oppId;
	}

	public List<OppUploadDetail> getOppUploadList() {
		return oppUploadList;
	}

	public void setOppUploadList(List<OppUploadDetail> oppUploadList) {
		this.oppUploadList = oppUploadList;
	}

	public EmdRequestDetails getEmdRequestDetails() {
		return emdRequestDetails;
	}

	public void setEmdRequestDetails(EmdRequestDetails emdRequestDetails) {
		this.emdRequestDetails = emdRequestDetails;
	}

	public List<FileTypeMst> getEmdFileTypes() {
		return emdFileTypes;
	}

	public void setEmdFileTypes(List<FileTypeMst> emdFileTypes) {
		this.emdFileTypes = emdFileTypes;
	}

	public List<FileTypeMst> getTenderFeeFileTypes() {
		return tenderFeeFileTypes;
	}

	public void setTenderFeeFileTypes(List<FileTypeMst> tenderFeeFileTypes) {
		this.tenderFeeFileTypes = tenderFeeFileTypes;
	}

	public List<UserEmailDetailsBean> getFinanceList() {
		return financeList;
	}

	public void setFinanceList(List<UserEmailDetailsBean> financeList) {
		this.financeList = financeList;
	}

	public List<TenderTypeMst> getTenderTypeList() {
		return tenderTypeList;
	}

	public void setTenderTypeList(List<TenderTypeMst> tenderTypeList) {
		this.tenderTypeList = tenderTypeList;
	}

}
