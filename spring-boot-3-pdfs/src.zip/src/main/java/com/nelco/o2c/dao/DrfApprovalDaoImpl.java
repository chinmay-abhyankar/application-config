/**
 * 
 */
package com.nelco.o2c.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ibm.icu.util.Calendar;
import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.DrfExtListDTO;
import com.nelco.o2c.dto.ExtendDemoDTO;
import com.nelco.o2c.jsonbeanmap.DrfApprDetailBean;
import com.nelco.o2c.jsonbeanmap.UserEmailDetailsBean;
import com.nelco.o2c.model.DrfApproverDetail;
import com.nelco.o2c.model.DrfExtComment;
import com.nelco.o2c.model.DrfStatusTracker;
import com.nelco.o2c.utility.Constants;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class DrfApprovalDaoImpl implements DrfApprovalDao {

	@PersistenceContext
	private EntityManager em;

	Query query;

	@Override
	public void saveDrfApprovals(List<DrfApproverDetail> drfApproverDetails) {
		// TODO Auto-generated method stub
		try {
			for (DrfApproverDetail drfApproverDetail : drfApproverDetails) {
				em.merge(drfApproverDetail);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public DrfApproverDetail getDrfApprovals(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("DrfApproverDetail.findByDrfApprId", DrfApproverDetail.class);
			query.setParameter(1, commonDTO.getDrfDetailsId());
			query.setParameter(2, commonDTO.getUserMstId());
			query.setMaxResults(1);
			
			List<DrfApproverDetail> resultList = (List<DrfApproverDetail>) query.getResultList();
			
			return (resultList!=null && resultList.size()>0) ?resultList.get(0):new DrfApproverDetail();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new DrfApproverDetail();
		} finally {
			em.close();
		}
	}

	@Override
	public DrfApproverDetail saveSingleDrfApprovals(DrfApproverDetail drfApproverDetail) {
		try {
			// TODO Auto-generated method stub
			DrfApproverDetail drfApproverDetailSaved = em.merge(drfApproverDetail);
			if(drfApproverDetail.getDrfApproverDetailsId()==null)
				em.refresh(drfApproverDetailSaved);
			return drfApproverDetailSaved;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean checkAllApproved(DrfApproverDetail drfApproverDetail) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("DrfApproverDetail.findByDrfId", DrfApproverDetail.class);
			query.setParameter(1, drfApproverDetail.getDrfDetailsId());
			List<DrfApproverDetail> drfApproverDetails = query.getResultList();
			boolean returnFlag = false;

			for (DrfApproverDetail drfApproverDetail2 : drfApproverDetails) {
				if (drfApproverDetail2.getApprFlg().equals(Constants.DRFAPPROVALSTATUS))
					returnFlag = true;
				else {
					returnFlag = false;
					break;
				}
			}
			return returnFlag;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		} finally {
			em.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean checkDrfRejectStatus(DrfApproverDetail drfApproverDetail) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("DrfStatusTracker.checkDrfRejectStatus", DrfStatusTracker.class);
			query.setParameter(1, drfApproverDetail.getDrfDetailsId());
			List<DrfStatusTracker> drfApproverDetails = query.getResultList();
			boolean returnFlag = false;

			if (drfApproverDetails != null && drfApproverDetails.size() > 0) {
				returnFlag = true;
			} else {
				returnFlag = false;
			}

			return returnFlag;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		} finally {
			em.close();
		}
	}

	@Override
	public void insertStatusTracker(DrfStatusTracker drfStatusTracker) {
		// TODO Auto-generated method stub
		em.merge(drfStatusTracker);
	}

	@SuppressWarnings({ "unchecked" })
	@Override
	public DrfApprDetailBean getDrfPeopleDetails(CommonDTO commonDTO) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("DrfDetails.getDrfPeopleDetails");
		query.setParameter(1, commonDTO.getDrfDetailsId());
		List<Object[]> objs = (List<Object[]>) query.getResultList();
		DrfApprDetailBean drfApprDetailBean = null;
		if (objs.size() > 0) {
			drfApprDetailBean = new DrfApprDetailBean();
			for (Object[] object : objs) {
				drfApprDetailBean.setPreSalesId((String) object[0]);
				drfApprDetailBean.setAccMgrId((String) object[1]);
				drfApprDetailBean.setPrgManagerId((String) object[2]);
				drfApprDetailBean.setTechApprId((String) object[3]);
				drfApprDetailBean.setOpHeadId((String) object[4]);
				drfApprDetailBean.setPmgtHeadId((String) object[5]);
				drfApprDetailBean.setPreSalesHeadId((String) object[6]);
				drfApprDetailBean.setCustName((String) object[7]);
				drfApprDetailBean.setEboSalesHeadId(object[8]!=null ? (Integer)object[8]:null);
				drfApprDetailBean.setVpSalesId(object[9]!=null ? (Integer)object[9]:null);
				drfApprDetailBean.setCeoId(object[10]!=null ? (Integer)object[10]:null);
			}

		}
		System.out.println("Approval Details -------");
		return drfApprDetailBean;
	}

	@SuppressWarnings("unchecked")
	@Override
	public UserEmailDetailsBean getUserEmailDetails(UserEmailDetailsBean bean) {
		UserEmailDetailsBean retBean = new UserEmailDetailsBean();
		query = em.createNamedQuery("UserMst.getEmailDetails");
		query.setParameter(1, Integer.valueOf(bean.getUserId()));
		List<Object[]> objs = (List<Object[]>) query.getResultList();
		for (Object[] objects : objs) {
			retBean.setUserId(bean.getUserId());
			retBean.setUserName((String) objects[0]);
			retBean.setUserMail((String) objects[1]);
			retBean.setLoginId((String) objects[2]);
			retBean.setUserMstId((Integer) objects[3]);
		}
		return retBean;
	}

	@Override
	public UserEmailDetailsBean getUserEmailDetailsByOpportunity(UserEmailDetailsBean bean) {
		//GETTING THE smowner id by passing opp id
		query = em.createNamedQuery("Opportunity.getSmownerByOppId");
		query.setParameter(1, Integer.valueOf(bean.getOppId()));
		@SuppressWarnings("unchecked")
		List<Object[]> res = (List<Object[]>) query.getResultList();
		for (Object[] objects : res) {
			bean.setSmOwnerId((String)objects[1]);
		}
		
		UserEmailDetailsBean retBean = new UserEmailDetailsBean();
		query = em.createNamedQuery("UserMst.getEmailDetailsBySmOwnerId");
		query.setParameter(1, bean.getSmOwnerId());
		@SuppressWarnings("unchecked")
		List<Object[]> objs = (List<Object[]>) query.getResultList();
		for (Object[] objects : objs) {
			retBean.setUserId(bean.getUserId());
			retBean.setUserName((String) objects[0]);
			retBean.setUserMail((String) objects[1]);
		}
		return retBean;
	}

	@Override
	public DrfExtComment saveDrfExtComment(DrfExtComment drfExtComment) {
		// TODO Auto-generated method stub
		try {
			return em.merge(drfExtComment);
		} finally {
			em.close();
		}
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public DrfExtComment getDrfCommentByDrfAndUserId(Integer userMstId, Integer drfDetailsId) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("DrfExtComment.getByDrfAndUserMstId");
			query.setParameter("userMstId", userMstId);
			query.setParameter("drfDetailsId", drfDetailsId);
			query.setMaxResults(1);
			List<DrfExtComment> resultList = (List<DrfExtComment>) query.getResultList();
			return resultList != null && resultList.size() > 0 ? resultList.get(0) : null;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public void updateVpsInDrf(Integer userMstId,Integer drfDetailsId) {
		try {
			// TODO Auto-generated method stub
			query = em.createQuery(
					"update DrfDetails d set d.vpSalesId = :userMstId where d.drfDetailsId = :drfDetailsId ");
			query.setParameter("userMstId", userMstId);
			query.setParameter("drfDetailsId", drfDetailsId);
			query.executeUpdate();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

	@Override
	public void updateEboSalesHeadInDrf(Integer userMstId,Integer drfDetailsId) {
		// TODO Auto-generated method stub
		try {
		query = em.createQuery("update DrfDetails d set d.eboSalesHeadId = :userMstId where d.drfDetailsId = :drfDetailsId ");
		query.setParameter("userMstId", userMstId);
		query.setParameter("drfDetailsId", drfDetailsId);
		query.executeUpdate();
	} finally {
		// TODO: handle finally clause
		em.close();
	}
	}

	@Override
	public void updateMdInDrf(Integer userMstId,Integer drfDetailsId) {
		// TODO Auto-generated method stub
		try {
		query = em.createQuery("update DrfDetails d set d.ceoId = :userMstId where d.drfDetailsId = :drfDetailsId ");
		query.setParameter("userMstId", userMstId);
		query.setParameter("drfDetailsId", drfDetailsId);
		query.executeUpdate();
	} finally {
		// TODO: handle finally clause
		em.close();
	}
	}

	@Override
	public List<DrfExtComment> getExtensionComments(ExtendDemoDTO extendDemoInputDTO) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("DrfExtComment.getByDrfId");
		query.setParameter("drfDetailsId", extendDemoInputDTO.getDrfDetailsId());
		
		List<DrfExtComment> resultCommentList = (List<DrfExtComment>) query.getResultList();
		
		return resultCommentList!=null && resultCommentList.size()>0?resultCommentList:new ArrayList<DrfExtComment>();
	}

	@Override
	public void updateDrfStatus(Integer drfDetailsId, Integer statusMstId) {
		// TODO Auto-generated method stub
		query = em.createQuery("update DrfDetails d set d.statusMstId = :statusMstId where d.drfDetailsId = :drfDetailsId");
		query.setParameter("statusMstId", statusMstId);
		query.setParameter("drfDetailsId", drfDetailsId);
		
		query.executeUpdate();
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public void updateDrfDemoDates(Integer drfDetailsId) throws ParseException {
		// TODO Auto-generated method stub
		query = em.createQuery("select d.demoStart,d.demoEnd from DrfDetails d where d.drfDetailsId = :drfDetailsId ");
		query.setParameter("drfDetailsId", drfDetailsId);
		String demoStart = null;
		String demoEnd = null;
		
		List<Object[]> resultList = (List<Object[]>)query.getResultList();
		for (Object[] objects : resultList) {
			demoStart = (String) objects[0];
			demoEnd = (String) objects[1];
		}
		
		if(demoStart!=null && demoEnd !=null) {
			Calendar c = Calendar.getInstance();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			c.setTime(formatter.parse(demoEnd));
		    c.add(Calendar.DAY_OF_MONTH, 15);  
		    demoEnd = formatter.format(c.getTime()); 
			query = em.createQuery("update DrfDetails d set d.demoEnd = :demoEnd where d.drfDetailsId = :drfDetailsId");
			query.setParameter("demoEnd", demoEnd);
			query.setParameter("drfDetailsId", drfDetailsId);
			
			query.executeUpdate();
		}
		
	}

	@Override
	public void updateDrfApprovalFlag(Integer drfDetailsId, String flag) {
		// TODO Auto-generated method stub
		
		query = em.createQuery("update DrfApproverDetail d set d.isActive = :flag where d.drfDetailsId = :drfDetailsId ");
		query.setParameter("drfDetailsId", drfDetailsId);
		query.setParameter("flag", flag);
		query.executeUpdate();
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getDrfExtensionList(DrfExtListDTO drfExtListInputDTO) {
		// TODO Auto-generated method stub
		try {
			StringBuilder queryStr = new StringBuilder();
			queryStr.append("select d.drf_details_id,d.cust_name,d.market_segment,CONVERT(varchar, d.demo_start, 105) as demostart,"
					+ " CONVERT(varchar, d.demo_end, 105) as demoend,"
					+ " CONVERT(varchar, d.created_date, 105) as createddate,sm.status_name,"
					+ " sm.status_code,sm.status_mst_id,CONVERT(varchar, dt.req_date, 105) as reqdate from drf_details d "
					+ " inner join "
					+ " (select drf_status_tracker_id,status_mst_id,req_date,drf_details_id "
					+ " from (select drf_status_tracker_id,status_mst_id,req_date,drf_details_id, "
					+ " ROW_NUMBER() over(partition by drf_details_id order by req_date desc) as cnt "
					+ " from drf_status_tracker "
					+ " group by drf_details_id,drf_status_tracker_id,status_mst_id,req_date) tbl where cnt =1 ) dt "
					+ " on d.drf_details_id = dt.drf_details_id inner join status_mst sm on dt.status_mst_id = sm.status_mst_id ");
			if(drfExtListInputDTO.getRoleCode()!=null && drfExtListInputDTO.getRoleCode().equalsIgnoreCase("MD")) {
				queryStr.append(" where sm.status_code in ('DRFSTSTC') and d.ceo_id = :userMstId ");
			} else if(drfExtListInputDTO.getRoleCode()!=null && drfExtListInputDTO.getRoleCode().equalsIgnoreCase("EBOHEAD")) {
				queryStr.append(" where sm.status_code in ('DRFSTSEA') and d.ebo_sales_head_id = :userMstId ");
			} else if(drfExtListInputDTO.getRoleCode()!=null && drfExtListInputDTO.getRoleCode().equalsIgnoreCase("VPS")) {
				queryStr.append(" where sm.status_code in ('DRFSTSEA') and d.vp_sales_id = :userMstId ");
			}
			
			query = em.createNativeQuery(queryStr.toString());
			query.setParameter("userMstId", drfExtListInputDTO.getUserMstId());
			return (List<Object[]>) query.getResultList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<Object[]>();
		}
	}

}
