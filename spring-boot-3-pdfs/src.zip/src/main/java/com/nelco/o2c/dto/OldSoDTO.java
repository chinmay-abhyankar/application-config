/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

import com.nelco.o2c.utility.DateUtil;

/**
 * @author Amol.l
 *
 */
public class OldSoDTO implements Serializable {

	private static final long serialVersionUID = 93L;
	private String oldSoNum;
	private String tentActDate;
	private String newSoActDate;
	private String newSoNum;
	
	public OldSoDTO() {
		
	}

	public String getOldSoNum() {
		return oldSoNum;
	}

	public void setOldSoNum(String oldSoNum) {
		this.oldSoNum = oldSoNum;
	}

	public String getNewSoNum() {
		return newSoNum;
	}

	public void setNewSoNum(String newSoNum) {
		this.newSoNum = newSoNum;
	}

	public String getTentActDate() {
		return tentActDate;
	}

	public void setTentActDate(String tentActDate) {
		this.tentActDate = tentActDate;
	}

	public String getNewSoActDate() {
		return newSoActDate;
	}

	public void setNewSoActDate(String newSoActDate) {
		this.newSoActDate = newSoActDate;
	};

	
}
