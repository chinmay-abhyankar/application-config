/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

/**
 * @author Jayshankar.r
 *
 */
public class ScreenExcelDownloadDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fromDate;
	private String toDate;
	private Integer userMstId;
	private String roleCode;
	private Integer proposalId;
	private Integer roleMstId;
	private String statusCode;
	private String smownerId;
	
	public String getSmownerId() {
		return smownerId;
	}
	public void setSmownerId(String smownerId) {
		this.smownerId = smownerId;
	}
	public Integer getRoleMstId() {
		return roleMstId;
	}
	public void setRoleMstId(Integer roleMstId) {
		this.roleMstId = roleMstId;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public Integer getProposalId() {
		return proposalId;
	}
	public void setProposalId(Integer proposalId) {
		this.proposalId = proposalId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	
	

}
