package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;

/**
 * The persistent class for the po_approval_details database table.
 * 
 */
@Entity
@Table(name = "po_approval_details")
@NamedQueries({ @NamedQuery(name = "PoApprovalDetail.findAll", query = "SELECT p FROM PoApprovalDetail p"),
	@NamedQuery(name = "PoApprovalDetail.getApprovalDetByPropIdAndUserId", query = "select p from PoApprovalDetail p where p.proposalId=?1 and p.apprById=?2 and p.isActive='Y' order by p.poApprovalDetailsId desc"),
	@NamedQuery(name = "PoApprovalDetail.findByProposalId", query = " select p from PoApprovalDetail p where p.proposalId=?1 and p.isActive='Y'"),
	@NamedQuery(name = "PoApprovalDetail.updateIsActivebyProposalIdAndApprId", query = " update PoApprovalDetail p set p.isActive=?1 where p.proposalId=?2 "),//and p.apprById=?3 
	@NamedQuery(name = "PoApprovalDetail.getActiveApproverByProposalId", query = "select new PoApprovalDetail(p.actTime, p.apprById,"
			+ " p.apprFlag, p.apprReason, p.proposalId, u.userName) "
			+ "from PoApprovalDetail p inner join UserMst u on p.apprById = u.userMstId where p.proposalId=?1 and p.isActive = 'Y'")})
public class PoApprovalDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "po_approval_details_id")
	private Integer poApprovalDetailsId;

	@Column(name = "act_time")
	private String actTime;

	@Column(name = "appr_by_id")
	private Integer apprById;

	@Column(name = "appr_flag")
	private String apprFlag;

	@Column(name = "appr_reason")
	private String apprReason;

	@Column(name = "proposal_id")
	private Integer proposalId;
	
	@Column(name = "is_active")
	private String isActive="Y";
	
	private String approverName;
	
	@Column(name = "uuid_key")
	private String uuidKey;
	
	
	
	public String getUuidKey() {
		return uuidKey;
	}

	public void setUuidKey(String uuidKey) {
		this.uuidKey = uuidKey;
	}

	public PoApprovalDetail(){
		
	}

	public PoApprovalDetail(String actTime, Integer apprById, String apprFlag, String apprReason, Integer proposalId,
			String approverName) {
		super();
		this.actTime = DateUtil.convertDateTimeToString(actTime);
		this.apprById = apprById;
		this.apprFlag = apprFlag;
		this.apprReason = apprReason;
		this.proposalId = proposalId;
		this.approverName = approverName;
	}

	public String getApproverName() {
		return approverName;
	}

	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public Integer getPoApprovalDetailsId() {
		return poApprovalDetailsId;
	}

	public void setPoApprovalDetailsId(Integer poApprovalDetailsId) {
		this.poApprovalDetailsId = poApprovalDetailsId;
	}

	public String getActTime() {
		return actTime;
	}

	public void setActTime(String actTime) {
		this.actTime = actTime;
	}

	public Integer getApprById() {
		return apprById;
	}

	public void setApprById(Integer apprById) {
		this.apprById = apprById;
	}

	public String getApprFlag() {
		return apprFlag;
	}

	public void setApprFlag(String apprFlag) {
		this.apprFlag = apprFlag;
	}

	public String getApprReason() {
		return apprReason;
	}

	public void setApprReason(String apprReason) {
		this.apprReason = apprReason;
	}

	public Integer getProposalId() {
		return proposalId;
	}

	public void setProposalId(Integer proposalId) {
		this.proposalId = proposalId;
	}
}