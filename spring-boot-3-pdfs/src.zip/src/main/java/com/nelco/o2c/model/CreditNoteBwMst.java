package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the credit_note_bw_mst database table.
 * 
 */
@Entity
@Table(name="credit_note_bw_mst")
@NamedQueries({@NamedQuery(name="CreditNoteBwMst.findAll", query="SELECT h FROM CreditNoteBwMst h ")
,@NamedQuery(name="CreditNoteBwMst.findByCrNo",query="select h from CreditNoteBwMst h where h.bandwidthCrNo=?1")

		
})
public class CreditNoteBwMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="amount")
	private BigDecimal amount;
	
	@Column(name="assignment")
	private String assignment;

	@Column(name="bandwidth_cr_no")
	private String bandwidthCrNo;

	

	@Column(name="comp_code")
	private String compCode;

	@Column(name="customer_code")
	private String customerCode;

	@Column(name="doc_date")
	private String docDate;

	@Column(name="document_type")
	private String documentType;

	@Column(name="fiscal_year")
	private String fiscalYear;

	@Column(name="posting_date")
	private String postingDate;
	@Column(name="reference")
	private String reference;

	
	

	public void setDocDate(String docDate) {
		this.docDate = docDate;
	}

	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}

	public CreditNoteBwMst() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public BigDecimal getAmount() {
		return this.amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getAssignment() {
		return this.assignment;
	}

	public void setAssignment(String assignment) {
		this.assignment = assignment;
	}

	public String getBandwidthCrNo() {
		return this.bandwidthCrNo;
	}

	public void setBandwidthCrNo(String bandwidthCrNo) {
		this.bandwidthCrNo = bandwidthCrNo;
	}

	

	public String getCompCode() {
		return this.compCode;
	}

	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}

	public String getCustomerCode() {
		return this.customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public Object getDocDate() {
		return this.docDate;
	}

	

	public String getDocumentType() {
		return this.documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getFiscalYear() {
		return this.fiscalYear;
	}

	public void setFiscalYear(String fiscalYear) {
		this.fiscalYear = fiscalYear;
	}

	public Object getPostingDate() {
		return this.postingDate;
	}

	

	public String getReference() {
		return this.reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

}