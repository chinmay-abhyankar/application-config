package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the dist_channel_mst database table.
 * 
 */
@Entity
@Table(name="dist_channel_mst")
@NamedQuery(name="DistChannelMst.findAll", query="SELECT d FROM DistChannelMst d")
public class DistChannelMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="dist_channel_mst_id")
	private int distChannelMstId;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="dc_code")
	private String dcCode;

	@Column(name="dc_desc")
	private String dcDesc;

	@Column(name="is_active")
	private String isActive;

	private String sequence;

	public DistChannelMst() {
	}

	public int getDistChannelMstId() {
		return this.distChannelMstId;
	}

	public void setDistChannelMstId(int distChannelMstId) {
		this.distChannelMstId = distChannelMstId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDcCode() {
		return this.dcCode;
	}

	public void setDcCode(String dcCode) {
		this.dcCode = dcCode;
	}

	public String getDcDesc() {
		return this.dcDesc;
	}

	public void setDcDesc(String dcDesc) {
		this.dcDesc = dcDesc;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getSequence() {
		return this.sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

}