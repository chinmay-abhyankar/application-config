/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

/**
 * @author Amol.l
 *
 */
public class GeoTempDTO implements Serializable {
	private static final long serialVersionUID = 90L;

	private String marketSegment;
	private String conEndDate;
	private String conStartDate;
	private String quarter;
	private String sapContractNum;
	private String bwAllocation;
	private String existingSite;
	private String oldSoNum;
	private Integer geoTemplateId;
	private String amsl;
	private String antennaMake;
	private String antennaSize;
	private String band;
	private Integer brfId;
	private String bucSerialNum;
	private String bwSatelliteDet;
	private String cableLength;
	private String createdDate;
	private Integer franchiseMstId;
	private String heightOfAntenna;
	private String heightOfBuilding;
	private String heightOfMast;
	private String hsnNum;
	private String iduSerial;
	private String installDate;
	private String ladderLenght;
	private String lanIp;
	private String lanSubnetMask;
	private String latitude;
	private String lnbcSerialNum;
	private String longitude;
	private String monkeyCage;
	private String newVsatIp;
	private String poNum;
	private String racCode;
	private String requestDate;
	private String requestType;
	private String sacfa;
	private String soNum;
	private String soldToParty;
	private String subSoldToParty;
	private String technology;
	private String tramsmitterOpPower;
	private String ups;
	private String vsatId;
	private String vsatIp;
	private String vsatSubnetMask;
	private Integer statusMstId;
	private String newPostalAddress;
	private String region;
	private String location;
	private String icInvoice;
	private String serialNum;
	private String hub;
	private String statusCode;
	private String statusName;
	private String franchiseName;
	private String siteName;  // Number of Site
	
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getHub() {
		return hub;
	}
	public void setHub(String hub) {
		this.hub = hub;
	}
	public String getMarketSegment() {
		return marketSegment;
	}
	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}
	public String getConEndDate() {
		return conEndDate;
	}
	public void setConEndDate(String conEndDate) {
		this.conEndDate = conEndDate;
	}
	public String getConStartDate() {
		return conStartDate;
	}
	public void setConStartDate(String conStartDate) {
		this.conStartDate = conStartDate;
	}
	public String getQuarter() {
		return quarter;
	}
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}
	public String getSapContractNum() {
		return sapContractNum;
	}
	public void setSapContractNum(String sapContractNum) {
		this.sapContractNum = sapContractNum;
	}
	public String getBwAllocation() {
		return bwAllocation;
	}
	public void setBwAllocation(String bwAllocation) {
		this.bwAllocation = bwAllocation;
	}
	public String getExistingSite() {
		return existingSite;
	}
	public void setExistingSite(String existingSite) {
		this.existingSite = existingSite;
	}
	public String getOldSoNum() {
		return oldSoNum;
	}
	public void setOldSoNum(String oldSoNum) {
		this.oldSoNum = oldSoNum;
	}
	public Integer getGeoTemplateId() {
		return geoTemplateId;
	}
	public void setGeoTemplateId(Integer geoTemplateId) {
		this.geoTemplateId = geoTemplateId;
	}
	public String getAmsl() {
		return amsl;
	}
	public void setAmsl(String amsl) {
		this.amsl = amsl;
	}
	public String getAntennaMake() {
		return antennaMake;
	}
	public void setAntennaMake(String antennaMake) {
		this.antennaMake = antennaMake;
	}
	public String getAntennaSize() {
		return antennaSize;
	}
	public void setAntennaSize(String antennaSize) {
		this.antennaSize = antennaSize;
	}
	public String getBand() {
		return band;
	}
	public void setBand(String band) {
		this.band = band;
	}
	public Integer getBrfId() {
		return brfId;
	}
	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}
	public String getBucSerialNum() {
		return bucSerialNum;
	}
	public void setBucSerialNum(String bucSerialNum) {
		this.bucSerialNum = bucSerialNum;
	}
	public String getBwSatelliteDet() {
		return bwSatelliteDet;
	}
	public void setBwSatelliteDet(String bwSatelliteDet) {
		this.bwSatelliteDet = bwSatelliteDet;
	}
	public String getCableLength() {
		return cableLength;
	}
	public void setCableLength(String cableLength) {
		this.cableLength = cableLength;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getHeightOfAntenna() {
		return heightOfAntenna;
	}
	public void setHeightOfAntenna(String heightOfAntenna) {
		this.heightOfAntenna = heightOfAntenna;
	}
	public String getHeightOfBuilding() {
		return heightOfBuilding;
	}
	public void setHeightOfBuilding(String heightOfBuilding) {
		this.heightOfBuilding = heightOfBuilding;
	}
	public String getHeightOfMast() {
		return heightOfMast;
	}
	public void setHeightOfMast(String heightOfMast) {
		this.heightOfMast = heightOfMast;
	}
	public String getHsnNum() {
		return hsnNum;
	}
	public void setHsnNum(String hsnNum) {
		this.hsnNum = hsnNum;
	}
	public String getIduSerial() {
		return iduSerial;
	}
	public void setIduSerial(String iduSerial) {
		this.iduSerial = iduSerial;
	}
	public String getInstallDate() {
		return installDate;
	}
	public void setInstallDate(String installDate) {
		this.installDate = installDate;
	}
	public String getLadderLenght() {
		return ladderLenght;
	}
	public void setLadderLenght(String ladderLenght) {
		this.ladderLenght = ladderLenght;
	}
	public String getLanIp() {
		return lanIp;
	}
	public void setLanIp(String lanIp) {
		this.lanIp = lanIp;
	}
	public String getLanSubnetMask() {
		return lanSubnetMask;
	}
	public void setLanSubnetMask(String lanSubnetMask) {
		this.lanSubnetMask = lanSubnetMask;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLnbcSerialNum() {
		return lnbcSerialNum;
	}
	public void setLnbcSerialNum(String lnbcSerialNum) {
		this.lnbcSerialNum = lnbcSerialNum;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getMonkeyCage() {
		return monkeyCage;
	}
	public void setMonkeyCage(String monkeyCage) {
		this.monkeyCage = monkeyCage;
	}
	public String getNewVsatIp() {
		return newVsatIp;
	}
	public void setNewVsatIp(String newVsatIp) {
		this.newVsatIp = newVsatIp;
	}
	public String getPoNum() {
		return poNum;
	}
	public void setPoNum(String poNum) {
		this.poNum = poNum;
	}
	public String getRacCode() {
		return racCode;
	}
	public void setRacCode(String racCode) {
		this.racCode = racCode;
	}
	public String getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getSacfa() {
		return sacfa;
	}
	public void setSacfa(String sacfa) {
		this.sacfa = sacfa;
	}
	public String getSoNum() {
		return soNum;
	}
	public void setSoNum(String soNum) {
		this.soNum = soNum;
	}
	public String getSoldToParty() {
		return soldToParty;
	}
	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}
	public String getSubSoldToParty() {
		return subSoldToParty;
	}
	public void setSubSoldToParty(String subSoldToParty) {
		this.subSoldToParty = subSoldToParty;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getTramsmitterOpPower() {
		return tramsmitterOpPower;
	}
	public void setTramsmitterOpPower(String tramsmitterOpPower) {
		this.tramsmitterOpPower = tramsmitterOpPower;
	}
	public String getUps() {
		return ups;
	}
	public void setUps(String ups) {
		this.ups = ups;
	}
	public String getVsatId() {
		return vsatId;
	}
	public void setVsatId(String vsatId) {
		this.vsatId = vsatId;
	}
	public String getVsatIp() {
		return vsatIp;
	}
	public void setVsatIp(String vsatIp) {
		this.vsatIp = vsatIp;
	}
	public String getVsatSubnetMask() {
		return vsatSubnetMask;
	}
	public void setVsatSubnetMask(String vsatSubnetMask) {
		this.vsatSubnetMask = vsatSubnetMask;
	}
	public Integer getStatusMstId() {
		return statusMstId;
	}
	public void setStatusMstId(Integer statusMstId) {
		this.statusMstId = statusMstId;
	}
	public String getNewPostalAddress() {
		return newPostalAddress;
	}
	public void setNewPostalAddress(String newPostalAddress) {
		this.newPostalAddress = newPostalAddress;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getIcInvoice() {
		return icInvoice;
	}
	public void setIcInvoice(String icInvoice) {
		this.icInvoice = icInvoice;
	}
	public String getSerialNum() {
		return serialNum;
	}
	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public Integer getFranchiseMstId() {
		return franchiseMstId;
	}
	public void setFranchiseMstId(Integer franchiseMstId) {
		this.franchiseMstId = franchiseMstId;
	}
	public String getFranchiseName() {
		return franchiseName;
	}
	public void setFranchiseName(String franchiseName) {
		this.franchiseName = franchiseName;
	}
	
	
	
}
