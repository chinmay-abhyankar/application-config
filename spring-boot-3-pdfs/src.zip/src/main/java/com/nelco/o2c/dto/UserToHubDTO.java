/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;

/**
 * @author Amol.l
 *
 */
public class UserToHubDTO   implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 98L;

	private Integer userMstId;
	private String userName;
	private String userEmail;
	private String isUserActive;
	private Integer deptMstId;
	private Integer subDepMstId;
	private Integer roleId;
	private Integer zoneMstId;
	private String headFlag;
	private String password;
	private String loginId;
	private String smOwnerId;
	private String orgCode;
	private Integer hubMstId;
	private String hubCode;
	private String hubDesc;
	private String isHubActive;
	private String nocInstaEmail;
	
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getIsUserActive() {
		return isUserActive;
	}
	public void setIsUserActive(String isUserActive) {
		this.isUserActive = isUserActive;
	}
	public Integer getDeptMstId() {
		return deptMstId;
	}
	public void setDeptMstId(Integer deptMstId) {
		this.deptMstId = deptMstId;
	}
	public Integer getSubDepMstId() {
		return subDepMstId;
	}
	public void setSubDepMstId(Integer subDepMstId) {
		this.subDepMstId = subDepMstId;
	}
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public Integer getZoneMstId() {
		return zoneMstId;
	}
	public void setZoneMstId(Integer zoneMstId) {
		this.zoneMstId = zoneMstId;
	}
	public String getHeadFlag() {
		return headFlag;
	}
	public void setHeadFlag(String headFlag) {
		this.headFlag = headFlag;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getSmOwnerId() {
		return smOwnerId;
	}
	public void setSmOwnerId(String smOwnerId) {
		this.smOwnerId = smOwnerId;
	}
	public String getOrgCode() {
		return orgCode;
	}
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}
	public Integer getHubMstId() {
		return hubMstId;
	}
	public void setHubMstId(Integer hubMstId) {
		this.hubMstId = hubMstId;
	}
	public String getHubCode() {
		return hubCode;
	}
	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}
	public String getHubDesc() {
		return hubDesc;
	}
	public void setHubDesc(String hubDesc) {
		this.hubDesc = hubDesc;
	}
	public String getIsHubActive() {
		return isHubActive;
	}
	public void setIsHubActive(String isHubActive) {
		this.isHubActive = isHubActive;
	}
	public String getNocInstaEmail() {
		return nocInstaEmail;
	}
	public void setNocInstaEmail(String nocInstaEmail) {
		this.nocInstaEmail = nocInstaEmail;
	}
	
}
