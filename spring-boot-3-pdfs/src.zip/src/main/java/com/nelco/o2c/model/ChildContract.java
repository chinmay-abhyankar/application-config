package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.nelco.o2c.utility.DateUtil;

/**
 * The persistent class for the child_contract database table.
 * 
 */
@Entity
@Table(name = "child_contract")
@NamedQueries({ @NamedQuery(name = "ChildContract.findAll", query = "SELECT c FROM ChildContract c where c.sapContractNum is null and c.isSubmit = 'Y'"),
		@NamedQuery(name = "ChildContract.getChildConByConId", query = "SELECT c from ChildContract c where c.contractId =?1 "),
		@NamedQuery(name = "ChildContract.getChildConBychildConId", query = "SELECT c from ChildContract c where c.childContractId =?1 "),
		@NamedQuery(name = "ChildContract.getChildConBySapContNum", query = "SELECT c from ChildContract c where c.sapContractNum =?1 "),
		@NamedQuery(name = "ChildContract.getChildConByConIdAndDate", query = "SELECT c.childContractId,c.sapContractNum,"
				+ " c.poNumber,c.conStartDate,c.conEndDate,c.marketSegment,"
				+ " c.quarter,rel.contStatus, "
				+ " c.createdDate,ccust.customerName,cncust.customerName,"
				+ " cn.contractId,"
				+ " ccust.customerSapmstId,ccust.soldToParty,"
				+ " cncust.customerSapmstId,cncust.soldToParty,c.isSubmit,c.soldToParty"
				+ " from ChildContract c inner join c.contract cn "
				+ " left join c.customerSapmst ccust "
				+ " left join cn.customerSapmst cncust "
				+ " left join c.contRelStatusSapmst rel "
				+ " where c.createdDate between ?1 and ?2 and c.contractId=?3 "),
		@NamedQuery(name = "ChildContract.getChildConByDate", query = "SELECT c.childContractId,c.sapContractNum,"
				+ " c.poNumber,c.conStartDate,c.conEndDate,c.marketSegment,"
				+ " c.quarter,rel.contStatus, "
				+ " c.createdDate,ccust.customerName,cncust.customerName, "
				+ " cn.contractId,"
				+ " ccust.customerSapmstId,ccust.soldToParty,"
				+ " cncust.customerSapmstId,cncust.soldToParty,c.isSubmit,c.soldToParty"
				+ " from ChildContract c inner join c.contract cn "
				+ " left join c.customerSapmst ccust "
				+ " left join cn.customerSapmst cncust "
				+ " left join c.contRelStatusSapmst rel "
				+ " where c.createdDate between ?1 and ?2 order by c.createdDate desc "),
		@NamedQuery(name = "ChildContract.getChildConByConIdAndDateFinance", query = " select c.childContractId,c.sapContractNum, " + 
				" c.poNumber,c.conStartDate,c.conEndDate,c.marketSegment, " + 
				" c.quarter,crel.contStatus, " + 
				" c.createdDate,ccust.customerName,cncust.customerName, " 
				+ " cn.contractId, "
				+ " ccust.customerSapmstId,ccust.soldToParty,"
				+ " cncust.customerSapmstId,cncust.soldToParty,c.isSubmit,c.soldToParty"+
				" from ChildContract c inner join c.contract cn " +
				" inner join c.contRelStatusSapmst crel " + 
				" left join c.customerSapmst ccust " + 
				" left join cn.customerSapmst cncust " + 
				"  where c.createdDate between ?1 and ?2 and c.contractId=?3 and c.isSubmit='Y' and (c.sapContractNum!='' or c.sapContractNum!=null) and crel.contStatus!='E0002' "),
		@NamedQuery(name = "ChildContract.updateRemarksFinance", query = " update ChildContract c set c.finRemarks=?1,c.finRemarksById=?2,c.financeUpdatedTime=?3 where c.childContractId=?4 "),
//		@NamedQuery(name = "ChildContract.getBrfListByDate", query = "SELECT c from ChildContract c inner join c.contract con inner join con.proposal p inner join p.serviceOrderMst som left join c.brf b left join b.statusMst sm where som.serviceOrderDetId in (3,4) and c.createdDate between ?1 and ?2 and c.sapContractNum is not null"),
//		@NamedQuery(name = "ChildContract.getGeoTemplateListByBrfId", query = "SELECT c from ChildContract c inner join c.contract con inner join con.proposal p inner join p.serviceOrderMst som inner join c.brf b left join b.statusMst sm where som.serviceOrderDetId in (3,4) and c.createdDate between ?1 and ?2 and c.sapContractNum is not null and b.statusMstId= 23 "),
		@NamedQuery(name = "ChildContract.getChildConByDatePM", query = "SELECT c.childContractId,c.sapContractNum,"
				+ " c.poNumber,c.conStartDate,c.conEndDate,c.marketSegment,"
				+ " c.quarter,rel.contStatus, "
				+ " c.createdDate,ccust.customerName,cncust.customerName, "
				+ " cn.contractId,"
				+ " ccust.customerSapmstId,ccust.soldToParty,"
				+ " cncust.customerSapmstId,cncust.soldToParty,c.isSubmit,c.soldToParty"
				+ " from ChildContract c inner join c.contract cn "
				+ " left join c.customerSapmst ccust "
				+ " left join cn.customerSapmst cncust "
				+ " left join c.contRelStatusSapmst rel "
				+ " where c.createdDate between ?1 and ?2 and c.pmId = ?3 order by c.createdDate desc ")})

public class ChildContract implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "child_contract_id")
	private Integer childContractId;

	@Column(name = "contract_id")
	private Integer contractId;

	@Column(name = "acc_mgr_code")
	private String accMgrCode;

	@Column(name = "con_end_date")
	private String conEndDate;

	@Column(name = "con_start_date")
	private String conStartDate;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "dist_channel")
	private String distChannel;

	@Column(name = "market_segment")
	private String marketSegment;

	private String quarter;

	@Column(name = "sap_contract_num")
	private String sapContractNum;

	@Column(name = "sold_to_party")
	private String soldToParty;

	@Column(name = "warrenty_period")
	private String warrentyPeriod;

	@Column(name = "is_submit")
	private String isSubmit = "N";

	@Column(name = "fin_remarks")
	private String finRemarks;

	@Column(name = "fin_remarks_by_id")
	private Integer finRemarksById;

	@Column(name = "finance_updated_time")
	private String financeUpdatedTime;

	@Column(name = "pm_id")
	private Integer pmId;

	@Column(name = "finance_id")
	private String financeId;

	@Column(name = "is_mail_sent")
	private String isMailSent;
	
	@Column(name = "pay_terms_code")
	private String payTermsCode;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "subsegment")
	private String subsegment;
	
	@Column(name = "po_number")
	private String poNumber;
	
	@Column(name = "po_date")
	private String poDate;
	
	@Column(name = "division")
	private String division;
	
	@Column(name = "sales_org")
	private String salesOrg;
	
	@Column(name = "created_by_id")
	private Integer createdbyId;
	
	@Column(name = "notice_period")
	private Integer noticePeriod;
	
	@Column(name = "child_contract_filename")
	private String childContractFilename;
	
	@Transient
	private String isDocUp;

	public String getChildContractFilename() {
		return childContractFilename;
	}

	public void setChildContractFilename(String childContractFilename) {
		this.childContractFilename = childContractFilename;
	}

	public String getIsDocUp() {
		return isDocUp;
	}

	public void setIsDocUp(String isDocUp) {
		this.isDocUp = isDocUp;
	}

	public Integer getCreatedbyId() {
		return createdbyId;
	}

	public void setCreatedbyId(Integer createdbyId) {
		this.createdbyId = createdbyId;
	}

	public String getSalesOrg() {
		return salesOrg;
	}

	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getPoDate() {
		return DateUtil.convertDateTimeToString(this.poDate);
		//return poDate;
	}

	public void setPoDate(String poDate) {
		this.poDate = poDate;
	}

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "child_contract_id", referencedColumnName = "child_contract_id", insertable = false, updatable = false)
	@OrderBy("item_no")
	private List<MaterialChildContract> materialChildContractList;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "sap_contract_num", referencedColumnName = "cont_doc_num", insertable = false, updatable = false)
	private ContRelStatusSapmst contRelStatusSapmst;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "contract_id", referencedColumnName = "contract_id", insertable = false, updatable = false)
	private Contract contract;
	
	@ManyToOne
	@JoinColumns({@JoinColumn(name = "sold_to_party", referencedColumnName = "customer_num", insertable = false, updatable = false),
			@JoinColumn(name = "dist_channel", referencedColumnName = "dist_channel", insertable = false, updatable = false),
			@JoinColumn(name = "division", referencedColumnName = "division", insertable = false, updatable = false),
			@JoinColumn(name = "sales_org", referencedColumnName = "sales_org", insertable = false, updatable = false)})
	private CustomerSapmst customerSapmst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "pay_terms_code", referencedColumnName = "pay_terms_code", insertable = false, updatable = false)
	private PayTermsMst payTermsMst;
	


	public ChildContract() {
	}
	
	
		
	public CustomerSapmst getCustomerSapmst() {
		return customerSapmst;
	}

	public void setCustomerSapmst(CustomerSapmst customerSapmst) {
		this.customerSapmst = customerSapmst;
	}

	public PayTermsMst getPayTermsMst() {
		return payTermsMst;
	}

	public void setPayTermsMst(PayTermsMst payTermsMst) {
		this.payTermsMst = payTermsMst;
	}

	public String getPayTermsCode() {
		return payTermsCode;
	}

	public void setPayTermsCode(String payTermsCode) {
		this.payTermsCode = payTermsCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSubsegment() {
		return subsegment;
	}

	public void setSubsegment(String subsegment) {
		this.subsegment = subsegment;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public ContRelStatusSapmst getContRelStatusSapmst() {
		return contRelStatusSapmst;
	}

	public void setContRelStatusSapmst(ContRelStatusSapmst contRelStatusSapmst) {
		this.contRelStatusSapmst = contRelStatusSapmst;
	}

	public String getFinanceUpdatedTime() {
		return financeUpdatedTime;
	}

	public void setFinanceUpdatedTime(String financeUpdatedTime) {
		this.financeUpdatedTime = financeUpdatedTime;
	}

	public Contract getContract() {
		return contract;
	}

	public void setContract(Contract contract) {
		this.contract = contract;
	}

	public Integer getFinRemarksById() {
		return finRemarksById;
	}

	public void setFinRemarksById(Integer finRemarksById) {
		this.finRemarksById = finRemarksById;
	}

	public String getFinRemarks() {
		return finRemarks;
	}

	public void setFinRemarks(String finRemarks) {
		this.finRemarks = finRemarks;
	}

	public String getIsSubmit() {
		return isSubmit;
	}

	public void setIsSubmit(String isSubmit) {
		this.isSubmit = isSubmit;
	}

	public Integer getChildContractId() {
		return childContractId;
	}

	public void setChildContractId(Integer childContractId) {
		this.childContractId = childContractId;
	}

	public Integer getContractId() {
		return contractId;
	}

	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}

	public String getAccMgrCode() {
		return this.accMgrCode;
	}

	public void setAccMgrCode(String accMgrCode) {
		this.accMgrCode = accMgrCode;
	}

	public String getConEndDate() {
//		return conEndDate;
		return DateUtil.convertDateTimeToString(this.conEndDate);
	}

	public void setConEndDate(String conEndDate) {
		this.conEndDate = conEndDate;
	}

	public String getConStartDate() {
//		return conStartDate;
		return DateUtil.convertDateTimeToString(this.conStartDate);
	}

	public void setConStartDate(String conStartDate) {
		this.conStartDate = conStartDate;
	}

	public String getCreatedDate() {
		return DateUtil.convertDateTimeToString(this.createdDate);
		// return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getDistChannel() {
		return this.distChannel;
	}

	public void setDistChannel(String distChannel) {
		this.distChannel = distChannel;
	}

	public String getMarketSegment() {
		return this.marketSegment;
	}

	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}

	public String getQuarter() {
		return this.quarter;
	}

	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}

	public String getSapContractNum() {
		return this.sapContractNum;
	}

	public void setSapContractNum(String sapContractNum) {
		this.sapContractNum = sapContractNum;
	}

	public String getSoldToParty() {
		return this.soldToParty;
	}

	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}

	public String getWarrentyPeriod() {
		return this.warrentyPeriod;
	}

	public void setWarrentyPeriod(String warrentyPeriod) {
		this.warrentyPeriod = warrentyPeriod;
	}

	public List<MaterialChildContract> getMaterialChildContractList() {
		return materialChildContractList;
	}

	public void setMaterialChildContractList(List<MaterialChildContract> materialChildContractList) {
		this.materialChildContractList = materialChildContractList;
	}

	public Integer getPmId() {
		return pmId;
	}

	public void setPmId(Integer pmId) {
		this.pmId = pmId;
	}

	public String getFinanceId() {
		return financeId;
	}

	public void setFinanceId(String financeId) {
		this.financeId = financeId;
	}

	public String getIsMailSent() {
		return isMailSent;
	}

	public void setIsMailSent(String isMailSent) {
		this.isMailSent = isMailSent;
	}

	public Integer getNoticePeriod() {
		return noticePeriod;
	}

	public void setNoticePeriod(Integer noticePeriod) {
		this.noticePeriod = noticePeriod;
	}
	
}