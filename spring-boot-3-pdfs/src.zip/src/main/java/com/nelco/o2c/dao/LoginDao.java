/**
 * 
 */
package com.nelco.o2c.dao;

import com.nelco.o2c.dto.LoginDTO;
import com.nelco.o2c.model.UserMst;

/**
 * @author Jayashankar.r
 *
 */
public interface LoginDao {
	
	public LoginDTO authenticateUser(LoginDTO loginDTO);
	
	public UserMst saveUser(UserMst userMst);
	
	public void logoutActionUpdate(LoginDTO loginDTO);
}
