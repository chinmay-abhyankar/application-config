package com.nelco.o2c.dto;

public class INCUploadDTO {
	private Integer userMstId;
	private Boolean isUploaded = false;
	private String status = "";
    private String message = "";
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public Boolean getIsUploaded() {
		return isUploaded;
	}
	public void setIsUploaded(Boolean isUploaded) {
		this.isUploaded = isUploaded;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
    
    
}
