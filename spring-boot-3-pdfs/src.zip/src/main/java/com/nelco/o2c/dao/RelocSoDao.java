/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.RelocSoDTO;
import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.RelocationSo;
import com.nelco.o2c.model.RelocationSoUserMap;
import com.nelco.o2c.model.RelocationTypeMst;
import com.nelco.o2c.model.SiteTypeMst;

/**
 * @author Jayshankar.r
 *
 */
public interface RelocSoDao {

	List<RelocationSo> getRolocationSoList(RelocSoDTO relocSoInputDTO);

	RelocationSo getRolocationSoById(RelocSoDTO relocSoInputDTO);

	List<RelocationTypeMst> getRelocTypeList();

	List<OppUploadDetail> getOppUploadByReloSoId(Integer relocationSoId);

	RelocationSo saveRelocationSo(RelocationSo relocationSo);

	RelocationSoUserMap saveRelocationSoUserMap(RelocationSoUserMap relocationSoUserMap);

	boolean checkAlreadyUserEnteredRelocationSoMap(Integer relocationSoId, Integer userMstId);

	RelocationTypeMst getRelocationTypeMstById(Integer relocationTypeMstId);

	List<SiteTypeMst> getSiteTypeList();

	SiteTypeMst getSiteTypeMst(Integer siteTypeMstId);

}
