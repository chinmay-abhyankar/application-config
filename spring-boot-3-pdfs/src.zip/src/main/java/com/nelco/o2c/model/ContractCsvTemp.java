package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the contract_csv_temp database table.
 * 
 */
@Entity
@Table(name = "contract_csv_temp")
@NamedQueries({ @NamedQuery(name = "ContractCsvTemp.findAll", query = "SELECT c FROM ContractCsvTemp c"),
	@NamedQuery(name = "ContractCsvTemp.findByChildContract", query = "SELECT c FROM ContractCsvTemp c where c.portalChildContractNo = ?1 "),
		@NamedQuery(name = "ContractCsvTemp.deleteAll", query = "delete from ContractCsvTemp c"),
		@NamedQuery(name = "ContractCsvTemp.deleteByChildContract", query = "delete from ContractCsvTemp c where c.portalChildContractNo = ?1 ")})
public class ContractCsvTemp implements Serializable {

	private String salesDocumentType;

	private String salesOrganization;

	private String distribution;

	private String division;

	private String salesOffice;

	private String poNumber;

	private String poDate;

	private String soldToParty;

	private String accManagerCode;

	private String contractStartDate;

	private String contractEndDate;

	@Id
	private String itemNo;

	@Id
	private String materialNo;

	private String quantity;

	private String plant;
	
	@Column(name = "condition_type")
	private String conditionType;

	private String rate;

	private String warrantyPeriod;

	private String orderNo;

	@Id
	private String portalMasterContractNo;

	@Id
	private String portalChildContractNo;

	@Id
	private String proposalId;
	
	
	
	private String segment;
	
	private String quater;
	
	private String incoterms;
	
	@Column(name = "terms_of_payment")
	private String termsOfPayment;
	
	@Column(name = "pricing_group_code")
	private String pricingGroupCode;
	
	private String description;
	
	@Column(name = "cust_po_num")
	private String custPoNum;
	
	private String subsegment;
	
	@Column(name = "notice_period")
	private String noticePeriod;

	public ContractCsvTemp() {

	}

	public ContractCsvTemp(String salesDocumentType, String salesOrganization, String distribution, String salesOffice,
			String poNumber, String poDate, String soldToParty, String accManagerCode, String contractStartDate,
			String contractEndDate, String itemNo, String materialNo, String quantity, String plant, String conditionType, String rate,
			String warrantyPeriod, String orderNo, String portalMasterContractNo, String portalChildContractNo,
			String proposalId, String division,String segment,String quater,String incoterms,
			String termsOfPayment,String pricingGroupCode,String description,String custPoNum,String subsegment,String noticePeriod) {
		super();
		this.salesDocumentType = salesDocumentType;
		this.salesOrganization = salesOrganization;
		this.distribution = distribution;
		this.division = division;
		this.salesOffice = salesOffice;
		this.poNumber = poNumber;
		this.poDate = poDate;
		this.soldToParty = soldToParty;
		this.accManagerCode = accManagerCode;
		this.contractStartDate = contractStartDate;
		this.contractEndDate = contractEndDate;
		this.itemNo = itemNo;
		this.materialNo = materialNo;
		this.quantity = quantity;
		this.plant = plant;
		this.conditionType = conditionType;
		this.rate = rate;
		this.warrantyPeriod = warrantyPeriod;
		this.orderNo = orderNo;
		this.portalMasterContractNo = portalMasterContractNo;
		this.portalChildContractNo = portalChildContractNo;
		this.proposalId = proposalId;
		this.segment = segment;
		this.quater = quater;
		this.incoterms = incoterms;
		this.termsOfPayment = termsOfPayment;
		this.pricingGroupCode = pricingGroupCode;
		this.description = description;
		this.custPoNum = custPoNum;
		this.subsegment = subsegment;
		this.noticePeriod = noticePeriod;
	}
	
	public String getTermsOfPayment() {
		return termsOfPayment;
	}

	public void setTermsOfPayment(String termsOfPayment) {
		this.termsOfPayment = termsOfPayment;
	}

	public String getPricingGroupCode() {
		return pricingGroupCode;
	}

	public void setPricingGroupCode(String pricingGroupCode) {
		this.pricingGroupCode = pricingGroupCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCustPoNum() {
		return custPoNum;
	}

	public void setCustPoNum(String custPoNum) {
		this.custPoNum = custPoNum;
	}

	public String getSubsegment() {
		return subsegment;
	}

	public void setSubsegment(String subsegment) {
		this.subsegment = subsegment;
	}
	
	public String getConditionType() {
		return conditionType;
	}

	public void setConditionType(String conditionType) {
		this.conditionType = conditionType;
	}

	public String getSegment() {
		return segment;
	}

	public void setSegment(String segment) {
		this.segment = segment;
	}

	public String getQuater() {
		return quater;
	}

	public void setQuater(String quater) {
		this.quater = quater;
	}

	public String getIncoterms() {
		return incoterms;
	}

	public void setIncoterms(String incoterms) {
		this.incoterms = incoterms;
	}

	public String getSalesDocumentType() {
		return salesDocumentType;
	}

	public void setSalesDocumentType(String salesDocumentType) {
		this.salesDocumentType = salesDocumentType;
	}

	public String getSalesOrganization() {
		return salesOrganization;
	}

	public void setSalesOrganization(String salesOrganization) {
		this.salesOrganization = salesOrganization;
	}

	public String getDistribution() {
		return distribution;
	}

	public void setDistribution(String distribution) {
		this.distribution = distribution;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getSalesOffice() {
		return salesOffice;
	}

	public void setSalesOffice(String salesOffice) {
		this.salesOffice = salesOffice;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getPoDate() {
		return poDate;
	}

	public void setPoDate(String poDate) {
		this.poDate = poDate;
	}

	public String getSoldToParty() {
		return soldToParty;
	}

	public void setSoldToParty(String soldToParty) {
		this.soldToParty = soldToParty;
	}

	public String getAccManagerCode() {
		return accManagerCode;
	}

	public void setAccManagerCode(String accManagerCode) {
		this.accManagerCode = accManagerCode;
	}

	public String getContractStartDate() {
		return contractStartDate;
	}

	public void setContractStartDate(String contractStartDate) {
		this.contractStartDate = contractStartDate;
	}

	public String getContractEndDate() {
		return contractEndDate;
	}

	public void setContractEndDate(String contractEndDate) {
		this.contractEndDate = contractEndDate;
	}

	public String getItemNo() {
		return itemNo;
	}

	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public String getMaterialNo() {
		return materialNo;
	}

	public void setMaterialNo(String materialNo) {
		this.materialNo = materialNo;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getWarrantyPeriod() {
		return warrantyPeriod;
	}

	public void setWarrantyPeriod(String warrantyPeriod) {
		this.warrantyPeriod = warrantyPeriod;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getPortalMasterContractNo() {
		return portalMasterContractNo;
	}

	public void setPortalMasterContractNo(String portalMasterContractNo) {
		this.portalMasterContractNo = portalMasterContractNo;
	}

	public String getPortalChildContractNo() {
		return portalChildContractNo;
	}

	public void setPortalChildContractNo(String portalChildContractNo) {
		this.portalChildContractNo = portalChildContractNo;
	}

	public String getProposalId() {
		return proposalId;
	}

	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}

	public String getNoticePeriod() {
		return noticePeriod;
	}

	public void setNoticePeriod(String noticePeriod) {
		this.noticePeriod = noticePeriod;
	}

	
}