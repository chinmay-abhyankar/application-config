package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the disconnection_request_details database table.
 * 
 */
@Entity
@Table(name="disconnection_request_details")
@NamedQueries({
	@NamedQuery(name="DisconnectionRequestDetail.findAll", query="SELECT d FROM DisconnectionRequestDetail d"),
//	@NamedQuery(name="DisconnectionRequestDetail.updateDisconnectionStatus", query="UPDATE DisconnectionRequestDetail d SET d."),
	
})
public class DisconnectionRequestDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private int typeid;

	@Column(length=2)
	private String actflag;

	@Column(name="action_date")
	private Timestamp actionDate;

	@Column(name="request_id", length=20)
	private String requestId;

	@Column(name="user_id", length=20)
	private String userId;

	public DisconnectionRequestDetail() {
	}

	public int getTypeid() {
		return this.typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public String getActflag() {
		return this.actflag;
	}

	public void setActflag(String actflag) {
		this.actflag = actflag;
	}

	public Timestamp getActionDate() {
		return this.actionDate;
	}

	public void setActionDate(Timestamp actionDate) {
		this.actionDate = actionDate;
	}

	public String getRequestId() {
		return this.requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}