package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the spares_so_delivery_pod_tracker database table.
 * 
 */
@Entity
@Table(name="spares_so_delivery_pod_tracker")
@NamedQuery(name="SparesSoDeliveryPodTracker.findAll", query="SELECT s FROM SparesSoDeliveryPodTracker s")
public class SparesSoDeliveryPodTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="spares_so_delivery_pod_tracker_id")
	private Integer sparesSoDeliveryPodTrackerId;

	@Column(name="pod_status_mst_id")
	private Integer podStatusMstId;

	@Column(name="req_by")
	private Integer reqBy;

	@Column(name="req_time")
	private String reqTime;

	@Column(name="spares_so_delivery_id")
	private Integer sparesSoDeliveryId;

	public SparesSoDeliveryPodTracker() {
	}

	public Integer getSparesSoDeliveryPodTrackerId() {
		return this.sparesSoDeliveryPodTrackerId;
	}

	public void setSparesSoDeliveryPodTrackerId(Integer sparesSoDeliveryPodTrackerId) {
		this.sparesSoDeliveryPodTrackerId = sparesSoDeliveryPodTrackerId;
	}

	public Integer getPodStatusMstId() {
		return this.podStatusMstId;
	}

	public void setPodStatusMstId(Integer podStatusMstId) {
		this.podStatusMstId = podStatusMstId;
	}

	public Integer getReqBy() {
		return this.reqBy;
	}

	public void setReqBy(Integer reqBy) {
		this.reqBy = reqBy;
	}

	public String getReqTime() {
		return this.reqTime;
	}

	public void setReqTime(String reqTime) {
		this.reqTime = reqTime;
	}

	public Integer getSparesSoDeliveryId() {
		return this.sparesSoDeliveryId;
	}

	public void setSparesSoDeliveryId(Integer sparesSoDeliveryId) {
		this.sparesSoDeliveryId = sparesSoDeliveryId;
	}

}