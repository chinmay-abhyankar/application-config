/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.model.OppUploadDetail;
import com.nelco.o2c.model.PreBidRespMatrix;
import com.nelco.o2c.model.PreBidTaskResponse;
import com.nelco.o2c.model.RespMatrixDetails;

/**
 * @author Amol.l
 *
 */

@Repository
public class PreBidRespMatrixDaoImpl implements PreBidRespMatrixDao {

	@PersistenceContext
	EntityManager em;

	Query query;

	@Override
	public PreBidRespMatrix savePreBidRespMatrixDetails(PreBidRespMatrix preBidRespMatrix) {
		PreBidRespMatrix preBidRespMatrixNew = em.merge(preBidRespMatrix);
		if(preBidRespMatrix.getPreBidRespMatrixId() == null) {
		em.refresh(preBidRespMatrixNew);
		}
		return preBidRespMatrixNew;
	}

	@Override
	public List<PreBidRespMatrix> getPreBidRespMatrixByUserMstIdAndOpId(Integer userMstId,Integer opportunityId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("PreBidRespMatrix.getPreBidRespMatrixByUserMstIdAndOpId");
			query.setParameter(1, userMstId);
			query.setParameter(2, opportunityId);
			@SuppressWarnings("unchecked")
			List<PreBidRespMatrix> preBidRespMatrixList = (List<PreBidRespMatrix>) query.getResultList();
			return preBidRespMatrixList;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<PreBidRespMatrix>();
		} finally {
			em.close();
		}
		
	}

	@Override
	public PreBidTaskResponse savePreBidResponse(PreBidTaskResponse preBidTaskResponse) {
		PreBidTaskResponse preBidTaskResponseNew = em.merge(preBidTaskResponse);
		if(preBidTaskResponse.getPreBidTaskResponseId()==null) {
		em.refresh(preBidTaskResponseNew);
		}
		return preBidTaskResponseNew;
	}

	@Override
	public List<PreBidRespMatrix> getPreBidResponsesByUserMstIdAndOpId(Integer userMstId, Integer opportunityId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("PreBidRespMatrix.getPreBidResponsesByRespPerIdAndOpId");
			query.setParameter(1, userMstId);
			query.setParameter(2, opportunityId);
			@SuppressWarnings("unchecked")
			List<PreBidRespMatrix> prePreBidRespMatrixList = (List<PreBidRespMatrix>) query.getResultList();
			return prePreBidRespMatrixList;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<PreBidRespMatrix>();
		} finally {
			em.close();
		}
	}

	@Override
	public List<PreBidRespMatrix> getFinalPBResponseByUserMstIdAndOpId(Integer userMstId, Integer opportunityId) {
		try {
			query = em.createNamedQuery("PreBidRespMatrix.getFinalPBResponseByUserMstIdAndOpId");
			query.setParameter(1, userMstId);
			query.setParameter(2, opportunityId);
			@SuppressWarnings("unchecked")
			List<PreBidRespMatrix> prePreBidRespMatrixList = (List<PreBidRespMatrix>) query.getResultList();
			return prePreBidRespMatrixList;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<PreBidRespMatrix>();
		} finally {
			em.close();
		}
	}

	@Override
	public PreBidRespMatrix getByPreBidRespMatrixId(Integer preBidRespMatrixId) {
		try {

			query = em.createNamedQuery("PreBidRespMatrix.getByPreBidRespMatrixId");
			query.setParameter(1, preBidRespMatrixId);
			PreBidRespMatrix preBidRespMatrix = (PreBidRespMatrix) query.getSingleResult();
			return preBidRespMatrix;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new PreBidRespMatrix();
		} finally {
			em.close();

		}
	}

	@Override
	public List<OppUploadDetail> getFileUpDetForPre(Integer opportunityId,Integer respMatrixDetailsId) {
		try {
			// TODO Auto-generated method stub
			query = em.createNamedQuery("OppUploadDetail.findByOppIdPre", OppUploadDetail.class);
			query.setParameter(1, opportunityId);
			query.setParameter(2, respMatrixDetailsId);
			List<OppUploadDetail> oppUploadDetailList = query.getResultList();
			return oppUploadDetailList != null ? oppUploadDetailList : new ArrayList<OppUploadDetail>();
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}
}
