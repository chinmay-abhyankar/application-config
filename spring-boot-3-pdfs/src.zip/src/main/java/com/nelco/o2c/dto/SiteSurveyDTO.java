package com.nelco.o2c.dto;

import java.util.List;

import com.nelco.o2c.model.CustomerSapmst;

public class SiteSurveyDTO {
	
	private Integer id;
	
	private Integer customer_id;
	
	private String customerName;
	
	private Integer state_id;
	
	private String uniq_id;	
	
	private String street_1;	
	
	private String street_2;	
	
	private String street_3;	
	
	private String street_4;	
	
	private String street_5;	
	
	private String city;	
	
	private String pin;	
	
	private Integer country_id;	
	
	private String site_person_contact_name;	
	
	private String contact_person_no;	
	
	private Integer technology_id;	
	
	private Integer hub_id;	
	
	private Integer antenna_size_id;	
	
	private String billable;	
	
	private String status;
	
	private String creation_date;
	
	private Integer user_id;	
	
	private Integer franchisee_id;		
	
	private String sub_customer;	
	
	private String alternative_mobile_no;	
	
	private String tentative_date;	
	
	private String tentative_timing;	
	
	private String remarks;	
	
	private String stateName ;
	
	private String countryName;
	
	private String hubName;
	
	private String technologyName;
	
	private String antennaSizeName;
	
	private String billableName;

	public String getSub_customer() {
		return sub_customer;
	}

	public void setSub_customer(String sub_customer) {
		this.sub_customer = sub_customer;
	}

	public String getAlternative_mobile_no() {
		return alternative_mobile_no;
	}

	public void setAlternative_mobile_no(String alternative_mobile_no) {
		this.alternative_mobile_no = alternative_mobile_no;
	}

	public String getTentative_date() {
		return tentative_date;
	}

	public void setTentative_date(String tentative_date) {
		this.tentative_date = tentative_date;
	}

	public String getTentative_timing() {
		return tentative_timing;
	}

	public void setTentative_timing(String tentative_timing) {
		this.tentative_timing = tentative_timing;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Integer getFranchisee_id() {
		return franchisee_id;
	}

	public void setFranchisee_id(Integer franchisee_id) {
		this.franchisee_id = franchisee_id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	private List<CustomerSapmst> custList;
	
	public List<CustomerSapmst> getCustList() {
		return custList;
	}

	public void setCustList(List<CustomerSapmst> custList) {
		this.custList = custList;
	}
	
	public Integer getState_id() {
		return state_id;
	}

	public void setState_id(Integer state_id) {
		this.state_id = state_id;
	}

	public String getUniq_id() {
		return uniq_id;
	}

	public void setUniq_id(String uniq_id) {
		this.uniq_id = uniq_id;
	}

	public String getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(String creation_date) {
		this.creation_date = creation_date;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(Integer customer_id) {
		this.customer_id = customer_id;
	}

	public String getStreet_1() {
		return street_1;
	}

	public void setStreet_1(String street_1) {
		this.street_1 = street_1;
	}

	public String getStreet_2() {
		return street_2;
	}

	public void setStreet_2(String street_2) {
		this.street_2 = street_2;
	}

	public String getStreet_3() {
		return street_3;
	}

	public void setStreet_3(String street_3) {
		this.street_3 = street_3;
	}

	public String getStreet_4() {
		return street_4;
	}

	public void setStreet_4(String street_4) {
		this.street_4 = street_4;
	}

	public String getStreet_5() {
		return street_5;
	}

	public void setStreet_5(String street_5) {
		this.street_5 = street_5;
	}

	

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public Integer getCountry_id() {
		return country_id;
	}

	public void setCountry_id(Integer country_id) {
		this.country_id = country_id;
	}

	public String getSite_person_contact_name() {
		return site_person_contact_name;
	}

	public void setSite_person_contact_name(String site_person_contact_name) {
		this.site_person_contact_name = site_person_contact_name;
	}

	public String getContact_person_no() {
		return contact_person_no;
	}

	public void setContact_person_no(String contact_person_no) {
		this.contact_person_no = contact_person_no;
	}

	public Integer getTechnology_id() {
		return technology_id;
	}

	public void setTechnology_id(Integer technology_id) {
		this.technology_id = technology_id;
	}

	public Integer getHub_id() {
		return hub_id;
	}

	public void setHub_id(Integer hub_id) {
		this.hub_id = hub_id;
	}

	public Integer getAntenna_size_id() {
		return antenna_size_id;
	}

	public void setAntenna_size_id(Integer antenna_size_id) {
		this.antenna_size_id = antenna_size_id;
	}

	public String getBillable() {
		return billable;
	}

	public void setBillable(String billable) {
		this.billable = billable;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getHubName() {
		return hubName;
	}

	public void setHubName(String hubName) {
		this.hubName = hubName;
	}

	public String getTechnologyName() {
		return technologyName;
	}

	public void setTechnologyName(String technologyName) {
		this.technologyName = technologyName;
	}

	public String getAntennaSizeName() {
		return antennaSizeName;
	}

	public void setAntennaSizeName(String antennaSizeName) {
		this.antennaSizeName = antennaSizeName;
	}

	public String getBillableName() {
		return billableName;
	}

	public void setBillableName(String billableName) {
		this.billableName = billableName;
	}
	
}
