package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.PlantSapmst;

public class PlantSapmstDTO  implements Serializable  {

	private static final long serialVersionUID = 104L;
	
	private List<PlantSapmst> plantList = new ArrayList<PlantSapmst>();

	public List<PlantSapmst> getPlantList() {
		return plantList;
	}

	public void setPlantList(List<PlantSapmst> plantList) {
		this.plantList = plantList;
	}
	
}
