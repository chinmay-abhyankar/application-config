/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.model.Contract;
import com.nelco.o2c.model.MaterialContract;
import com.nelco.o2c.utility.Constants;
import com.nelco.o2c.utility.DateUtil;

/**
 * @author Amol.l
 *
 */
@Repository
public class ContractDaoImpl implements ContractDao {

	@PersistenceContext
	private EntityManager em;

	Query query;

	@Override
	public Contract getContractByProposalId(String proposalId) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("Contract.getContractByProposalId");
			query.setParameter(1, proposalId);
			Contract contract = (Contract) query.getSingleResult();
			return contract;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new Contract();
		} finally {
			em.close();
		}
	}

	@Override
	public Contract getContractByContractId(Integer contractId) {
		// TODO Auto-generated method stub
		try {

			query = em.createNamedQuery("Contract.getContractByContractId");
			query.setParameter(1, contractId);
			Contract contract = (Contract) query.getSingleResult();
			return contract;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new Contract();
		} finally {
			em.close();
		}
	}

	@Override
	public Contract saveContract(Contract contract) {
		// TODO Auto-generated method stub
		String validityDate = DateUtil.convertDateToSqlDate(contract.getValidityDate());
		contract.setValidityDate(validityDate);
		contract.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		Contract contractNew = em.merge(contract);

		if (contract.getContractId() == null) {
			em.refresh(contractNew);
		}

		return contractNew;
	}

	@Override
	public MaterialContract saveMaterialContract(MaterialContract materialContract) {
		// TODO Auto-generated method stub
		materialContract.setCreatedDate(DateUtil.getCurrentISTDateAsString(DateUtil.IST_DATE_FORMAT_IN_MS));
		MaterialContract materialContractNew = em.merge(materialContract);

		if (materialContract.getMaterialContractId() == null) {
			em.refresh(materialContractNew);
		}

		return materialContractNew;

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Contract> getMasterContractList(CommonDTO commonDTO) {
		try {
			// TODO Auto-generated method stub
			String fromDate = DateUtil.convertDateToSqlDate(commonDTO.getFromDate());
			String toDate = DateUtil.convertDateToSqlDate(commonDTO.getToDate());
			/*if (commonDTO.getRoleCode().equals(Constants.FINANCEROLECODE)) {*/
			if(commonDTO.getProposalId()!=null) {
				query = em.createNamedQuery("Contract.findByDateFilterAndProposalIdAll");
				query.setParameter(1, fromDate);
				query.setParameter(2, toDate + " 23:59:59");
				query.setParameter(3, commonDTO.getProposalId());
			} else {
				if(commonDTO.getRoleCode().equals(Constants.PROGRAMMGRCODE)) {
					query = em.createNativeQuery("select c.* from proposal p "
							+ " inner join contract c on p.proposal_id = c.proposal_id "
							+ " where c.created_date between ?1 and ?2 and p.pm_id = ?3 "
							+ " union select c.* from proposal p "
							+ " inner join contract c on p.proposal_id = c.proposal_id "
							+ " inner join child_contract cc on c.contract_id = cc.contract_id "
							+ " where c.created_date between ?1 and ?2 and cc.pm_id = ?3 ", Contract.class);
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
					query.setParameter(3, commonDTO.getUserMstId());
				} else {
					query = em.createNamedQuery("Contract.findByDateFilterAll");
					query.setParameter(1, fromDate);
					query.setParameter(2, toDate + " 23:59:59");
				}
				
			}
				
				
				
			/*}*/
			List<Contract> contracts = (List<Contract>) query.getResultList();
			/*String createdDate = "";
			for (Contract contract : contracts) {
				createdDate = DateUtil.getSimpleUIDateFromSqlDate(contract.getCreatedDate());
				contract.setCreatedDate(createdDate);
			}*/
			return contracts;
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		} finally {
			em.close();
		}
	}

}
