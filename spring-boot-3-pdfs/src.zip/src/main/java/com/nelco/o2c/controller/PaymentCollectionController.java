package com.nelco.o2c.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.InvoiceSubmissionFormDTO;
import com.nelco.o2c.dto.PaymentCollectionFormDTO;
import com.nelco.o2c.service.PaymentCollectionService;

@RestController
public class PaymentCollectionController {
@Autowired
PaymentCollectionService paymentCollectionService;

@RequestMapping(value = "/customerwisePaymentCollectionList.do", method = RequestMethod.GET)
public PaymentCollectionFormDTO customerwisePaymentCollectionList(PaymentCollectionFormDTO paymentCollectionFormDTO, HttpServletRequest request) {
	return paymentCollectionService.customerwisePaymentCollectionList(paymentCollectionFormDTO, request);
}

@RequestMapping(value = "/paymentCollectionBreakupList.do", method = RequestMethod.GET)
public PaymentCollectionFormDTO getPaymentCollectionBreakupList(PaymentCollectionFormDTO paymentCollectionFormDTO, HttpServletRequest request) {
	return paymentCollectionService.getPaymentCollectionBreakupList(paymentCollectionFormDTO, request);
}

@RequestMapping(value = "/submitCustomerwisePayment.do", method = RequestMethod.POST)
public PaymentCollectionFormDTO submitCustomerwisePayment(@RequestBody PaymentCollectionFormDTO paymentCollectionFormDTO, HttpServletRequest request) {
	return paymentCollectionService.submitPaymentDetails(paymentCollectionFormDTO,request);
}

@RequestMapping(value = "/submitInvoicewisePaymentBreakup.do", method = RequestMethod.POST)
public PaymentCollectionFormDTO submitInvoicewisePaymentBreakup(@RequestBody PaymentCollectionFormDTO paymentCollectionFormDTO, HttpServletRequest request) {
	return paymentCollectionService.submitInvoicewisePaymentBreakup(paymentCollectionFormDTO,request);
}
}
