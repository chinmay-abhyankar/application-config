package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;


/**
 * The persistent class for the hso_transaction_details database table.
 * 
 */
@Entity
@Table(name="hso_transaction_details")
@NamedQueries({
	@NamedQuery(name="HsoTransactionDetail.findAll", query="SELECT h FROM HsoTransactionDetail h"),
	@NamedQuery(name="HsoTransactionDetail.findAllByStatusAndHubUserIdGreaterThan", query="SELECT h FROM HsoTransactionDetail h "
			+ " inner join fetch h.hsoDetail hd "
			+ " inner join fetch hd.hubMst hm "
			+ " inner join fetch hm.userToHub uth "
			+ " inner join fetch h.hsoTransactionStatusMst stat "
			+ " where hd.verifiedDate between :fromDate and :toDate and hd.status='Approved' "
			+ "and  h.hsoTransactionStatusMstId= :hsoTransactionStatusMstId and uth.userMstId = :userMstId and h.hsoTransactionDetailsId > :hsoTransactionDetailsId order by h.hsoTransactionDetailsId asc "),
	@NamedQuery(name="HsoTransactionDetail.findAllByStatusAndHubUserIdLessThan", query="SELECT h FROM HsoTransactionDetail h "
			+ " inner join fetch h.hsoDetail hd "
			+ " inner join fetch hd.hubMst hm "
			+ " inner join fetch hm.userToHub uth "
			+ " inner join fetch h.hsoTransactionStatusMst stat "
			+ " where hd.verifiedDate between :fromDate and :toDate and hd.status='Approved' "
			+ "and  h.hsoTransactionStatusMstId= :hsoTransactionStatusMstId and uth.userMstId = :userMstId  and h.hsoTransactionDetailsId < :hsoTransactionDetailsId order by h.hsoTransactionDetailsId asc ")
})
public class HsoTransactionDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="hso_transaction_details_id")
	private Integer hsoTransactionDetailsId;

	@Column(name="act_del_date")
	private String actDelDate;

	@Column(name="amsl_mtrs")
	private String amslMtrs;

	@Column(name="antenna_ht")
	private String antennaHt;

	@Column(name="antenna_location_mst_id")
	private Integer antennaLocationMstId;

	@Column(name="building_ht")
	private String buildingHt;

	@Column(name="cn_test_cable")
	private String cnTestCable;

	private String earthing;

	@Column(name="ebno_test_cable")
	private String ebnoTestCable;

	@Column(name="end_date")
	private String endDate;

	@Column(name="exp_del_date")
	private String expDelDate;

	@Column(name="field_key")
	private String fieldKey;

	@Column(name="hso_details_id")
	private Integer hsoDetailsId;

	@Column(name="hso_transaction_status_mst_id")
	private Integer hsoTransactionStatusMstId;

	@Column(name="hub_tech_mst_id")
	private Integer hubTechMstId;

	@Column(name="item_no")
	private String itemNo;

	@Column(name="lan_cable")
	private String lanCable;

	private String lattitude;

	private String longitude;

	@Column(name="mast_ht")
	private String mastHt;

	@Column(name="nature_mst_id")
	private Integer natureMstId;

	private String noc;

	private String others;

	@Column(name="pc_with_lan")
	private String pcWithLan;

	@Column(name="ping_not_ok")
	private String pingNotOk;

	@Column(name="ping_ok")
	private String pingOk;

	private String region;

	@Column(name="road_permit_avail")
	private String roadPermitAvail;

	@Column(name="short_desc")
	private String shortDesc;

	@Column(name="site_cleared")
	private String siteCleared;

	@Column(name="start_date")
	private String startDate;

	@Column(name="status_change_date")
	private String statusChangeDate;

	@Column(name="ups_avail")
	private String upsAvail;

	@Column(name="ups_ok")
	private String upsOk;

	@Column(name="visit_date")
	private String visitDate;

	@Column(name="vsat_name")
	private String vsatName;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "hso_details_id", referencedColumnName = "hso_details_id", insertable = false, updatable = false)
	private HsoDetail hsoDetail;
	
	@Column(name = "file_name")
	private String fileName;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "hso_transaction_status_mst_id", referencedColumnName = "hso_transaction_status_mst_id", insertable = false, updatable = false)
	private HsoTransactionStatusMst hsoTransactionStatusMst;
	
	@Column(name = "circuit_id")
	private String circuitId;
	
	@Column(name = "project_type")
	private String projectType = "STANDARD";
	
	@Column(name = "modified_by")
	private Integer modifiedBy;
	
	@Column(name = "modified_date")
	private String modifiedDate;
	
	/*@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "hso_transaction_status_mst_id", referencedColumnName = "hso_transaction_status_mst_id", insertable = false, updatable = false)
	private HsoTransactionStatusMst hsoTransactionStatusMst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "hub_tech_mst_id", referencedColumnName = "hub_tech_mst_id", insertable = false, updatable = false)
	private HubTechMst hubTechMst;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "nature_mst_id", referencedColumnName = "nature_mst_id", insertable = false, updatable = false)
	private NatureMst natureMst;*/
	
	

	public String getCircuitId() {
		return circuitId;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public void setCircuitId(String circuitId) {
		this.circuitId = circuitId;
	}

	public String getProjectType() {
		return projectType;
	}

	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}

	public String getFileName() {
		return fileName;
	}

	public HsoTransactionStatusMst getHsoTransactionStatusMst() {
		return hsoTransactionStatusMst;
	}

	public void setHsoTransactionStatusMst(HsoTransactionStatusMst hsoTransactionStatusMst) {
		this.hsoTransactionStatusMst = hsoTransactionStatusMst;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public HsoDetail getHsoDetail() {
		return hsoDetail;
	}

	public void setHsoDetail(HsoDetail hsoDetail) {
		this.hsoDetail = hsoDetail;
	}

	public HsoTransactionDetail() {
	}

	

	public Integer getHsoTransactionDetailsId() {
		return hsoTransactionDetailsId;
	}

	public void setHsoTransactionDetailsId(Integer hsoTransactionDetailsId) {
		this.hsoTransactionDetailsId = hsoTransactionDetailsId;
	}

	public String getActDelDate() {
		return DateUtil.convertDateTimeToString(this.actDelDate);
		//return this.actDelDate;
	}

	public void setActDelDate(String actDelDate) {
		this.actDelDate = actDelDate;
	}

	public String getAmslMtrs() {
		return this.amslMtrs;
	}

	public void setAmslMtrs(String amslMtrs) {
		this.amslMtrs = amslMtrs;
	}

	public String getAntennaHt() {
		return this.antennaHt;
	}

	public void setAntennaHt(String antennaHt) {
		this.antennaHt = antennaHt;
	}

	public Integer getAntennaLocationMstId() {
		return this.antennaLocationMstId;
	}

	public void setAntennaLocationMstId(Integer antennaLocationMstId) {
		this.antennaLocationMstId = antennaLocationMstId;
	}

	public String getBuildingHt() {
		return this.buildingHt;
	}

	public void setBuildingHt(String buildingHt) {
		this.buildingHt = buildingHt;
	}

	public String getCnTestCable() {
		return this.cnTestCable;
	}

	public void setCnTestCable(String cnTestCable) {
		this.cnTestCable = cnTestCable;
	}

	public String getEarthing() {
		return this.earthing;
	}

	public void setEarthing(String earthing) {
		this.earthing = earthing;
	}

	public String getEbnoTestCable() {
		return this.ebnoTestCable;
	}

	public void setEbnoTestCable(String ebnoTestCable) {
		this.ebnoTestCable = ebnoTestCable;
	}

	public String getEndDate() {
		return DateUtil.convertDateTimeToString(this.endDate);
		//return this.endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getExpDelDate() {
		return DateUtil.convertDateTimeToString(this.expDelDate);
		//return this.expDelDate;
	}

	public void setExpDelDate(String expDelDate) {
		this.expDelDate = expDelDate;
	}

	public String getFieldKey() {
		return this.fieldKey;
	}

	public void setFieldKey(String fieldKey) {
		this.fieldKey = fieldKey;
	}

	public Integer getHsoDetailsId() {
		return this.hsoDetailsId;
	}

	public void setHsoDetailsId(Integer hsoDetailsId) {
		this.hsoDetailsId = hsoDetailsId;
	}

	public Integer getHsoTransactionStatusMstId() {
		return this.hsoTransactionStatusMstId;
	}

	public void setHsoTransactionStatusMstId(Integer hsoTransactionStatusMstId) {
		this.hsoTransactionStatusMstId = hsoTransactionStatusMstId;
	}

	public Integer getHubTechMstId() {
		return this.hubTechMstId;
	}

	public void setHubTechMstId(Integer hubTechMstId) {
		this.hubTechMstId = hubTechMstId;
	}

	public String getItemNo() {
		return this.itemNo;
	}

	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public String getLanCable() {
		return this.lanCable;
	}

	public void setLanCable(String lanCable) {
		this.lanCable = lanCable;
	}

	public String getLattitude() {
		return this.lattitude;
	}

	public void setLattitude(String lattitude) {
		this.lattitude = lattitude;
	}

	public String getLongitude() {
		return this.longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getMastHt() {
		return this.mastHt;
	}

	public void setMastHt(String mastHt) {
		this.mastHt = mastHt;
	}

	public Integer getNatureMstId() {
		return this.natureMstId;
	}

	public void setNatureMstId(Integer natureMstId) {
		this.natureMstId = natureMstId;
	}

	public String getNoc() {
		return this.noc;
	}

	public void setNoc(String noc) {
		this.noc = noc;
	}

	public String getOthers() {
		return this.others;
	}

	public void setOthers(String others) {
		this.others = others;
	}

	public String getPcWithLan() {
		return this.pcWithLan;
	}

	public void setPcWithLan(String pcWithLan) {
		this.pcWithLan = pcWithLan;
	}

	public String getPingNotOk() {
		return this.pingNotOk;
	}

	public void setPingNotOk(String pingNotOk) {
		this.pingNotOk = pingNotOk;
	}

	public String getPingOk() {
		return this.pingOk;
	}

	public void setPingOk(String pingOk) {
		this.pingOk = pingOk;
	}

	public String getRegion() {
		return this.region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRoadPermitAvail() {
		return this.roadPermitAvail;
	}

	public void setRoadPermitAvail(String roadPermitAvail) {
		this.roadPermitAvail = roadPermitAvail;
	}

	public String getShortDesc() {
		return this.shortDesc;
	}

	public void setShortDesc(String shortDesc) {
		this.shortDesc = shortDesc;
	}

	public String getSiteCleared() {
		return this.siteCleared;
	}

	public void setSiteCleared(String siteCleared) {
		this.siteCleared = siteCleared;
	}

	public String getStartDate() {
		return DateUtil.convertDateTimeToString(this.startDate);
		//return this.startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getStatusChangeDate() {
		return DateUtil.convertDateTimeToString(this.statusChangeDate);
		//return this.statusChangeDate;
	}

	public void setStatusChangeDate(String statusChangeDate) {
		this.statusChangeDate = statusChangeDate;
	}

	public String getUpsAvail() {
		return this.upsAvail;
	}

	public void setUpsAvail(String upsAvail) {
		this.upsAvail = upsAvail;
	}

	public String getUpsOk() {
		return this.upsOk;
	}

	public void setUpsOk(String upsOk) {
		this.upsOk = upsOk;
	}

	public String getVisitDate() {
		return DateUtil.convertDateTimeToString(this.visitDate);
		//return this.visitDate;
	}

	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}

	public String getVsatName() {
		return this.vsatName;
	}

	public void setVsatName(String vsatName) {
		this.vsatName = vsatName;
	}

}