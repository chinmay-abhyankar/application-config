/**
 * 
 */
package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.BwSizingDTO;
import com.nelco.o2c.model.BWSizingDetails;
import com.nelco.o2c.model.CityMst;
import com.nelco.o2c.model.CountryMst;
import com.nelco.o2c.model.CustomerMst;
import com.nelco.o2c.model.ErrorJobLog;
import com.nelco.o2c.model.LocationMst;
import com.nelco.o2c.model.StateMst;

/**
 * @author Jayashankar.r
 *
 */
@Repository
public class BwSizingDaoImpl implements BwSizingDao {

	@PersistenceContext
	EntityManager em;

	Query query;

	@SuppressWarnings("unchecked")
	@Override
	public List<CustomerMst> getCustomerDetails(String custSearchStr) {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("CustomerMst.searchCustomer");
		query.setMaxResults(10);
		query.setParameter(1, "%" + custSearchStr + "%");
		query.setParameter(2, "%" + custSearchStr + "%");
		List<CustomerMst> custList = (List<CustomerMst>) query.getResultList();
		return custList != null ? custList : new ArrayList<CustomerMst>();
	}

	@Override
	public BWSizingDetails getBwSizingbyDrf(Integer drfDetailsId) {
		// TODO Auto-generated method stub
		try {
			query = em.createNamedQuery("BWSizingDetails.findByDrfId");
			query.setParameter(1, drfDetailsId);
			BWSizingDetails bWSizingDetails = (BWSizingDetails) query.getSingleResult();
			return bWSizingDetails;
		} catch (NoResultException ex) {
			return new BWSizingDetails();
		} finally {
			em.close();
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<LocationMst> getLocations() {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("LocationMst.findAll");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		return (List<LocationMst>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CityMst> getCitys() {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("CityMst.findAll");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		return (List<CityMst>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StateMst> getStates() {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("StateMst.findAll");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		return (List<StateMst>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CountryMst> getCountrys() {
		// TODO Auto-generated method stub
		query = em.createNamedQuery("CountryMst.findAll");
		query.setHint("org.hibernate.cacheable", Boolean.TRUE);
		return (List<CountryMst>) query.getResultList();
	}

	@Override
	public BWSizingDetails saveBwSizingDetails(BWSizingDetails bWSizingDetails) {
		// TODO Auto-generated method stub
		return em.merge(bWSizingDetails);
	}

	@Override
	public BWSizingDetails getBwSizingById(Integer bwSizingDetailsId) {
		// TODO Auto-generated method stub
		return em.find(BWSizingDetails.class, bwSizingDetailsId);
	}

	@Override
	public void saveCustMaster(CustomerMst custMst) {
		// TODO Auto-generated method stub
		em.merge(custMst);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ErrorJobLog> getErrorLogs(BwSizingDTO input) {
		try {
			// TODO Auto-generated method stub
			String[] arr = input.getCurrDate().split("-");
			
			StringBuilder currDateStr = new StringBuilder(arr[2]);
			currDateStr.append(arr[1]);
			currDateStr.append(arr[0]);
			
			System.out.println(currDateStr.toString());
			
			query = em.createNamedQuery("ErrorJobLog.findByDate");
			query.setParameter("runDate", new Integer(currDateStr.toString()));
			List<ErrorJobLog> resultList = (List<ErrorJobLog>) query.getResultList();
			return resultList;
		} finally {
			// TODO: handle finally clause
			em.close();
		}
	}

}
