/**
 * 
 */
package com.nelco.o2c.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nelco.o2c.dto.CustomerMstDTO;
import com.nelco.o2c.model.CustomerSapmst;

/**
 * @author Amol.l
 *
 */
@Repository
public class CustomerMstDaoImpl implements CustomerMstDao {

	@PersistenceContext
	private EntityManager em;

	Query query;
	
	@Override
	public CustomerSapmst getCustomerdetailsByCustomerNum(CustomerMstDTO customerMstDTO) {
		// TODO Auto-generated method stub
		try {

			/*query = em.createNamedQuery("CustomerSapmst.getCustomerdetailsByCustomerNum");
			query.setParameter(1, customerMstDTO.getCustomerSapmstId());*/
			CustomerSapmst customerSapmst = em.find(CustomerSapmst.class, customerMstDTO.getCustomerSapmstId());
			return customerSapmst;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new CustomerSapmst();
		} finally {
			em.close();
		}
	}

	@Override
	public String getCustomerName(String soldToParty) {
		 query = em.createNativeQuery("select top 1 customer_name from customer_sapmst where customer_num = ?1");
		 query.setParameter(1,soldToParty);
		 
		
		 String custName = (String) query.getSingleResult();
		
	
		return custName!=null?custName:"";
	}

}
