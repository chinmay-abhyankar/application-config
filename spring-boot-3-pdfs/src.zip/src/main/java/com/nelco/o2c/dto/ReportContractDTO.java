package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.List;

public class ReportContractDTO implements Serializable {
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		
		private String childContractId;
		private String sapContractNumber;
		
		private List<ReportContractDTO> childContractList;
		
		public String getChildContractId() {
			return childContractId;
		}
		public void setChildContractId(String childContractId) {
			this.childContractId = childContractId;
		}
		public String getSapContractNumber() {
			return sapContractNumber;
		}
		public void setSapContractNumber(String sapContractNumber) {
			this.sapContractNumber = sapContractNumber;
		}
		public List<ReportContractDTO> getChildContractList() {
			return childContractList;
		}
		public void setChildContractList(List<ReportContractDTO> childContractList) {
			this.childContractList = childContractList;
		}
		
		
}
