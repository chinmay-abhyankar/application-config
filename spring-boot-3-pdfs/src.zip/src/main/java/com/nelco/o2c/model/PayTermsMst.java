package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the pay_terms_mst database table.
 * 
 */
@Entity
@Table(name="pay_terms_mst")
@NamedQueries({
	@NamedQuery(name = "PayTermsMst.searchPaymentTerms", query = "select p from PayTermsMst p where p.payTermsCode like ?1 or p.payTermsVal like ?2 "),
	@NamedQuery(name="PayTermsMst.findAll", query="SELECT p FROM PayTermsMst p")
})
public class PayTermsMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pay_terms_mst_id")
	private Integer payTermsMstId;

	@Column(name="pay_terms_code")
	private String payTermsCode;

	@Column(name="pay_terms_val")
	private String payTermsVal;

	public Integer getPayTermsMstId() {
		return payTermsMstId;
	}

	public void setPayTermsMstId(Integer payTermsMstId) {
		this.payTermsMstId = payTermsMstId;
	}

	public String getPayTermsCode() {
		return payTermsCode;
	}

	public void setPayTermsCode(String payTermsCode) {
		this.payTermsCode = payTermsCode;
	}

	public String getPayTermsVal() {
		return payTermsVal;
	}

	public void setPayTermsVal(String payTermsVal) {
		this.payTermsVal = payTermsVal;
	}

	

}