package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the price_mst database table.
 * 
 */
@Entity
@Table(name="price_mst")
@NamedQuery(name="PriceMst.findAll", query="SELECT p FROM PriceMst p")
public class PriceMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="price_mst_id")
	private Integer priceMstId;

	@Column(name="activity_type_mst_id")
	private Integer activityTypeMstId;

	private BigDecimal cost;

	@Column(name="franchise_proc_type_mst")
	private Integer franchiseProcTypeMst;

	@Column(name="is_active")
	private String isActive;

	@Column(name="km_app_flag")
	private String kmAppFlag;

	@Column(name="km_appl_mst_id")
	private Integer kmApplMstId;

	public PriceMst() {
	}

	public Integer getPriceMstId() {
		return this.priceMstId;
	}

	public void setPriceMstId(Integer priceMstId) {
		this.priceMstId = priceMstId;
	}

	public Integer getActivityTypeMstId() {
		return this.activityTypeMstId;
	}

	public void setActivityTypeMstId(Integer activityTypeMstId) {
		this.activityTypeMstId = activityTypeMstId;
	}

	public BigDecimal getCost() {
		return this.cost;
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public Integer getFranchiseProcTypeMst() {
		return this.franchiseProcTypeMst;
	}

	public void setFranchiseProcTypeMst(Integer franchiseProcTypeMst) {
		this.franchiseProcTypeMst = franchiseProcTypeMst;
	}

	public String getIsActive() {
		return this.isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getKmAppFlag() {
		return this.kmAppFlag;
	}

	public void setKmAppFlag(String kmAppFlag) {
		this.kmAppFlag = kmAppFlag;
	}

	public Integer getKmApplMstId() {
		return this.kmApplMstId;
	}

	public void setKmApplMstId(Integer kmApplMstId) {
		this.kmApplMstId = kmApplMstId;
	}

}