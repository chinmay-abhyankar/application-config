package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the new_opp_details database table.
 * 
 */
@Entity
@Table(name="new_opp_details")
@NamedQuery(name="NewOppDetails.findAll", query="SELECT n FROM NewOppDetails n")
public class NewOppDetails implements Serializable {
	private static final long serialVersionUID = 108L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="new_opp_details_id")
	private Integer newOppDetailsId;

	@Column(name="account_id")
	private String accountId;

	@Column(name="account_name")
	private String accountName;

	@Column(name="amc_ms")
	private String amcMs;

	private String approved;

	@Column(name="appv_approve")
	private String appvApprove;

	@Column(name="appv_delegate")
	private String appvDelegate;

	@Column(name="appv_reject")
	private String appvReject;

	@Column(name="appv_resubmit")
	private String appvResubmit;

	@Column(name="bandwidth_short_term_rs_in_lac")
	private String bandwidthShortTermRsInLac;

	@Column(name="bid_submission_date")
	private String bidSubmissionDate;

	@Column(name="business_line")
	private String businessLine;

	@Column(name="bw_ms")
	private String bwMs;

	@Column(name="closing_date")
	private String closingDate;

	@Column(name="contact_name")
	private String contactName;
	
	@Column(name="contact_name_id")
	private String contactNameId;

	@Column(name="contract_duration_in_years")
	private String contractDurationInYears;

	@Column(name="created_by_id")
	private String createdById;

	@Column(name="created_by_name")
	private String createdByName;

	@Column(name="created_date")
	private String createdDate;

	@Column(name="created_time")
	private String createdTime;

	@Column(name="currency_symbol")
	private String currencySymbol;

	@Column(name="current_status")
	private String currentStatus;

	@Column(name="date_of_opportunity_creation")
	private String dateOfOpportunityCreation;

	@Column(name="deal_name")
	private String dealName;

	@Column(name="dropped_remarks")
	private String droppedRemarks;

	private String editable;

	@Column(name="equip_ms")
	private String equipMs;

	private String followed;

	private String followers;

	@Column(name="funnel_segment")
	private String funnelSegment;

	@Column(name="funnel_status")
	private String funnelStatus;

	@Column(name="go_to_market_channel")
	private String goToMarketChannel;

	@Column(name="last_activity_time")
	private String lastActivityTime;

	@Column(name="lead_conversion_time")
	private String leadConversionTime;

	@Column(name="market_segment")
	private String marketSegment;

	@Column(name="market_share_expected")
	private String marketShareExpected;

	@Column(name="modified_by_id")
	private String modifiedById;

	@Column(name="modified_by_name")
	private String modifiedByName;

	@Column(name="modified_date")
	private String modifiedDate;

	@Column(name="modified_time")
	private String modifiedTime;

	@Column(name="nature_of_opportunity_opex_capex")
	private String natureOfOpportunityOpexCapex;

	@Column(name="nelco_rental_rs_in_lac")
	private String nelcoRentalRsInLac;

	@Column(name="number_3")
	private String number3;

	@Column(name="opportunity_size_no_of_sites")
	private String opportunitySizeNoOfSites;

	@Column(name="opportunity_size_value_nelco_annuity_rs_in_lac1")
	private String opportunitySizeValueNelcoAnnuityRsInLac1;

	@Column(name="opportunity_size_value_one_time_rs_in_lac")
	private String opportunitySizeValueOneTimeRsInLac;

	@Column(name="opportunity_size_value_tnsl_annuity_rs_in_lac")
	private String opportunitySizeValueTnslAnnuityRsInLac;

	private String orchestration;

	@Column(name="our_addressability_with_present_services")
	private String ourAddressabilityWithPresentServices;

	@Column(name="overall_sales_duration")
	private String overallSalesDuration;

	@Column(name="owner_id")
	private String ownerId;

	@Column(name="owner_name")
	private String ownerName;

	@Column(name="potential_ageing")
	private String potentialAgeing;

	@Column(name="pre_sales_resource")
	private String preSalesResource;

	@Column(name="probability_of_getting_decided_cust_end")
	private String probabilityOfGettingDecidedCustEnd;

	@Column(name="probability_to_win")
	private String probabilityToWin;

	@Column(name="process_flow")
	private String processFlow;

	private String region;

	@Column(name="remarks_comments_any_other_details")
	private String remarksCommentsAnyOtherDetails;

	@Column(name="rental_ms")
	private String rentalMs;

	private String review;

	@Column(name="review_process")
	private String reviewProcess;

	@Column(name="sales_cycle_duration")
	private String salesCycleDuration;

	@Column(name="sap_contract_no")
	private String sapContractNo;

	@Column(name="segment_1")
	private String segment1;

	@Column(name="short_term_bw_ms")
	private String shortTermBwMs;

	@Column(name="sites_ms1")
	private String sitesMs1;

	@Column(name="solution_description")
	private String solutionDescription;

	private String stage;

	private String state;

	@Column(name="zoho_id")
	private String zohoId;

	public NewOppDetails() {
	}

	public Integer getNewOppDetailsId() {
		return newOppDetailsId;
	}

	public void setNewOppDetailsId(Integer newOppDetailsId) {
		this.newOppDetailsId = newOppDetailsId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAmcMs() {
		return amcMs;
	}

	public void setAmcMs(String amcMs) {
		this.amcMs = amcMs;
	}

	public String getApproved() {
		return approved;
	}

	public void setApproved(String approved) {
		this.approved = approved;
	}

	public String getAppvApprove() {
		return appvApprove;
	}

	public void setAppvApprove(String appvApprove) {
		this.appvApprove = appvApprove;
	}

	public String getAppvDelegate() {
		return appvDelegate;
	}

	public void setAppvDelegate(String appvDelegate) {
		this.appvDelegate = appvDelegate;
	}

	public String getAppvReject() {
		return appvReject;
	}

	public void setAppvReject(String appvReject) {
		this.appvReject = appvReject;
	}

	public String getAppvResubmit() {
		return appvResubmit;
	}

	public void setAppvResubmit(String appvResubmit) {
		this.appvResubmit = appvResubmit;
	}

	public String getBandwidthShortTermRsInLac() {
		return bandwidthShortTermRsInLac;
	}

	public void setBandwidthShortTermRsInLac(String bandwidthShortTermRsInLac) {
		this.bandwidthShortTermRsInLac = bandwidthShortTermRsInLac;
	}

	public String getBidSubmissionDate() {
		return bidSubmissionDate;
	}

	public void setBidSubmissionDate(String bidSubmissionDate) {
		this.bidSubmissionDate = bidSubmissionDate;
	}

	public String getBusinessLine() {
		return businessLine;
	}

	public void setBusinessLine(String businessLine) {
		this.businessLine = businessLine;
	}

	public String getBwMs() {
		return bwMs;
	}

	public void setBwMs(String bwMs) {
		this.bwMs = bwMs;
	}

	public String getClosingDate() {
		return closingDate;
	}

	public void setClosingDate(String closingDate) {
		this.closingDate = closingDate;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactNameId() {
		return contactNameId;
	}

	public void setContactNameId(String contactNameId) {
		this.contactNameId = contactNameId;
	}

	public String getContractDurationInYears() {
		return contractDurationInYears;
	}

	public void setContractDurationInYears(String contractDurationInYears) {
		this.contractDurationInYears = contractDurationInYears;
	}

	public String getCreatedById() {
		return createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public String getCreatedByName() {
		return createdByName;
	}

	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}

	public String getCurrencySymbol() {
		return currencySymbol;
	}

	public void setCurrencySymbol(String currencySymbol) {
		this.currencySymbol = currencySymbol;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public String getDateOfOpportunityCreation() {
		return dateOfOpportunityCreation;
	}

	public void setDateOfOpportunityCreation(String dateOfOpportunityCreation) {
		this.dateOfOpportunityCreation = dateOfOpportunityCreation;
	}

	public String getDealName() {
		return dealName;
	}

	public void setDealName(String dealName) {
		this.dealName = dealName;
	}

	public String getDroppedRemarks() {
		return droppedRemarks;
	}

	public void setDroppedRemarks(String droppedRemarks) {
		this.droppedRemarks = droppedRemarks;
	}

	public String getEditable() {
		return editable;
	}

	public void setEditable(String editable) {
		this.editable = editable;
	}

	public String getEquipMs() {
		return equipMs;
	}

	public void setEquipMs(String equipMs) {
		this.equipMs = equipMs;
	}

	public String getFollowed() {
		return followed;
	}

	public void setFollowed(String followed) {
		this.followed = followed;
	}

	public String getFollowers() {
		return followers;
	}

	public void setFollowers(String followers) {
		this.followers = followers;
	}

	public String getFunnelSegment() {
		return funnelSegment;
	}

	public void setFunnelSegment(String funnelSegment) {
		this.funnelSegment = funnelSegment;
	}

	public String getFunnelStatus() {
		return funnelStatus;
	}

	public void setFunnelStatus(String funnelStatus) {
		this.funnelStatus = funnelStatus;
	}

	public String getGoToMarketChannel() {
		return goToMarketChannel;
	}

	public void setGoToMarketChannel(String goToMarketChannel) {
		this.goToMarketChannel = goToMarketChannel;
	}

	public String getLastActivityTime() {
		return lastActivityTime;
	}

	public void setLastActivityTime(String lastActivityTime) {
		this.lastActivityTime = lastActivityTime;
	}

	public String getLeadConversionTime() {
		return leadConversionTime;
	}

	public void setLeadConversionTime(String leadConversionTime) {
		this.leadConversionTime = leadConversionTime;
	}

	public String getMarketSegment() {
		return marketSegment;
	}

	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}

	public String getMarketShareExpected() {
		return marketShareExpected;
	}

	public void setMarketShareExpected(String marketShareExpected) {
		this.marketShareExpected = marketShareExpected;
	}

	public String getModifiedById() {
		return modifiedById;
	}

	public void setModifiedById(String modifiedById) {
		this.modifiedById = modifiedById;
	}

	public String getModifiedByName() {
		return modifiedByName;
	}

	public void setModifiedByName(String modifiedByName) {
		this.modifiedByName = modifiedByName;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(String modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	public String getNatureOfOpportunityOpexCapex() {
		return natureOfOpportunityOpexCapex;
	}

	public void setNatureOfOpportunityOpexCapex(String natureOfOpportunityOpexCapex) {
		this.natureOfOpportunityOpexCapex = natureOfOpportunityOpexCapex;
	}

	public String getNelcoRentalRsInLac() {
		return nelcoRentalRsInLac;
	}

	public void setNelcoRentalRsInLac(String nelcoRentalRsInLac) {
		this.nelcoRentalRsInLac = nelcoRentalRsInLac;
	}

	public String getNumber3() {
		return number3;
	}

	public void setNumber3(String number3) {
		this.number3 = number3;
	}

	public String getOpportunitySizeNoOfSites() {
		return opportunitySizeNoOfSites;
	}

	public void setOpportunitySizeNoOfSites(String opportunitySizeNoOfSites) {
		this.opportunitySizeNoOfSites = opportunitySizeNoOfSites;
	}

	public String getOpportunitySizeValueNelcoAnnuityRsInLac1() {
		return opportunitySizeValueNelcoAnnuityRsInLac1;
	}

	public void setOpportunitySizeValueNelcoAnnuityRsInLac1(String opportunitySizeValueNelcoAnnuityRsInLac1) {
		this.opportunitySizeValueNelcoAnnuityRsInLac1 = opportunitySizeValueNelcoAnnuityRsInLac1;
	}

	public String getOpportunitySizeValueOneTimeRsInLac() {
		return opportunitySizeValueOneTimeRsInLac;
	}

	public void setOpportunitySizeValueOneTimeRsInLac(String opportunitySizeValueOneTimeRsInLac) {
		this.opportunitySizeValueOneTimeRsInLac = opportunitySizeValueOneTimeRsInLac;
	}

	public String getOpportunitySizeValueTnslAnnuityRsInLac() {
		return opportunitySizeValueTnslAnnuityRsInLac;
	}

	public void setOpportunitySizeValueTnslAnnuityRsInLac(String opportunitySizeValueTnslAnnuityRsInLac) {
		this.opportunitySizeValueTnslAnnuityRsInLac = opportunitySizeValueTnslAnnuityRsInLac;
	}

	public String getOrchestration() {
		return orchestration;
	}

	public void setOrchestration(String orchestration) {
		this.orchestration = orchestration;
	}

	public String getOurAddressabilityWithPresentServices() {
		return ourAddressabilityWithPresentServices;
	}

	public void setOurAddressabilityWithPresentServices(String ourAddressabilityWithPresentServices) {
		this.ourAddressabilityWithPresentServices = ourAddressabilityWithPresentServices;
	}

	public String getOverallSalesDuration() {
		return overallSalesDuration;
	}

	public void setOverallSalesDuration(String overallSalesDuration) {
		this.overallSalesDuration = overallSalesDuration;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getPotentialAgeing() {
		return potentialAgeing;
	}

	public void setPotentialAgeing(String potentialAgeing) {
		this.potentialAgeing = potentialAgeing;
	}

	public String getPreSalesResource() {
		return preSalesResource;
	}

	public void setPreSalesResource(String preSalesResource) {
		this.preSalesResource = preSalesResource;
	}

	public String getProbabilityOfGettingDecidedCustEnd() {
		return probabilityOfGettingDecidedCustEnd;
	}

	public void setProbabilityOfGettingDecidedCustEnd(String probabilityOfGettingDecidedCustEnd) {
		this.probabilityOfGettingDecidedCustEnd = probabilityOfGettingDecidedCustEnd;
	}

	public String getProbabilityToWin() {
		return probabilityToWin;
	}

	public void setProbabilityToWin(String probabilityToWin) {
		this.probabilityToWin = probabilityToWin;
	}

	public String getProcessFlow() {
		return processFlow;
	}

	public void setProcessFlow(String processFlow) {
		this.processFlow = processFlow;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRemarksCommentsAnyOtherDetails() {
		return remarksCommentsAnyOtherDetails;
	}

	public void setRemarksCommentsAnyOtherDetails(String remarksCommentsAnyOtherDetails) {
		this.remarksCommentsAnyOtherDetails = remarksCommentsAnyOtherDetails;
	}

	public String getRentalMs() {
		return rentalMs;
	}

	public void setRentalMs(String rentalMs) {
		this.rentalMs = rentalMs;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public String getReviewProcess() {
		return reviewProcess;
	}

	public void setReviewProcess(String reviewProcess) {
		this.reviewProcess = reviewProcess;
	}

	public String getSalesCycleDuration() {
		return salesCycleDuration;
	}

	public void setSalesCycleDuration(String salesCycleDuration) {
		this.salesCycleDuration = salesCycleDuration;
	}

	public String getSapContractNo() {
		return sapContractNo;
	}

	public void setSapContractNo(String sapContractNo) {
		this.sapContractNo = sapContractNo;
	}

	public String getSegment1() {
		return segment1;
	}

	public void setSegment1(String segment1) {
		this.segment1 = segment1;
	}

	public String getShortTermBwMs() {
		return shortTermBwMs;
	}

	public void setShortTermBwMs(String shortTermBwMs) {
		this.shortTermBwMs = shortTermBwMs;
	}

	public String getSitesMs1() {
		return sitesMs1;
	}

	public void setSitesMs1(String sitesMs1) {
		this.sitesMs1 = sitesMs1;
	}

	public String getSolutionDescription() {
		return solutionDescription;
	}

	public void setSolutionDescription(String solutionDescription) {
		this.solutionDescription = solutionDescription;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZohoId() {
		return zohoId;
	}

	public void setZohoId(String zohoId) {
		this.zohoId = zohoId;
	}

	@Override
	public String toString() {
		return "NewOppDetails [newOppDetailsId=" + newOppDetailsId + ", accountId=" + accountId + ", accountName="
				+ accountName + ", amcMs=" + amcMs + ", approved=" + approved + ", appvApprove=" + appvApprove
				+ ", appvDelegate=" + appvDelegate + ", appvReject=" + appvReject + ", appvResubmit=" + appvResubmit
				+ ", bandwidthShortTermRsInLac=" + bandwidthShortTermRsInLac + ", bidSubmissionDate="
				+ bidSubmissionDate + ", businessLine=" + businessLine + ", bwMs=" + bwMs + ", closingDate="
				+ closingDate + ", contactName=" + contactName + ", contactNameId=" + contactNameId
				+ ", contractDurationInYears=" + contractDurationInYears + ", createdById=" + createdById
				+ ", createdByName=" + createdByName + ", createdDate=" + createdDate + ", createdTime=" + createdTime
				+ ", currencySymbol=" + currencySymbol + ", currentStatus=" + currentStatus
				+ ", dateOfOpportunityCreation=" + dateOfOpportunityCreation + ", dealName=" + dealName
				+ ", droppedRemarks=" + droppedRemarks + ", editable=" + editable + ", equipMs=" + equipMs
				+ ", followed=" + followed + ", followers=" + followers + ", funnelSegment=" + funnelSegment
				+ ", funnelStatus=" + funnelStatus + ", goToMarketChannel=" + goToMarketChannel + ", lastActivityTime="
				+ lastActivityTime + ", leadConversionTime=" + leadConversionTime + ", marketSegment=" + marketSegment
				+ ", marketShareExpected=" + marketShareExpected + ", modifiedById=" + modifiedById
				+ ", modifiedByName=" + modifiedByName + ", modifiedDate=" + modifiedDate + ", modifiedTime="
				+ modifiedTime + ", natureOfOpportunityOpexCapex=" + natureOfOpportunityOpexCapex
				+ ", nelcoRentalRsInLac=" + nelcoRentalRsInLac + ", number3=" + number3 + ", opportunitySizeNoOfSites="
				+ opportunitySizeNoOfSites + ", opportunitySizeValueNelcoAnnuityRsInLac1="
				+ opportunitySizeValueNelcoAnnuityRsInLac1 + ", opportunitySizeValueOneTimeRsInLac="
				+ opportunitySizeValueOneTimeRsInLac + ", opportunitySizeValueTnslAnnuityRsInLac="
				+ opportunitySizeValueTnslAnnuityRsInLac + ", orchestration=" + orchestration
				+ ", ourAddressabilityWithPresentServices=" + ourAddressabilityWithPresentServices
				+ ", overallSalesDuration=" + overallSalesDuration + ", ownerId=" + ownerId + ", ownerName=" + ownerName
				+ ", potentialAgeing=" + potentialAgeing + ", preSalesResource=" + preSalesResource
				+ ", probabilityOfGettingDecidedCustEnd=" + probabilityOfGettingDecidedCustEnd + ", probabilityToWin="
				+ probabilityToWin + ", processFlow=" + processFlow + ", region=" + region
				+ ", remarksCommentsAnyOtherDetails=" + remarksCommentsAnyOtherDetails + ", rentalMs=" + rentalMs
				+ ", review=" + review + ", reviewProcess=" + reviewProcess + ", salesCycleDuration="
				+ salesCycleDuration + ", sapContractNo=" + sapContractNo + ", segment1=" + segment1
				+ ", shortTermBwMs=" + shortTermBwMs + ", sitesMs1=" + sitesMs1 + ", solutionDescription="
				+ solutionDescription + ", stage=" + stage + ", state=" + state + ", zohoId=" + zohoId + "]";
	}
	
}