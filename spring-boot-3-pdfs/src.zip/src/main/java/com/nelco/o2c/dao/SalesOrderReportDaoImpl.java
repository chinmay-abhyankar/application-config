package com.nelco.o2c.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

@Repository
public class SalesOrderReportDaoImpl implements SalesOrderReportDao {
	
	@PersistenceContext
	private EntityManager em;
	Query query;
	
	@Override
	public List<String> getAllSoTypes() {
		try {
			query = em.createNativeQuery("select distinct so.cont_sales_doc_type+' - '+cd.cont_desc as sotype from so_orders so\r\n" + 
					"inner join  contract_doc_type_sapmst cd \r\n" + 
					"on so.cont_sales_doc_type = cd.cont_sales_doc_type");
			List<String> soTypes = query.getResultList();
			
	
			return soTypes!=null?soTypes:new ArrayList<String>();
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
