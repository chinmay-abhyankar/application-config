package com.nelco.o2c.dto;

import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.ReactivationRequestMst;

public class ReactivationFormDTO {
private List<ReactivationListDTO> reactivationRequestList=new ArrayList<ReactivationListDTO>();
private List<ReactivationRequestMst> appRejList=new ArrayList<ReactivationRequestMst>();
private List<ReactivationRequestMst> reactivationRequestDetails=new ArrayList<ReactivationRequestMst>();
private ReqctivationRequestDetailsDTO reactivationRequestInfo;

private DisconnectionFormDTO disconnectionFormDTO;


public ReqctivationRequestDetailsDTO getReactivationRequestInfo() {
	return reactivationRequestInfo;
}

public void setReactivationRequestInfo(ReqctivationRequestDetailsDTO reactivationRequestInfo) {
	this.reactivationRequestInfo = reactivationRequestInfo;
}

public DisconnectionFormDTO getDisconnectionFormDTO() {
	return disconnectionFormDTO;
}

public void setDisconnectionFormDTO(DisconnectionFormDTO disconnectionFormDTO) {
	this.disconnectionFormDTO = disconnectionFormDTO;
}

public List<ReactivationRequestMst> getReactivationRequestDetails() {
	return reactivationRequestDetails;
}

public void setReactivationRequestDetails(List<ReactivationRequestMst> reactivationRequestDetails) {
	this.reactivationRequestDetails = reactivationRequestDetails;
}

public List<ReactivationRequestMst> getAppRejList() {
	return appRejList;
}

public void setAppRejList(List<ReactivationRequestMst> appRejList) {
	this.appRejList = appRejList;
}

public List<ReactivationListDTO> getReactivationRequestList() {
	return reactivationRequestList;
}

public void setReactivationRequestList(List<ReactivationListDTO> reactivationRequestList) {
	this.reactivationRequestList = reactivationRequestList;
}

}
