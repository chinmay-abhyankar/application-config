package com.nelco.o2c.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the delivery_status_sapmst database table.
 * 
 */
@Entity
@Table(name="delivery_status_sapmst")
@NamedQuery(name="DeliveryStatusSapmst.findAll", query="SELECT d FROM DeliveryStatusSapmst d")
public class DeliveryStatusSapmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="delivery_status_sapmst_id")
	private int deliveryStatusSapmstId;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="delivery_num")
	private String deliveryNum;

	@Column(name="obj_num")
	private String objNum;

	@Column(name="status_desc")
	private String statusDesc;

	@Column(name="status_num")
	private String statusNum;

	@Column(name="wbs_element")
	private String wbsElement;

	public DeliveryStatusSapmst() {
	}

	public int getDeliveryStatusSapmstId() {
		return this.deliveryStatusSapmstId;
	}

	public void setDeliveryStatusSapmstId(int deliveryStatusSapmstId) {
		this.deliveryStatusSapmstId = deliveryStatusSapmstId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDeliveryNum() {
		return this.deliveryNum;
	}

	public void setDeliveryNum(String deliveryNum) {
		this.deliveryNum = deliveryNum;
	}

	public String getObjNum() {
		return this.objNum;
	}

	public void setObjNum(String objNum) {
		this.objNum = objNum;
	}

	public String getStatusDesc() {
		return this.statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getStatusNum() {
		return this.statusNum;
	}

	public void setStatusNum(String statusNum) {
		this.statusNum = statusNum;
	}

	public String getWbsElement() {
		return this.wbsElement;
	}

	public void setWbsElement(String wbsElement) {
		this.wbsElement = wbsElement;
	}

}