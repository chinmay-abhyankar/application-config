/**
 * 
 */
package com.nelco.o2c.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nelco.o2c.model.GeoTemplate;

/**
 * @author Amol.l
 *
 */
public class BrfDetailsListDTO implements Serializable {
	private static final long serialVersionUID = 88L;

	private Integer geoTemplateId;
	private GeoTemplate geoTemplate = new GeoTemplate();
	private Integer contractId;
	private String fromDate;
	private String toDate;
	private List<BrfDetailsDTO> brfDetailsDTOList = new ArrayList<BrfDetailsDTO>();
	private Integer userMstId;
	private String roleCode;
	private String finRemarks;
	private Integer childContractId;
	private Boolean isSaved = false;
	private Integer brfId;
	private String contractNum;
	private String pendingList;
	private String drfDetailsId;
	private String soNumber;
	
	public String getContractNum() {
		return contractNum;
	}
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}
	public Integer getGeoTemplateId() {
		return geoTemplateId;
	}
	public void setGeoTemplateId(Integer geoTemplateId) {
		this.geoTemplateId = geoTemplateId;
	}
	public GeoTemplate getGeoTemplate() {
		return geoTemplate;
	}
	public void setGeoTemplate(GeoTemplate geoTemplate) {
		this.geoTemplate = geoTemplate;
	}
	public Integer getContractId() {
		return contractId;
	}
	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public List<BrfDetailsDTO> getBrfDetailsDTOList() {
		return brfDetailsDTOList;
	}
	public void setBrfDetailsDTOList(List<BrfDetailsDTO> brfDetailsDTOList) {
		this.brfDetailsDTOList = brfDetailsDTOList;
	}
	public Integer getUserMstId() {
		return userMstId;
	}
	public void setUserMstId(Integer userMstId) {
		this.userMstId = userMstId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getFinRemarks() {
		return finRemarks;
	}
	public void setFinRemarks(String finRemarks) {
		this.finRemarks = finRemarks;
	}
	public Integer getChildContractId() {
		return childContractId;
	}
	public void setChildContractId(Integer childContractId) {
		this.childContractId = childContractId;
	}
	public Boolean getIsSaved() {
		return isSaved;
	}
	public void setIsSaved(Boolean isSaved) {
		this.isSaved = isSaved;
	}
	public Integer getBrfId() {
		return brfId;
	}
	public void setBrfId(Integer brfId) {
		this.brfId = brfId;
	}
	public String getPendingList() {
		return pendingList;
	}
	public void setPendingList(String pendingList) {
		this.pendingList = pendingList;
	}
	public String getDrfDetailsId() {
		return drfDetailsId;
	}
	public void setDrfDetailsId(String drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}
	public String getSoNumber() {
		return soNumber;
	}
	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}
		
}
