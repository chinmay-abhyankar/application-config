/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.nelco.o2c.utility.DateUtil;

/**
 * @author Amol.l
 *
 */
@Entity
@Table(name = "drf_demo_date")
@NamedQueries({
	@NamedQuery(name = "DrfDemoDate.getDrfInfoByDrfId", query = "select ddd from DrfDemoDate ddd where ddd.drfDemoDateId =?1")})
public class DrfDemoDate implements Serializable {

	private static final long serialVersionUID = 107L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "drf_demo_date_id")
	private Integer drfDemoDateId;
	
	@Column(name = "drf_details_id")
	private Integer drfDetailsId;
	
	@Column(name = "demo_start_date")
	private String demoStartDate;

	@Column(name = "demo_end_date")
	private String demoEndDate;

	@Column(name = "created_date", updatable= false)
	private String createdDate;

	public Integer getDrfDemoDateId() {
		return drfDemoDateId;
	}

	public void setDrfDemoDateId(Integer drfDemoDateId) {
		this.drfDemoDateId = drfDemoDateId;
	}

	public Integer getDrfDetailsId() {
		return drfDetailsId;
	}

	public void setDrfDetailsId(Integer drfDetailsId) {
		this.drfDetailsId = drfDetailsId;
	}

	public String getDemoStartDate() {
		return DateUtil.convertDateTimeToString(this.demoStartDate);
	}

	public void setDemoStartDate(String demoStartDate) {
		this.demoStartDate = demoStartDate;
	}

	public String getDemoEndDate() {
		return DateUtil.convertDateTimeToString(this.demoEndDate);
	}

	public void setDemoEndDate(String demoEndDate) {
		this.demoEndDate = demoEndDate;
	}

	public String getCreatedDate() {
		return DateUtil.convertDateTimeToString(this.createdDate);
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	
}
