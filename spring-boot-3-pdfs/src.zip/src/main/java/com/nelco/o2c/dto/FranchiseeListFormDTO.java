package com.nelco.o2c.dto;

public class FranchiseeListFormDTO {
	private String delivery_id;
	private String month;
	private String dispatch_date;
	private String delivery_num;
	private String challan_num;
	private String tax_invoice;
	private String so_number;
	private String value;
	private String docket_num;
	private String courier_name;
	private String eddate;
	private String addate;
	private String pod_status_code;
	private String pod_status_mst_id;
	private String pod_status_name;
	private String del_status_code;
	private String del_status_name;
	private String delivery_status_mst_id;
	private String material_num;
	private String material_desc;
	private String material_sapmst_id;
	private String ship_to_party;
	private String ship_to_party_id;
	private String customer_name;
	private String street1;
	private String street2;
	private String street3;
	private String street4;
	private String street5;
	private String pin;
	private String city_name;
	private String state_val;
	private String country;
	private String f_id;
	private String f_uniq_id;
	private String f_delivery_id;
	private String f_delivery_num;
	private String f_installation_address;
	private String f_site_contact_person;
	private String f_contact_person_number;
	private String f_vsat_id;
	private String f_vsat_ip;
	private String f_so_number;
	private String f_site_survey_done;
	private String f_site_survey_uniq_id;
	private String activity_type;
	private String f_status;
	private String f_creation_date;
	private String eng_id;
	private String eng_name;
	private String eng_mobile_no;
	private String eng_email_id;
	private String eng_creation_date;
	private String receive_name;
	private String receive_contact;
	private String status_code;
	private String status_name;	
	private String franchisee_id;
	private String franchisee_name;
	private String siteSurveyId;
	private Integer installationTypeMstId;
	private String csAcceptFlag;
	private String item;
	private String soCreationDate;
	private String contactNumber;
	private String tentativeDate;
	private Integer hubMstId;
	private String additionalRemarks;
	private Integer technologyMstId;
	private String installationTypeVal;
	private Integer installationStatusMstId;
	private String installationStatusCode;
	private String installationStatusVal;
	private String oldShtpAddress;
	private String subCustomer;
	
	
	
	
	
	
	
	public String getSubCustomer() {
		return subCustomer;
	}

	public void setSubCustomer(String subCustomer) {
		this.subCustomer = subCustomer;
	}

	public String getOldShtpAddress() {
		return oldShtpAddress;
	}

	public void setOldShtpAddress(String oldShtpAddress) {
		this.oldShtpAddress = oldShtpAddress;
	}

	public Integer getInstallationStatusMstId() {
		return installationStatusMstId;
	}

	public void setInstallationStatusMstId(Integer installationStatusMstId) {
		this.installationStatusMstId = installationStatusMstId;
	}

	public String getInstallationStatusCode() {
		return installationStatusCode;
	}

	public void setInstallationStatusCode(String installationStatusCode) {
		this.installationStatusCode = installationStatusCode;
	}

	public String getInstallationStatusVal() {
		return installationStatusVal;
	}

	public void setInstallationStatusVal(String installationStatusVal) {
		this.installationStatusVal = installationStatusVal;
	}

	public String getInstallationTypeVal() {
		return installationTypeVal;
	}

	public void setInstallationTypeVal(String installationTypeVal) {
		this.installationTypeVal = installationTypeVal;
	}

	public String getTentativeDate() {
		return tentativeDate;
	}

	public void setTentativeDate(String tentativeDate) {
		this.tentativeDate = tentativeDate;
	}

	public Integer getHubMstId() {
		return hubMstId;
	}

	public void setHubMstId(Integer hubMstId) {
		this.hubMstId = hubMstId;
	}

	public String getAdditionalRemarks() {
		return additionalRemarks;
	}

	public void setAdditionalRemarks(String additionalRemarks) {
		this.additionalRemarks = additionalRemarks;
	}

	public Integer getTechnologyMstId() {
		return technologyMstId;
	}

	public void setTechnologyMstId(Integer technologyMstId) {
		this.technologyMstId = technologyMstId;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getSoCreationDate() {
		return soCreationDate;
	}

	public void setSoCreationDate(String soCreationDate) {
		this.soCreationDate = soCreationDate;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getCsAcceptFlag() {
		return csAcceptFlag;
	}

	public void setCsAcceptFlag(String csAcceptFlag) {
		this.csAcceptFlag = csAcceptFlag;
	}

	public Integer getInstallationTypeMstId() {
		return installationTypeMstId;
	}

	public void setInstallationTypeMstId(Integer installationTypeMstId) {
		this.installationTypeMstId = installationTypeMstId;
	}

	public String getSiteSurveyId() {
		return siteSurveyId;
	}

	public void setSiteSurveyId(String siteSurveyId) {
		this.siteSurveyId = siteSurveyId;
	}

	public String getFranchisee_id() {
		return franchisee_id;
	}

	public void setFranchisee_id(String franchisee_id) {
		this.franchisee_id = franchisee_id;
	}

	public String getFranchisee_name() {
		return franchisee_name;
	}

	public void setFranchisee_name(String franchisee_name) {
		this.franchisee_name = franchisee_name;
	}

	public String getReceive_name() {
		return receive_name;
	}

	public void setReceive_name(String receive_name) {
		this.receive_name = receive_name;
	}

	public String getReceive_contact() {
		return receive_contact;
	}

	public void setReceive_contact(String receive_contact) {
		this.receive_contact = receive_contact;
	}

	public String getStatus_code() {
		return status_code;
	}

	public void setStatus_code(String status_code) {
		this.status_code = status_code;
	}

	public String getStatus_name() {
		return status_name;
	}

	public void setStatus_name(String status_name) {
		this.status_name = status_name;
	}

	public String getEng_id() {
		return eng_id;
	}

	public void setEng_id(String eng_id) {
		this.eng_id = eng_id;
	}

	public String getEng_name() {
		return eng_name;
	}

	public void setEng_name(String eng_name) {
		this.eng_name = eng_name;
	}

	public String getEng_mobile_no() {
		return eng_mobile_no;
	}

	public void setEng_mobile_no(String eng_mobile_no) {
		this.eng_mobile_no = eng_mobile_no;
	}

	public String getEng_email_id() {
		return eng_email_id;
	}

	public void setEng_email_id(String eng_email_id) {
		this.eng_email_id = eng_email_id;
	}

	public String getEng_creation_date() {
		return eng_creation_date;
	}

	public void setEng_creation_date(String eng_creation_date) {
		this.eng_creation_date = eng_creation_date;
	}

	public String getDelivery_id() {
		return delivery_id;
	}

	public void setDelivery_id(String delivery_id) {
		this.delivery_id = delivery_id;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getDispatch_date() {
		return dispatch_date;
	}

	public void setDispatch_date(String dispatch_date) {
		this.dispatch_date = dispatch_date;
	}

	public String getDelivery_num() {
		return delivery_num;
	}

	public void setDelivery_num(String delivery_num) {
		this.delivery_num = delivery_num;
	}

	public String getChallan_num() {
		return challan_num;
	}

	public void setChallan_num(String challan_num) {
		this.challan_num = challan_num;
	}

	public String getTax_invoice() {
		return tax_invoice;
	}

	public void setTax_invoice(String tax_invoice) {
		this.tax_invoice = tax_invoice;
	}

	public String getSo_number() {
		return so_number;
	}

	public void setSo_number(String so_number) {
		this.so_number = so_number;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDocket_num() {
		return docket_num;
	}

	public void setDocket_num(String docket_num) {
		this.docket_num = docket_num;
	}

	public String getCourier_name() {
		return courier_name;
	}

	public void setCourier_name(String courier_name) {
		this.courier_name = courier_name;
	}

	public String getEddate() {
		return eddate;
	}

	public void setEddate(String eddate) {
		this.eddate = eddate;
	}

	public String getAddate() {
		return addate;
	}

	public void setAddate(String addate) {
		this.addate = addate;
	}

	public String getPod_status_code() {
		return pod_status_code;
	}

	public void setPod_status_code(String pod_status_code) {
		this.pod_status_code = pod_status_code;
	}

	public String getPod_status_mst_id() {
		return pod_status_mst_id;
	}

	public void setPod_status_mst_id(String pod_status_mst_id) {
		this.pod_status_mst_id = pod_status_mst_id;
	}

	public String getPod_status_name() {
		return pod_status_name;
	}

	public void setPod_status_name(String pod_status_name) {
		this.pod_status_name = pod_status_name;
	}

	public String getDel_status_code() {
		return del_status_code;
	}

	public void setDel_status_code(String del_status_code) {
		this.del_status_code = del_status_code;
	}

	public String getDel_status_name() {
		return del_status_name;
	}

	public void setDel_status_name(String del_status_name) {
		this.del_status_name = del_status_name;
	}

	public String getDelivery_status_mst_id() {
		return delivery_status_mst_id;
	}

	public void setDelivery_status_mst_id(String delivery_status_mst_id) {
		this.delivery_status_mst_id = delivery_status_mst_id;
	}

	public String getMaterial_num() {
		return material_num;
	}

	public void setMaterial_num(String material_num) {
		this.material_num = material_num;
	}

	public String getMaterial_desc() {
		return material_desc;
	}

	public void setMaterial_desc(String material_desc) {
		this.material_desc = material_desc;
	}

	public String getMaterial_sapmst_id() {
		return material_sapmst_id;
	}

	public void setMaterial_sapmst_id(String material_sapmst_id) {
		this.material_sapmst_id = material_sapmst_id;
	}

	public String getShip_to_party() {
		return ship_to_party;
	}

	public void setShip_to_party(String ship_to_party) {
		this.ship_to_party = ship_to_party;
	}

	public String getShip_to_party_id() {
		return ship_to_party_id;
	}

	public void setShip_to_party_id(String ship_to_party_id) {
		this.ship_to_party_id = ship_to_party_id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getStreet1() {
		return street1;
	}

	public void setStreet1(String street1) {
		this.street1 = street1;
	}

	public String getStreet2() {
		return street2;
	}

	public void setStreet2(String street2) {
		this.street2 = street2;
	}

	public String getStreet3() {
		return street3;
	}

	public void setStreet3(String street3) {
		this.street3 = street3;
	}

	public String getStreet4() {
		return street4;
	}

	public void setStreet4(String street4) {
		this.street4 = street4;
	}

	public String getStreet5() {
		return street5;
	}

	public void setStreet5(String street5) {
		this.street5 = street5;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getCity_name() {
		return city_name;
	}

	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}

	public String getState_val() {
		return state_val;
	}

	public void setState_val(String state_val) {
		this.state_val = state_val;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getF_id() {
		return f_id;
	}

	public void setF_id(String f_id) {
		this.f_id = f_id;
	}

	public String getF_uniq_id() {
		return f_uniq_id;
	}

	public void setF_uniq_id(String f_uniq_id) {
		this.f_uniq_id = f_uniq_id;
	}

	public String getF_delivery_id() {
		return f_delivery_id;
	}

	public void setF_delivery_id(String f_delivery_id) {
		this.f_delivery_id = f_delivery_id;
	}

	public String getF_delivery_num() {
		return f_delivery_num;
	}

	public void setF_delivery_num(String f_delivery_num) {
		this.f_delivery_num = f_delivery_num;
	}

	public String getF_installation_address() {
		return f_installation_address;
	}

	public void setF_installation_address(String f_installation_address) {
		this.f_installation_address = f_installation_address;
	}

	public String getF_site_contact_person() {
		return f_site_contact_person;
	}

	public void setF_site_contact_person(String f_site_contact_person) {
		this.f_site_contact_person = f_site_contact_person;
	}

	public String getF_contact_person_number() {
		return f_contact_person_number;
	}

	public void setF_contact_person_number(String f_contact_person_number) {
		this.f_contact_person_number = f_contact_person_number;
	}

	public String getF_vsat_id() {
		return f_vsat_id;
	}

	public void setF_vsat_id(String f_vsat_id) {
		this.f_vsat_id = f_vsat_id;
	}

	public String getF_vsat_ip() {
		return f_vsat_ip;
	}

	public void setF_vsat_ip(String f_vsat_ip) {
		this.f_vsat_ip = f_vsat_ip;
	}

	public String getF_so_number() {
		return f_so_number;
	}

	public void setF_so_number(String f_so_number) {
		this.f_so_number = f_so_number;
	}

	public String getF_site_survey_done() {
		return f_site_survey_done;
	}

	public void setF_site_survey_done(String f_site_survey_done) {
		this.f_site_survey_done = f_site_survey_done;
	}

	public String getF_site_survey_uniq_id() {
		return f_site_survey_uniq_id;
	}

	public void setF_site_survey_uniq_id(String f_site_survey_uniq_id) {
		this.f_site_survey_uniq_id = f_site_survey_uniq_id;
	}

	public String getActivity_type() {
		return activity_type;
	}

	public void setActivity_type(String activity_type) {
		this.activity_type = activity_type;
	}

	public String getF_status() {
		return f_status;
	}

	public void setF_status(String f_status) {
		this.f_status = f_status;
	}

	public String getF_creation_date() {
		return f_creation_date;
	}

	public void setF_creation_date(String f_creation_date) {
		this.f_creation_date = f_creation_date;
	}

}
