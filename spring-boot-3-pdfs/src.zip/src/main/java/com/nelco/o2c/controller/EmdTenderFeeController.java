/**
 * 
 */
package com.nelco.o2c.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nelco.o2c.dto.CommonDTO;
import com.nelco.o2c.dto.EmdTenderFeeDTO;
import com.nelco.o2c.service.EmdTenderFeeService;

/**
 * @author Jayashankar.r
 *
 */
@RestController
public class EmdTenderFeeController {

	@Autowired
	EmdTenderFeeService emdTenderFeeService;

	@RequestMapping(value = "/saveTafCeoStatus.do", method = RequestMethod.POST)
	public CommonDTO getOppDetails(@RequestBody CommonDTO commonDTO) {
		return emdTenderFeeService.saveTafCeoStatus(commonDTO);
	}

	@RequestMapping(value = "/getEmdTenderDropDowns.do", method = RequestMethod.POST)
	public EmdTenderFeeDTO getEmdTenderDropDowns(@RequestBody CommonDTO commonDTO) {
		return emdTenderFeeService.getEmdTenderDropDowns(commonDTO);
	}

	@RequestMapping(value = "/getEmdDetails.do", method = RequestMethod.POST)
	public EmdTenderFeeDTO getEmdDetails(@RequestBody CommonDTO commonDTO) {
		return emdTenderFeeService.getEmdDetails(commonDTO);
	}

	@RequestMapping(value = "/submitEmdDetails.do", method = RequestMethod.POST)
	public EmdTenderFeeDTO submitEmdDetails(@RequestBody EmdTenderFeeDTO emdTenderFeeInputDTO, HttpServletRequest request) throws IOException {
		return emdTenderFeeService.submitEmdDetailsCall(emdTenderFeeInputDTO, request);
	}
	
	@RequestMapping(value = "/getEmdTasks.do", method = RequestMethod.POST)
	public EmdTenderFeeDTO getEmdTasks(@RequestBody CommonDTO commonDTO) {
		return emdTenderFeeService.getEmdTasks(commonDTO);
	}
	
	@RequestMapping(value = "/getTenderFeeDetails.do", method = RequestMethod.POST)
	public EmdTenderFeeDTO getTenderFeeDetails(@RequestBody CommonDTO commonDTO) {
		return emdTenderFeeService.getTenderFeeDetails(commonDTO);
	}
	
	@RequestMapping(value = "/getBidSubmissionData.do", method = RequestMethod.POST)
	public EmdTenderFeeDTO getBidSubmissionData(@RequestBody CommonDTO commonDTO) {
		return emdTenderFeeService.getBidSubmissionData(commonDTO);
	}
	
	@RequestMapping(value = "/submitBidSubmissionData.do", method = RequestMethod.POST)
	public EmdTenderFeeDTO submitBidSubmissionData(@RequestBody EmdTenderFeeDTO emdTenderFeeInputDTO, HttpServletRequest request) {
		return emdTenderFeeService.submitBidSubmissionData(emdTenderFeeInputDTO, request);
	}
	
	@RequestMapping(value = "/submitTenderFeeDetails.do", method = RequestMethod.POST)
	public EmdTenderFeeDTO submitTenderFeeDetails(@RequestBody EmdTenderFeeDTO emdTenderFeeInputDTO, HttpServletRequest request) throws IOException {
		return emdTenderFeeService.submitTenderFeeDetailsCall(emdTenderFeeInputDTO, request);
	}
	
	@RequestMapping(value = "/getTenderFeeTasks.do", method = RequestMethod.POST)
	public EmdTenderFeeDTO getTenderFeeTasks(@RequestBody CommonDTO commonDTO) {
		return emdTenderFeeService.getTenderFeeTasks(commonDTO);
	}
	
}
