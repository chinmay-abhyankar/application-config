/**
 * 
 */
package com.nelco.o2c.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Amol.l
 *
 */
public class DrfTypeMstDTO implements Serializable  {

	private static final long serialVersionUID = 37L;
	
	private List<DrfTypeMst> drfTypeMstList = new ArrayList<DrfTypeMst>();

	public List<DrfTypeMst> getDrfTypeMstList() {
		return drfTypeMstList;
	}

	public void setDrfTypeMstList(List<DrfTypeMst> drfTypeMstList) {
		this.drfTypeMstList = drfTypeMstList;
	}
}
