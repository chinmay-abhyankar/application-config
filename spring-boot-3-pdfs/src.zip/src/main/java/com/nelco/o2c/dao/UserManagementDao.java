package com.nelco.o2c.dao;

import java.util.List;

import com.nelco.o2c.dto.UserDTO;
import com.nelco.o2c.dto.UserManagementDTO;
import com.nelco.o2c.model.UserMst;
import com.nelco.o2c.model.UserToFranchisee;

public interface UserManagementDao {
	public UserManagementDTO getAllDropDowns();
	
	public List<UserDTO> getUserDetails();
	
	public boolean addUserToHub(UserMst user,UserDTO userDTO);
	
	public boolean addUserToFranchiseMst(UserMst user,UserDTO userDTO);
	
	public boolean addUserToRegionMaster(UserMst user,String stateIds);
	
	public Integer getCountOfUser(UserMst user,UserDTO userDTO,String table, String column1, Integer value1,String column2, String value2);
	
	public Integer getFranchiseByUserMstId(UserMst user,UserDTO userDTO);
}
